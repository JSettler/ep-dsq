//! Mouse-driven desktop GUI for Dou Shou Qi supporting three isolated engines:
//! 1. EP-DSQ (Energy Points + board-only SuperKo)
//! 2. Classic SuperKo (Arimaa-style 3rd-occurrence ban with same side-to-move, no EP)
//! 3. Monster Rats (EP + SuperKo where Rats in water can strike directly onto land
//!    Elephants & land Rats, while remaining untouchable from land)
//!
//! Features:
//! - Self-contained vector artwork for Chinese (象狮虎豹狼狗猫鼠) and Animals (including Lion!)
//! - Compact `Pieces ▾` and `Mode ▾` toolbar menus + dedicated `⚔ IronMan` switch with confirmation
//! - `New Game` while in IronMan asks confirmation and returns to normal non-IronMan mode
//! - Mode-specific Rules Help window (`[F1]` to open, `[Esc]` to close)
//! - `[Esc]` closes open dialogs/help, or triggers Quit Confirmation when on the main screen
//! - Discrete Max Thinking Time slider (1s..180s + Unlimited; disabled in IronMan)
//! - IronMan new-record player-name prompt & encrypted Top-50 Hall of Fame (max 5 per depth)
//! - Auto-detecting `import <file> [start|end]`, Show Thinking, Stop, Setup Mode, Undo/Redo

use crate::classic::board::{ClassicHistory, ClassicPos};
use crate::classic::eval::PIECE_VALUE as CLASSIC_PIECE_VALUE;
use crate::classic::search::ClassicSearcher;
use crate::core::board_bb::{BitboardPos, History, CAPTURED, EMPTY_SQ};
use crate::core::{
    Color, GameResult, Move, PieceKind, Square, COLS, DEN_SQ, INITIAL_PIECES, INVASION_LAND_MASK,
    MAX_EP, ROWS, START_EP, TRAPS_MASK, WATER_MASK,
};
use crate::eval::{PIECE_VALUE as EP_PIECE_VALUE, SCORE_WIN};
use crate::hall_of_fame::{
    now_unix_secs, sanitize_player_name, EndCode, HallOfFame, HallOfFameEntry,
    MAX_ENTRIES_PER_DEPTH, MAX_PLAYER_NAME_LEN, MAX_TOTAL_ENTRIES,
};
use crate::piece_art::{draw_animal_icon, draw_chinese_char};
use crate::rats::board::{RatsHistory, RatsPos};
use crate::rats::eval::PIECE_VALUE as RATS_PIECE_VALUE;
use crate::rats::search::RatsSearcher;
use crate::search::{SearchLimits, SearchProgress, SearchResult, Searcher};
use eframe::egui;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

pub const MIN_IRONMAN_DEPTH: usize = 12;
const MAX_GUI_DEPTH: usize = 60;
const AUTOSAVE_VERSION: &str = "DSQ_SAVE_V1";

const TIME_PRESETS_SECS: [Option<u64>; 24] = [
    Some(1),
    Some(2),
    Some(3),
    Some(4),
    Some(5),
    Some(6),
    Some(7),
    Some(8),
    Some(9),
    Some(10),
    Some(12),
    Some(15),
    Some(20),
    Some(25),
    Some(30),
    Some(35),
    Some(40),
    Some(45),
    Some(60),
    Some(90),
    Some(120),
    Some(150),
    Some(180),
    None,
];
const UNLIMITED_TIME_IDX: usize = TIME_PRESETS_SECS.len() - 1;

fn format_time_limit(secs: Option<u64>) -> String {
    match secs {
        Some(s) => format!("{}s", s),
        None => "Unlimited".to_owned(),
    }
}

fn time_idx_from_secs(secs: Option<u64>) -> usize {
    match secs {
        None => UNLIMITED_TIME_IDX,
        Some(target) => TIME_PRESETS_SECS
            .iter()
            .position(|&p| p == Some(target))
            .unwrap_or_else(|| {
                TIME_PRESETS_SECS[..UNLIMITED_TIME_IDX]
                    .iter()
                    .enumerate()
                    .min_by_key(|(_, &p)| p.unwrap_or(u64::MAX).abs_diff(target))
                    .map(|(i, _)| i)
                    .unwrap_or(UNLIMITED_TIME_IDX)
            }),
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GameVariant {
    EpSuperKo,
    ClassicSuperKo,
    MonsterRats,
}

impl GameVariant {
    pub const ALL: [GameVariant; 3] = [
        GameVariant::EpSuperKo,
        GameVariant::ClassicSuperKo,
        GameVariant::MonsterRats,
    ];

    pub const fn display_name(self) -> &'static str {
        match self {
            GameVariant::EpSuperKo => "EP + SuperKo",
            GameVariant::ClassicSuperKo => "Classic SuperKo",
            GameVariant::MonsterRats => "Monster Rats",
        }
    }

    pub const fn export_header(self) -> &'static str {
        match self {
            GameVariant::EpSuperKo => "# Mode: EP+SuperKo",
            GameVariant::ClassicSuperKo => "# Mode: Classic SuperKo",
            GameVariant::MonsterRats => "# Mode: Monster Rats",
        }
    }

    pub const fn uses_ep(self) -> bool {
        matches!(self, GameVariant::EpSuperKo | GameVariant::MonsterRats)
    }

    fn data_dir() -> Option<PathBuf> {
        if let Ok(xdg) = std::env::var("XDG_DATA_HOME") {
            if !xdg.is_empty() {
                return Some(PathBuf::from(xdg).join("dsq_engine"));
            }
        }
        if let Ok(home) = std::env::var("HOME") {
            if !home.is_empty() {
                return Some(
                    PathBuf::from(home)
                        .join(".local")
                        .join("share")
                        .join("dsq_engine"),
                );
            }
        }
        None
    }

    fn autosave_path(self) -> PathBuf {
        let fname = match self {
            GameVariant::EpSuperKo => "autosave.txt",
            GameVariant::ClassicSuperKo => "autosave_classic.txt",
            GameVariant::MonsterRats => "autosave_monster_rats.txt",
        };
        match Self::data_dir() {
            Some(dir) => dir.join(fname),
            None => PathBuf::from(format!("dsq_{}", fname)),
        }
    }

    fn hof_path(self) -> PathBuf {
        match self {
            GameVariant::EpSuperKo => HallOfFame::default_path(),
            GameVariant::ClassicSuperKo => match Self::data_dir() {
                Some(dir) => dir.join("ironman_hof_classic.dat"),
                None => PathBuf::from("ironman_hof_classic.dat"),
            },
            GameVariant::MonsterRats => match Self::data_dir() {
                Some(dir) => dir.join("ironman_hof_monster_rats.dat"),
                None => PathBuf::from("ironman_hof_monster_rats.dat"),
            },
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ImportPosition {
    Start,
    End,
}

#[derive(Clone, Debug)]
pub struct ImportRequest {
    pub filename: String,
    pub moves: Vec<Move>,
    pub open_at: ImportPosition,
}

#[derive(Clone, Debug)]
struct AutosaveSummary {
    moves: usize,
    plies: usize,
    depth: usize,
    time_limit: Option<u64>,
    is_custom: bool,
}

fn detect_header_variant(raw: &str) -> Option<GameVariant> {
    for line in raw.lines() {
        let trimmed = line.trim();
        let rest = if let Some(r) = trimmed.strip_prefix('#') {
            r.trim()
        } else if let Some(r) = trimmed.strip_prefix(';') {
            r.trim()
        } else {
            continue;
        };
        let lower = rest.to_ascii_lowercase();
        if let Some(val) = lower.strip_prefix("mode:") {
            let v = val.trim();
            if v.contains("monster") || v.contains("rat") {
                return Some(GameVariant::MonsterRats);
            }
            if v.contains("classic") {
                return Some(GameVariant::ClassicSuperKo);
            }
            if v.contains("ep") {
                return Some(GameVariant::EpSuperKo);
            }
        }
    }
    None
}

fn parse_movelist_tokens(raw: &str) -> Result<Vec<Move>, String> {
    let mut parsed = Vec::new();
    for (line_no, raw_line) in raw.lines().enumerate() {
        let line = raw_line
            .split('#')
            .next()
            .unwrap_or("")
            .split(';')
            .next()
            .unwrap_or("");
        for tok in line.split_whitespace() {
            if tok.ends_with('.') && tok[..tok.len() - 1].chars().all(|c| c.is_ascii_digit()) {
                continue;
            }
            let after_num = if let Some(dot_idx) = tok.find('.') {
                if tok[..dot_idx].chars().all(|c| c.is_ascii_digit()) && dot_idx > 0 {
                    &tok[dot_idx + 1..]
                } else {
                    tok
                }
            } else {
                tok
            };
            if after_num.is_empty() {
                continue;
            }
            let mv = parse_exported_move_token(after_num).ok_or_else(|| {
                format!(
                    "Line {}: could not parse move token '{}'",
                    line_no + 1,
                    tok
                )
            })?;
            parsed.push(mv);
        }
    }

    if parsed.is_empty() {
        return Err("Movelist file contains no moves.".to_owned());
    }
    Ok(parsed)
}

fn validate_moves_for_variant(variant: GameVariant, moves: &[Move]) -> Result<(), String> {
    let mut state = EngineState::new_start(variant);
    for (idx, &mv) in moves.iter().enumerate() {
        if state.game_result() != GameResult::Ongoing {
            return Err(format!(
                "Ply {} ({}): game has already ended before this move.",
                idx + 1,
                mv
            ));
        }
        let legal = state.gen_legal_moves();
        if !legal.contains(&mv) {
            return Err(format!(
                "Ply {} (move {}.{}): illegal move '{}' for {} in {} mode.",
                idx + 1,
                idx / 2 + 1,
                if idx % 2 == 0 { "P1" } else { "P2" },
                mv,
                state.side_to_move(),
                variant.display_name()
            ));
        }
        state.apply_move(mv);
    }
    Ok(())
}

pub fn parse_and_detect_movelist(raw: &str) -> Result<(GameVariant, Vec<Move>), String> {
    let moves = parse_movelist_tokens(raw)?;

    if let Some(header_variant) = detect_header_variant(raw) {
        validate_moves_for_variant(header_variant, &moves)?;
        return Ok((header_variant, moves));
    }

    let ep_res = validate_moves_for_variant(GameVariant::EpSuperKo, &moves);
    let cl_res = validate_moves_for_variant(GameVariant::ClassicSuperKo, &moves);
    let mr_res = validate_moves_for_variant(GameVariant::MonsterRats, &moves);

    match (ep_res, cl_res, mr_res) {
        (Ok(()), _, _) => Ok((GameVariant::EpSuperKo, moves)),
        (Err(_), Ok(()), _) => Ok((GameVariant::ClassicSuperKo, moves)),
        (Err(_), Err(_), Ok(())) => Ok((GameVariant::MonsterRats, moves)),
        (Err(e_ep), Err(e_cl), Err(e_mr)) => Err(format!(
            "Invalid movelist under all modes:\n  - EP+SuperKo: {}\n  - Classic SuperKo: {}\n  - Monster Rats: {}",
            e_ep, e_cl, e_mr
        )),
    }
}

fn parse_exported_move_token(tok: &str) -> Option<Move> {
    let after_prefix = match tok.split_once(':') {
        Some((_, rest)) => rest,
        None => tok,
    };
    let cleaned = after_prefix.trim_end_matches(|c: char| matches!(c, '*' | '+' | '!' | '?' | ','));
    let lower = cleaned.to_ascii_lowercase();
    let bytes = lower.as_bytes();

    if bytes.len() == 4 {
        let from = Square::from_alg(&lower[0..2])?;
        let to = Square::from_alg(&lower[2..4])?;
        Some(Move::new(from, to))
    } else if bytes.len() == 5 && (bytes[2] == b'-' || bytes[2] == b'x') {
        let from = Square::from_alg(&lower[0..2])?;
        let to = Square::from_alg(&lower[3..5])?;
        Some(Move::new(from, to))
    } else {
        None
    }
}

#[derive(Clone)]
enum EngineState {
    Ep(BitboardPos, History),
    Classic(ClassicPos, ClassicHistory),
    Rats(RatsPos, RatsHistory),
}

impl EngineState {
    fn new_start(variant: GameVariant) -> Self {
        match variant {
            GameVariant::EpSuperKo => {
                let (p, h) = BitboardPos::new_start();
                EngineState::Ep(p, h)
            }
            GameVariant::ClassicSuperKo => {
                let (p, h) = ClassicPos::new_start();
                EngineState::Classic(p, h)
            }
            GameVariant::MonsterRats => {
                let (p, h) = RatsPos::new_start();
                EngineState::Rats(p, h)
            }
        }
    }

    fn from_custom(
        variant: GameVariant,
        pieces: &[(Color, PieceKind, Square)],
        side_to_move: Color,
        ep: [u8; 2],
    ) -> Self {
        match variant {
            GameVariant::EpSuperKo => {
                let (p, h) = BitboardPos::from_custom(pieces, side_to_move, ep);
                EngineState::Ep(p, h)
            }
            GameVariant::ClassicSuperKo => {
                let (p, h) = ClassicPos::from_custom(pieces, side_to_move);
                EngineState::Classic(p, h)
            }
            GameVariant::MonsterRats => {
                let (p, h) = RatsPos::from_custom(pieces, side_to_move, ep);
                EngineState::Rats(p, h)
            }
        }
    }

    fn piece_sq(&self) -> [u8; 16] {
        match self {
            EngineState::Ep(p, _) => p.piece_sq,
            EngineState::Classic(p, _) => p.piece_sq,
            EngineState::Rats(p, _) => p.piece_sq,
        }
    }

    fn board_piece(&self, sq_idx: usize) -> u8 {
        match self {
            EngineState::Ep(p, _) => p.board_piece[sq_idx],
            EngineState::Classic(p, _) => p.board_piece[sq_idx],
            EngineState::Rats(p, _) => p.board_piece[sq_idx],
        }
    }

    fn occ_side(&self, side: usize) -> u64 {
        match self {
            EngineState::Ep(p, _) => p.occ_side[side],
            EngineState::Classic(p, _) => p.occ_side[side],
            EngineState::Rats(p, _) => p.occ_side[side],
        }
    }

    fn side_to_move(&self) -> Color {
        match self {
            EngineState::Ep(p, _) => p.side_to_move,
            EngineState::Classic(p, _) => p.side_to_move,
            EngineState::Rats(p, _) => p.side_to_move,
        }
    }

    fn winner(&self) -> Option<Color> {
        match self {
            EngineState::Ep(p, _) => p.winner,
            EngineState::Classic(p, _) => p.winner,
            EngineState::Rats(p, _) => p.winner,
        }
    }

    fn ep(&self) -> [u8; 2] {
        match self {
            EngineState::Ep(p, _) => p.ep,
            EngineState::Classic(_, _) => [0, 0],
            EngineState::Rats(p, _) => p.ep,
        }
    }

    fn side_army_strength(&self, side: Color) -> i32 {
        let base = side.idx() * 8;
        let (piece_sq, values) = match self {
            EngineState::Ep(p, _) => (&p.piece_sq, &EP_PIECE_VALUE),
            EngineState::Classic(p, _) => (&p.piece_sq, &CLASSIC_PIECE_VALUE),
            EngineState::Rats(p, _) => (&p.piece_sq, &RATS_PIECE_VALUE),
        };
        let mut total = 0i32;
        for k in 0..8usize {
            if piece_sq[base + k] != CAPTURED {
                total += values[k];
            }
        }
        total
    }

    fn gen_legal_moves(&self) -> Vec<Move> {
        match self {
            EngineState::Ep(p, h) => p.gen_legal_moves(h).as_slice().to_vec(),
            EngineState::Classic(p, h) => p.gen_legal_moves(h).as_slice().to_vec(),
            EngineState::Rats(p, h) => p.gen_legal_moves(h).as_slice().to_vec(),
        }
    }

    fn game_result(&self) -> GameResult {
        match self {
            EngineState::Ep(p, h) => p.game_result(h),
            EngineState::Classic(p, h) => p.game_result(h),
            EngineState::Rats(p, h) => p.game_result(h),
        }
    }

    fn move_has_rep_warning(&self, mv: Move) -> bool {
        match self {
            EngineState::Ep(p, h) => {
                let opp_den = DEN_SQ[p.side_to_move.opp().idx()].0;
                if mv.to().0 == opp_den || p.board_piece[mv.to().idx()] != EMPTY_SQ {
                    return false;
                }
                let pid = p.board_piece[mv.from().idx()] as usize;
                let mut next_sq = p.piece_sq;
                next_sq[pid] = mv.to().0;
                h.contains(u128::from_ne_bytes(next_sq))
            }
            EngineState::Classic(p, h) => p.prior_occurrences_after(mv, h) == 1,
            EngineState::Rats(p, h) => {
                let opp_den = DEN_SQ[p.side_to_move.opp().idx()].0;
                if mv.to().0 == opp_den || p.board_piece[mv.to().idx()] != EMPTY_SQ {
                    return false;
                }
                let pid = p.board_piece[mv.from().idx()] as usize;
                let mut next_sq = p.piece_sq;
                next_sq[pid] = mv.to().0;
                h.contains(u128::from_ne_bytes(next_sq))
            }
        }
    }

    fn apply_move(&mut self, mv: Move) -> bool {
        match self {
            EngineState::Ep(p, h) => {
                let mover_idx = p.side_to_move.idx();
                let ep_before = p.ep[mover_idx];
                *p = p.make_move(mv, h);
                p.ep[mover_idx] < ep_before
            }
            EngineState::Classic(p, h) => {
                let is_rep2 = p.prior_occurrences_after(mv, h) == 1;
                *p = p.make_move(mv, h);
                is_rep2
            }
            EngineState::Rats(p, h) => {
                let mover_idx = p.side_to_move.idx();
                let ep_before = p.ep[mover_idx];
                *p = p.make_move(mv, h);
                p.ep[mover_idx] < ep_before
            }
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PieceSet {
    Chinese,
    Animals,
    Unicode,
    Numbers,
    Letters,
}

impl PieceSet {
    const ALL: [PieceSet; 5] = [
        PieceSet::Chinese,
        PieceSet::Animals,
        PieceSet::Unicode,
        PieceSet::Numbers,
        PieceSet::Letters,
    ];

    const fn label(self) -> &'static str {
        match self {
            PieceSet::Chinese => "Chinese",
            PieceSet::Animals => "Animals",
            PieceSet::Unicode => "Unicode",
            PieceSet::Numbers => "Numbers",
            PieceSet::Letters => "Letters",
        }
    }

    fn as_str(self) -> &'static str {
        match self {
            PieceSet::Chinese => "chinese",
            PieceSet::Animals => "animals",
            PieceSet::Unicode => "unicode",
            PieceSet::Numbers => "numbers",
            PieceSet::Letters => "letters",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        match s {
            "chinese" => Some(PieceSet::Chinese),
            "animals" => Some(PieceSet::Animals),
            "unicode" => Some(PieceSet::Unicode),
            "numbers" => Some(PieceSet::Numbers),
            "letters" => Some(PieceSet::Letters),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ColorTheme {
    Night,
    Day,
}

impl ColorTheme {
    fn as_str(self) -> &'static str {
        match self {
            ColorTheme::Night => "night",
            ColorTheme::Day => "day",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        match s {
            "night" => Some(ColorTheme::Night),
            "day" => Some(ColorTheme::Day),
            _ => None,
        }
    }

    fn palette(self) -> Palette {
        match self {
            ColorTheme::Night => Palette {
                board_frame: egui::Color32::from_rgb(20, 23, 30),
                coord_text: egui::Color32::from_rgb(155, 165, 185),
                land_light: egui::Color32::from_rgb(46, 52, 64),
                land_dark: egui::Color32::from_rgb(38, 43, 54),
                water_light: egui::Color32::from_rgb(22, 62, 92),
                water_dark: egui::Color32::from_rgb(18, 52, 78),
                trap_p1: egui::Color32::from_rgb(82, 54, 44),
                trap_p2: egui::Color32::from_rgb(44, 62, 86),
                den_p1: egui::Color32::from_rgb(112, 74, 34),
                den_p2: egui::Color32::from_rgb(36, 78, 114),
                grid_line: egui::Color32::from_rgb(24, 28, 36),
                p1_fill: egui::Color32::from_rgb(218, 148, 52),
                p1_border: egui::Color32::from_rgb(255, 224, 150),
                p1_text: egui::Color32::from_rgb(24, 16, 8),
                p2_fill: egui::Color32::from_rgb(56, 138, 212),
                p2_border: egui::Color32::from_rgb(180, 225, 255),
                p2_text: egui::Color32::from_rgb(245, 250, 255),
                selected_ring: egui::Color32::from_rgb(110, 240, 140),
                last_move_tint: egui::Color32::from_rgba_unmultiplied(240, 210, 80, 52),
                thinking_from_tint: egui::Color32::from_rgba_unmultiplied(64, 225, 255, 78),
                thinking_to_tint: egui::Color32::from_rgba_unmultiplied(215, 95, 255, 86),
                thinking_accent: egui::Color32::from_rgb(88, 228, 255),
                legal_quiet: egui::Color32::from_rgba_unmultiplied(100, 230, 130, 190),
                legal_rep_warn: egui::Color32::from_rgba_unmultiplied(255, 175, 50, 220),
                legal_capture: egui::Color32::from_rgba_unmultiplied(255, 85, 85, 230),
                legal_win: egui::Color32::from_rgba_unmultiplied(255, 230, 60, 240),
                panel_card_bg: egui::Color32::from_rgb(30, 34, 43),
                badge_text: egui::Color32::from_rgb(215, 222, 235),
                ep_empty_cell: egui::Color32::from_rgb(44, 49, 60),
                ep_grid_border: egui::Color32::from_rgb(20, 23, 30),
                ep_zero_warn: egui::Color32::from_rgb(235, 82, 82),
                ep_gain_badge: egui::Color32::from_rgb(100, 225, 135),
                setup_banner: egui::Color32::from_rgb(160, 115, 245),
                ironman_accent: egui::Color32::from_rgb(240, 96, 64),
                classic_accent: egui::Color32::from_rgb(86, 196, 184),
                rats_accent: egui::Color32::from_rgb(188, 235, 74),
            },
            ColorTheme::Day => Palette {
                board_frame: egui::Color32::from_rgb(218, 210, 196),
                coord_text: egui::Color32::from_rgb(68, 62, 54),
                land_light: egui::Color32::from_rgb(236, 221, 192),
                land_dark: egui::Color32::from_rgb(220, 202, 168),
                water_light: egui::Color32::from_rgb(115, 186, 230),
                water_dark: egui::Color32::from_rgb(98, 172, 218),
                trap_p1: egui::Color32::from_rgb(228, 180, 162),
                trap_p2: egui::Color32::from_rgb(168, 194, 226),
                den_p1: egui::Color32::from_rgb(224, 152, 112),
                den_p2: egui::Color32::from_rgb(122, 168, 222),
                grid_line: egui::Color32::from_rgb(165, 148, 122),
                p1_fill: egui::Color32::from_rgb(196, 56, 44),
                p1_border: egui::Color32::from_rgb(110, 22, 18),
                p1_text: egui::Color32::from_rgb(255, 248, 240),
                p2_fill: egui::Color32::from_rgb(36, 90, 168),
                p2_border: egui::Color32::from_rgb(16, 46, 96),
                p2_text: egui::Color32::from_rgb(245, 250, 255),
                selected_ring: egui::Color32::from_rgb(22, 160, 68),
                last_move_tint: egui::Color32::from_rgba_unmultiplied(230, 190, 20, 80),
                thinking_from_tint: egui::Color32::from_rgba_unmultiplied(0, 165, 205, 85),
                thinking_to_tint: egui::Color32::from_rgba_unmultiplied(155, 45, 215, 90),
                thinking_accent: egui::Color32::from_rgb(0, 128, 168),
                legal_quiet: egui::Color32::from_rgba_unmultiplied(26, 150, 68, 190),
                legal_rep_warn: egui::Color32::from_rgba_unmultiplied(220, 120, 10, 225),
                legal_capture: egui::Color32::from_rgba_unmultiplied(215, 35, 35, 235),
                legal_win: egui::Color32::from_rgba_unmultiplied(230, 170, 0, 245),
                panel_card_bg: egui::Color32::from_rgb(238, 234, 226),
                badge_text: egui::Color32::from_rgb(38, 36, 32),
                ep_empty_cell: egui::Color32::from_rgb(214, 208, 198),
                ep_grid_border: egui::Color32::from_rgb(165, 156, 142),
                ep_zero_warn: egui::Color32::from_rgb(195, 32, 32),
                ep_gain_badge: egui::Color32::from_rgb(24, 138, 58),
                setup_banner: egui::Color32::from_rgb(110, 56, 185),
                ironman_accent: egui::Color32::from_rgb(185, 42, 24),
                classic_accent: egui::Color32::from_rgb(20, 128, 118),
                rats_accent: egui::Color32::from_rgb(92, 145, 18),
            },
        }
    }
}

struct Palette {
    board_frame: egui::Color32,
    coord_text: egui::Color32,
    land_light: egui::Color32,
    land_dark: egui::Color32,
    water_light: egui::Color32,
    water_dark: egui::Color32,
    trap_p1: egui::Color32,
    trap_p2: egui::Color32,
    den_p1: egui::Color32,
    den_p2: egui::Color32,
    grid_line: egui::Color32,
    p1_fill: egui::Color32,
    p1_border: egui::Color32,
    p1_text: egui::Color32,
    p2_fill: egui::Color32,
    p2_border: egui::Color32,
    p2_text: egui::Color32,
    selected_ring: egui::Color32,
    last_move_tint: egui::Color32,
    thinking_from_tint: egui::Color32,
    thinking_to_tint: egui::Color32,
    thinking_accent: egui::Color32,
    legal_quiet: egui::Color32,
    legal_rep_warn: egui::Color32,
    legal_capture: egui::Color32,
    legal_win: egui::Color32,
    panel_card_bg: egui::Color32,
    badge_text: egui::Color32,
    ep_empty_cell: egui::Color32,
    ep_grid_border: egui::Color32,
    ep_zero_warn: egui::Color32,
    ep_gain_badge: egui::Color32,
    setup_banner: egui::Color32,
    ironman_accent: egui::Color32,
    classic_accent: egui::Color32,
    rats_accent: egui::Color32,
}

#[derive(Clone)]
struct MoveRecord {
    #[allow(dead_code)]
    side: Color,
    mv: Move,
    piece: PieceKind,
    captured: Option<PieceKind>,
    rep_marked: bool,
}

#[derive(Clone)]
struct Snapshot {
    state: EngineState,
    move_log: Vec<MoveRecord>,
    last_move: Option<Move>,
}

#[derive(Clone)]
struct GameOrigin {
    piece_sq: [u8; 16],
    side_to_move: Color,
    ep: [u8; 2],
    is_custom: bool,
}

impl GameOrigin {
    fn standard() -> Self {
        let mut piece_sq = [CAPTURED; 16];
        for &(c, k, sq) in &INITIAL_PIECES {
            piece_sq[c.idx() * 8 + k.idx()] = sq.0;
        }
        Self {
            piece_sq,
            side_to_move: Color::P1,
            ep: START_EP,
            is_custom: false,
        }
    }

    fn from_custom(piece_sq: [u8; 16], side_to_move: Color, ep: [u8; 2]) -> Self {
        Self {
            piece_sq,
            side_to_move,
            ep,
            is_custom: true,
        }
    }

    fn to_pieces_vec(&self) -> Vec<(Color, PieceKind, Square)> {
        let mut out = Vec::with_capacity(16);
        for (pid, &s) in self.piece_sq.iter().enumerate() {
            if s != CAPTURED {
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                out.push((color, kind, Square(s)));
            }
        }
        out
    }
}

struct PendingSearch {
    generation: u64,
    rx: Receiver<SearchResult>,
    progress_rx: Option<Receiver<SearchProgress>>,
    latest_progress: Option<SearchProgress>,
    stop_flag: Arc<AtomicBool>,
    stop_requested: bool,
    started_at: Instant,
}

#[derive(Clone)]
struct SetupState {
    piece_sq: [u8; 16],
    side_to_move: Color,
    ep: [u8; 2],
    brush_color: Color,
    brush_kind: PieceKind,
    chord_consumed: bool,
    status_msg: String,
}

impl SetupState {
    fn from_state(state: &EngineState) -> Self {
        Self {
            piece_sq: state.piece_sq(),
            side_to_move: state.side_to_move(),
            ep: state.ep(),
            brush_color: Color::P1,
            brush_kind: PieceKind::Elephant,
            chord_consumed: false,
            status_msg: "L-click: selected color | R-click: other color | L+R (or M-click): remove"
                .to_owned(),
        }
    }

    fn clear_board(&mut self) {
        self.piece_sq = [CAPTURED; 16];
        self.status_msg = "Board cleared.".to_owned();
    }

    fn reset_start(&mut self) {
        self.piece_sq = [CAPTURED; 16];
        for &(color, kind, sq) in &INITIAL_PIECES {
            self.piece_sq[color.idx() * 8 + kind.idx()] = sq.0;
        }
        self.side_to_move = Color::P1;
        self.ep = START_EP;
        self.status_msg = "Reset to standard starting position.".to_owned();
    }

    fn piece_at(&self, sq: Square) -> Option<usize> {
        self.piece_sq.iter().position(|&s| s == sq.0)
    }

    fn remove_at(&mut self, sq: Square) {
        if let Some(pid) = self.piece_at(sq) {
            self.piece_sq[pid] = CAPTURED;
            let c = if pid < 8 { Color::P1 } else { Color::P2 };
            let k = PieceKind::from_idx(pid & 7);
            self.status_msg = format!("Removed {} {} from {}.", c, piece_name(k), sq);
        }
    }

    fn place_piece(&mut self, color: Color, kind: PieceKind, sq: Square) {
        if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
            self.status_msg = format!("Cannot place any piece inside a Den ({})!", sq);
            return;
        }
        if (sq.bit() & WATER_MASK) != 0 && !kind.can_enter_water() {
            self.status_msg = format!(
                "Only Rats can be placed in water! ({} cannot enter {})",
                piece_name(kind),
                sq
            );
            return;
        }

        if let Some(existing_pid) = self.piece_at(sq) {
            self.piece_sq[existing_pid] = CAPTURED;
        }

        let pid = color.idx() * 8 + kind.idx();
        self.piece_sq[pid] = sq.0;
        self.status_msg = format!("Placed {} {} on {}.", color, piece_name(kind), sq);
    }

    fn side_occ(&self, side: usize) -> u64 {
        let base = side * 8;
        let mut m = 0u64;
        for k in 0..8 {
            let s = self.piece_sq[base + k];
            if s != CAPTURED {
                m |= 1u64 << s;
            }
        }
        m
    }

    fn validate(&self) -> Result<(), &'static str> {
        validate_piece_array(&self.piece_sq)
    }

    fn to_pieces_vec(&self) -> Vec<(Color, PieceKind, Square)> {
        let mut out = Vec::with_capacity(16);
        for (pid, &s) in self.piece_sq.iter().enumerate() {
            if s != CAPTURED {
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                out.push((color, kind, Square(s)));
            }
        }
        out
    }
}

fn validate_piece_array(piece_sq: &[u8; 16]) -> Result<(), &'static str> {
    let mut p1_cnt = 0usize;
    let mut p2_cnt = 0usize;
    let mut occ = 0u64;
    for (pid, &s) in piece_sq.iter().enumerate() {
        if s == CAPTURED {
            continue;
        }
        if s >= 63 {
            return Err("Invalid square index.");
        }
        let sq = Square(s);
        let bit = sq.bit();
        if (occ & bit) != 0 {
            return Err("Two pieces occupy the same square.");
        }
        occ |= bit;
        if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
            return Err("No piece may be inside a Den.");
        }
        let kind = PieceKind::from_idx(pid & 7);
        if !kind.can_enter_water() && (bit & WATER_MASK) != 0 {
            return Err("Only Rats may stand in water.");
        }
        if pid < 8 {
            p1_cnt += 1;
        } else {
            p2_cnt += 1;
        }
    }
    if p1_cnt == 0 {
        return Err("P1 must have at least 1 piece.");
    }
    if p2_cnt == 0 {
        return Err("P2 must have at least 1 piece.");
    }
    Ok(())
}

fn inspect_autosave_summary(variant: GameVariant) -> Option<AutosaveSummary> {
    let path = variant.autosave_path();
    let text = std::fs::read_to_string(&path).ok()?;
    let mut lines = text.lines();
    if lines.next().map(|l| l.trim()) != Some(AUTOSAVE_VERSION) {
        return None;
    }
    let mut is_custom = false;
    let mut depth = 8usize;
    let mut time_limit: Option<u64> = None;
    let mut plies = 0usize;

    for line in lines {
        let Some((k, v)) = line.split_once('=') else {
            continue;
        };
        let v = v.trim();
        match k.trim() {
            "origin_custom" => is_custom = v == "1",
            "depth" => {
                if let Ok(d) = v.parse::<usize>() {
                    depth = d.clamp(1, MAX_GUI_DEPTH);
                }
            }
            "time_limit" => {
                if v.eq_ignore_ascii_case("unlimited") {
                    time_limit = None;
                } else if let Ok(s) = v.parse::<u64>() {
                    time_limit = Some(s);
                }
            }
            "moves" => {
                plies = v.split_whitespace().count();
            }
            _ => {}
        }
    }

    if plies == 0 && !is_custom {
        return None;
    }

    Some(AutosaveSummary {
        moves: plies.div_ceil(2),
        plies,
        depth,
        time_limit,
        is_custom,
    })
}

#[derive(Clone)]
struct IronManState {
    start_depth: usize,
    min_depth: usize,
    recorded_this_game: bool,
}

pub struct DsqGuiApp {
    variant: GameVariant,
    origin: GameOrigin,
    state: EngineState,
    move_log: Vec<MoveRecord>,
    undo_stack: Vec<Snapshot>,
    redo_stack: Vec<Snapshot>,
    last_move: Option<Move>,

    setup: Option<SetupState>,
    ironman: Option<IronManState>,
    hof: HallOfFame,
    hof_status: Option<String>,

    show_hof_window: bool,
    show_help_window: bool,
    show_ironman_setup_confirm: bool,
    show_enter_ironman_confirm: bool,
    enter_ironman_depth_choice: usize,
    show_new_game_leave_ironman_confirm: bool,

    pending_hof_record: Option<(HallOfFameEntry, usize)>,
    hof_name_input: String,

    pending_import_confirm: Option<(ImportRequest, AutosaveSummary)>,

    human_side: Color,
    search_depth: usize,
    time_limit_idx: usize,
    piece_set: PieceSet,
    theme: ColorTheme,
    rotation: u8,
    show_legal_moves: bool,
    show_thinking: bool,

    selected_sq: Option<Square>,
    pending_search: Option<PendingSearch>,
    search_generation: u64,
    last_engine_info: String,
    copied_until: Option<Instant>,

    show_quit_confirm: bool,
    allow_close: bool,
}

impl DsqGuiApp {
    fn new(
        cc: &eframe::CreationContext<'_>,
        variant: GameVariant,
        ironman_depth: Option<usize>,
        import_req: Option<ImportRequest>,
    ) -> Self {
        install_system_symbol_fonts(&cc.egui_ctx);
        cc.egui_ctx.set_visuals(egui::Visuals::dark());

        let (hof, hof_status) = match HallOfFame::load_from_path(&variant.hof_path()) {
            Ok(h) => (h, None),
            Err(err) => (HallOfFame::default(), Some(err)),
        };

        let state = EngineState::new_start(variant);

        let (ironman, human_side, search_depth, rotation, show_legal_moves, info) =
            if let Some(d) = ironman_depth {
                let d = d.clamp(MIN_IRONMAN_DEPTH, MAX_GUI_DEPTH);
                (
                    Some(IronManState {
                        start_depth: d,
                        min_depth: d,
                        recorded_this_game: false,
                    }),
                    Color::P2,
                    d,
                    2u8,
                    false,
                    format!(
                        "IRONMAN {} (Depth {}). You play P2. Engine moves first...",
                        variant.display_name(),
                        d
                    ),
                )
            } else {
                (
                    None,
                    Color::P1,
                    8usize,
                    0u8,
                    true,
                    format!("Ready ({}). Your move as P1.", variant.display_name()),
                )
            };

        let mut app = Self {
            variant,
            origin: GameOrigin::standard(),
            state,
            move_log: Vec::new(),
            undo_stack: Vec::new(),
            redo_stack: Vec::new(),
            last_move: None,
            setup: None,
            ironman,
            hof,
            hof_status,
            show_hof_window: false,
            show_help_window: false,
            show_ironman_setup_confirm: false,
            show_enter_ironman_confirm: false,
            enter_ironman_depth_choice: MIN_IRONMAN_DEPTH,
            show_new_game_leave_ironman_confirm: false,
            pending_hof_record: None,
            hof_name_input: String::new(),
            pending_import_confirm: None,
            human_side,
            search_depth,
            time_limit_idx: UNLIMITED_TIME_IDX,
            piece_set: PieceSet::Letters,
            theme: ColorTheme::Night,
            rotation,
            show_legal_moves,
            show_thinking: false,
            selected_sq: None,
            pending_search: None,
            search_generation: 0,
            last_engine_info: info,
            copied_until: None,
            show_quit_confirm: false,
            allow_close: false,
        };

        if app.is_ironman() {
            app.start_engine_search(&cc.egui_ctx);
        } else if let Some(req) = import_req {
            if let Some(summary) = inspect_autosave_summary(variant) {
                app.pending_import_confirm = Some((req, summary));
            } else {
                app.apply_import(req);
            }
        } else if app.try_autoload(&cc.egui_ctx) {
            app.apply_theme(&cc.egui_ctx);
        }

        app
    }

    fn is_ironman(&self) -> bool {
        self.ironman.is_some()
    }

    fn is_setup(&self) -> bool {
        self.setup.is_some()
    }

    fn current_time_limit_secs(&self) -> Option<u64> {
        if self.is_ironman() {
            None
        } else {
            TIME_PRESETS_SECS[self.time_limit_idx.min(UNLIMITED_TIME_IDX)]
        }
    }

    fn any_modal_open(&self) -> bool {
        self.show_quit_confirm
            || self.show_ironman_setup_confirm
            || self.show_enter_ironman_confirm
            || self.show_new_game_leave_ironman_confirm
            || self.show_hof_window
            || self.show_help_window
            || self.pending_hof_record.is_some()
            || self.pending_import_confirm.is_some()
    }

    fn update_window_title(&self, ctx: &egui::Context) {
        let title = match &self.ironman {
            Some(im) => format!(
                "Dou Shou Qi ({}) — IRONMAN MODE (Depth {}+)",
                self.variant.display_name(),
                im.start_depth
            ),
            None => format!("Dou Shou Qi ({})", self.variant.display_name()),
        };
        ctx.send_viewport_cmd(egui::ViewportCommand::Title(title));
    }

    fn has_running_game(&self) -> bool {
        if self.state.game_result() != GameResult::Ongoing {
            return false;
        }
        !self.move_log.is_empty() || self.origin.is_custom
    }

    /// Switches to another non-IronMan game mode, preserving the previous mode's autosave
    /// and auto-loading any saved game in the target mode.
    fn switch_variant(&mut self, new_variant: GameVariant, ctx: &egui::Context) {
        if self.is_ironman() || self.is_setup() || self.variant == new_variant {
            return;
        }
        self.cancel_search();
        self.save_autosave();

        self.variant = new_variant;
        match HallOfFame::load_from_path(&new_variant.hof_path()) {
            Ok(h) => {
                self.hof = h;
                self.hof_status = None;
            }
            Err(e) => {
                self.hof = HallOfFame::default();
                self.hof_status = Some(e);
            }
        }

        // Preserve user's visual preferences across modes unless target autosave overrides them
        let prev_piece_set = self.piece_set;
        let prev_theme = self.theme;

        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(new_variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;
        self.human_side = Color::P1;
        self.rotation = 0;
        self.last_engine_info = format!(
            "Switched to {}. Your move as P1.",
            new_variant.display_name()
        );

        if self.try_autoload(ctx) {
            self.apply_theme(ctx);
        } else {
            self.piece_set = prev_piece_set;
            self.theme = prev_theme;
        }
        self.update_window_title(ctx);
    }

    /// Enters IronMan Mode for the current `variant` at `start_depth` (>= 12).
    fn enter_ironman_mode(&mut self, start_depth: usize, ctx: &egui::Context) {
        let d = start_depth.clamp(MIN_IRONMAN_DEPTH, MAX_GUI_DEPTH);
        self.cancel_search();
        self.save_autosave(); // Preserve any running normal game before entering IronMan

        self.setup = None;
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;

        self.ironman = Some(IronManState {
            start_depth: d,
            min_depth: d,
            recorded_this_game: false,
        });
        self.human_side = Color::P2;
        self.search_depth = d;
        self.time_limit_idx = UNLIMITED_TIME_IDX;
        self.rotation = 2; // Face P2 at bottom
        self.show_legal_moves = false;
        self.show_thinking = false;
        self.last_engine_info = format!(
            "IRONMAN {} (Depth {}). You play P2. Engine moves first...",
            self.variant.display_name(),
            d
        );
        self.update_window_title(ctx);
        self.start_engine_search(ctx);
    }

    /// Leaves IronMan Mode and starts a fresh normal (non-IronMan) game.
    fn leave_ironman_to_new_normal_game(&mut self, ctx: &egui::Context) {
        self.cancel_search();
        self.ironman = None;
        self.pending_hof_record = None;
        self.setup = None;
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;
        self.human_side = Color::P1;
        self.rotation = 0;
        self.show_legal_moves = true;
        self.last_engine_info = format!(
            "Exited IronMan Mode. New {} game started (You play P1).",
            self.variant.display_name()
        );
        self.update_window_title(ctx);
    }

    fn apply_import(&mut self, req: ImportRequest) {
        self.cancel_search();
        self.setup = None;
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;

        let mut timeline: Vec<Snapshot> = Vec::with_capacity(req.moves.len() + 1);
        timeline.push(self.current_snapshot());

        for &mv in &req.moves {
            let mover = self.state.side_to_move();
            let att_pid = self.state.board_piece(mv.from().idx()) as usize;
            let att_kind = PieceKind::from_idx(att_pid & 7);
            let cap_pid = self.state.board_piece(mv.to().idx());
            let captured = if cap_pid != EMPTY_SQ {
                Some(PieceKind::from_idx((cap_pid as usize) & 7))
            } else {
                None
            };
            let rep_marked = self.state.apply_move(mv);
            self.move_log.push(MoveRecord {
                side: mover,
                mv,
                piece: att_kind,
                captured,
                rep_marked,
            });
            self.last_move = Some(mv);
            timeline.push(self.current_snapshot());
        }

        match req.open_at {
            ImportPosition::End => {
                let end_snap = timeline.pop().unwrap();
                self.undo_stack = timeline;
                self.redo_stack.clear();
                self.restore_snapshot(end_snap);
            }
            ImportPosition::Start => {
                let start_snap = timeline.remove(0);
                timeline.reverse();
                self.undo_stack.clear();
                self.redo_stack = timeline;
                self.restore_snapshot(start_snap);
            }
        }

        self.human_side = self.state.side_to_move();
        self.rotation = if self.human_side == Color::P1 { 0 } else { 2 };

        let pos_label = match req.open_at {
            ImportPosition::Start => "start",
            ImportPosition::End => "end",
        };
        self.last_engine_info = format!(
            "Imported '{}' as {} ({} plies, opened at {}). You play {}.",
            req.filename,
            self.variant.display_name(),
            req.moves.len(),
            pos_label,
            self.human_side
        );
    }

    fn save_autosave(&self) {
        if self.is_ironman() || self.pending_import_confirm.is_some() {
            return;
        }
        let path = self.variant.autosave_path();
        if !self.has_running_game() {
            let _ = std::fs::remove_file(&path);
            return;
        }

        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }

        let pieces_str: String = self
            .origin
            .piece_sq
            .iter()
            .map(|v| v.to_string())
            .collect::<Vec<_>>()
            .join(",");

        let moves_str: String = self
            .move_log
            .iter()
            .map(|r| r.mv.to_string())
            .collect::<Vec<_>>()
            .join(" ");

        let time_str = match self.current_time_limit_secs() {
            Some(s) => s.to_string(),
            None => "unlimited".to_owned(),
        };

        let content = format!(
            "{}\n\
             origin_custom={}\n\
             origin_pieces={}\n\
             origin_stm={}\n\
             origin_ep={},{}\n\
             human_side={}\n\
             depth={}\n\
             time_limit={}\n\
             piece_set={}\n\
             theme={}\n\
             rotation={}\n\
             show_legal={}\n\
             show_thinking={}\n\
             moves={}\n",
            AUTOSAVE_VERSION,
            if self.origin.is_custom { 1 } else { 0 },
            pieces_str,
            self.origin.side_to_move.idx(),
            self.origin.ep[0],
            self.origin.ep[1],
            self.human_side.idx(),
            self.search_depth,
            time_str,
            self.piece_set.as_str(),
            self.theme.as_str(),
            self.rotation % 4,
            if self.show_legal_moves { 1 } else { 0 },
            if self.show_thinking { 1 } else { 0 },
            moves_str
        );

        let _ = std::fs::write(&path, content);
    }

    fn try_autoload(&mut self, ctx: &egui::Context) -> bool {
        let path = self.variant.autosave_path();
        let Ok(text) = std::fs::read_to_string(&path) else {
            return false;
        };

        let mut lines = text.lines();
        if lines.next().map(|l| l.trim()) != Some(AUTOSAVE_VERSION) {
            return false;
        }

        let mut origin_custom = false;
        let mut origin_pieces: Option<[u8; 16]> = None;
        let mut origin_stm = Color::P1;
        let mut origin_ep = START_EP;
        let mut human_side = Color::P1;
        let mut depth = self.search_depth;
        let mut time_limit_idx = UNLIMITED_TIME_IDX;
        let mut piece_set = self.piece_set;
        let mut theme = self.theme;
        let mut rotation = 0u8;
        let mut show_legal = true;
        let mut show_thinking = false;
        let mut moves_line = String::new();

        for line in lines {
            let Some((k, v)) = line.split_once('=') else {
                continue;
            };
            let v = v.trim();
            match k.trim() {
                "origin_custom" => origin_custom = v == "1",
                "origin_pieces" => {
                    let nums: Vec<u8> = v.split(',').filter_map(|s| s.parse().ok()).collect();
                    if nums.len() == 16 {
                        let mut arr = [CAPTURED; 16];
                        arr.copy_from_slice(&nums);
                        origin_pieces = Some(arr);
                    }
                }
                "origin_stm" => {
                    origin_stm = if v == "1" { Color::P2 } else { Color::P1 };
                }
                "origin_ep" => {
                    if let Some((a, b)) = v.split_once(',') {
                        if let (Ok(e0), Ok(e1)) = (a.parse::<u8>(), b.parse::<u8>()) {
                            if e0 <= MAX_EP && e1 <= MAX_EP {
                                origin_ep = [e0, e1];
                            }
                        }
                    }
                }
                "human_side" => {
                    human_side = if v == "1" { Color::P2 } else { Color::P1 };
                }
                "depth" => {
                    if let Ok(d) = v.parse::<usize>() {
                        depth = d.clamp(1, MAX_GUI_DEPTH);
                    }
                }
                "time_limit" => {
                    if v.eq_ignore_ascii_case("unlimited") {
                        time_limit_idx = UNLIMITED_TIME_IDX;
                    } else if let Ok(s) = v.parse::<u64>() {
                        time_limit_idx = time_idx_from_secs(Some(s));
                    }
                }
                "piece_set" => {
                    if let Some(ps) = PieceSet::from_str(v) {
                        piece_set = ps;
                    }
                }
                "theme" => {
                    if let Some(th) = ColorTheme::from_str(v) {
                        theme = th;
                    }
                }
                "rotation" => {
                    if let Ok(r) = v.parse::<u8>() {
                        rotation = r % 4;
                    }
                }
                "show_legal" => show_legal = v != "0",
                "show_thinking" => show_thinking = v == "1",
                "moves" => moves_line = v.to_owned(),
                _ => {}
            }
        }

        let Some(piece_sq) = origin_pieces else {
            return false;
        };
        if validate_piece_array(&piece_sq).is_err() {
            return false;
        }

        let origin = GameOrigin {
            piece_sq,
            side_to_move: origin_stm,
            ep: origin_ep,
            is_custom: origin_custom,
        };
        let pieces_vec = origin.to_pieces_vec();
        let start_state = EngineState::from_custom(self.variant, &pieces_vec, origin_stm, origin_ep);

        let mut parsed_moves = Vec::new();
        for tok in moves_line.split_whitespace() {
            let Some(mv) = parse_alg_move(tok) else {
                return false;
            };
            parsed_moves.push(mv);
        }

        self.origin = origin;
        self.state = start_state;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;
        self.human_side = human_side;
        self.search_depth = depth;
        self.time_limit_idx = time_limit_idx;
        self.piece_set = piece_set;
        self.theme = theme;
        self.rotation = rotation;
        self.show_legal_moves = show_legal;
        self.show_thinking = show_thinking;

        for mv in parsed_moves {
            let legal = self.state.gen_legal_moves();
            if !legal.contains(&mv) {
                self.origin = GameOrigin::standard();
                self.state = EngineState::new_start(self.variant);
                self.move_log.clear();
                self.undo_stack.clear();
                self.redo_stack.clear();
                self.last_move = None;
                return false;
            }
            self.play_move(mv);
        }

        if self.state.game_result() != GameResult::Ongoing {
            let _ = std::fs::remove_file(&path);
            self.origin = GameOrigin::standard();
            self.state = EngineState::new_start(self.variant);
            self.move_log.clear();
            self.undo_stack.clear();
            self.redo_stack.clear();
            self.last_move = None;
            return false;
        }

        self.last_engine_info = format!(
            "Auto-loaded saved {} game ({} plies). You play {}.",
            self.variant.display_name(),
            self.move_log.len(),
            self.human_side
        );

        if self.state.side_to_move() != self.human_side {
            self.start_engine_search(ctx);
        }

        true
    }

    fn current_snapshot(&self) -> Snapshot {
        Snapshot {
            state: self.state.clone(),
            move_log: self.move_log.clone(),
            last_move: self.last_move,
        }
    }

    fn restore_snapshot(&mut self, snap: Snapshot) {
        self.state = snap.state;
        self.move_log = snap.move_log;
        self.last_move = snap.last_move;
        self.selected_sq = None;
    }

    fn apply_theme(&self, ctx: &egui::Context) {
        match self.theme {
            ColorTheme::Night => ctx.set_visuals(egui::Visuals::dark()),
            ColorTheme::Day => ctx.set_visuals(egui::Visuals::light()),
        }
    }

    fn enter_setup(&mut self) {
        self.cancel_search();
        self.selected_sq = None;
        self.setup = Some(SetupState::from_state(&self.state));
    }

    fn cancel_setup(&mut self) {
        self.setup = None;
        self.last_engine_info = "Cancelled setup mode.".to_owned();
    }

    fn finish_setup(&mut self, ctx: &egui::Context) {
        let Some(setup) = self.setup.clone() else {
            return;
        };
        if setup.validate().is_err() {
            return;
        }
        let pieces = setup.to_pieces_vec();
        let new_state =
            EngineState::from_custom(self.variant, &pieces, setup.side_to_move, setup.ep);

        self.setup = None;
        self.origin = GameOrigin::from_custom(setup.piece_sq, setup.side_to_move, setup.ep);
        self.state = new_state;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;

        self.last_engine_info = format!(
            "Custom position ready! Turn: {} | You play {}.",
            self.state.side_to_move(),
            self.human_side
        );

        if self.state.game_result() == GameResult::Ongoing
            && self.state.side_to_move() != self.human_side
        {
            self.start_engine_search(ctx);
        }
    }

    fn new_game(&mut self, ctx: &egui::Context) {
        self.setup = None;
        self.cancel_search();
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;

        self.last_engine_info = format!(
            "New {} game started. You play {}.",
            self.variant.display_name(),
            self.human_side
        );

        if self.state.side_to_move() != self.human_side {
            self.start_engine_search(ctx);
        }
    }

    fn cancel_search(&mut self) {
        if let Some(p) = &self.pending_search {
            p.stop_flag.store(true, Ordering::Relaxed);
        }
        self.search_generation = self.search_generation.wrapping_add(1);
        self.pending_search = None;
    }

    fn request_stop_and_play(&mut self) {
        if self.is_ironman() {
            return;
        }
        if let Some(p) = &mut self.pending_search {
            if !p.stop_requested {
                p.stop_flag.store(true, Ordering::Relaxed);
                p.stop_requested = true;
                self.last_engine_info = "Stopping search — playing best completed move...".to_owned();
            }
        }
    }

    fn undo_move(&mut self) {
        if self.is_ironman() {
            return;
        }
        self.cancel_search();
        self.selected_sq = None;

        while let Some(snap) = self.undo_stack.pop() {
            let cur = self.current_snapshot();
            self.redo_stack.push(cur);
            self.restore_snapshot(snap);
            if self.state.side_to_move() == self.human_side {
                break;
            }
        }
        self.last_engine_info = "Undid move.".to_owned();
    }

    fn redo_move(&mut self) {
        if self.is_ironman() {
            return;
        }
        self.cancel_search();
        self.selected_sq = None;

        while let Some(snap) = self.redo_stack.pop() {
            let cur = self.current_snapshot();
            self.undo_stack.push(cur);
            self.restore_snapshot(snap);
            if self.state.side_to_move() == self.human_side {
                break;
            }
        }
        self.last_engine_info = "Redid move.".to_owned();
    }

    fn switch_sides(&mut self, ctx: &egui::Context) {
        if self.is_ironman() {
            return;
        }
        self.cancel_search();
        self.selected_sq = None;
        self.human_side = self.human_side.opp();
        self.rotation = (self.rotation + 2) % 4;

        if !self.is_setup()
            && self.state.game_result() == GameResult::Ongoing
            && self.state.side_to_move() != self.human_side
        {
            self.start_engine_search(ctx);
        } else {
            self.last_engine_info = format!("Switched sides. You now play {}.", self.human_side);
        }
    }

    fn play_move(&mut self, mv: Move) {
        if !self.is_ironman() {
            let snap = self.current_snapshot();
            self.undo_stack.push(snap);
            self.redo_stack.clear();
        }

        let mover = self.state.side_to_move();
        let opp_idx = mover.opp().idx();
        let att_pid = self.state.board_piece(mv.from().idx()) as usize;
        let att_kind = PieceKind::from_idx(att_pid & 7);
        let cap_pid = self.state.board_piece(mv.to().idx());
        let captured = if cap_pid != EMPTY_SQ {
            Some(PieceKind::from_idx((cap_pid as usize) & 7))
        } else {
            None
        };

        let rep_marked = self.state.apply_move(mv);

        self.move_log.push(MoveRecord {
            side: mover,
            mv,
            piece: att_kind,
            captured,
            rep_marked,
        });
        self.last_move = Some(mv);
        self.selected_sq = None;

        if let GameResult::Win(winner) = self.state.game_result() {
            let end_code = if self.state.winner().is_some() {
                if mv.to() == DEN_SQ[opp_idx] {
                    EndCode::Goal
                } else {
                    EndCode::Elimination
                }
            } else {
                EndCode::Immobilization
            };
            self.record_ironman_finish(winner, end_code);
        }
    }

    fn record_ironman_finish(&mut self, winner: Color, end_code: EndCode) {
        let Some(im) = &mut self.ironman else {
            return;
        };
        if im.recorded_this_game {
            return;
        }
        im.recorded_this_game = true;

        let plies = self.move_log.len();
        let moves = plies.div_ceil(2);
        let human_won = winner == self.human_side;
        let army_strength = self.state.side_army_strength(self.human_side);
        let start_depth = im.start_depth;

        let candidate = HallOfFameEntry {
            timestamp_secs: now_unix_secs(),
            player_name: String::new(),
            human_won,
            start_depth,
            end_depth: self.search_depth,
            moves,
            plies,
            end_code,
            army_strength,
        };

        let outcome_str = if human_won { "VICTORY" } else { "DEFEAT" };
        if let Some(rank) = self.hof.would_qualify(&candidate) {
            self.pending_hof_record = Some((candidate, rank));
            self.last_engine_info = format!(
                "NEW HALL OF FAME RECORD (#{}): {} (d{}, {} moves, Army {}, {})! Enter your name.",
                rank,
                outcome_str,
                start_depth,
                moves,
                army_strength,
                end_code.code_char()
            );
        } else {
            self.last_engine_info = format!(
                "IronMan {}: d{}, {} moves, Army {} ({}) — did not qualify for Top {}/depth or Top {}.",
                outcome_str,
                start_depth,
                moves,
                army_strength,
                end_code.code_char(),
                MAX_ENTRIES_PER_DEPTH,
                MAX_TOTAL_ENTRIES
            );
        }
    }

    fn commit_pending_hof_record(&mut self) {
        let Some((mut entry, _predicted_rank)) = self.pending_hof_record.take() else {
            return;
        };
        entry.player_name = sanitize_player_name(&self.hof_name_input);
        self.hof_name_input = entry.player_name.clone();

        let outcome_str = if entry.human_won { "VICTORY" } else { "DEFEAT" };
        let sd = entry.start_depth;
        let moves = entry.moves;
        let army = entry.army_strength;
        let code = entry.end_code.code_char();
        let name = entry.player_name.clone();

        if let Some(rank) = self.hof.add_entry(entry) {
            match self.hof.save_to_path(&self.variant.hof_path()) {
                Ok(()) => {
                    self.hof_status = None;
                    self.last_engine_info = format!(
                        "HALL OF FAME #{}: {} — {} (d{}, {} moves, Army {}, {}) saved!",
                        rank, name, outcome_str, sd, moves, army, code
                    );
                }
                Err(e) => {
                    self.hof_status = Some(e);
                }
            }
        }
    }

    fn start_engine_search(&mut self, ctx: &egui::Context) {
        if self.state.game_result() != GameResult::Ongoing {
            return;
        }
        self.cancel_search();
        let generation = self.search_generation;
        let depth = self.search_depth;
        let time_limit_secs = self.current_time_limit_secs();
        let limits = SearchLimits {
            max_depth: depth,
            max_time: time_limit_secs.map(Duration::from_secs),
            max_nodes: None,
        };
        let ctx_clone = ctx.clone();
        let state_clone = self.state.clone();
        let stop_flag = Arc::new(AtomicBool::new(false));
        let stop_clone = Arc::clone(&stop_flag);

        let (prog_tx, prog_rx) = if self.is_ironman() {
            (None, None)
        } else {
            let (tx, rx) = mpsc::channel();
            (Some(tx), Some(rx))
        };

        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            let res = match state_clone {
                EngineState::Ep(pos, mut hist) => {
                    let mut searcher = Searcher::with_tt_mb(32);
                    searcher.search_with_hooks(
                        &pos,
                        &mut hist,
                        limits,
                        Some(stop_clone),
                        prog_tx,
                    )
                }
                EngineState::Classic(pos, mut hist) => {
                    let mut searcher = ClassicSearcher::with_tt_mb(32);
                    searcher.search_with_hooks(
                        &pos,
                        &mut hist,
                        limits,
                        Some(stop_clone),
                        prog_tx,
                    )
                }
                EngineState::Rats(pos, mut hist) => {
                    let mut searcher = RatsSearcher::with_tt_mb(32);
                    searcher.search_with_hooks(
                        &pos,
                        &mut hist,
                        limits,
                        Some(stop_clone),
                        prog_tx,
                    )
                }
            };
            let _ = tx.send(res);
            ctx_clone.request_repaint();
        });

        self.pending_search = Some(PendingSearch {
            generation,
            rx,
            progress_rx: prog_rx,
            latest_progress: None,
            stop_flag,
            stop_requested: false,
            started_at: Instant::now(),
        });
        let limit_desc = match time_limit_secs {
            Some(s) => format!("depth {}, max {}s", depth, s),
            None => format!("depth {}", depth),
        };
        self.last_engine_info = format!("Engine thinking ({})...", limit_desc);
    }

    fn poll_engine(&mut self) {
        if let Some(pending) = &mut self.pending_search {
            if let Some(prx) = &pending.progress_rx {
                while let Ok(p) = prx.try_recv() {
                    pending.latest_progress = Some(p);
                }
            }
        }

        let Some(pending) = &self.pending_search else {
            return;
        };
        if let Ok(res) = pending.rx.try_recv() {
            let gen = pending.generation;
            let was_stopped = pending.stop_requested;
            self.pending_search = None;
            if gen != self.search_generation || self.is_setup() {
                return;
            }
            if res.best_move != Move::NULL {
                let legal = self.state.gen_legal_moves();
                if legal.contains(&res.best_move) {
                    if self.is_ironman() {
                        self.last_engine_info = format!(
                            "Engine played {} (d{}, {:.2}s)",
                            res.best_move,
                            res.depth,
                            res.elapsed.as_secs_f64()
                        );
                    } else {
                        let score_str = format_score(res.score);
                        let stop_tag = if was_stopped { " [stopped]" } else { "" };
                        self.last_engine_info = format!(
                            "Engine played {} | d{} | {} | {} nodes ({:.2}s){}",
                            res.best_move,
                            res.depth,
                            score_str,
                            res.nodes,
                            res.elapsed.as_secs_f64(),
                            stop_tag
                        );
                    }
                    self.play_move(res.best_move);
                }
            }
        }
    }

    fn visible_thinking(&self) -> Option<SearchProgress> {
        if self.is_ironman() || self.is_setup() || !self.show_thinking {
            return None;
        }
        self.pending_search
            .as_ref()
            .and_then(|p| p.latest_progress)
    }

    fn board_to_visual(&self, r: usize, c: usize) -> (usize, usize) {
        board_to_visual_rot(self.rotation, r, c)
    }

    fn visual_to_board(&self, vx: usize, vy: usize) -> (usize, usize) {
        visual_to_board_rot(self.rotation, vx, vy)
    }

    fn visual_dims(&self) -> (usize, usize) {
        if self.rotation % 2 == 0 {
            (COLS, ROWS)
        } else {
            (ROWS, COLS)
        }
    }

    fn format_movelist(&self) -> String {
        let mut out = String::new();
        for (i, rec) in self.move_log.iter().enumerate() {
            if i % 2 == 0 {
                if i > 0 {
                    out.push('\n');
                }
                out.push_str(&format!("{:>3}. ", i / 2 + 1));
            } else {
                out.push_str("   ");
            }
            let cap_sym = if rec.captured.is_some() { "x" } else { "-" };
            let rep_sym = if rec.rep_marked { "*" } else { "" };
            let p_ch = piece_letter(rec.piece);
            out.push_str(&format!(
                "{}:{}{}{}{}",
                p_ch,
                rec.mv.from(),
                cap_sym,
                rec.mv.to(),
                rep_sym
            ));
        }
        out
    }

    fn format_movelist_for_export(&self) -> String {
        let body = self.format_movelist();
        if body.is_empty() {
            format!("{}\n", self.variant.export_header())
        } else {
            format!("{}\n{}\n", self.variant.export_header(), body)
        }
    }

    fn draw_piece_disc(
        &self,
        painter: &egui::Painter,
        center: egui::Pos2,
        radius: f32,
        color: Color,
        kind: PieceKind,
        pal: &Palette,
    ) {
        let (fill, border, text_col) = match color {
            Color::P1 => (pal.p1_fill, pal.p1_border, pal.p1_text),
            Color::P2 => (pal.p2_fill, pal.p2_border, pal.p2_text),
        };

        painter.circle_filled(center, radius, fill);
        painter.circle_stroke(
            center,
            radius,
            egui::Stroke::new((radius * 0.11).max(1.5), border),
        );

        let rank_str = kind.rank().to_string();
        match self.piece_set {
            PieceSet::Numbers => {
                painter.text(
                    center,
                    egui::Align2::CENTER_CENTER,
                    rank_str,
                    egui::FontId::proportional(radius * 1.18),
                    text_col,
                );
            }
            PieceSet::Letters => {
                let main_pos = egui::pos2(center.x - radius * 0.10, center.y - radius * 0.02);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_letter(kind),
                    egui::FontId::proportional(radius * 1.08),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.56, center.y + radius * 0.52);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.48).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Unicode => {
                let main_pos = egui::pos2(center.x - radius * 0.08, center.y - radius * 0.03);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_unicode_symbol(kind),
                    egui::FontId::proportional(radius * 1.12),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.58, center.y + radius * 0.54);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.44).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Animals => {
                // Self-contained vector animal silhouettes (zero font dependencies!)
                let art_center = egui::pos2(center.x - radius * 0.08, center.y - radius * 0.05);
                draw_animal_icon(painter, art_center, radius * 0.58, kind, text_col, fill);
                let num_pos = egui::pos2(center.x + radius * 0.62, center.y + radius * 0.58);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.45).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Chinese => {
                // Self-contained vector Chinese characters 象獅虎豹狼狗貓鼠 (zero font dependencies!)
                let art_center = egui::pos2(center.x - radius * 0.10, center.y - radius * 0.04);
                draw_chinese_char(painter, art_center, radius * 0.54, kind, text_col);
                let num_pos = egui::pos2(center.x + radius * 0.62, center.y + radius * 0.58);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.45).max(8.0)),
                    text_col,
                );
            }
        }
    }

    fn handle_global_shortcuts(&mut self, ctx: &egui::Context) {
        let (f1_pressed, esc_pressed) = ctx.input(|i| {
            (
                i.key_pressed(egui::Key::F1),
                i.key_pressed(egui::Key::Escape),
            )
        });

        if f1_pressed {
            self.show_help_window = !self.show_help_window;
            return;
        }

        if esc_pressed {
            if self.show_help_window {
                self.show_help_window = false;
            } else if self.show_hof_window {
                self.show_hof_window = false;
            } else if self.show_quit_confirm {
                self.show_quit_confirm = false;
            } else if self.show_enter_ironman_confirm {
                self.show_enter_ironman_confirm = false;
            } else if self.show_ironman_setup_confirm {
                self.show_ironman_setup_confirm = false;
            } else if self.show_new_game_leave_ironman_confirm {
                self.show_new_game_leave_ironman_confirm = false;
            } else if self.pending_hof_record.is_none() && self.pending_import_confirm.is_none() {
                // On the main screen with no open modal: Esc asks quit confirmation
                self.show_quit_confirm = true;
            }
        }
    }

    fn ui_rules_help_window(&mut self, ctx: &egui::Context, pal: &Palette) {
        if !self.show_help_window {
            return;
        }

        let mut open = true;
        let title = format!("Rules & Help — {}  [Esc to close]", self.variant.display_name());

        egui::Window::new(title)
            .open(&mut open)
            .resizable(true)
            .default_size([620.0, 520.0])
            .min_size([440.0, 320.0])
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        ui.heading(format!("Current Mode: {}", self.variant.display_name()));
                        ui.add_space(4.0);

                        // Mode-specific core rules first
                        egui::Frame::none()
                            .fill(pal.panel_card_bg)
                            .rounding(egui::Rounding::same(6.0))
                            .inner_margin(egui::Margin::same(10.0))
                            .show(ui, |ui| match self.variant {
                                GameVariant::EpSuperKo => {
                                    ui.strong("EP + SuperKo Rules (Active Mode)");
                                    ui.label("• Starting Energy Points (EP): P1 starts with 4 EP, P2 starts with 5 EP (max 10 EP).");
                                    ui.label("• SuperKo Repetition: Repeating ANY prior board piece layout (ignoring side-to-move and EP) costs 1 EP.");
                                    ui.label("• With 0 EP, repeating any prior position is ILLEGAL.");
                                    ui.label("• Gaining EP: At the start of your turn, if you already have at least 1 piece on a LAND tile in the opponent's last 4 rows, you gain +1 EP (capped at 10) before moving.");
                                    ui.label("• Water Captures: Captures are strictly same-medium only (land→land or water→water).");
                                }
                                GameVariant::ClassicSuperKo => {
                                    ui.colored_label(
                                        pal.classic_accent,
                                        egui::RichText::new("Classic SuperKo Rules — Arimaa 3-Fold Ban (Active Mode)").strong(),
                                    );
                                    ui.label("• No Energy Points (EP) are used in this mode.");
                                    ui.label("• 3rd-Occurrence Ban: A move that would recreate any prior (board layout + same side-to-move) state for the 3rd time is ILLEGAL.");
                                    ui.label("• A 2nd occurrence is allowed (marked with '*' in the Move List).");
                                    ui.label("• Water Captures: Captures are strictly same-medium only (land→land or water→water).");
                                }
                                GameVariant::MonsterRats => {
                                    ui.colored_label(
                                        pal.rats_accent,
                                        egui::RichText::new("Monster Rats Rules (Active Mode)").strong(),
                                    );
                                    ui.label("• MONSTER RAT AMBUSH: A Rat standing in WATER CAN directly capture adjacent enemy Elephants and enemy Rats on LAND!");
                                    ui.label("• WATER SANCTUARY: Capturing FROM land INTO water is STILL FORBIDDEN — land Rats and all other land pieces cannot attack a Rat inside water!");
                                    ui.label("• Uses full EP + SuperKo rules: P1 starts with 4 EP, P2 with 5 EP (max 10 EP); repeating any prior board layout costs 1 EP (illegal at 0 EP); land piece in opponent's last 4 rows grants +1 EP at start of turn.");
                                }
                            });

                        ui.add_space(10.0);
                        ui.heading("Core Dou Shou Qi Rules");
                        ui.label("• Win Conditions: (G) Reach the opponent's Den, (E) Capture all opponent pieces, or (M) Leave the opponent with zero legal moves.");
                        ui.label("• Piece Ranks (strongest to weakest): 8 Elephant (E) > 7 Lion (L) > 6 Tiger (T) > 5 Leopard (P) > 4 Wolf (W) > 3 Dog (D) > 2 Cat (C) > 1 Rat (R).");
                        ui.label("• Equal rank captures equal rank. Special rule: Rat (1) captures Elephant (8), while Elephant (8) CANNOT capture Rat (1) unless the Rat is trapped.");
                        ui.label("• Movement: All pieces move 1 square orthogonally. No piece may enter its own Den.");
                        ui.label("• Water & River Jumping: Only Rats may enter water tiles (~). Lions and Tigers may jump orthogonally across water onto the opposite bank, UNLESS any Rat (friendly or enemy) sits in the intervening water squares.");
                        ui.label("• Traps: Stepping onto an opponent's Trap (#) weakens that piece to strength 0 (capturable by ANY enemy piece, including Elephant vs trapped Rat, and unable to capture out of the trap). Your own traps do not weaken your own pieces.");

                        ui.add_space(10.0);
                        ui.heading("IronMan Challenge Mode");
                        ui.label("• You always play as P2 (second mover) against the engine at Depth >= 12.");
                        ui.label("• Undo/Redo, Switch Sides, Show Legal Moves, Show Thinking, Stop, Max Time, and engine evaluation are disabled.");
                        ui.label("• Depth may be increased mid-game, never decreased; Hall of Fame ranks strictly by starting depth.");
                        ui.label("• Qualifying finished games enter the encrypted Top-50 Hall of Fame (max 5 per depth).");
                        ui.label("• Leave IronMan Mode anytime via 'New Game' or 'Setup Board' (both ask confirmation).");

                        ui.add_space(10.0);
                        ui.heading("Controls & Shortcuts");
                        ui.label("• [F1]   Toggle this Rules & Help window.");
                        ui.label("• [Esc]  Close active Help/Dialog window, or open Quit Confirmation on the main screen.");
                        ui.label("• Setup Mode: Left-click = selected color, Right-click = opposite color, Left+Right (or Middle-click) = remove piece.");
                    });
            });

        if !open {
            self.show_help_window = false;
        }
    }

    fn ui_enter_ironman_confirm(&mut self, ctx: &egui::Context, pal: &Palette) {
        if !self.show_enter_ironman_confirm {
            return;
        }

        let mut start_confirmed = false;
        let mut cancelled = false;

        egui::Window::new("Start IronMan Challenge?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.colored_label(
                    pal.ironman_accent,
                    egui::RichText::new(format!(
                        "Enter IronMan Mode ({})",
                        self.variant.display_name()
                    ))
                    .strong(),
                );
                ui.add_space(4.0);
                ui.label("In IronMan Mode, you always play as P2 (second mover) and the following aids are disabled:");
                ui.small("• Undo / Redo, Switch Sides, Show Legal Moves, Show Thinking, Stop, Max Time, and Eval scores.");
                ui.small("• Your current normal game (if any) will be auto-saved safely.");
                ui.add_space(8.0);

                ui.horizontal(|ui| {
                    ui.label("Starting IronMan Depth (>= 12):");
                    if ui.small_button("-").clicked()
                        && self.enter_ironman_depth_choice > MIN_IRONMAN_DEPTH
                    {
                        self.enter_ironman_depth_choice -= 1;
                    }
                    ui.add(
                        egui::Slider::new(
                            &mut self.enter_ironman_depth_choice,
                            MIN_IRONMAN_DEPTH..=MAX_GUI_DEPTH,
                        )
                        .show_value(true)
                        .clamping(egui::SliderClamping::Always),
                    );
                    if ui.small_button("+").clicked()
                        && self.enter_ironman_depth_choice < MAX_GUI_DEPTH
                    {
                        self.enter_ironman_depth_choice += 1;
                    }
                });

                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("⚔ Start IronMan Mode").clicked() {
                        start_confirmed = true;
                    }
                    if ui.button("Cancel").clicked() {
                        cancelled = true;
                    }
                });
                ui.add_space(4.0);
            });

        if start_confirmed {
            self.show_enter_ironman_confirm = false;
            let d = self.enter_ironman_depth_choice;
            self.enter_ironman_mode(d, ctx);
        } else if cancelled {
            self.show_enter_ironman_confirm = false;
        }
    }

    fn ui_new_game_leave_ironman_confirm(&mut self, ctx: &egui::Context) {
        if !self.show_new_game_leave_ironman_confirm {
            return;
        }

        let mut leave_confirmed = false;
        let mut cancelled = false;

        egui::Window::new("Leave IronMan Mode?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.label("Starting a new game will END IronMan Mode and return to standard (non-IronMan) mode.");
                ui.small("Any unfinished IronMan run will not be recorded in the Hall of Fame.");
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Leave IronMan & Start Normal Game").clicked() {
                        leave_confirmed = true;
                    }
                    if ui.button("Stay in IronMan Mode").clicked() {
                        cancelled = true;
                    }
                });
                ui.add_space(4.0);
            });

        if leave_confirmed {
            self.show_new_game_leave_ironman_confirm = false;
            self.leave_ironman_to_new_normal_game(ctx);
        } else if cancelled {
            self.show_new_game_leave_ironman_confirm = false;
        }
    }

    fn ui_import_overwrite_confirm(&mut self, ctx: &egui::Context) {
        let Some((req, summary)) = self.pending_import_confirm.clone() else {
            return;
        };

        let mut choice: Option<bool> = None;

        egui::Window::new("Existing Saved Game Found")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.strong(format!(
                    "Importing '{}' will overwrite your existing saved {} game!",
                    req.filename,
                    self.variant.display_name()
                ));
                ui.add_space(6.0);
                ui.label(format!(
                    "Previous saved game: {} moves ({} plies){}",
                    summary.moves,
                    summary.plies,
                    if summary.is_custom { " [custom setup]" } else { "" }
                ));
                ui.label(format!(
                    "Previous settings: Depth {}  |  Max Time: {}",
                    summary.depth,
                    format_time_limit(summary.time_limit)
                ));
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Overwrite & Import").clicked() {
                        choice = Some(true);
                    }
                    if ui.button("Cancel (Keep Saved Game)").clicked() {
                        choice = Some(false);
                    }
                });
                ui.add_space(4.0);
            });

        if let Some(do_overwrite) = choice {
            self.pending_import_confirm = None;
            if do_overwrite {
                self.apply_import(req);
            } else if self.try_autoload(ctx) {
                self.apply_theme(ctx);
            }
        }
    }

    fn ui_hof_name_prompt(&mut self, ctx: &egui::Context, pal: &Palette) {
        let Some((entry, rank)) = self.pending_hof_record.clone() else {
            return;
        };

        let mut submit = false;
        let outcome_str = if entry.human_won { "VICTORY" } else { "DEFEAT" };
        let title = if rank == 1 {
            "New #1 Hall of Fame Record!"
        } else {
            "New Hall of Fame Record!"
        };

        egui::Window::new(title)
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                let rank_color = if entry.human_won {
                    pal.ep_gain_badge
                } else {
                    pal.ironman_accent
                };
                ui.colored_label(
                    rank_color,
                    egui::RichText::new(format!(
                        "Congratulations! You qualified for Hall of Fame Rank #{}!",
                        rank
                    ))
                    .strong(),
                );
                ui.add_space(4.0);
                ui.monospace(format!(
                    "{} | {} | {} moves | Army {} | {}",
                    outcome_str,
                    entry.formatted_depth(),
                    entry.moves,
                    entry.army_strength,
                    entry.end_code.label()
                ));
                ui.add_space(8.0);
                ui.label("Enter your name for the Hall of Fame:");
                let resp = ui.add(
                    egui::TextEdit::singleline(&mut self.hof_name_input)
                        .char_limit(MAX_PLAYER_NAME_LEN)
                        .desired_width(260.0)
                        .hint_text("Your name (or blank for Anonymous)"),
                );
                if resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                    submit = true;
                }
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    if ui.button("Save to Hall of Fame").clicked() {
                        submit = true;
                    }
                });
                ui.add_space(4.0);
            });

        if submit {
            self.commit_pending_hof_record();
        }
    }

    fn ui_quit_confirmation(&mut self, ctx: &egui::Context) {
        if !self.show_quit_confirm {
            return;
        }

        let in_ironman = self.is_ironman();
        let running = self.has_running_game();
        egui::Window::new("Confirm Quit")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                if in_ironman {
                    ui.label("Are you sure you want to quit IronMan Mode?");
                    if running {
                        ui.small("This unfinished IronMan run will NOT be saved.");
                    }
                } else if running {
                    ui.label("Are you sure you want to quit?");
                    ui.small("Your running game will be auto-saved and restored next time you open this mode.");
                } else {
                    ui.label("Are you sure you want to quit Dou Shou Qi?");
                }
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    let quit_label = if !in_ironman && running {
                        "Save & Quit"
                    } else {
                        "Quit"
                    };
                    if ui.button(quit_label).clicked() {
                        self.cancel_search();
                        self.save_autosave();
                        self.allow_close = true;
                        self.show_quit_confirm = false;
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                    if !in_ironman && running && ui.button("Quit Without Saving").clicked() {
                        self.cancel_search();
                        let _ = std::fs::remove_file(self.variant.autosave_path());
                        self.allow_close = true;
                        self.show_quit_confirm = false;
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                    if ui.button("Cancel").clicked() {
                        self.show_quit_confirm = false;
                    }
                });
                ui.add_space(4.0);
            });
    }

    fn ui_ironman_setup_confirm(&mut self, ctx: &egui::Context) {
        if !self.show_ironman_setup_confirm {
            return;
        }

        egui::Window::new("Leave IronMan Mode?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.label("Opening Setup Mode for analysis will permanently END IronMan Mode for this session.");
                ui.small("This game will not be eligible for the IronMan Hall of Fame.");
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("End IronMan & Open Setup").clicked() {
                        self.show_ironman_setup_confirm = false;
                        self.ironman = None;
                        self.show_legal_moves = true;
                        self.update_window_title(ctx);
                        self.enter_setup();
                    }
                    if ui.button("Stay in IronMan Mode").clicked() {
                        self.show_ironman_setup_confirm = false;
                    }
                });
                ui.add_space(4.0);
            });
    }

    fn ui_hall_of_fame_window(&mut self, ctx: &egui::Context, pal: &Palette) {
        if !self.show_hof_window {
            return;
        }

        let mut open = true;
        let mut reload_clicked = false;
        let title = format!("IronMan Hall of Fame — {}", self.variant.display_name());

        egui::Window::new(title)
            .open(&mut open)
            .resizable(true)
            .default_size([740.0, 440.0])
            .min_size([560.0, 260.0])
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.strong(format!(
                        "Encrypted {} IronMan Top {} (max {} per start depth)",
                        self.variant.display_name(),
                        MAX_TOTAL_ENTRIES,
                        MAX_ENTRIES_PER_DEPTH
                    ));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button("Reload").clicked() {
                            reload_clicked = true;
                        }
                    });
                });

                ui.small("Ranking: Wins > Defeats  |  Higher start depth  |  Moves (shorter win / longer defeat)  |  Surviving Army");
                ui.small("End-codes: G = Goal (Den reached) | E = Elimination (all pieces captured) | M = Immobilization (no legal moves)");
                if let Some(err) = &self.hof_status {
                    ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", err));
                }
                ui.separator();

                let wins = self.hof.entries.iter().filter(|e| e.human_won).count();
                let losses = self.hof.entries.len() - wins;
                ui.label(format!(
                    "Entries: {}/{}  |  Wins: {}  |  Defeats: {}",
                    self.hof.entries.len(),
                    MAX_TOTAL_ENTRIES,
                    wins,
                    losses
                ));
                ui.add_space(6.0);

                if self.hof.entries.is_empty() {
                    let hint = match self.variant {
                        GameVariant::EpSuperKo => {
                            "No completed EP IronMan games yet. Click '⚔ IronMan' or launch with: dsq_engine ironman [depth>=12]"
                        }
                        GameVariant::ClassicSuperKo => {
                            "No completed Classic IronMan games yet. Click '⚔ IronMan' or launch with: dsq_engine classic_superKo ironman [depth>=12]"
                        }
                        GameVariant::MonsterRats => {
                            "No completed Monster Rats IronMan games yet. Click '⚔ IronMan' or launch with: dsq_engine monster_rats ironman [depth>=12]"
                        }
                    };
                    ui.colored_label(pal.coord_text, hint);
                } else {
                    egui::ScrollArea::vertical()
                        .auto_shrink([false, false])
                        .show(ui, |ui| {
                            egui::Grid::new("hof_combined_grid")
                                .striped(true)
                                .spacing([12.0, 5.0])
                                .show(ui, |ui| {
                                    ui.strong("#");
                                    ui.strong("Player");
                                    ui.strong("Result");
                                    ui.strong("Depth");
                                    ui.strong("Moves");
                                    ui.strong("Army");
                                    ui.strong("Code");
                                    ui.strong("Date (UTC)");
                                    ui.end_row();

                                    for (idx, e) in self.hof.entries.iter().enumerate() {
                                        ui.monospace(format!("{:>2}", idx + 1));
                                        ui.label(&e.player_name);
                                        if e.human_won {
                                            ui.colored_label(
                                                pal.ep_gain_badge,
                                                egui::RichText::new("WIN").strong(),
                                            );
                                        } else {
                                            ui.colored_label(
                                                pal.ep_zero_warn,
                                                egui::RichText::new("LOSS").strong(),
                                            );
                                        }
                                        ui.monospace(e.formatted_depth());
                                        ui.monospace(format!("{} ({}p)", e.moves, e.plies));
                                        ui.monospace(format!("{:>4}", e.army_strength));
                                        ui.monospace(e.end_code.label());
                                        ui.monospace(e.formatted_date_utc());
                                        ui.end_row();
                                    }
                                });
                        });
                }
            });

        if reload_clicked {
            match HallOfFame::load_from_path(&self.variant.hof_path()) {
                Ok(h) => {
                    self.hof = h;
                    self.hof_status = None;
                }
                Err(e) => self.hof_status = Some(e),
            }
        }
        if !open {
            self.show_hof_window = false;
        }
    }

    fn ui_top_toolbar(&mut self, ctx: &egui::Context, pal: &Palette) {
        let in_setup = self.is_setup();
        let in_ironman = self.is_ironman();
        let mut switch_to_variant: Option<GameVariant> = None;

        egui::TopBottomPanel::top("top_toolbar").show(ctx, |ui| {
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing.x = 7.0;

                // Mode selector menu (switches cleanly between the 3 non-IronMan modes)
                if !in_setup {
                    ui.add_enabled_ui(!in_ironman, |ui| {
                        let mode_label = format!("Mode: {} ▾", self.variant.display_name());
                        ui.menu_button(mode_label, |ui| {
                            for v in GameVariant::ALL {
                                let selected = self.variant == v;
                                if ui.selectable_label(selected, v.display_name()).clicked() {
                                    if !selected {
                                        switch_to_variant = Some(v);
                                    }
                                    ui.close_menu();
                                }
                            }
                        });
                    });

                    // IronMan badge or button to enter IronMan Mode (with confirmation)
                    if in_ironman {
                        ui.colored_label(
                            pal.ironman_accent,
                            egui::RichText::new("⚔ IRONMAN").strong(),
                        );
                    } else if ui
                        .button("⚔ IronMan")
                        .on_hover_text("Enter competitive IronMan Mode (Depth >= 12, P2 vs Engine)")
                        .clicked()
                    {
                        self.enter_ironman_depth_choice =
                            self.search_depth.clamp(MIN_IRONMAN_DEPTH, MAX_GUI_DEPTH);
                        self.show_enter_ironman_confirm = true;
                    }
                    ui.separator();
                }

                if in_setup {
                    let valid = self
                        .setup
                        .as_ref()
                        .map(|s| s.validate().is_ok())
                        .unwrap_or(false);
                    if ui
                        .add_enabled(valid, egui::Button::new("✓ End Setup"))
                        .clicked()
                    {
                        self.finish_setup(ctx);
                        return;
                    }
                    if ui.button("✕ Cancel Setup").clicked() {
                        self.cancel_setup();
                        return;
                    }
                    if ui.button("Clear Board").clicked() {
                        if let Some(s) = &mut self.setup {
                            s.clear_board();
                        }
                    }
                    if ui.button("Reset Start").clicked() {
                        if let Some(s) = &mut self.setup {
                            s.reset_start();
                        }
                    }
                } else {
                    if ui.button("New Game").clicked() {
                        if in_ironman {
                            self.show_new_game_leave_ironman_confirm = true;
                        } else {
                            self.new_game(ctx);
                        }
                    }

                    let can_undo = !in_ironman && !self.undo_stack.is_empty();
                    if ui.add_enabled(can_undo, egui::Button::new("Undo")).clicked() {
                        self.undo_move();
                    }

                    let can_redo = !in_ironman && !self.redo_stack.is_empty();
                    if ui.add_enabled(can_redo, egui::Button::new("Redo")).clicked() {
                        self.redo_move();
                    }

                    if ui.button("Setup Board").clicked() {
                        if in_ironman {
                            self.show_ironman_setup_confirm = true;
                        } else {
                            self.enter_setup();
                            return;
                        }
                    }

                    if ui
                        .add_enabled(
                            !in_ironman,
                            egui::Button::new(format!("Switch Sides ({})", self.human_side)),
                        )
                        .clicked()
                    {
                        self.switch_sides(ctx);
                    }
                }

                if ui
                    .button(format!("Rotate ↻ ({}°)", self.rotation as u16 * 90))
                    .clicked()
                {
                    self.rotation = (self.rotation + 1) % 4;
                }

                if ui.button("Hall of Fame").clicked() {
                    self.show_hof_window = !self.show_hof_window;
                }

                // Compact Pieces dropdown menu (frees up toolbar space!)
                let pieces_btn = format!("Pieces: {} ▾", self.piece_set.label());
                ui.menu_button(pieces_btn, |ui| {
                    for ps in PieceSet::ALL {
                        let selected = self.piece_set == ps;
                        if ui.selectable_label(selected, ps.label()).clicked() {
                            self.piece_set = ps;
                            ui.close_menu();
                        }
                    }
                });

                let theme_label = match self.theme {
                    ColorTheme::Night => "Night",
                    ColorTheme::Day => "Day",
                };
                if ui.button(theme_label).clicked() {
                    self.theme = match self.theme {
                        ColorTheme::Night => ColorTheme::Day,
                        ColorTheme::Day => ColorTheme::Night,
                    };
                    self.apply_theme(ctx);
                }

                if ui
                    .button("? Help (F1)")
                    .on_hover_text("Show rules for current game mode (F1)")
                    .clicked()
                {
                    self.show_help_window = !self.show_help_window;
                }

                ui.separator();

                let min_depth = self
                    .ironman
                    .as_ref()
                    .map(|im| im.min_depth)
                    .unwrap_or(1);

                ui.label("Depth:");
                let can_dec = !in_ironman && self.search_depth > 1;
                if ui.add_enabled(can_dec, egui::Button::new("-").small()).clicked() {
                    self.search_depth -= 1;
                }
                ui.add(
                    egui::Slider::new(&mut self.search_depth, min_depth..=MAX_GUI_DEPTH)
                        .show_value(true)
                        .clamping(egui::SliderClamping::Always),
                );
                if ui
                    .add_enabled(
                        self.search_depth < MAX_GUI_DEPTH,
                        egui::Button::new("+").small(),
                    )
                    .clicked()
                {
                    self.search_depth += 1;
                }

                if let Some(im) = &mut self.ironman {
                    if self.search_depth < im.min_depth {
                        self.search_depth = im.min_depth;
                    } else if self.search_depth > im.min_depth {
                        im.min_depth = self.search_depth;
                    }
                }

                ui.separator();

                if in_ironman {
                    self.time_limit_idx = UNLIMITED_TIME_IDX;
                }
                ui.label("Max Time:");
                ui.add_enabled_ui(!in_ironman, |ui| {
                    if ui
                        .add_enabled(self.time_limit_idx > 0, egui::Button::new("-").small())
                        .clicked()
                    {
                        self.time_limit_idx -= 1;
                    }
                    ui.add(
                        egui::Slider::new(&mut self.time_limit_idx, 0..=UNLIMITED_TIME_IDX)
                            .custom_formatter(|n, _| {
                                let idx = (n.round() as usize).min(UNLIMITED_TIME_IDX);
                                format_time_limit(TIME_PRESETS_SECS[idx])
                            })
                            .clamping(egui::SliderClamping::Always),
                    );
                    if ui
                        .add_enabled(
                            self.time_limit_idx < UNLIMITED_TIME_IDX,
                            egui::Button::new("+").small(),
                        )
                        .clicked()
                    {
                        self.time_limit_idx += 1;
                    }
                });

                if !in_setup {
                    let can_stop = !in_ironman
                        && self
                            .pending_search
                            .as_ref()
                            .map(|p| !p.stop_requested)
                            .unwrap_or(false);
                    if ui
                        .add_enabled(can_stop, egui::Button::new("⏹ Stop"))
                        .on_hover_text("Stop thinking and immediately play best move found so far")
                        .clicked()
                    {
                        self.request_stop_and_play();
                    }

                    ui.separator();
                    if in_ironman {
                        self.show_legal_moves = false;
                        self.show_thinking = false;
                    }
                    ui.add_enabled(
                        !in_ironman,
                        egui::Checkbox::new(&mut self.show_legal_moves, "Legal Moves"),
                    );
                    let think_label = if self.show_thinking {
                        "Show Thinking: ON"
                    } else {
                        "Show Thinking: OFF"
                    };
                    if ui
                        .add_enabled(
                            !in_ironman,
                            egui::SelectableLabel::new(self.show_thinking, think_label),
                        )
                        .on_hover_text(
                            "Highlight engine's current best move and live evaluation while thinking",
                        )
                        .clicked()
                    {
                        self.show_thinking = !self.show_thinking;
                    }
                }
            });
            ui.add_space(4.0);
        });

        if let Some(new_v) = switch_to_variant {
            self.switch_variant(new_v, ctx);
        }
    }

    fn ui_ep_grid_row(
        &self,
        ui: &mut egui::Ui,
        side: Color,
        ep: u8,
        gaining: bool,
        is_turn: bool,
        pal: &Palette,
    ) {
        let fill_color = match side {
            Color::P1 => pal.p1_fill,
            Color::P2 => pal.p2_fill,
        };
        let label_text = match side {
            Color::P1 => "P1",
            Color::P2 => "P2",
        };

        ui.horizontal(|ui| {
            let tag = if is_turn {
                format!("▶ {}:", label_text)
            } else {
                format!("   {}:", label_text)
            };
            ui.colored_label(fill_color, egui::RichText::new(tag).strong().monospace());

            let count_color = if ep == 0 {
                pal.ep_zero_warn
            } else {
                pal.badge_text
            };
            ui.colored_label(
                count_color,
                egui::RichText::new(format!("{:>2}/{}", ep, MAX_EP))
                    .monospace()
                    .strong(),
            );

            if gaining {
                ui.colored_label(
                    pal.ep_gain_badge,
                    egui::RichText::new("+1/turn").small().strong(),
                );
            } else if ep == 0 {
                ui.colored_label(
                    pal.ep_zero_warn,
                    egui::RichText::new("NO REPEAT").small().strong(),
                );
            }
        });

        let cells = MAX_EP as usize;
        let avail_w = ui.available_width().max(120.0);
        let cell_h = 15.0;
        let gap = 2.0;
        let cell_w = ((avail_w - gap * (cells as f32 - 1.0)) / cells as f32).max(8.0);

        let (rect, _) =
            ui.allocate_exact_size(egui::vec2(avail_w, cell_h), egui::Sense::hover());
        let painter = ui.painter_at(rect);

        for i in 0..cells {
            let x0 = rect.left() + i as f32 * (cell_w + gap);
            let cell_rect = egui::Rect::from_min_size(
                egui::pos2(x0, rect.top()),
                egui::vec2(cell_w, cell_h),
            );
            let filled = (i as u8) < ep;
            let bg = if filled {
                fill_color
            } else {
                pal.ep_empty_cell
            };
            let stroke_col = if ep == 0 {
                pal.ep_zero_warn
            } else {
                pal.ep_grid_border
            };

            painter.rect_filled(cell_rect, egui::Rounding::same(2.5), bg);
            painter.rect_stroke(
                cell_rect,
                egui::Rounding::same(2.5),
                egui::Stroke::new(1.0, stroke_col),
            );
        }
    }

    fn ui_right_panel(&mut self, ctx: &egui::Context, pal: &Palette) {
        egui::SidePanel::right("right_panel")
            .resizable(true)
            .default_width(315.0)
            .min_width(235.0)
            .max_width(540.0)
            .show(ctx, |ui| {
                ui.add_space(6.0);

                if self.is_setup() {
                    self.ui_right_panel_setup(ctx, ui, pal);
                } else {
                    self.ui_right_panel_play(ui, pal);
                }
            });
    }

    fn ui_right_panel_play(&mut self, ui: &mut egui::Ui, pal: &Palette) {
        let thinking = self.visible_thinking();

        egui::Frame::none()
            .fill(pal.panel_card_bg)
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(egui::Margin::same(8.0))
            .show(ui, |ui| {
                if let Some(im) = &self.ironman {
                    ui.colored_label(
                        pal.ironman_accent,
                        egui::RichText::new(format!(
                            "IRONMAN {} (Start d{}, Current d{})",
                            self.variant.display_name(),
                            im.start_depth,
                            self.search_depth
                        ))
                        .strong()
                        .small(),
                    );
                }

                let result = self.state.game_result();
                let status_line = match result {
                    GameResult::Win(w) => format!("GAME OVER: {} WINS!", w),
                    GameResult::Ongoing => {
                        if let Some(p) = &self.pending_search {
                            format!(
                                "Turn: {} (Engine thinking {:.1}s...)",
                                self.state.side_to_move(),
                                p.started_at.elapsed().as_secs_f32()
                            )
                        } else {
                            format!("Turn: {} (Your move)", self.state.side_to_move())
                        }
                    }
                };
                ui.strong(status_line);
                ui.small(&self.last_engine_info);

                if let Some(tp) = thinking {
                    ui.add_space(4.0);
                    ui.colored_label(
                        pal.thinking_accent,
                        egui::RichText::new(format!(
                            "Thinking: {}  |  eval {}  |  d{} ({} nodes)",
                            tp.best_move,
                            format_score(tp.score),
                            tp.depth,
                            tp.nodes
                        ))
                        .monospace()
                        .strong()
                        .small(),
                    );
                }

                if self.variant == GameVariant::MonsterRats {
                    ui.add_space(4.0);
                    ui.colored_label(
                        pal.rats_accent,
                        egui::RichText::new("Monster Rats: Water → Land ambush active!")
                            .strong()
                            .small(),
                    );
                }

                if self.variant.uses_ep() {
                    ui.add_space(6.0);
                    ui.label(egui::RichText::new("Energy Points (EP)").strong());
                    ui.add_space(2.0);
                    let ep = self.state.ep();
                    let p1_gain = (self.state.occ_side(0) & INVASION_LAND_MASK[0]) != 0;
                    let p2_gain = (self.state.occ_side(1) & INVASION_LAND_MASK[1]) != 0;
                    let ongoing = self.state.winner().is_none();
                    self.ui_ep_grid_row(
                        ui,
                        Color::P1,
                        ep[0],
                        p1_gain,
                        self.state.side_to_move() == Color::P1 && ongoing,
                        pal,
                    );
                    ui.add_space(5.0);
                    self.ui_ep_grid_row(
                        ui,
                        Color::P2,
                        ep[1],
                        p2_gain,
                        self.state.side_to_move() == Color::P2 && ongoing,
                        pal,
                    );
                } else {
                    ui.add_space(6.0);
                    ui.colored_label(
                        pal.classic_accent,
                        egui::RichText::new("Classic SuperKo (Arimaa 3-Fold Ban)").strong(),
                    );
                    ui.small("No EP. Repeating a position (same side to move) for the 3rd time is illegal.");
                }
            });

        ui.add_space(8.0);

        ui.heading("Piece Graveyard");
        egui::Frame::none()
            .fill(pal.panel_card_bg)
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(egui::Margin::same(8.0))
            .show(ui, |ui| {
                let sqs = self.state.piece_sq();
                self.ui_piece_tray_row(ui, &sqs, Color::P1, "Captured P1:", false, pal);
                ui.add_space(6.0);
                self.ui_piece_tray_row(ui, &sqs, Color::P2, "Captured P2:", false, pal);
            });

        ui.add_space(10.0);

        ui.horizontal(|ui| {
            ui.heading("Move List");
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                let copied_active = self
                    .copied_until
                    .map(|t| Instant::now() < t)
                    .unwrap_or(false);
                let btn_text = if copied_active { "Copied!" } else { "Copy" };
                if ui.button(btn_text).clicked() {
                    let text = self.format_movelist_for_export();
                    ui.ctx().copy_text(text);
                    self.copied_until = Some(Instant::now() + std::time::Duration::from_secs(2));
                }
            });
        });

        let legend = if self.variant.uses_ep() {
            "(* = paid 1 EP for SuperKo repetition, x = capture)"
        } else {
            "(* = 2nd identical occurrence, x = capture)"
        };
        ui.small(legend);
        ui.add_space(4.0);

        let movelist_str = self.format_movelist();
        let mut ro_str: &str = if movelist_str.is_empty() {
            "(No moves played yet)"
        } else {
            &movelist_str
        };

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .stick_to_bottom(true)
            .show(ui, |ui| {
                ui.add_sized(
                    ui.available_size(),
                    egui::TextEdit::multiline(&mut ro_str)
                        .font(egui::TextStyle::Monospace)
                        .desired_width(f32::INFINITY),
                );
            });
    }

    fn ui_right_panel_setup(&mut self, ctx: &egui::Context, ui: &mut egui::Ui, pal: &Palette) {
        let mut finish_clicked = false;
        let mut cancel_clicked = false;
        let mut picked_from_reservoir: Option<(Color, PieceKind)> = None;
        let uses_ep = self.variant.uses_ep();

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                let (ep_p1, ep_p2, p1_gain, p2_gain, stm, status_msg, validation) = {
                    let s = self.setup.as_ref().unwrap();
                    (
                        s.ep[0],
                        s.ep[1],
                        (s.side_occ(0) & INVASION_LAND_MASK[0]) != 0,
                        (s.side_occ(1) & INVASION_LAND_MASK[1]) != 0,
                        s.side_to_move,
                        s.status_msg.clone(),
                        s.validate(),
                    )
                };

                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        ui.colored_label(
                            pal.setup_banner,
                            egui::RichText::new(format!(
                                "SETUP MODE ({})",
                                self.variant.display_name()
                            ))
                            .strong()
                            .size(15.0),
                        );
                        ui.small(&status_msg);

                        if uses_ep {
                            ui.add_space(6.0);
                            ui.label(egui::RichText::new("Configure Energy Points (EP)").strong());
                            ui.add_space(2.0);
                            self.ui_ep_grid_row(
                                ui,
                                Color::P1,
                                ep_p1,
                                p1_gain,
                                stm == Color::P1,
                                pal,
                            );
                            ui.horizontal(|ui| {
                                ui.small("P1 EP:");
                                let s = self.setup.as_mut().unwrap();
                                if ui.small_button("-").clicked() && s.ep[0] > 0 {
                                    s.ep[0] -= 1;
                                }
                                ui.add(
                                    egui::Slider::new(&mut s.ep[0], 0..=MAX_EP)
                                        .show_value(false)
                                        .clamping(egui::SliderClamping::Always),
                                );
                                if ui.small_button("+").clicked() && s.ep[0] < MAX_EP {
                                    s.ep[0] += 1;
                                }
                            });

                            ui.add_space(4.0);
                            self.ui_ep_grid_row(
                                ui,
                                Color::P2,
                                ep_p2,
                                p2_gain,
                                stm == Color::P2,
                                pal,
                            );
                            ui.horizontal(|ui| {
                                ui.small("P2 EP:");
                                let s = self.setup.as_mut().unwrap();
                                if ui.small_button("-").clicked() && s.ep[1] > 0 {
                                    s.ep[1] -= 1;
                                }
                                ui.add(
                                    egui::Slider::new(&mut s.ep[1], 0..=MAX_EP)
                                        .show_value(false)
                                        .clamping(egui::SliderClamping::Always),
                                );
                                if ui.small_button("+").clicked() && s.ep[1] < MAX_EP {
                                    s.ep[1] += 1;
                                }
                            });
                        } else {
                            ui.add_space(4.0);
                            ui.colored_label(
                                pal.classic_accent,
                                "Classic SuperKo: No EP reserves (3rd identical position banned).",
                            );
                        }
                    });

                ui.add_space(8.0);

                ui.heading("Piece Reservoir");
                ui.small("Unplaced pieces (click any piece to select it as your brush):");
                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        let sqs = self.setup.as_ref().unwrap().piece_sq;
                        if let Some(k) =
                            self.ui_piece_tray_row(ui, &sqs, Color::P1, "P1 Reservoir:", true, pal)
                        {
                            picked_from_reservoir = Some((Color::P1, k));
                        }
                        ui.add_space(6.0);
                        if let Some(k) =
                            self.ui_piece_tray_row(ui, &sqs, Color::P2, "P2 Reservoir:", true, pal)
                        {
                            picked_from_reservoir = Some((Color::P2, k));
                        }
                    });

                ui.add_space(8.0);

                ui.heading("Setup Controls");
                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        {
                            let s = self.setup.as_mut().unwrap();

                            ui.horizontal(|ui| {
                                ui.label("Left-click color:");
                                ui.selectable_value(&mut s.brush_color, Color::P1, "P1");
                                ui.selectable_value(&mut s.brush_color, Color::P2, "P2");
                            });
                            ui.small(format!(
                                "(Right-click places {}; L+R click or Middle-click removes)",
                                s.brush_color.opp()
                            ));

                            ui.add_space(6.0);
                            ui.label("Select piece to place:");
                            ui.horizontal_wrapped(|ui| {
                                for &kind in PieceKind::ALL.iter().rev() {
                                    let label = format!("{} ({})", piece_name(kind), kind.rank());
                                    ui.selectable_value(&mut s.brush_kind, kind, label);
                                }
                            });

                            ui.add_space(8.0);
                            ui.separator();
                            ui.add_space(4.0);

                            ui.horizontal(|ui| {
                                ui.label("Side to move:");
                                ui.selectable_value(&mut s.side_to_move, Color::P1, "P1");
                                ui.selectable_value(&mut s.side_to_move, Color::P2, "P2");
                            });
                        }

                        ui.horizontal(|ui| {
                            ui.label("You play as:");
                            ui.selectable_value(&mut self.human_side, Color::P1, "P1");
                            ui.selectable_value(&mut self.human_side, Color::P2, "P2");
                        });

                        ui.add_space(8.0);
                        ui.horizontal(|ui| {
                            let s = self.setup.as_mut().unwrap();
                            if ui.button("Clear Board").clicked() {
                                s.clear_board();
                            }
                            if ui.button("Reset Start").clicked() {
                                s.reset_start();
                            }
                        });

                        ui.add_space(8.0);
                        if let Err(reason) = validation {
                            ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", reason));
                        } else {
                            ui.colored_label(pal.ep_gain_badge, "✓ Position is valid.");
                        }

                        ui.add_space(4.0);
                        ui.horizontal(|ui| {
                            if ui
                                .add_enabled(validation.is_ok(), egui::Button::new("✓ End Setup"))
                                .clicked()
                            {
                                finish_clicked = true;
                            }
                            if ui.button("✕ Cancel").clicked() {
                                cancel_clicked = true;
                            }
                        });
                    });
            });

        if let Some((color, kind)) = picked_from_reservoir {
            if let Some(s) = &mut self.setup {
                s.brush_color = color;
                s.brush_kind = kind;
                s.status_msg = format!("Selected {} {} for placement.", color, piece_name(kind));
            }
        }
        if finish_clicked {
            self.finish_setup(ctx);
        } else if cancel_clicked {
            self.cancel_setup();
        }
    }

    fn ui_piece_tray_row(
        &self,
        ui: &mut egui::Ui,
        piece_sq: &[u8; 16],
        side: Color,
        label: &str,
        clickable: bool,
        pal: &Palette,
    ) -> Option<PieceKind> {
        let base = side.idx() * 8;
        let mut unplaced = Vec::new();
        for k in (0..8usize).rev() {
            if piece_sq[base + k] == CAPTURED {
                unplaced.push(PieceKind::from_idx(k));
            }
        }

        ui.small(label);
        if unplaced.is_empty() {
            ui.colored_label(
                pal.coord_text,
                if clickable {
                    "  (all pieces placed)"
                } else {
                    "  (none)"
                },
            );
            return None;
        }

        let disc_size = 30.0;
        let spacing = 5.0;
        let avail_w = ui.available_width().max(disc_size);
        let per_row = ((avail_w + spacing) / (disc_size + spacing))
            .floor()
            .max(1.0) as usize;
        let rows = unplaced.len().div_ceil(per_row);
        let total_h = rows as f32 * (disc_size + spacing);

        let sense = if clickable {
            egui::Sense::click()
        } else {
            egui::Sense::hover()
        };
        let (rect, response) = ui.allocate_exact_size(egui::vec2(avail_w, total_h), sense);
        let painter = ui.painter_at(rect);

        let active_brush = self
            .setup
            .as_ref()
            .map(|s| (s.brush_color, s.brush_kind));

        let mut clicked_kind = None;
        let click_pos = if clickable && response.clicked() {
            response.interact_pointer_pos()
        } else {
            None
        };

        for (i, &kind) in unplaced.iter().enumerate() {
            let col = i % per_row;
            let row = i / per_row;
            let cx = rect.left() + col as f32 * (disc_size + spacing) + disc_size * 0.5;
            let cy = rect.top() + row as f32 * (disc_size + spacing) + disc_size * 0.5;
            let center = egui::pos2(cx, cy);
            let r = disc_size * 0.45;

            self.draw_piece_disc(&painter, center, r, side, kind, pal);

            if clickable && active_brush == Some((side, kind)) {
                painter.circle_stroke(
                    center,
                    r + 2.5,
                    egui::Stroke::new(2.2, pal.selected_ring),
                );
            }

            if let Some(p) = click_pos {
                if (p - center).length() <= r + 3.0 {
                    clicked_kind = Some(kind);
                }
            }
        }

        clicked_kind
    }

    fn ui_board_panel(&mut self, ctx: &egui::Context, pal: &Palette) {
        let thinking = self.visible_thinking();

        egui::CentralPanel::default().show(ctx, |ui| {
            let avail = ui.available_size();
            let (vis_cols, vis_rows) = self.visual_dims();
            let rotation = self.rotation;

            let margin = 26.0;
            let max_w = (avail.x - margin * 2.0).max(100.0);
            let max_h = (avail.y - margin * 2.0).max(100.0);
            let tile = (max_w / vis_cols as f32).min(max_h / vis_rows as f32);

            let board_w = tile * vis_cols as f32;
            let board_h = tile * vis_rows as f32;
            let total_w = board_w + margin * 2.0;
            let total_h = board_h + margin * 2.0;

            let (full_rect, response) =
                ui.allocate_exact_size(avail, egui::Sense::click_and_drag());
            let origin = egui::pos2(
                full_rect.center().x - total_w * 0.5,
                full_rect.center().y - total_h * 0.5,
            );
            let frame_rect = egui::Rect::from_min_size(origin, egui::vec2(total_w, total_h));
            let board_origin = egui::pos2(origin.x + margin, origin.y + margin);

            let painter = ui.painter_at(full_rect);

            painter.rect_filled(frame_rect, egui::Rounding::same(10.0), pal.board_frame);
            if self.is_setup() {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.5, pal.setup_banner),
                );
            } else if self.is_ironman() {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.5, pal.ironman_accent),
                );
            } else if self.variant == GameVariant::ClassicSuperKo {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.0, pal.classic_accent),
                );
            } else if self.variant == GameVariant::MonsterRats {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.0, pal.rats_accent),
                );
            }

            let coord_font = egui::FontId::monospace((tile * 0.24).clamp(10.0, 18.0));
            for vx in 0..vis_cols {
                let (r_top, c_top) = self.visual_to_board(vx, 0);
                let label = if rotation % 2 == 0 {
                    ((b'a' + c_top as u8) as char).to_string()
                } else {
                    (r_top + 1).to_string()
                };
                let cx = board_origin.x + (vx as f32 + 0.5) * tile;
                painter.text(
                    egui::pos2(cx, origin.y + margin * 0.5),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
                painter.text(
                    egui::pos2(cx, board_origin.y + board_h + margin * 0.5),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
            }
            for vy in 0..vis_rows {
                let (r_left, c_left) = self.visual_to_board(0, vy);
                let label = if rotation % 2 == 0 {
                    (r_left + 1).to_string()
                } else {
                    ((b'a' + c_left as u8) as char).to_string()
                };
                let cy = board_origin.y + (vy as f32 + 0.5) * tile;
                painter.text(
                    egui::pos2(origin.x + margin * 0.5, cy),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
                painter.text(
                    egui::pos2(board_origin.x + board_w + margin * 0.5, cy),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
            }

            let active_piece_sq: [u8; 16] = match &self.setup {
                Some(s) => s.piece_sq,
                None => self.state.piece_sq(),
            };

            let selected_moves: Vec<Move> = if !self.is_setup()
                && self.state.game_result() == GameResult::Ongoing
                && self.state.side_to_move() == self.human_side
                && self.pending_search.is_none()
            {
                if let Some(sel) = self.selected_sq {
                    self.state
                        .gen_legal_moves()
                        .into_iter()
                        .filter(|m| m.from() == sel)
                        .collect()
                } else {
                    Vec::new()
                }
            } else {
                Vec::new()
            };

            let thinking_mv = thinking.map(|t| t.best_move);

            for r in 0..ROWS {
                for c in 0..COLS {
                    let sq = Square::from_rc(r, c);
                    let bit = sq.bit();
                    let (vx, vy) = self.board_to_visual(r, c);
                    let tile_rect = egui::Rect::from_min_size(
                        egui::pos2(
                            board_origin.x + vx as f32 * tile,
                            board_origin.y + vy as f32 * tile,
                        ),
                        egui::vec2(tile, tile),
                    );

                    let checker = (r + c) % 2 == 0;
                    let fill = if sq == DEN_SQ[0] {
                        pal.den_p1
                    } else if sq == DEN_SQ[1] {
                        pal.den_p2
                    } else if (bit & TRAPS_MASK[0]) != 0 {
                        pal.trap_p1
                    } else if (bit & TRAPS_MASK[1]) != 0 {
                        pal.trap_p2
                    } else if (bit & WATER_MASK) != 0 {
                        if checker {
                            pal.water_light
                        } else {
                            pal.water_dark
                        }
                    } else if checker {
                        pal.land_light
                    } else {
                        pal.land_dark
                    };

                    painter.rect_filled(tile_rect, egui::Rounding::ZERO, fill);
                    painter.rect_stroke(
                        tile_rect,
                        egui::Rounding::ZERO,
                        egui::Stroke::new(1.0, pal.grid_line),
                    );

                    let marker_font = egui::FontId::proportional((tile * 0.22).clamp(9.0, 16.0));
                    if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "DEN",
                            marker_font,
                            pal.badge_text.linear_multiply(0.65),
                        );
                    } else if (bit & (TRAPS_MASK[0] | TRAPS_MASK[1])) != 0 {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "TRAP",
                            egui::FontId::proportional((tile * 0.18).clamp(8.0, 13.0)),
                            pal.badge_text.linear_multiply(0.55),
                        );
                    } else if (bit & WATER_MASK) != 0 {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "~",
                            egui::FontId::proportional((tile * 0.34).clamp(11.0, 22.0)),
                            egui::Color32::from_rgba_unmultiplied(200, 235, 255, 65),
                        );
                    }

                    if !self.is_setup() {
                        if let Some(lm) = self.last_move {
                            if lm.from() == sq || lm.to() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.last_move_tint,
                                );
                            }
                        }

                        if let Some(tmv) = thinking_mv {
                            if tmv.from() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.thinking_from_tint,
                                );
                                painter.rect_stroke(
                                    tile_rect.shrink(2.0),
                                    egui::Rounding::same(4.0),
                                    egui::Stroke::new(3.0, pal.thinking_accent),
                                );
                            } else if tmv.to() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.thinking_to_tint,
                                );
                                painter.rect_stroke(
                                    tile_rect.shrink(2.0),
                                    egui::Rounding::same(4.0),
                                    egui::Stroke::new(3.0, pal.thinking_accent),
                                );
                            }
                        }

                        if self.selected_sq == Some(sq) {
                            painter.rect_stroke(
                                tile_rect.shrink(2.0),
                                egui::Rounding::same(4.0),
                                egui::Stroke::new(3.0, pal.selected_ring),
                            );
                        }
                    }
                }
            }

            let piece_radius = tile * 0.39;
            for (pid, &sq_u8) in active_piece_sq.iter().enumerate() {
                if sq_u8 == CAPTURED {
                    continue;
                }
                let sq = Square(sq_u8);
                let (vx, vy) = self.board_to_visual(sq.row(), sq.col());
                let center = egui::pos2(
                    board_origin.x + (vx as f32 + 0.5) * tile,
                    board_origin.y + (vy as f32 + 0.5) * tile,
                );
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                self.draw_piece_disc(&painter, center, piece_radius, color, kind, pal);
            }

            if let Some(tmv) = thinking_mv {
                let from = tmv.from();
                let to = tmv.to();
                let (fvx, fvy) = self.board_to_visual(from.row(), from.col());
                let (tvx, tvy) = self.board_to_visual(to.row(), to.col());
                let p_from = egui::pos2(
                    board_origin.x + (fvx as f32 + 0.5) * tile,
                    board_origin.y + (fvy as f32 + 0.5) * tile,
                );
                let p_to = egui::pos2(
                    board_origin.x + (tvx as f32 + 0.5) * tile,
                    board_origin.y + (tvy as f32 + 0.5) * tile,
                );
                draw_thinking_arrow(&painter, p_from, p_to, tile, pal.thinking_accent);
            }

            if !self.is_setup() && !self.is_ironman() && self.show_legal_moves {
                let opp_den = DEN_SQ[self.state.side_to_move().opp().idx()];
                for &mv in &selected_moves {
                    let to = mv.to();
                    let (vx, vy) = self.board_to_visual(to.row(), to.col());
                    let center = egui::pos2(
                        board_origin.x + (vx as f32 + 0.5) * tile,
                        board_origin.y + (vy as f32 + 0.5) * tile,
                    );
                    let is_capture = self.state.board_piece(to.idx()) != EMPTY_SQ;
                    if to == opp_den {
                        painter.circle_stroke(
                            center,
                            tile * 0.42,
                            egui::Stroke::new(4.0, pal.legal_win),
                        );
                    } else if is_capture {
                        painter.circle_stroke(
                            center,
                            tile * 0.42,
                            egui::Stroke::new(3.5, pal.legal_capture),
                        );
                    } else if self.state.move_has_rep_warning(mv) {
                        painter.circle_filled(center, tile * 0.16, pal.legal_rep_warn);
                    } else {
                        painter.circle_filled(center, tile * 0.14, pal.legal_quiet);
                    }
                }
            }

            if self.any_modal_open() {
                return;
            }

            let px_to_sq = move |pos_px: egui::Pos2| -> Option<Square> {
                let rel_x = pos_px.x - board_origin.x;
                let rel_y = pos_px.y - board_origin.y;
                if rel_x >= 0.0 && rel_x < board_w && rel_y >= 0.0 && rel_y < board_h {
                    let vx = (rel_x / tile) as usize;
                    let vy = (rel_y / tile) as usize;
                    if vx < vis_cols && vy < vis_rows {
                        let (r, c) = visual_to_board_rot(rotation, vx, vy);
                        return Some(Square::from_rc(r, c));
                    }
                }
                None
            };

            if self.is_setup() {
                self.handle_setup_board_input(ctx, &response, &px_to_sq);
            } else if response.clicked() {
                if let Some(pos_px) = response.interact_pointer_pos() {
                    if let Some(clicked_sq) = px_to_sq(pos_px) {
                        self.handle_square_click(clicked_sq, &selected_moves, ctx);
                    } else {
                        self.selected_sq = None;
                    }
                }
            }
        });
    }

    fn handle_setup_board_input<F>(
        &mut self,
        ctx: &egui::Context,
        response: &egui::Response,
        px_to_sq: &F,
    ) where
        F: Fn(egui::Pos2) -> Option<Square>,
    {
        let (primary_down, secondary_down, primary_released, secondary_released, middle_clicked, ptr) =
            ctx.input(|i| {
                (
                    i.pointer.primary_down(),
                    i.pointer.secondary_down(),
                    i.pointer.primary_released(),
                    i.pointer.secondary_released(),
                    i.pointer.button_clicked(egui::PointerButton::Middle),
                    i.pointer.interact_pos(),
                )
            });

        let Some(setup) = self.setup.as_mut() else {
            return;
        };

        if primary_down && secondary_down {
            if !setup.chord_consumed {
                if let Some(p) = ptr {
                    if response.rect.contains(p) {
                        if let Some(sq) = px_to_sq(p) {
                            setup.remove_at(sq);
                        }
                    }
                }
                setup.chord_consumed = true;
            }
            return;
        }

        if middle_clicked {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        setup.remove_at(sq);
                    }
                }
            }
            return;
        }

        if setup.chord_consumed {
            if !primary_down && !secondary_down {
                setup.chord_consumed = false;
            }
            return;
        }

        if primary_released {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        let color = setup.brush_color;
                        let kind = setup.brush_kind;
                        setup.place_piece(color, kind, sq);
                    }
                }
            }
        } else if secondary_released {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        let color = setup.brush_color.opp();
                        let kind = setup.brush_kind;
                        setup.place_piece(color, kind, sq);
                    }
                }
            }
        }
    }

    fn handle_square_click(
        &mut self,
        clicked_sq: Square,
        selected_moves: &[Move],
        ctx: &egui::Context,
    ) {
        if self.pending_search.is_some()
            || self.state.side_to_move() != self.human_side
            || self.state.game_result() != GameResult::Ongoing
        {
            return;
        }

        if let Some(&mv) = selected_moves.iter().find(|m| m.to() == clicked_sq) {
            self.play_move(mv);
            if self.state.game_result() == GameResult::Ongoing
                && self.state.side_to_move() != self.human_side
            {
                self.start_engine_search(ctx);
            }
            return;
        }

        let pid = self.state.board_piece(clicked_sq.idx());
        if pid != EMPTY_SQ {
            let color = if pid < 8 { Color::P1 } else { Color::P2 };
            if color == self.human_side {
                if self.selected_sq == Some(clicked_sq) {
                    self.selected_sq = None;
                } else {
                    self.selected_sq = Some(clicked_sq);
                }
                return;
            }
        }

        self.selected_sq = None;
    }
}

impl eframe::App for DsqGuiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if ctx.input(|i| i.viewport().close_requested()) && !self.allow_close {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.show_quit_confirm = true;
        }

        self.handle_global_shortcuts(ctx);
        self.poll_engine();

        if self.pending_search.is_some() || self.copied_until.is_some() {
            ctx.request_repaint_after(std::time::Duration::from_millis(50));
            if let Some(t) = self.copied_until {
                if Instant::now() >= t {
                    self.copied_until = None;
                }
            }
        }

        let pal = self.theme.palette();
        self.ui_top_toolbar(ctx, &pal);
        self.ui_right_panel(ctx, &pal);
        self.ui_board_panel(ctx, &pal);
        self.ui_rules_help_window(ctx, &pal);
        self.ui_hall_of_fame_window(ctx, &pal);
        self.ui_hof_name_prompt(ctx, &pal);
        self.ui_import_overwrite_confirm(ctx);
        self.ui_enter_ironman_confirm(ctx, &pal);
        self.ui_new_game_leave_ironman_confirm(ctx);
        self.ui_ironman_setup_confirm(ctx);
        self.ui_quit_confirmation(ctx);
    }

    fn on_exit(&mut self, _gl: Option<&eframe::glow::Context>) {
        self.cancel_search();
        if !self.allow_close {
            self.save_autosave();
        }
    }
}

fn draw_thinking_arrow(
    painter: &egui::Painter,
    from: egui::Pos2,
    to: egui::Pos2,
    tile: f32,
    color: egui::Color32,
) {
    let delta = to - from;
    let len = delta.length();
    if len < 4.0 {
        return;
    }
    let dir = delta / len;
    let perp = egui::vec2(-dir.y, dir.x);
    let start = from + dir * (tile * 0.22);
    let tip = to - dir * (tile * 0.16);
    let head_len = (tile * 0.26).clamp(8.0, 22.0);
    let head_w = head_len * 0.55;
    let shaft_end = tip - dir * (head_len * 0.75);

    let line_col = egui::Color32::from_rgba_unmultiplied(color.r(), color.g(), color.b(), 215);
    painter.line_segment(
        [start, shaft_end],
        egui::Stroke::new((tile * 0.10).clamp(3.0, 7.0), line_col),
    );
    painter.add(egui::Shape::convex_polygon(
        vec![
            tip,
            tip - dir * head_len + perp * head_w,
            tip - dir * head_len - perp * head_w,
        ],
        line_col,
        egui::Stroke::NONE,
    ));
}

fn parse_alg_move(s: &str) -> Option<Move> {
    if s.len() != 4 {
        return None;
    }
    let from = Square::from_alg(&s[0..2])?;
    let to = Square::from_alg(&s[2..4])?;
    Some(Move::new(from, to))
}

fn board_to_visual_rot(rotation: u8, r: usize, c: usize) -> (usize, usize) {
    match rotation % 4 {
        0 => (c, (ROWS - 1) - r),
        1 => (r, c),
        2 => ((COLS - 1) - c, r),
        _ => ((ROWS - 1) - r, (COLS - 1) - c),
    }
}

fn visual_to_board_rot(rotation: u8, vx: usize, vy: usize) -> (usize, usize) {
    match rotation % 4 {
        0 => ((ROWS - 1) - vy, vx),
        1 => (vx, vy),
        2 => (vy, (COLS - 1) - vx),
        _ => ((ROWS - 1) - vx, (COLS - 1) - vy),
    }
}

fn piece_letter(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Rat => "R",
        PieceKind::Cat => "C",
        PieceKind::Dog => "D",
        PieceKind::Wolf => "W",
        PieceKind::Leopard => "P",
        PieceKind::Tiger => "T",
        PieceKind::Lion => "L",
        PieceKind::Elephant => "E",
    }
}

fn piece_name(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Rat => "Rat",
        PieceKind::Cat => "Cat",
        PieceKind::Dog => "Dog",
        PieceKind::Wolf => "Wolf",
        PieceKind::Leopard => "Leopard",
        PieceKind::Tiger => "Tiger",
        PieceKind::Lion => "Lion",
        PieceKind::Elephant => "Elephant",
    }
}

fn piece_unicode_symbol(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Elephant => "\u{265A}", // ♚ (Rank 8)
        PieceKind::Lion => "\u{265B}",     // ♛ (Rank 7)
        PieceKind::Tiger => "\u{265C}",    // ♜ (Rank 6)
        PieceKind::Leopard => "\u{265D}",  // ♝ (Rank 5)
        PieceKind::Wolf => "\u{265E}",     // ♞ (Rank 4)
        PieceKind::Dog => "\u{265F}",      // ♟ (Rank 3)
        PieceKind::Cat => "\u{2666}",      // ♦ (Rank 2)
        PieceKind::Rat => "\u{2605}",      // ★ (Rank 1)
    }
}

fn format_score(score: i32) -> String {
    if score.abs() >= 28_000 {
        let plies = SCORE_WIN - score.abs();
        if score > 0 {
            format!("WIN in {}", plies)
        } else {
            format!("LOSS in {}", plies)
        }
    } else {
        format!("{:+.2}", score as f64 / 100.0)
    }
}

fn install_system_symbol_fonts(ctx: &egui::Context) {
    let symbol_candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansSymbols2-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansSymbols-Regular.ttf",
    ];

    let mut fonts = egui::FontDefinitions::default();
    let mut loaded_any = false;

    for (idx, path) in symbol_candidates.iter().enumerate() {
        if let Ok(bytes) = std::fs::read(path) {
            let name = format!("sys_sym_{}", idx);
            fonts
                .font_data
                .insert(name.clone(), egui::FontData::from_owned(bytes));
            fonts
                .families
                .entry(egui::FontFamily::Proportional)
                .or_default()
                .push(name.clone());
            fonts
                .families
                .entry(egui::FontFamily::Monospace)
                .or_default()
                .push(name);
            loaded_any = true;
        }
    }

    if loaded_any {
        ctx.set_fonts(fonts);
    }
}

pub fn run_gui(
    variant: GameVariant,
    ironman_depth: Option<usize>,
    import_req: Option<ImportRequest>,
) -> Result<(), eframe::Error> {
    let title = match (&ironman_depth, &import_req) {
        (Some(d), _) => format!(
            "Dou Shou Qi ({}) — IRONMAN MODE (Depth {}+)",
            variant.display_name(),
            (*d).max(MIN_IRONMAN_DEPTH)
        ),
        (None, Some(req)) => format!(
            "Dou Shou Qi ({}) — Imported: {}",
            variant.display_name(),
            req.filename
        ),
        (None, None) => format!("Dou Shou Qi ({})", variant.display_name()),
    };

    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title(title.clone())
            .with_inner_size([1240.0, 860.0])
            .with_min_inner_size([780.0, 540.0]),
        ..Default::default()
    };

    eframe::run_native(
        &title,
        options,
        Box::new(move |cc| Ok(Box::new(DsqGuiApp::new(cc, variant, ironman_depth, import_req)))),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_auto_detect_by_header() {
        let classic_export = "\
            # Mode: Classic SuperKo\n\
              1. R:g3-g4   R:a7-a6\n\
              2. R:g4-g5   R:a6-a5\n";
        let (v1, m1) = parse_and_detect_movelist(classic_export).unwrap();
        assert_eq!(v1, GameVariant::ClassicSuperKo);
        assert_eq!(m1.len(), 4);

        let ep_export = "\
            # Mode: EP+SuperKo\n\
              1. R:g3-g4   R:a7-a6\n";
        let (v2, m2) = parse_and_detect_movelist(ep_export).unwrap();
        assert_eq!(v2, GameVariant::EpSuperKo);
        assert_eq!(m2.len(), 2);

        let mr_export = "\
            # Mode: Monster Rats\n\
              1. R:g3-g4   R:a7-a6\n";
        let (v3, m3) = parse_and_detect_movelist(mr_export).unwrap();
        assert_eq!(v3, GameVariant::MonsterRats);
        assert_eq!(m3.len(), 2);
    }

    #[test]
    fn test_auto_detect_headerless_by_rules() {
        let ep_only = "\
              1. R:g3-g4   R:a7-a6\n\
              2. R:g4-g3   R:a6-a7\n\
              3. R:g3-g4   R:a7-a6\n\
              4. R:g4-g3   R:a6-a7\n";
        let (variant, moves) = parse_and_detect_movelist(ep_only).unwrap();
        assert_eq!(variant, GameVariant::EpSuperKo);
        assert_eq!(moves.len(), 8);

        let mr_only = "\
              1. R:g3-g4   E:g7-g6\n\
              2. R:g4-f4   R:a7-a6\n\
              3. R:f4-f5   R:a6-a5\n\
              4. R:f5-f6   R:a5-a4\n\
              5. R:f6xg6\n";
        let (mr_v, mr_m) = parse_and_detect_movelist(mr_only).unwrap();
        assert_eq!(mr_v, GameVariant::MonsterRats);
        assert_eq!(mr_m.len(), 9);

        assert!(parse_and_detect_movelist("1. E:a3-b4").is_err());
    }

    #[test]
    fn test_time_preset_table_values() {
        assert_eq!(TIME_PRESETS_SECS.len(), 24);
        assert_eq!(TIME_PRESETS_SECS[0], Some(1));
        assert_eq!(TIME_PRESETS_SECS[9], Some(10));
        assert_eq!(TIME_PRESETS_SECS[10], Some(12));
        assert_eq!(TIME_PRESETS_SECS[22], Some(180));
        assert_eq!(TIME_PRESETS_SECS[23], None);
        assert_eq!(time_idx_from_secs(None), 23);
        assert_eq!(time_idx_from_secs(Some(60)), 18);
    }
}

