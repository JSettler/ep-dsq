pub mod classic;
pub mod core;
pub mod eval;
pub mod gui;
pub mod hall_of_fame;
pub mod piece_art;
pub mod rats;
pub mod search;

