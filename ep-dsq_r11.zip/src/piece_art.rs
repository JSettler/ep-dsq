//! Self-contained vector piece artwork for the **Chinese** and **Animals** piece sets.
//!
//! Uses `egui::Painter` directly with zero external font files or system packages,
//! guaranteeing crisp rendering on every Linux distribution (no missing-glyph boxes!).

use crate::core::PieceKind;
use eframe::egui::{self, Color32, Pos2, Shape, Stroke};

/// Draws an authentic Dou Shou Qi Chinese character (`象 狮 虎 豹 狼 狗 猫 鼠`)
/// centered at `center` with half-extent `scale`, using clean stroke polylines.
pub fn draw_chinese_char(
    painter: &egui::Painter,
    center: Pos2,
    scale: f32,
    kind: PieceKind,
    color: Color32,
) {
    let w = (scale * 0.135).clamp(1.3, 4.2);
    let stroke = Stroke::new(w, color);

    let pt = |x: f32, y: f32| Pos2::new(center.x + x * scale, center.y + y * scale);
    let poly = |pts: &[(f32, f32)]| {
        let mapped: Vec<Pos2> = pts.iter().map(|&(x, y)| pt(x, y)).collect();
        painter.add(Shape::line(mapped, stroke));
    };

    // Shared left dog-radical 犭 used in 狮 (Lion), 狼 (Wolf), 狗 (Dog), 猫 (Cat)
    let draw_quanzipang = || {
        poly(&[(-0.34, -0.82), (-0.82, -0.34)]);
        poly(&[
            (-0.74, -0.68),
            (-0.48, -0.22),
            (-0.44, 0.32),
            (-0.50, 0.86),
            (-0.70, 0.72),
        ]);
        poly(&[(-0.48, -0.02), (-0.84, 0.44)]);
    };

    match kind {
        // 象 (Elephant, 8)
        PieceKind::Elephant => {
            // Top ⺈
            poly(&[(0.00, -0.94), (-0.44, -0.56)]);
            poly(&[(-0.18, -0.82), (0.36, -0.82), (0.12, -0.54)]);
            // Middle 口 with vertical divider
            poly(&[(-0.56, -0.52), (-0.50, -0.10)]);
            poly(&[(-0.56, -0.52), (0.56, -0.52), (0.50, -0.10)]);
            poly(&[(-0.50, -0.10), (0.50, -0.10)]);
            poly(&[(0.00, -0.52), (0.00, -0.10)]);
            // Lower 豕
            poly(&[(0.00, -0.10), (-0.58, 0.24)]);
            poly(&[
                (-0.14, 0.04),
                (0.08, 0.28),
                (0.10, 0.72),
                (0.02, 0.92),
                (-0.20, 0.80),
            ]);
            poly(&[(0.02, 0.22), (-0.64, 0.54)]);
            poly(&[(0.08, 0.44), (-0.68, 0.88)]);
            poly(&[(0.58, 0.02), (0.14, 0.30)]);
            poly(&[(0.14, 0.32), (0.76, 0.88)]);
        }

        // 狮 (Lion, 7)
        PieceKind::Lion => {
            draw_quanzipang();
            // Right side 师
            poly(&[(-0.08, -0.66), (-0.08, 0.06)]);
            poly(&[(0.12, -0.84), (0.12, 0.14), (-0.12, 0.84)]);
            poly(&[(0.22, -0.68), (0.86, -0.68)]);
            poly(&[(0.28, -0.32), (0.28, 0.56)]);
            poly(&[(0.28, -0.32), (0.82, -0.32), (0.82, 0.56), (0.66, 0.44)]);
            poly(&[(0.55, -0.68), (0.55, 0.90)]);
        }

        // 虎 (Tiger, 6)
        PieceKind::Tiger => {
            // Top 虍
            poly(&[(0.00, -0.94), (0.00, -0.46)]);
            poly(&[(0.00, -0.72), (0.52, -0.72)]);
            poly(&[(-0.56, -0.46), (0.68, -0.46), (0.56, -0.24)]);
            poly(&[(-0.56, -0.46), (-0.56, 0.22), (-0.78, 0.88)]);
            // Inner 七
            poly(&[(-0.36, -0.14), (0.48, -0.22)]);
            poly(&[(-0.08, -0.44), (-0.08, 0.02), (0.48, 0.02), (0.48, -0.10)]);
            // Bottom 几
            poly(&[(-0.18, 0.26), (-0.22, 0.62), (-0.46, 0.90)]);
            poly(&[
                (-0.18, 0.26),
                (0.36, 0.26),
                (0.36, 0.78),
                (0.50, 0.88),
                (0.76, 0.88),
                (0.76, 0.64),
            ]);
        }

        // 豹 (Leopard, 5)
        PieceKind::Leopard => {
            // Left radical 豸
            poly(&[(-0.22, -0.88), (-0.80, -0.56)]);
            poly(&[(-0.74, -0.46), (-0.62, -0.30)]);
            poly(&[(-0.50, -0.54), (-0.40, -0.38)]);
            poly(&[(-0.16, -0.58), (-0.34, -0.32)]);
            poly(&[(-0.34, -0.24), (-0.80, 0.14)]);
            poly(&[
                (-0.50, -0.12),
                (-0.24, 0.20),
                (-0.22, 0.68),
                (-0.32, 0.90),
                (-0.52, 0.78),
            ]);
            poly(&[(-0.32, 0.12), (-0.78, 0.48)]);
            poly(&[(-0.26, 0.36), (-0.82, 0.80)]);
            // Right side 勺
            poly(&[(0.26, -0.84), (0.04, -0.20)]);
            poly(&[
                (0.18, -0.48),
                (0.82, -0.48),
                (0.76, 0.56),
                (0.64, 0.88),
                (0.42, 0.74),
            ]);
            poly(&[(0.28, -0.04), (0.48, 0.22)]);
        }

        // 狼 (Wolf, 4)
        PieceKind::Wolf => {
            draw_quanzipang();
            // Right side 良
            poly(&[(0.34, -0.92), (0.46, -0.74)]);
            poly(&[(0.12, -0.64), (0.74, -0.64), (0.70, -0.04)]);
            poly(&[(0.12, -0.34), (0.72, -0.34)]);
            poly(&[(0.12, -0.04), (0.70, -0.04)]);
            poly(&[(0.12, -0.64), (0.12, 0.86), (0.46, 0.64)]);
            poly(&[(0.82, 0.08), (0.46, 0.36)]);
            poly(&[(0.30, 0.12), (0.86, 0.86)]);
        }

        // 狗 (Dog, 3)
        PieceKind::Dog => {
            draw_quanzipang();
            // Right side 句
            poly(&[(0.24, -0.86), (-0.02, -0.22)]);
            poly(&[
                (0.16, -0.54),
                (0.82, -0.54),
                (0.76, 0.56),
                (0.64, 0.88),
                (0.42, 0.74),
            ]);
            // Inner 口
            poly(&[(0.12, -0.14), (0.12, 0.40)]);
            poly(&[(0.12, -0.14), (0.50, -0.14), (0.50, 0.40)]);
            poly(&[(0.12, 0.40), (0.50, 0.40)]);
        }

        // 猫 (Cat, 2)
        PieceKind::Cat => {
            draw_quanzipang();
            // Right side 苗 (艹 + 田)
            poly(&[(-0.04, -0.56), (0.88, -0.56)]);
            poly(&[(0.22, -0.84), (0.22, -0.32)]);
            poly(&[(0.62, -0.84), (0.62, -0.32)]);
            poly(&[(0.04, -0.14), (0.04, 0.82)]);
            poly(&[(0.04, -0.14), (0.80, -0.14), (0.80, 0.82)]);
            poly(&[(0.42, -0.14), (0.42, 0.78)]);
            poly(&[(0.04, 0.32), (0.80, 0.32)]);
            poly(&[(0.04, 0.78), (0.80, 0.78)]);
        }

        // 鼠 (Rat, 1)
        PieceKind::Rat => {
            // Top 臼
            poly(&[(-0.22, -0.88), (-0.64, -0.70)]);
            poly(&[(-0.64, -0.70), (-0.54, -0.12)]);
            poly(&[(-0.58, -0.42), (-0.20, -0.42)]);
            poly(&[(0.18, -0.76), (0.62, -0.76), (0.52, -0.12)]);
            poly(&[(0.18, -0.42), (0.56, -0.42)]);
            poly(&[(-0.54, -0.12), (0.52, -0.12)]);
            // Bottom claws & tail
            poly(&[(-0.54, 0.04), (-0.54, 0.86), (-0.22, 0.70)]);
            poly(&[(-0.34, 0.16), (-0.22, 0.30)]);
            poly(&[(-0.34, 0.44), (-0.22, 0.58)]);
            poly(&[(-0.04, 0.04), (-0.04, 0.86), (0.24, 0.70)]);
            poly(&[(0.14, 0.16), (0.26, 0.30)]);
            poly(&[(0.14, 0.44), (0.26, 0.58)]);
            poly(&[(0.38, 0.02), (0.46, 0.52), (0.66, 0.88), (0.80, 0.62)]);
        }
    }
}

/// Draws a distinct, instantly recognizable vector animal icon centered at `center`
/// with half-extent `scale`. Uses `fg` for silhouettes/strokes and `bg` for inner eyes/details.
pub fn draw_animal_icon(
    painter: &egui::Painter,
    center: Pos2,
    scale: f32,
    kind: PieceKind,
    fg: Color32,
    bg: Color32,
) {
    let pt = |x: f32, y: f32| Pos2::new(center.x + x * scale, center.y + y * scale);
    let poly_fill = |pts: &[(f32, f32)], col: Color32| {
        let mapped: Vec<Pos2> = pts.iter().map(|&(x, y)| pt(x, y)).collect();
        painter.add(Shape::convex_polygon(mapped, col, Stroke::NONE));
    };
    let line = |pts: &[(f32, f32)], width: f32, col: Color32| {
        let mapped: Vec<Pos2> = pts.iter().map(|&(x, y)| pt(x, y)).collect();
        painter.add(Shape::line(mapped, Stroke::new(width.max(1.2), col)));
    };
    let eye_r = (scale * 0.10).max(1.2);
    let thin = (scale * 0.11).max(1.2);

    match kind {
        // Elephant (8): huge ears + domed head + curved trunk + tusks
        PieceKind::Elephant => {
            // Left & right big flapping ears
            poly_fill(
                &[
                    (-0.42, -0.48),
                    (-0.92, -0.34),
                    (-0.96, 0.16),
                    (-0.56, 0.34),
                    (-0.34, 0.08),
                ],
                fg,
            );
            poly_fill(
                &[
                    (0.42, -0.48),
                    (0.92, -0.34),
                    (0.96, 0.16),
                    (0.56, 0.34),
                    (0.34, 0.08),
                ],
                fg,
            );
            // Head dome
            painter.circle_filled(pt(0.0, -0.14), scale * 0.50, fg);
            // Curved trunk
            line(
                &[
                    (0.0, 0.14),
                    (0.0, 0.56),
                    (0.14, 0.80),
                    (0.36, 0.72),
                ],
                scale * 0.24,
                fg,
            );
            // Ivory tusks (drawn in bg contrast)
            line(&[(-0.24, 0.16), (-0.42, 0.52)], thin * 1.15, bg);
            line(&[(0.24, 0.16), (0.42, 0.52)], thin * 1.15, bg);
            // Eyes
            painter.circle_filled(pt(-0.22, -0.18), eye_r, bg);
            painter.circle_filled(pt(0.22, -0.18), eye_r, bg);
        }

        // Lion (7): bold sunburst mane + round ears + regal face
        PieceKind::Lion => {
            // Spiky 12-point mane starburst
            let spikes = 12usize;
            for i in 0..spikes {
                let a0 = (i as f32) * std::f32::consts::TAU / (spikes as f32);
                let a_mid = a0 + std::f32::consts::PI / (spikes as f32);
                let a1 = a0 + std::f32::consts::TAU / (spikes as f32);
                let r_in = 0.56;
                let r_out = 0.94;
                poly_fill(
                    &[
                        (0.0, 0.0),
                        (a0.cos() * r_in, a0.sin() * r_in),
                        (a_mid.cos() * r_out, a_mid.sin() * r_out),
                        (a1.cos() * r_in, a1.sin() * r_in),
                    ],
                    fg,
                );
            }
            // Inner face ring (contrast) + solid face
            painter.circle_filled(pt(0.0, 0.04), scale * 0.56, bg);
            painter.circle_filled(pt(0.0, 0.04), scale * 0.45, fg);
            // Eyes & nose
            painter.circle_filled(pt(-0.18, -0.06), eye_r, bg);
            painter.circle_filled(pt(0.18, -0.06), eye_r, bg);
            poly_fill(&[(-0.12, 0.12), (0.12, 0.12), (0.0, 0.25)], bg);
            line(&[(-0.14, 0.30), (0.0, 0.24), (0.14, 0.30)], thin * 0.85, bg);
        }

        // Tiger (6): round head + small round ears + bold iconic forehead & cheek stripes
        PieceKind::Tiger => {
            painter.circle_filled(pt(-0.56, -0.58), scale * 0.24, fg);
            painter.circle_filled(pt(0.56, -0.58), scale * 0.24, fg);
            painter.circle_filled(pt(0.0, 0.04), scale * 0.72, fg);
            // Iconic forehead stripes (3 horizontal + vertical 王 mark)
            line(&[(-0.22, -0.44), (0.22, -0.44)], thin, bg);
            line(&[(-0.28, -0.28), (0.28, -0.28)], thin, bg);
            line(&[(0.0, -0.52), (0.0, -0.18)], thin, bg);
            // Cheek stripes
            line(&[(-0.68, 0.04), (-0.40, 0.08)], thin, bg);
            line(&[(-0.64, 0.26), (-0.36, 0.22)], thin, bg);
            line(&[(0.68, 0.04), (0.40, 0.08)], thin, bg);
            line(&[(0.64, 0.26), (0.36, 0.22)], thin, bg);
            // Eyes & snout
            painter.circle_filled(pt(-0.24, -0.02), eye_r, bg);
            painter.circle_filled(pt(0.24, -0.02), eye_r, bg);
            poly_fill(&[(-0.14, 0.22), (0.14, 0.22), (0.0, 0.36)], bg);
        }

        // Leopard (5): sleek feline head + pointed ears + spots/rosettes
        PieceKind::Leopard => {
            poly_fill(&[(-0.58, -0.26), (-0.64, -0.82), (-0.18, -0.56)], fg);
            poly_fill(&[(0.58, -0.26), (0.64, -0.82), (0.18, -0.56)], fg);
            painter.circle_filled(pt(0.0, 0.06), scale * 0.66, fg);
            // Distinct leopard spots across forehead & cheeks
            let spot_r = (scale * 0.09).max(1.1);
            for &(sx, sy) in &[
                (0.0, -0.38),
                (-0.30, -0.32),
                (0.30, -0.32),
                (-0.44, 0.16),
                (0.44, 0.16),
                (-0.34, 0.42),
                (0.34, 0.42),
            ] {
                painter.circle_filled(pt(sx, sy), spot_r, bg);
            }
            // Eyes & nose
            painter.circle_filled(pt(-0.22, -0.04), eye_r * 1.1, bg);
            painter.circle_filled(pt(0.22, -0.04), eye_r * 1.1, bg);
            poly_fill(&[(-0.12, 0.24), (0.12, 0.24), (0.0, 0.38)], bg);
        }

        // Wolf (4): tall sharp ears + angular cheeks + pointed snout
        PieceKind::Wolf => {
            // Tall sharp triangular ears
            poly_fill(&[(-0.56, -0.18), (-0.62, -0.94), (-0.14, -0.48)], fg);
            poly_fill(&[(0.56, -0.18), (0.62, -0.94), (0.14, -0.48)], fg);
            // Angular wolf head tapering to pointed muzzle
            poly_fill(
                &[
                    (-0.62, -0.24),
                    (0.0, -0.52),
                    (0.62, -0.24),
                    (0.72, 0.16),
                    (0.28, 0.62),
                    (0.0, 0.86),
                    (-0.28, 0.62),
                    (-0.72, 0.16),
                ],
                fg,
            );
            // Fierce slanted eyes
            line(&[(-0.38, -0.12), (-0.14, -0.02)], thin * 1.15, bg);
            line(&[(0.38, -0.12), (0.14, -0.02)], thin * 1.15, bg);
            // Nose tip & muzzle line
            painter.circle_filled(pt(0.0, 0.54), scale * 0.14, bg);
            line(&[(0.0, 0.14), (0.0, 0.42)], thin * 0.85, bg);
        }

        // Dog (3): friendly round head + long drooping floppy ears
        PieceKind::Dog => {
            // Long floppy drooping ears
            poly_fill(
                &[
                    (-0.46, -0.42),
                    (-0.88, -0.16),
                    (-0.90, 0.56),
                    (-0.54, 0.58),
                    (-0.42, 0.10),
                ],
                fg,
            );
            poly_fill(
                &[
                    (0.46, -0.42),
                    (0.88, -0.16),
                    (0.90, 0.56),
                    (0.54, 0.58),
                    (0.42, 0.10),
                ],
                fg,
            );
            // Round head + muzzle
            painter.circle_filled(pt(0.0, -0.06), scale * 0.56, fg);
            painter.circle_filled(pt(0.0, 0.34), scale * 0.36, fg);
            // Eyes, nose & smile
            painter.circle_filled(pt(-0.22, -0.14), eye_r, bg);
            painter.circle_filled(pt(0.22, -0.14), eye_r, bg);
            painter.circle_filled(pt(0.0, 0.20), scale * 0.13, bg);
            line(&[(-0.16, 0.42), (0.0, 0.34), (0.16, 0.42)], thin * 0.9, bg);
        }

        // Cat (2): neat pointed ears + round head + crisp protruding whiskers
        PieceKind::Cat => {
            poly_fill(&[(-0.56, -0.10), (-0.54, -0.82), (-0.08, -0.46)], fg);
            poly_fill(&[(0.56, -0.10), (0.54, -0.82), (0.08, -0.46)], fg);
            painter.circle_filled(pt(0.0, 0.08), scale * 0.58, fg);
            // Whiskers extending cleanly outside cheeks
            line(&[(-0.92, 0.04), (-0.42, 0.14)], thin * 0.9, fg);
            line(&[(-0.90, 0.30), (-0.42, 0.26)], thin * 0.9, fg);
            line(&[(0.92, 0.04), (0.42, 0.14)], thin * 0.9, fg);
            line(&[(0.90, 0.30), (0.42, 0.26)], thin * 0.9, fg);
            // Eyes & tiny nose
            painter.circle_filled(pt(-0.22, 0.00), eye_r, bg);
            painter.circle_filled(pt(0.22, 0.00), eye_r, bg);
            poly_fill(&[(-0.10, 0.22), (0.10, 0.22), (0.0, 0.33)], bg);
        }

        // Rat (1): oversized round mouse ears + sharp pointed snout + whiskers
        PieceKind::Rat => {
            // Huge iconic round ears
            painter.circle_filled(pt(-0.54, -0.46), scale * 0.38, fg);
            painter.circle_filled(pt(0.54, -0.46), scale * 0.38, fg);
            painter.circle_filled(pt(-0.54, -0.46), scale * 0.18, bg);
            painter.circle_filled(pt(0.54, -0.46), scale * 0.18, bg);
            // Pointed teardrop snout
            poly_fill(
                &[
                    (-0.52, -0.06),
                    (0.0, -0.34),
                    (0.52, -0.06),
                    (0.32, 0.44),
                    (0.0, 0.78),
                    (-0.32, 0.44),
                ],
                fg,
            );
            // Whiskers
            line(&[(-0.84, 0.36), (-0.28, 0.44)], thin * 0.85, fg);
            line(&[(0.84, 0.36), (0.28, 0.44)], thin * 0.85, fg);
            // Beady eyes & nose tip
            painter.circle_filled(pt(-0.18, 0.06), eye_r, bg);
            painter.circle_filled(pt(0.18, 0.06), eye_r, bg);
            painter.circle_filled(pt(0.0, 0.62), scale * 0.11, bg);
        }
    }
}

