use dsq_engine::classic::board::ClassicPos;
use dsq_engine::classic::search::ClassicSearcher;
use dsq_engine::core::board_bb::BitboardPos;
use dsq_engine::core::board_ref::RefGame;
use dsq_engine::core::{Color, GameResult, Move, Rng, Square};
use dsq_engine::eval::SCORE_WIN;
use dsq_engine::gui::{
    parse_and_detect_import, run_gui, GameVariant, ImportPosition, ImportRequest, IronManLaunch,
    MIN_IRONMAN_DEPTH,
};
use dsq_engine::hall_of_fame::{
    is_valid_ironman_tc, ALLOWED_TIMED_BASE_MINS, ALLOWED_TIMED_INC_SECS,
};
use dsq_engine::rats::board::RatsPos;
use dsq_engine::rats::search::RatsSearcher;
use dsq_engine::search::{SearchLimits, Searcher};
use std::env;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::time::Instant;

fn parse_move(input: &str) -> Option<Move> {
    let s = input.trim().to_ascii_lowercase();
    if s.len() != 4 {
        return None;
    }
    let from = Square::from_alg(&s[0..2])?;
    let to = Square::from_alg(&s[2..4])?;
    Some(Move::new(from, to))
}

fn format_score(score: i32) -> String {
    if score.abs() >= 28_000 {
        let plies = SCORE_WIN - score.abs();
        if score > 0 {
            format!("WIN in {} plies", plies)
        } else {
            format!("LOSS in {} plies", plies)
        }
    } else {
        format!("{:+.2} ({} cp)", score as f64 / 100.0, score)
    }
}

fn parse_ironman_args(arg_a: Option<&String>, arg_b: Option<&String>, arg_c: Option<&String>) -> IronManLaunch {
    let Some(first) = arg_a else {
        return IronManLaunch::Depth(MIN_IRONMAN_DEPTH);
    };
    let lower = first.trim_start_matches('-').to_ascii_lowercase();

    // Form 1: `ironman timed <base_mins> <inc_secs>`
    if lower == "timed" || lower == "t" {
        let (Some(b_str), Some(i_str)) = (arg_b, arg_c) else {
            eprintln!("Usage: ironman timed <base_mins> <inc_secs>");
            eprintln!("  Allowed base mins: {:?}", ALLOWED_TIMED_BASE_MINS);
            eprintln!("  Allowed inc secs:  {:?}", ALLOWED_TIMED_INC_SECS);
            std::process::exit(1);
        };
        return parse_validated_tc(b_str, i_str);
    }

    // Form 2: `ironman <base_mins>+<inc_secs>` (e.g. `ironman 15+10`)
    if let Some((b_str, i_str)) = first.split_once('+') {
        return parse_validated_tc(b_str, i_str);
    }

    // Form 3: `ironman <depth>` (depth in 12..=60)
    match first.parse::<usize>() {
        Ok(d) if (MIN_IRONMAN_DEPTH..=60).contains(&d) => IronManLaunch::Depth(d),
        Ok(d) if d < MIN_IRONMAN_DEPTH => {
            eprintln!(
                "IronMan depth mode requires depth >= {} (got {}).",
                MIN_IRONMAN_DEPTH, d
            );
            std::process::exit(1);
        }
        Ok(d) => {
            eprintln!("IronMan depth must be <= 60 (got {}).", d);
            std::process::exit(1);
        }
        Err(_) => {
            eprintln!(
                "Invalid IronMan parameter '{}'. Expected depth ({}..=60), '<mins>+<inc>', or 'timed <mins> <inc>'.",
                first, MIN_IRONMAN_DEPTH
            );
            std::process::exit(1);
        }
    }
}

fn parse_validated_tc(b_str: &str, i_str: &str) -> IronManLaunch {
    let base_mins: u16 = match b_str.parse() {
        Ok(v) => v,
        Err(_) => {
            eprintln!("Invalid base minutes '{}'.", b_str);
            std::process::exit(1);
        }
    };
    let inc_secs: u16 = match i_str.parse() {
        Ok(v) => v,
        Err(_) => {
            eprintln!("Invalid Fischer increment seconds '{}'.", i_str);
            std::process::exit(1);
        }
    };
    if !is_valid_ironman_tc(base_mins, inc_secs) {
        eprintln!(
            "Time control {}+{} is not an allowed IronMan combination.",
            base_mins, inc_secs
        );
        eprintln!("  Allowed base mins: {:?}", ALLOWED_TIMED_BASE_MINS);
        eprintln!("  Allowed inc secs:  {:?}", ALLOWED_TIMED_INC_SECS);
        std::process::exit(1);
    }
    IronManLaunch::Timed {
        base_mins,
        inc_secs,
    }
}

fn load_import_request(
    filename_arg: Option<&String>,
    pos_arg: Option<&String>,
) -> (GameVariant, ImportRequest) {
    let Some(filename) = filename_arg else {
        eprintln!("Missing filename for 'import'.");
        eprintln!("Usage: dsq_engine import <filename> [start|end]");
        std::process::exit(1);
    };

    let open_at = match pos_arg.map(|s| s.to_ascii_lowercase()).as_deref() {
        None | Some("end") => ImportPosition::End,
        Some("start") => ImportPosition::Start,
        Some(other) => {
            eprintln!(
                "Invalid import position '{}'. Expected 'start' or 'end'.",
                other
            );
            std::process::exit(1);
        }
    };

    let direct_path = Path::new(filename);
    let resolved_path: PathBuf = if direct_path.is_absolute() {
        direct_path.to_path_buf()
    } else if let Ok(cwd) = env::current_dir() {
        let candidate = cwd.join(direct_path);
        if candidate.exists() {
            candidate
        } else {
            direct_path.to_path_buf()
        }
    } else {
        direct_path.to_path_buf()
    };

    let contents = match std::fs::read_to_string(&resolved_path) {
        Ok(c) => c,
        Err(e) => {
            eprintln!(
                "Failed to read movelist file '{}': {}",
                resolved_path.display(),
                e
            );
            std::process::exit(1);
        }
    };

    match parse_and_detect_import(filename.clone(), &contents, open_at) {
        Ok(res) => res,
        Err(e) => {
            eprintln!("Failed to import '{}': {}", filename, e);
            std::process::exit(1);
        }
    }
}

fn print_help() {
    println!("Dou Shou Qi Engine — EP+SuperKo, Classic SuperKo & Monster Rats");
    println!();
    println!("GUI MODES:");
    println!("  dsq_engine                                              Launch default EP+SuperKo GUI");
    println!("  dsq_engine gui                                          Launch default EP+SuperKo GUI");
    println!(
        "  dsq_engine ironman [depth]                              EP+SuperKo IronMan (depth {}..=60, default {})",
        MIN_IRONMAN_DEPTH, MIN_IRONMAN_DEPTH
    );
    println!("  dsq_engine ironman timed <mins> <inc>                   EP+SuperKo Timed IronMan (or 'ironman 15+10')");
    println!("  dsq_engine classic_superKo                              Launch Classic SuperKo GUI (Arimaa 3-fold ban)");
    println!("  dsq_engine classic_superKo ironman [depth|mins+inc]     Classic SuperKo IronMan (depth or timed)");
    println!("  dsq_engine monster_rats                                 Launch Monster Rats GUI (water->land ambush)");
    println!("  dsq_engine monster_rats ironman [depth|mins+inc]        Monster Rats IronMan (depth or timed)");
    println!("  dsq_engine import <file> [start|end]                    Import movelist & auto-detect mode/setup (default: end)");
    println!();
    println!("ALLOWED TIMED IRONMAN FISCHER COMBINATIONS:");
    println!("  Base reserves (min): {:?}", ALLOWED_TIMED_BASE_MINS);
    println!("  Increment (sec/mv):  {:?}", ALLOWED_TIMED_INC_SECS);
    println!();
    println!("BENCHMARKS, VERIFICATION & CONSOLE PLAY:");
    println!("  dsq_engine bench [depth]                                Benchmark EP+SuperKo search (default depth 9)");
    println!("  dsq_engine classic_superKo bench [depth]                Benchmark Classic SuperKo search");
    println!("  dsq_engine monster_rats bench [depth]                   Benchmark Monster Rats search");
    println!("  dsq_engine perft [depth]                                Move-gen perft benchmark for EP+SuperKo");
    println!("  dsq_engine classic_superKo perft [depth]                Move-gen perft benchmark for Classic SuperKo");
    println!("  dsq_engine monster_rats perft [depth]                   Move-gen perft benchmark for Monster Rats");
    println!("  dsq_engine fuzz [num_games]                             Differential fuzz test vs Reference Oracle");
    println!("  dsq_engine verify-search [games] [nodes]                Self-play search verification");
    println!("  dsq_engine play [p1|p2] [think_ms]                      Play EP+SuperKo in terminal");
    println!("  dsq_engine show                                         Print starting board diagram");
    println!("  dsq_engine help | --help | -h                           Show this help message");
    println!();
    println!("CARGO BUILD & RUN PROFILES:");
    println!("  1) Standard optimized mode (--release) — MUCH FASTER to compile:");
    println!("       cargo run --release");
    println!("       cargo run --release -- ironman 14");
    println!("       cargo run --release -- ironman 15+10");
    println!("       cargo run --release -- classic_superKo ironman timed 5 15");
    println!("       cargo run --release -- monster_rats ironman 3+10");
    println!("       cargo run --release -- import game.txt start");
    println!("     (Uses -O3 with incremental compilation; rebuilds in just a few seconds.)");
    println!();
    println!("  2) Maximum optimization mode (--profile dist) — SLOWER compile, max optimization:");
    println!("       cargo run --profile dist");
    println!("       cargo build --profile dist                       (outputs target/dist/dsq_engine)");
    println!("     (Enables fat LTO, single codegen unit, and symbol stripping; much slower to compile.)");
    println!();
    println!("SAVED DATA LOCATION (~/.local/share/dsq_engine/):");
    println!("  autosave.txt / autosave_classic.txt / autosave_monster_rats.txt");
    println!("  ironman_hof.dat / ironman_hof_classic.dat / ironman_hof_monster_rats.dat                  (Depth HoF)");
    println!("  ironman_hof_timed.dat / ironman_hof_classic_timed.dat / ironman_hof_monster_rats_timed.dat (Timed HoF)");
}

fn run_play(human_side: Color, think_ms: u64) {
    let mut ref_g = RefGame::new_start();
    let (mut bb, mut hist) = BitboardPos::new_start();
    let mut searcher = Searcher::with_tt_mb(64);
    searcher.verbose = true;

    println!(
        "Starting game! You play {} | Engine thinks {} ms/move.",
        human_side, think_ms
    );
    println!("Enter moves like 'a3a4', or type 'moves' to list legal moves, 'quit' to exit.\n");

    loop {
        println!("{}", ref_g.render());
        match bb.game_result(&hist) {
            GameResult::Win(w) => {
                println!("=== GAME OVER: {} WINS! ===", w);
                break;
            }
            GameResult::Ongoing => {}
        }

        let legal = bb.gen_legal_moves(&hist);

        let chosen = if bb.side_to_move == human_side {
            loop {
                print!("Your move ({}): ", human_side);
                io::stdout().flush().unwrap();
                let mut line = String::new();
                if io::stdin().read_line(&mut line).is_err() {
                    return;
                }
                let trimmed = line.trim();
                if trimmed.eq_ignore_ascii_case("quit") || trimmed.eq_ignore_ascii_case("exit") {
                    return;
                }
                if trimmed.eq_ignore_ascii_case("moves") {
                    let mut ms: Vec<String> =
                        legal.as_slice().iter().map(|m| m.to_string()).collect();
                    ms.sort();
                    println!("Legal moves ({}): {}", ms.len(), ms.join(" "));
                    continue;
                }
                if let Some(mv) = parse_move(trimmed) {
                    if legal.as_slice().contains(&mv) {
                        break mv;
                    } else {
                        println!("Illegal move '{}'. Type 'moves' to see legal moves.", trimmed);
                    }
                } else {
                    println!("Invalid format. Use 4 chars like 'a3a4' (or 'moves' / 'quit').");
                }
            }
        } else {
            println!("Engine ({}) thinking...", bb.side_to_move);
            let res = searcher.search(&bb, &mut hist, SearchLimits::time_ms(think_ms));
            println!(
                "Engine plays: {} | depth {} | score {} | {} nodes in {:.2}s\n",
                res.best_move,
                res.depth,
                format_score(res.score),
                res.nodes,
                res.elapsed.as_secs_f64()
            );
            assert!(
                legal.as_slice().contains(&res.best_move),
                "BUG: Engine returned illegal move {}!",
                res.best_move
            );
            res.best_move
        };

        ref_g = ref_g.make_move(chosen);
        bb = bb.make_move(chosen, &mut hist);
        assert_eq!(ref_g.ep, bb.ep, "BUG: EP desync!");
        assert_eq!(ref_g.winner, bb.winner, "BUG: Winner desync!");
    }
}

fn run_bench_ep(depth: usize) {
    let (bb, mut hist) = BitboardPos::new_start();
    let mut searcher = Searcher::with_tt_mb(64);
    searcher.verbose = true;

    println!(
        "Benchmarking EP+SuperKo search from starting position to depth {}:",
        depth
    );
    let res = searcher.search(&bb, &mut hist, SearchLimits::depth(depth));
    let secs = res.elapsed.as_secs_f64();
    let nps = if secs > 0.0 {
        (res.nodes as f64 / secs) as u64
    } else {
        0
    };
    println!(
        "\nResult: best={} score={} depth={} nodes={} time={:.3}s nps={}",
        res.best_move,
        format_score(res.score),
        res.depth,
        res.nodes,
        secs,
        nps
    );
}

fn run_bench_rats(depth: usize) {
    let (bb, mut hist) = RatsPos::new_start();
    let mut searcher = RatsSearcher::with_tt_mb(64);
    searcher.verbose = true;

    println!(
        "Benchmarking Monster Rats search from starting position to depth {}:",
        depth
    );
    let res = searcher.search(&bb, &mut hist, SearchLimits::depth(depth));
    let secs = res.elapsed.as_secs_f64();
    let nps = if secs > 0.0 {
        (res.nodes as f64 / secs) as u64
    } else {
        0
    };
    println!(
        "\nResult: best={} score={} depth={} nodes={} time={:.3}s nps={}",
        res.best_move,
        format_score(res.score),
        res.depth,
        res.nodes,
        secs,
        nps
    );
}

fn run_bench_classic(depth: usize) {
    let (bb, mut hist) = ClassicPos::new_start();
    let mut searcher = ClassicSearcher::with_tt_mb(64);
    searcher.verbose = true;

    println!(
        "Benchmarking Classic SuperKo search from starting position to depth {}:",
        depth
    );
    let res = searcher.search(&bb, &mut hist, SearchLimits::depth(depth));
    let secs = res.elapsed.as_secs_f64();
    let nps = if secs > 0.0 {
        (res.nodes as f64 / secs) as u64
    } else {
        0
    };
    println!(
        "\nResult: best={} score={} depth={} nodes={} time={:.3}s nps={}",
        res.best_move,
        format_score(res.score),
        res.depth,
        res.nodes,
        secs,
        nps
    );
}

fn run_verify_search(num_games: usize, nodes_per_move: u64) {
    let mut searcher = Searcher::with_tt_mb(16);
    let mut rng = Rng::new(0x9876_5432_10FE_DCBA);
    let mut total_plies = 0u64;
    let mut p1_wins = 0u64;
    let mut p2_wins = 0u64;
    let mut timeouts = 0u64;
    let t0 = Instant::now();

    for g in 0..num_games {
        searcher.clear_tables();
        let mut ref_g = RefGame::new_start();
        let (mut bb, mut hist) = BitboardPos::new_start();

        for _ in 0..4 {
            let moves = bb.gen_legal_moves(&hist);
            if moves.is_empty() {
                break;
            }
            let mv = moves.as_slice()[rng.gen_range(moves.len())];
            ref_g = ref_g.make_move(mv);
            bb = bb.make_move(mv, &mut hist);
        }

        let mut finished = false;
        for _ply in 0..300 {
            let mut rm = ref_g.legal_moves();
            let mut bm = bb.gen_legal_moves(&hist).as_slice().to_vec();
            rm.sort();
            bm.sort();
            assert_eq!(rm, bm, "Move mismatch in verify-search game {}", g);
            assert_eq!(ref_g.ep, bb.ep, "EP mismatch in verify-search game {}", g);

            match bb.game_result(&hist) {
                GameResult::Win(Color::P1) => {
                    assert_eq!(ref_g.game_result(), GameResult::Win(Color::P1));
                    p1_wins += 1;
                    finished = true;
                    break;
                }
                GameResult::Win(Color::P2) => {
                    assert_eq!(ref_g.game_result(), GameResult::Win(Color::P2));
                    p2_wins += 1;
                    finished = true;
                    break;
                }
                GameResult::Ongoing => {}
            }

            let res = searcher.search(&bb, &mut hist, SearchLimits::nodes(nodes_per_move));
            assert!(
                bm.contains(&res.best_move),
                "ILLEGAL SEARCH MOVE {} in game {}!\n{}",
                res.best_move,
                g,
                ref_g.render()
            );

            ref_g = ref_g.make_move(res.best_move);
            bb = bb.make_move(res.best_move, &mut hist);
            total_plies += 1;
        }

        if !finished {
            timeouts += 1;
        }
    }

    println!(
        "VERIFIED {} self-play games ({} plies, P1={}, P2={}, max-ply-cap={}) in {:.2}s — ZERO bugs!",
        num_games,
        total_plies,
        p1_wins,
        p2_wins,
        timeouts,
        t0.elapsed().as_secs_f64()
    );
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let raw_cmd = args.get(1).map(|s| s.as_str()).unwrap_or("gui");
    let cmd = raw_cmd.trim_start_matches('-').to_ascii_lowercase();

    match cmd.as_str() {
        "help" | "h" => {
            print_help();
        }
        "gui" => {
            if let Err(e) = run_gui(GameVariant::EpSuperKo, None, None) {
                eprintln!("GUI error: {}", e);
                std::process::exit(1);
            }
        }
        "ironman" | "i" => {
            let launch = parse_ironman_args(args.get(2), args.get(3), args.get(4));
            if let Err(e) = run_gui(GameVariant::EpSuperKo, Some(launch), None) {
                eprintln!("GUI error: {}", e);
                std::process::exit(1);
            }
        }
        "import" => {
            let (variant, req) = load_import_request(args.get(2), args.get(3));
            if let Err(e) = run_gui(variant, None, Some(req)) {
                eprintln!("GUI error: {}", e);
                std::process::exit(1);
            }
        }
        "monster_rats" | "monsterrats" | "monster" | "rats" => {
            let sub = args
                .get(2)
                .map(|s| s.trim_start_matches('-').to_ascii_lowercase());
            match sub.as_deref() {
                None | Some("gui") => {
                    if let Err(e) = run_gui(GameVariant::MonsterRats, None, None) {
                        eprintln!("GUI error: {}", e);
                        std::process::exit(1);
                    }
                }
                Some("ironman") | Some("i") => {
                    let launch = parse_ironman_args(args.get(3), args.get(4), args.get(5));
                    if let Err(e) = run_gui(GameVariant::MonsterRats, Some(launch), None) {
                        eprintln!("GUI error: {}", e);
                        std::process::exit(1);
                    }
                }
                Some("bench") => {
                    let depth: usize = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(9);
                    run_bench_rats(depth);
                }
                Some("perft") => {
                    let max_depth: u32 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(5);
                    let (bb, mut hist) = RatsPos::new_start();
                    println!(
                        "Running Monster Rats perft from starting position up to depth {}:",
                        max_depth
                    );
                    for d in 1..=max_depth {
                        let t0 = Instant::now();
                        let nodes = bb.perft(&mut hist, d);
                        let secs = t0.elapsed().as_secs_f64();
                        let nps = if secs > 0.0 {
                            (nodes as f64 / secs) as u64
                        } else {
                            0
                        };
                        println!(
                            "  depth {}: {:>12} nodes | {:>8.3} s | {:>12} nodes/s",
                            d, nodes, secs, nps
                        );
                    }
                }
                Some(other) => {
                    eprintln!("Unknown monster_rats subcommand '{}'.", other);
                    eprintln!("Run with 'help' to see all valid options.");
                    std::process::exit(1);
                }
            }
        }
        "classic_superko" | "classic" => {
            let sub = args
                .get(2)
                .map(|s| s.trim_start_matches('-').to_ascii_lowercase());
            match sub.as_deref() {
                None | Some("gui") => {
                    if let Err(e) = run_gui(GameVariant::ClassicSuperKo, None, None) {
                        eprintln!("GUI error: {}", e);
                        std::process::exit(1);
                    }
                }
                Some("ironman") | Some("i") => {
                    let launch = parse_ironman_args(args.get(3), args.get(4), args.get(5));
                    if let Err(e) = run_gui(GameVariant::ClassicSuperKo, Some(launch), None) {
                        eprintln!("GUI error: {}", e);
                        std::process::exit(1);
                    }
                }
                Some("bench") => {
                    let depth: usize = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(9);
                    run_bench_classic(depth);
                }
                Some("perft") => {
                    let max_depth: u32 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(5);
                    let (bb, mut hist) = ClassicPos::new_start();
                    println!(
                        "Running Classic SuperKo perft from starting position up to depth {}:",
                        max_depth
                    );
                    for d in 1..=max_depth {
                        let t0 = Instant::now();
                        let nodes = bb.perft(&mut hist, d);
                        let secs = t0.elapsed().as_secs_f64();
                        let nps = if secs > 0.0 {
                            (nodes as f64 / secs) as u64
                        } else {
                            0
                        };
                        println!(
                            "  depth {}: {:>12} nodes | {:>8.3} s | {:>12} nodes/s",
                            d, nodes, secs, nps
                        );
                    }
                }
                Some(other) => {
                    eprintln!("Unknown classic_superKo subcommand '{}'.", other);
                    eprintln!("Run with 'help' to see all valid options.");
                    std::process::exit(1);
                }
            }
        }
        "show" => {
            let g = RefGame::new_start();
            println!("{}", g.render());
            println!("Initial legal moves: {}", g.legal_moves().len());
        }
        "perft" => {
            let max_depth: u32 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(5);
            let (bb, mut hist) = BitboardPos::new_start();
            println!(
                "Running EP+SuperKo perft from starting position up to depth {}:",
                max_depth
            );
            for d in 1..=max_depth {
                let t0 = Instant::now();
                let nodes = bb.perft(&mut hist, d);
                let dt = t0.elapsed();
                let secs = dt.as_secs_f64();
                let nps = if secs > 0.0 {
                    (nodes as f64 / secs) as u64
                } else {
                    0
                };
                println!(
                    "  depth {}: {:>12} nodes | {:>8.3} s | {:>12} nodes/s",
                    d, nodes, secs, nps
                );
            }
        }
        "fuzz" => {
            let games: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(500);
            let mut rng = Rng::new(0x2025_0101_ABCD_EF01);
            let mut total_plies: u64 = 0;
            let mut repetitions_triggered: u64 = 0;
            let mut wins_p1: u64 = 0;
            let mut wins_p2: u64 = 0;
            let t0 = Instant::now();

            for g_idx in 0..games {
                let mut ref_g = RefGame::new_start();
                let (mut bb, mut hist) = BitboardPos::new_start();

                for _ply in 0..400 {
                    let mut rm = ref_g.legal_moves();
                    let mut bm = bb.gen_legal_moves(&hist).as_slice().to_vec();
                    rm.sort();
                    bm.sort();

                    if rm != bm || ref_g.ep != bb.ep || ref_g.winner != bb.winner {
                        eprintln!("MISMATCH on game {}!\n{}", g_idx, ref_g.render());
                        std::process::exit(1);
                    }

                    if bm.is_empty() {
                        match bb.game_result(&hist) {
                            GameResult::Win(Color::P1) => wins_p1 += 1,
                            GameResult::Win(Color::P2) => wins_p2 += 1,
                            _ => unreachable!(),
                        }
                        break;
                    }

                    let ep_before = bb.ep[bb.side_to_move.idx()];
                    let chosen = bm[rng.gen_range(bm.len())];
                    let mover = bb.side_to_move.idx();

                    ref_g = ref_g.make_move(chosen);
                    bb = bb.make_move(chosen, &mut hist);
                    if bb.ep[mover] < ep_before {
                        repetitions_triggered += 1;
                    }
                    total_plies += 1;
                }
            }

            println!(
                "PASSED {} random games ({} plies, {} EP-paid repetitions, P1 wins={}, P2 wins={}) in {:.2}s — ZERO discrepancies!",
                games,
                total_plies,
                repetitions_triggered,
                wins_p1,
                wins_p2,
                t0.elapsed().as_secs_f64()
            );
        }
        "bench" => {
            let depth: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(9);
            run_bench_ep(depth);
        }
        "verify-search" => {
            let games: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(40);
            let nodes: u64 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(8_000);
            run_verify_search(games, nodes);
        }
        "play" => {
            let side = match args.get(2).map(|s| s.to_ascii_lowercase()).as_deref() {
                Some("p2") | Some("2") => Color::P2,
                _ => Color::P1,
            };
            let ms: u64 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(1500);
            run_play(side, ms);
        }
        _ => {
            eprintln!("Unknown command '{}'.\n", raw_cmd);
            print_help();
            std::process::exit(1);
        }
    }
}

