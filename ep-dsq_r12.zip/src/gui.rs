//! Mouse-driven desktop GUI for Dou Shou Qi supporting three isolated engines:
//! 1. EP-DSQ (Energy Points + board-only SuperKo)
//! 2. Classic SuperKo (Arimaa-style 3rd-occurrence ban with same side-to-move, no EP)
//! 3. Monster Rats (EP + SuperKo where Rats in water can strike directly onto land
//!    Elephants & land Rats, while remaining untouchable from land)
//!
//! Features:
//! - Custom setup export/import (`# Setup:`, `# Turn:`, `# EP:`) + automatic mode detection
//! - Unlimited Depth level (`1..=60` + `Unlimited`) & `[Space]` shortcut to Stop thinking
//! - Max Thinking Time slider with `0.25s`, `0.5s`, `1s..180s`, and `Unlimited` rungs
//! - IronMan Depth Mode AND IronMan Timed Match Mode (any allowed Fischer `base+inc`
//!   combination with live clocks, zero-timeout dynamic time management, and dedicated
//!   per-time-control encrypted Hall of Fame files per variant)
//! - Self-contained vector artwork for Chinese (象狮虎豹狼狗猫鼠) and Animals (including Lion!)
//! - Compact `Mode ▾` & `Pieces ▾` menus, `Show Eval`, `Show Thinking`, GUI `Import`,
//!   `[F1]` Rules Help, `[Esc]` close/quit confirmation, Undo/Redo, Setup Mode, Night/Day themes

use crate::classic::board::{ClassicHistory, ClassicPos};
use crate::classic::eval::PIECE_VALUE as CLASSIC_PIECE_VALUE;
use crate::classic::search::ClassicSearcher;
use crate::core::board_bb::{BitboardPos, History, CAPTURED, EMPTY_SQ};
use crate::core::{
    Color, GameResult, Move, PieceKind, Square, COLS, DEN_SQ, INITIAL_PIECES, INVASION_LAND_MASK,
    MAX_EP, ROWS, START_EP, TRAPS_MASK, WATER_MASK,
};
use crate::eval::{PIECE_VALUE as EP_PIECE_VALUE, SCORE_WIN};
use crate::hall_of_fame::{
    now_unix_secs, sanitize_player_name, EndCode, HallOfFame, HallOfFameEntry, TimedHallOfFame,
    TimedHofEntry, ALLOWED_TIMED_BASE_MINS, ALLOWED_TIMED_INC_SECS, MAX_ENTRIES_PER_DEPTH,
    MAX_PLAYER_NAME_LEN, MAX_TIMED_ENTRIES_PER_TC, MAX_TOTAL_ENTRIES,
};
use crate::piece_art::{draw_animal_icon, draw_chinese_char};
use crate::rats::board::{RatsHistory, RatsPos};
use crate::rats::eval::PIECE_VALUE as RATS_PIECE_VALUE;
use crate::rats::search::RatsSearcher;
use crate::search::{SearchLimits, SearchProgress, SearchResult, Searcher, MAX_PLY};
use eframe::egui;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

pub const MIN_IRONMAN_DEPTH: usize = 12;
const MAX_FINITE_DEPTH: usize = 60;
/// Slider value `61` represents Unlimited depth (searches until time limit or Stop).
const UNLIMITED_DEPTH_VAL: usize = 61;
const AUTOSAVE_VERSION: &str = "DSQ_SAVE_V1";

/// Exact discrete thinking-time presets in milliseconds, ending with `None` = Unlimited.
const TIME_PRESETS_MS: [Option<u64>; 26] = [
    Some(250),
    Some(500),
    Some(1_000),
    Some(2_000),
    Some(3_000),
    Some(4_000),
    Some(5_000),
    Some(6_000),
    Some(7_000),
    Some(8_000),
    Some(9_000),
    Some(10_000),
    Some(12_000),
    Some(15_000),
    Some(20_000),
    Some(25_000),
    Some(30_000),
    Some(35_000),
    Some(40_000),
    Some(45_000),
    Some(60_000),
    Some(90_000),
    Some(120_000),
    Some(150_000),
    Some(180_000),
    None,
];
const UNLIMITED_TIME_IDX: usize = TIME_PRESETS_MS.len() - 1;

/// Classic quick-select presets for Timed IronMan Matches `(base_mins, inc_secs)`.
const TIMED_IRONMAN_QUICK_PRESETS: [(u16, u16); 8] = [
    (15, 10),
    (15, 45),
    (10, 30),
    (10, 20),
    (5, 15),
    (3, 10),
    (2, 8),
    (1, 5),
];

fn format_time_limit_ms(ms: Option<u64>) -> String {
    match ms {
        None => "Unlimited".to_owned(),
        Some(250) => "0.25s".to_owned(),
        Some(500) => "0.5s".to_owned(),
        Some(v) if v % 1000 == 0 => format!("{}s", v / 1000),
        Some(v) => format!("{:.2}s", v as f64 / 1000.0),
    }
}

fn format_clock_ms(ms: u64) -> String {
    if ms < 10_000 {
        let secs = ms / 1000;
        let tenths = (ms % 1000) / 100;
        format!("0:{:02}.{}", secs, tenths)
    } else {
        let total_secs = ms / 1000;
        let mins = total_secs / 60;
        let secs = total_secs % 60;
        format!("{:02}:{:02}", mins, secs)
    }
}

fn time_idx_from_ms(ms: Option<u64>) -> usize {
    match ms {
        None => UNLIMITED_TIME_IDX,
        Some(target) => TIME_PRESETS_MS
            .iter()
            .position(|&p| p == Some(target))
            .unwrap_or_else(|| {
                TIME_PRESETS_MS[..UNLIMITED_TIME_IDX]
                    .iter()
                    .enumerate()
                    .min_by_key(|(_, &p)| p.unwrap_or(u64::MAX).abs_diff(target))
                    .map(|(i, _)| i)
                    .unwrap_or(UNLIMITED_TIME_IDX)
            }),
    }
}

fn format_depth_val(d: usize) -> String {
    if d >= UNLIMITED_DEPTH_VAL {
        "Unlimited".to_owned()
    } else {
        d.to_string()
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum IronManLaunch {
    Depth(usize),
    Timed { base_mins: u16, inc_secs: u16 },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GameVariant {
    EpSuperKo,
    ClassicSuperKo,
    MonsterRats,
}

impl GameVariant {
    pub const ALL: [GameVariant; 3] = [
        GameVariant::EpSuperKo,
        GameVariant::ClassicSuperKo,
        GameVariant::MonsterRats,
    ];

    pub const fn display_name(self) -> &'static str {
        match self {
            GameVariant::EpSuperKo => "EP + SuperKo",
            GameVariant::ClassicSuperKo => "Classic SuperKo",
            GameVariant::MonsterRats => "Monster Rats",
        }
    }

    pub const fn export_header(self) -> &'static str {
        match self {
            GameVariant::EpSuperKo => "# Mode: EP+SuperKo",
            GameVariant::ClassicSuperKo => "# Mode: Classic SuperKo",
            GameVariant::MonsterRats => "# Mode: Monster Rats",
        }
    }

    pub const fn uses_ep(self) -> bool {
        matches!(self, GameVariant::EpSuperKo | GameVariant::MonsterRats)
    }

    fn data_dir() -> Option<PathBuf> {
        if let Ok(xdg) = std::env::var("XDG_DATA_HOME") {
            if !xdg.is_empty() {
                return Some(PathBuf::from(xdg).join("dsq_engine"));
            }
        }
        if let Ok(home) = std::env::var("HOME") {
            if !home.is_empty() {
                return Some(
                    PathBuf::from(home)
                        .join(".local")
                        .join("share")
                        .join("dsq_engine"),
                );
            }
        }
        None
    }

    fn autosave_path(self) -> PathBuf {
        let fname = match self {
            GameVariant::EpSuperKo => "autosave.txt",
            GameVariant::ClassicSuperKo => "autosave_classic.txt",
            GameVariant::MonsterRats => "autosave_monster_rats.txt",
        };
        match Self::data_dir() {
            Some(dir) => dir.join(fname),
            None => PathBuf::from(format!("dsq_{}", fname)),
        }
    }

    fn hof_path(self) -> PathBuf {
        match self {
            GameVariant::EpSuperKo => HallOfFame::default_path(),
            GameVariant::ClassicSuperKo => match Self::data_dir() {
                Some(dir) => dir.join("ironman_hof_classic.dat"),
                None => PathBuf::from("ironman_hof_classic.dat"),
            },
            GameVariant::MonsterRats => match Self::data_dir() {
                Some(dir) => dir.join("ironman_hof_monster_rats.dat"),
                None => PathBuf::from("ironman_hof_monster_rats.dat"),
            },
        }
    }

    fn timed_hof_path(self) -> PathBuf {
        let fname = match self {
            GameVariant::EpSuperKo => "ironman_hof_timed.dat",
            GameVariant::ClassicSuperKo => "ironman_hof_classic_timed.dat",
            GameVariant::MonsterRats => "ironman_hof_monster_rats_timed.dat",
        };
        match Self::data_dir() {
            Some(dir) => dir.join(fname),
            None => PathBuf::from(fname),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ImportPosition {
    Start,
    End,
}

#[derive(Clone, Debug)]
pub struct GameOrigin {
    piece_sq: [u8; 16],
    side_to_move: Color,
    ep: [u8; 2],
    is_custom: bool,
}

impl GameOrigin {
    fn standard() -> Self {
        let mut piece_sq = [CAPTURED; 16];
        for &(c, k, sq) in &INITIAL_PIECES {
            piece_sq[c.idx() * 8 + k.idx()] = sq.0;
        }
        Self {
            piece_sq,
            side_to_move: Color::P1,
            ep: START_EP,
            is_custom: false,
        }
    }

    fn from_custom(piece_sq: [u8; 16], side_to_move: Color, ep: [u8; 2]) -> Self {
        Self {
            piece_sq,
            side_to_move,
            ep,
            is_custom: true,
        }
    }

    fn to_pieces_vec(&self) -> Vec<(Color, PieceKind, Square)> {
        let mut out = Vec::with_capacity(16);
        for (pid, &s) in self.piece_sq.iter().enumerate() {
            if s != CAPTURED {
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                out.push((color, kind, Square(s)));
            }
        }
        out
    }

    fn format_setup_headers(&self, uses_ep: bool) -> String {
        let mut tokens = Vec::with_capacity(16);
        for side in [Color::P1, Color::P2] {
            let base = side.idx() * 8;
            for k in (0..8usize).rev() {
                let s = self.piece_sq[base + k];
                if s != CAPTURED {
                    let ch = PieceKind::from_idx(k).to_char(side);
                    tokens.push(format!("{}@{}", ch, Square(s)));
                }
            }
        }
        let mut out = format!("# Setup: {}\n# Turn: {}\n", tokens.join(" "), self.side_to_move);
        if uses_ep {
            out.push_str(&format!("# EP: {},{}\n", self.ep[0], self.ep[1]));
        }
        out
    }
}

#[derive(Clone, Debug)]
pub struct ImportRequest {
    pub filename: String,
    pub origin: GameOrigin,
    pub moves: Vec<Move>,
    pub open_at: ImportPosition,
}

#[derive(Clone, Debug)]
struct AutosaveSummary {
    moves: usize,
    plies: usize,
    depth_val: usize,
    time_limit_ms: Option<u64>,
    is_custom: bool,
}

#[derive(Clone, Copy, Debug)]
struct EngineMoveReport {
    mv: Move,
    depth: usize,
    score: i32,
    nodes: u64,
    elapsed_secs: f64,
    stopped: bool,
}

struct ImportDialogState {
    path_input: String,
    paste_input: String,
    use_paste: bool,
    open_at: ImportPosition,
    dir_files: Vec<String>,
    error_msg: Option<String>,
    browse_rx: Option<Receiver<Option<PathBuf>>>,
}

impl ImportDialogState {
    fn new() -> Self {
        Self {
            path_input: String::new(),
            paste_input: String::new(),
            use_paste: false,
            open_at: ImportPosition::End,
            dir_files: scan_cwd_movelist_files(),
            error_msg: None,
            browse_rx: None,
        }
    }

    fn refresh_dir_files(&mut self) {
        self.dir_files = scan_cwd_movelist_files();
    }
}

fn scan_cwd_movelist_files() -> Vec<String> {
    let mut files = Vec::new();
    if let Ok(entries) = std::fs::read_dir(".") {
        for entry in entries.flatten() {
            if let Ok(ft) = entry.file_type() {
                if !ft.is_file() {
                    continue;
                }
            }
            let name = entry.file_name().to_string_lossy().into_owned();
            let lower = name.to_ascii_lowercase();
            if lower.ends_with(".txt") || lower.ends_with(".dsq") || lower.ends_with(".log") {
                files.push(name);
            }
        }
    }
    files.sort();
    files
}

fn parse_piece_char(c: char) -> Option<(Color, PieceKind)> {
    let color = if c.is_ascii_uppercase() {
        Color::P1
    } else if c.is_ascii_lowercase() {
        Color::P2
    } else {
        return None;
    };
    let kind = match c.to_ascii_uppercase() {
        'R' => PieceKind::Rat,
        'C' => PieceKind::Cat,
        'D' => PieceKind::Dog,
        'W' => PieceKind::Wolf,
        'P' => PieceKind::Leopard,
        'T' => PieceKind::Tiger,
        'L' => PieceKind::Lion,
        'E' => PieceKind::Elephant,
        _ => return None,
    };
    Some((color, kind))
}

struct ParsedHeaders {
    variant: Option<GameVariant>,
    origin: GameOrigin,
}

fn parse_export_headers(raw: &str) -> Result<ParsedHeaders, String> {
    let mut variant: Option<GameVariant> = None;
    let mut custom_pieces: Option<[u8; 16]> = None;
    let mut custom_turn: Option<Color> = None;
    let mut custom_ep: Option<[u8; 2]> = None;

    for (line_no, line) in raw.lines().enumerate() {
        let trimmed = line.trim();
        let rest = if let Some(r) = trimmed.strip_prefix('#') {
            r.trim()
        } else if let Some(r) = trimmed.strip_prefix(';') {
            r.trim()
        } else {
            continue;
        };

        let Some((key, val)) = rest.split_once(':') else {
            continue;
        };
        let key_lo = key.trim().to_ascii_lowercase();
        let val = val.trim();

        match key_lo.as_str() {
            "mode" => {
                let v = val.to_ascii_lowercase();
                if v.contains("monster") || v.contains("rat") {
                    variant = Some(GameVariant::MonsterRats);
                } else if v.contains("classic") {
                    variant = Some(GameVariant::ClassicSuperKo);
                } else if v.contains("ep") {
                    variant = Some(GameVariant::EpSuperKo);
                }
            }
            "setup" => {
                let mut arr = [CAPTURED; 16];
                for tok in val.split_whitespace() {
                    let (p_str, sq_str) = tok.split_once('@').ok_or_else(|| {
                        format!(
                            "Line {}: invalid setup token '{}' (expected e.g. E@a3)",
                            line_no + 1,
                            tok
                        )
                    })?;
                    let mut chars = p_str.chars();
                    let p_ch = chars.next().ok_or_else(|| {
                        format!("Line {}: empty piece in '{}'", line_no + 1, tok)
                    })?;
                    if chars.next().is_some() {
                        return Err(format!("Line {}: invalid piece '{}'", line_no + 1, p_str));
                    }
                    let (color, kind) = parse_piece_char(p_ch).ok_or_else(|| {
                        format!("Line {}: unknown piece '{}'", line_no + 1, p_ch)
                    })?;
                    let sq = Square::from_alg(&sq_str.to_ascii_lowercase()).ok_or_else(|| {
                        format!("Line {}: invalid square '{}'", line_no + 1, sq_str)
                    })?;
                    let pid = color.idx() * 8 + kind.idx();
                    if arr[pid] != CAPTURED {
                        return Err(format!(
                            "Line {}: duplicate piece '{}' in setup",
                            line_no + 1,
                            p_ch
                        ));
                    }
                    arr[pid] = sq.0;
                }
                validate_piece_array(&arr)
                    .map_err(|e| format!("Invalid custom setup header: {}", e))?;
                custom_pieces = Some(arr);
            }
            "turn" => {
                let v = val.to_ascii_uppercase();
                custom_turn = match v.as_str() {
                    "P1" | "1" => Some(Color::P1),
                    "P2" | "2" => Some(Color::P2),
                    _ => return Err(format!("Line {}: invalid Turn '{}'", line_no + 1, val)),
                };
            }
            "ep" => {
                let (a, b) = val
                    .split_once(',')
                    .ok_or_else(|| format!("Line {}: invalid EP '{}'", line_no + 1, val))?;
                let e0: u8 = a
                    .trim()
                    .parse()
                    .map_err(|_| format!("Line {}: invalid P1 EP '{}'", line_no + 1, a))?;
                let e1: u8 = b
                    .trim()
                    .parse()
                    .map_err(|_| format!("Line {}: invalid P2 EP '{}'", line_no + 1, b))?;
                if e0 > MAX_EP || e1 > MAX_EP {
                    return Err(format!("Line {}: EP exceeds max {}", line_no + 1, MAX_EP));
                }
                custom_ep = Some([e0, e1]);
            }
            _ => {}
        }
    }

    let origin = if let Some(piece_sq) = custom_pieces {
        GameOrigin::from_custom(
            piece_sq,
            custom_turn.unwrap_or(Color::P1),
            custom_ep.unwrap_or(START_EP),
        )
    } else if custom_turn.is_some() || custom_ep.is_some() {
        let mut std_o = GameOrigin::standard();
        if let Some(t) = custom_turn {
            std_o.side_to_move = t;
        }
        if let Some(e) = custom_ep {
            std_o.ep = e;
        }
        std_o.is_custom = true;
        std_o
    } else {
        GameOrigin::standard()
    };

    Ok(ParsedHeaders { variant, origin })
}

fn parse_movelist_tokens(raw: &str, allow_empty: bool) -> Result<Vec<Move>, String> {
    let mut parsed = Vec::new();
    for (line_no, raw_line) in raw.lines().enumerate() {
        let line = raw_line
            .split('#')
            .next()
            .unwrap_or("")
            .split(';')
            .next()
            .unwrap_or("");
        for tok in line.split_whitespace() {
            if tok.ends_with('.') && tok[..tok.len() - 1].chars().all(|c| c.is_ascii_digit()) {
                continue;
            }
            let after_num = if let Some(dot_idx) = tok.find('.') {
                if tok[..dot_idx].chars().all(|c| c.is_ascii_digit()) && dot_idx > 0 {
                    &tok[dot_idx + 1..]
                } else {
                    tok
                }
            } else {
                tok
            };
            if after_num.is_empty() {
                continue;
            }
            let mv = parse_exported_move_token(after_num).ok_or_else(|| {
                format!(
                    "Line {}: could not parse move token '{}'",
                    line_no + 1,
                    tok
                )
            })?;
            parsed.push(mv);
        }
    }

    if parsed.is_empty() && !allow_empty {
        return Err("Movelist file contains no moves.".to_owned());
    }
    Ok(parsed)
}

fn validate_moves_from_origin(
    variant: GameVariant,
    origin: &GameOrigin,
    moves: &[Move],
) -> Result<(), String> {
    let pieces = origin.to_pieces_vec();
    let mut state = EngineState::from_custom(variant, &pieces, origin.side_to_move, origin.ep);
    for (idx, &mv) in moves.iter().enumerate() {
        if state.game_result() != GameResult::Ongoing {
            return Err(format!(
                "Ply {} ({}): game has already ended before this move.",
                idx + 1,
                mv
            ));
        }
        let legal = state.gen_legal_moves();
        if !legal.contains(&mv) {
            return Err(format!(
                "Ply {} ({}): illegal move '{}' for {} in {} mode.",
                idx + 1,
                idx / 2 + 1,
                mv,
                state.side_to_move(),
                variant.display_name()
            ));
        }
        state.apply_move(mv);
    }
    Ok(())
}

/// Parses an exported movelist file (supporting standard starts AND custom `# Setup:` starts),
/// auto-detects the game mode, and validates every move legally.
pub fn parse_and_detect_import(
    filename: String,
    raw: &str,
    open_at: ImportPosition,
) -> Result<(GameVariant, ImportRequest), String> {
    let headers = parse_export_headers(raw)?;
    let moves = parse_movelist_tokens(raw, headers.origin.is_custom)?;

    if let Some(header_variant) = headers.variant {
        validate_moves_from_origin(header_variant, &headers.origin, &moves)?;
        return Ok((
            header_variant,
            ImportRequest {
                filename,
                origin: headers.origin,
                moves,
                open_at,
            },
        ));
    }

    let ep_res = validate_moves_from_origin(GameVariant::EpSuperKo, &headers.origin, &moves);
    let cl_res = validate_moves_from_origin(GameVariant::ClassicSuperKo, &headers.origin, &moves);
    let mr_res = validate_moves_from_origin(GameVariant::MonsterRats, &headers.origin, &moves);

    let chosen_variant = match (ep_res, cl_res, mr_res) {
        (Ok(()), _, _) => GameVariant::EpSuperKo,
        (Err(_), Ok(()), _) => GameVariant::ClassicSuperKo,
        (Err(_), Err(_), Ok(())) => GameVariant::MonsterRats,
        (Err(e_ep), Err(e_cl), Err(e_mr)) => {
            return Err(format!(
                "Invalid movelist under all modes:\n  - EP+SuperKo: {}\n  - Classic SuperKo: {}\n  - Monster Rats: {}",
                e_ep, e_cl, e_mr
            ));
        }
    };

    Ok((
        chosen_variant,
        ImportRequest {
            filename,
            origin: headers.origin,
            moves,
            open_at,
        },
    ))
}

fn parse_exported_move_token(tok: &str) -> Option<Move> {
    let after_prefix = match tok.split_once(':') {
        Some((_, rest)) => rest,
        None => tok,
    };
    let cleaned = after_prefix.trim_end_matches(|c: char| matches!(c, '*' | '+' | '!' | '?' | ','));
    let lower = cleaned.to_ascii_lowercase();
    let bytes = lower.as_bytes();

    if bytes.len() == 4 {
        let from = Square::from_alg(&lower[0..2])?;
        let to = Square::from_alg(&lower[2..4])?;
        Some(Move::new(from, to))
    } else if bytes.len() == 5 && (bytes[2] == b'-' || bytes[2] == b'x') {
        let from = Square::from_alg(&lower[0..2])?;
        let to = Square::from_alg(&lower[3..5])?;
        Some(Move::new(from, to))
    } else {
        None
    }
}

#[derive(Clone)]
enum EngineState {
    Ep(BitboardPos, History),
    Classic(ClassicPos, ClassicHistory),
    Rats(RatsPos, RatsHistory),
}

impl EngineState {
    fn new_start(variant: GameVariant) -> Self {
        match variant {
            GameVariant::EpSuperKo => {
                let (p, h) = BitboardPos::new_start();
                EngineState::Ep(p, h)
            }
            GameVariant::ClassicSuperKo => {
                let (p, h) = ClassicPos::new_start();
                EngineState::Classic(p, h)
            }
            GameVariant::MonsterRats => {
                let (p, h) = RatsPos::new_start();
                EngineState::Rats(p, h)
            }
        }
    }

    fn from_custom(
        variant: GameVariant,
        pieces: &[(Color, PieceKind, Square)],
        side_to_move: Color,
        ep: [u8; 2],
    ) -> Self {
        match variant {
            GameVariant::EpSuperKo => {
                let (p, h) = BitboardPos::from_custom(pieces, side_to_move, ep);
                EngineState::Ep(p, h)
            }
            GameVariant::ClassicSuperKo => {
                let (p, h) = ClassicPos::from_custom(pieces, side_to_move);
                EngineState::Classic(p, h)
            }
            GameVariant::MonsterRats => {
                let (p, h) = RatsPos::from_custom(pieces, side_to_move, ep);
                EngineState::Rats(p, h)
            }
        }
    }

    fn piece_sq(&self) -> [u8; 16] {
        match self {
            EngineState::Ep(p, _) => p.piece_sq,
            EngineState::Classic(p, _) => p.piece_sq,
            EngineState::Rats(p, _) => p.piece_sq,
        }
    }

    fn board_piece(&self, sq_idx: usize) -> u8 {
        match self {
            EngineState::Ep(p, _) => p.board_piece[sq_idx],
            EngineState::Classic(p, _) => p.board_piece[sq_idx],
            EngineState::Rats(p, _) => p.board_piece[sq_idx],
        }
    }

    fn occ_side(&self, side: usize) -> u64 {
        match self {
            EngineState::Ep(p, _) => p.occ_side[side],
            EngineState::Classic(p, _) => p.occ_side[side],
            EngineState::Rats(p, _) => p.occ_side[side],
        }
    }

    fn total_pieces(&self) -> u32 {
        (self.occ_side(0) | self.occ_side(1)).count_ones()
    }

    fn side_to_move(&self) -> Color {
        match self {
            EngineState::Ep(p, _) => p.side_to_move,
            EngineState::Classic(p, _) => p.side_to_move,
            EngineState::Rats(p, _) => p.side_to_move,
        }
    }

    fn winner(&self) -> Option<Color> {
        match self {
            EngineState::Ep(p, _) => p.winner,
            EngineState::Classic(p, _) => p.winner,
            EngineState::Rats(p, _) => p.winner,
        }
    }

    fn ep(&self) -> [u8; 2] {
        match self {
            EngineState::Ep(p, _) => p.ep,
            EngineState::Classic(_, _) => [0, 0],
            EngineState::Rats(p, _) => p.ep,
        }
    }

    fn side_army_strength(&self, side: Color) -> i32 {
        let base = side.idx() * 8;
        let (piece_sq, values) = match self {
            EngineState::Ep(p, _) => (&p.piece_sq, &EP_PIECE_VALUE),
            EngineState::Classic(p, _) => (&p.piece_sq, &CLASSIC_PIECE_VALUE),
            EngineState::Rats(p, _) => (&p.piece_sq, &RATS_PIECE_VALUE),
        };
        let mut total = 0i32;
        for k in 0..8usize {
            if piece_sq[base + k] != CAPTURED {
                total += values[k];
            }
        }
        total
    }

    fn gen_legal_moves(&self) -> Vec<Move> {
        match self {
            EngineState::Ep(p, h) => p.gen_legal_moves(h).as_slice().to_vec(),
            EngineState::Classic(p, h) => p.gen_legal_moves(h).as_slice().to_vec(),
            EngineState::Rats(p, h) => p.gen_legal_moves(h).as_slice().to_vec(),
        }
    }

    fn game_result(&self) -> GameResult {
        match self {
            EngineState::Ep(p, h) => p.game_result(h),
            EngineState::Classic(p, h) => p.game_result(h),
            EngineState::Rats(p, h) => p.game_result(h),
        }
    }

    fn move_has_rep_warning(&self, mv: Move) -> bool {
        match self {
            EngineState::Ep(p, h) => {
                let opp_den = DEN_SQ[p.side_to_move.opp().idx()].0;
                if mv.to().0 == opp_den || p.board_piece[mv.to().idx()] != EMPTY_SQ {
                    return false;
                }
                let pid = p.board_piece[mv.from().idx()] as usize;
                let mut next_sq = p.piece_sq;
                next_sq[pid] = mv.to().0;
                h.contains(u128::from_ne_bytes(next_sq))
            }
            EngineState::Classic(p, h) => p.prior_occurrences_after(mv, h) == 1,
            EngineState::Rats(p, h) => {
                let opp_den = DEN_SQ[p.side_to_move.opp().idx()].0;
                if mv.to().0 == opp_den || p.board_piece[mv.to().idx()] != EMPTY_SQ {
                    return false;
                }
                let pid = p.board_piece[mv.from().idx()] as usize;
                let mut next_sq = p.piece_sq;
                next_sq[pid] = mv.to().0;
                h.contains(u128::from_ne_bytes(next_sq))
            }
        }
    }

    fn apply_move(&mut self, mv: Move) -> bool {
        match self {
            EngineState::Ep(p, h) => {
                let mover_idx = p.side_to_move.idx();
                let ep_before = p.ep[mover_idx];
                *p = p.make_move(mv, h);
                p.ep[mover_idx] < ep_before
            }
            EngineState::Classic(p, h) => {
                let is_rep2 = p.prior_occurrences_after(mv, h) == 1;
                *p = p.make_move(mv, h);
                is_rep2
            }
            EngineState::Rats(p, h) => {
                let mover_idx = p.side_to_move.idx();
                let ep_before = p.ep[mover_idx];
                *p = p.make_move(mv, h);
                p.ep[mover_idx] < ep_before
            }
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PieceSet {
    Chinese,
    Animals,
    Unicode,
    Numbers,
    Letters,
}

impl PieceSet {
    const ALL: [PieceSet; 5] = [
        PieceSet::Chinese,
        PieceSet::Animals,
        PieceSet::Unicode,
        PieceSet::Numbers,
        PieceSet::Letters,
    ];

    const fn label(self) -> &'static str {
        match self {
            PieceSet::Chinese => "Chinese",
            PieceSet::Animals => "Animals",
            PieceSet::Unicode => "Unicode",
            PieceSet::Numbers => "Numbers",
            PieceSet::Letters => "Letters",
        }
    }

    fn as_str(self) -> &'static str {
        match self {
            PieceSet::Chinese => "chinese",
            PieceSet::Animals => "animals",
            PieceSet::Unicode => "unicode",
            PieceSet::Numbers => "numbers",
            PieceSet::Letters => "letters",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        match s {
            "chinese" => Some(PieceSet::Chinese),
            "animals" => Some(PieceSet::Animals),
            "unicode" => Some(PieceSet::Unicode),
            "numbers" => Some(PieceSet::Numbers),
            "letters" => Some(PieceSet::Letters),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ColorTheme {
    Night,
    Day,
}

impl ColorTheme {
    fn as_str(self) -> &'static str {
        match self {
            ColorTheme::Night => "night",
            ColorTheme::Day => "day",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        match s {
            "night" => Some(ColorTheme::Night),
            "day" => Some(ColorTheme::Day),
            _ => None,
        }
    }

    fn palette(self) -> Palette {
        match self {
            ColorTheme::Night => Palette {
                board_frame: egui::Color32::from_rgb(20, 23, 30),
                coord_text: egui::Color32::from_rgb(155, 165, 185),
                land_light: egui::Color32::from_rgb(46, 52, 64),
                land_dark: egui::Color32::from_rgb(38, 43, 54),
                water_light: egui::Color32::from_rgb(22, 62, 92),
                water_dark: egui::Color32::from_rgb(18, 52, 78),
                trap_p1: egui::Color32::from_rgb(82, 54, 44),
                trap_p2: egui::Color32::from_rgb(44, 62, 86),
                den_p1: egui::Color32::from_rgb(112, 74, 34),
                den_p2: egui::Color32::from_rgb(36, 78, 114),
                grid_line: egui::Color32::from_rgb(24, 28, 36),
                p1_fill: egui::Color32::from_rgb(218, 148, 52),
                p1_border: egui::Color32::from_rgb(255, 224, 150),
                p1_text: egui::Color32::from_rgb(24, 16, 8),
                p2_fill: egui::Color32::from_rgb(56, 138, 212),
                p2_border: egui::Color32::from_rgb(180, 225, 255),
                p2_text: egui::Color32::from_rgb(245, 250, 255),
                selected_ring: egui::Color32::from_rgb(110, 240, 140),
                last_move_tint: egui::Color32::from_rgba_unmultiplied(240, 210, 80, 52),
                thinking_from_tint: egui::Color32::from_rgba_unmultiplied(64, 225, 255, 78),
                thinking_to_tint: egui::Color32::from_rgba_unmultiplied(215, 95, 255, 86),
                thinking_accent: egui::Color32::from_rgb(88, 228, 255),
                legal_quiet: egui::Color32::from_rgba_unmultiplied(100, 230, 130, 190),
                legal_rep_warn: egui::Color32::from_rgba_unmultiplied(255, 175, 50, 220),
                legal_capture: egui::Color32::from_rgba_unmultiplied(255, 85, 85, 230),
                legal_win: egui::Color32::from_rgba_unmultiplied(255, 230, 60, 240),
                panel_card_bg: egui::Color32::from_rgb(30, 34, 43),
                badge_text: egui::Color32::from_rgb(215, 222, 235),
                ep_empty_cell: egui::Color32::from_rgb(44, 49, 60),
                ep_grid_border: egui::Color32::from_rgb(20, 23, 30),
                ep_zero_warn: egui::Color32::from_rgb(235, 82, 82),
                ep_gain_badge: egui::Color32::from_rgb(100, 225, 135),
                setup_banner: egui::Color32::from_rgb(160, 115, 245),
                ironman_accent: egui::Color32::from_rgb(240, 96, 64),
                classic_accent: egui::Color32::from_rgb(86, 196, 184),
                rats_accent: egui::Color32::from_rgb(188, 235, 74),
            },
            ColorTheme::Day => Palette {
                board_frame: egui::Color32::from_rgb(218, 210, 196),
                coord_text: egui::Color32::from_rgb(68, 62, 54),
                land_light: egui::Color32::from_rgb(236, 221, 192),
                land_dark: egui::Color32::from_rgb(220, 202, 168),
                water_light: egui::Color32::from_rgb(115, 186, 230),
                water_dark: egui::Color32::from_rgb(98, 172, 218),
                trap_p1: egui::Color32::from_rgb(228, 180, 162),
                trap_p2: egui::Color32::from_rgb(168, 194, 226),
                den_p1: egui::Color32::from_rgb(224, 152, 112),
                den_p2: egui::Color32::from_rgb(122, 168, 222),
                grid_line: egui::Color32::from_rgb(165, 148, 122),
                p1_fill: egui::Color32::from_rgb(196, 56, 44),
                p1_border: egui::Color32::from_rgb(110, 22, 18),
                p1_text: egui::Color32::from_rgb(255, 248, 240),
                p2_fill: egui::Color32::from_rgb(36, 90, 168),
                p2_border: egui::Color32::from_rgb(16, 46, 96),
                p2_text: egui::Color32::from_rgb(245, 250, 255),
                selected_ring: egui::Color32::from_rgb(22, 160, 68),
                last_move_tint: egui::Color32::from_rgba_unmultiplied(230, 190, 20, 80),
                thinking_from_tint: egui::Color32::from_rgba_unmultiplied(0, 165, 205, 85),
                thinking_to_tint: egui::Color32::from_rgba_unmultiplied(155, 45, 215, 90),
                thinking_accent: egui::Color32::from_rgb(0, 128, 168),
                legal_quiet: egui::Color32::from_rgba_unmultiplied(26, 150, 68, 190),
                legal_rep_warn: egui::Color32::from_rgba_unmultiplied(220, 120, 10, 225),
                legal_capture: egui::Color32::from_rgba_unmultiplied(215, 35, 35, 235),
                legal_win: egui::Color32::from_rgba_unmultiplied(230, 170, 0, 245),
                panel_card_bg: egui::Color32::from_rgb(238, 234, 226),
                badge_text: egui::Color32::from_rgb(38, 36, 32),
                ep_empty_cell: egui::Color32::from_rgb(214, 208, 198),
                ep_grid_border: egui::Color32::from_rgb(165, 156, 142),
                ep_zero_warn: egui::Color32::from_rgb(195, 32, 32),
                ep_gain_badge: egui::Color32::from_rgb(24, 138, 58),
                setup_banner: egui::Color32::from_rgb(110, 56, 185),
                ironman_accent: egui::Color32::from_rgb(185, 42, 24),
                classic_accent: egui::Color32::from_rgb(20, 128, 118),
                rats_accent: egui::Color32::from_rgb(92, 145, 18),
            },
        }
    }
}

struct Palette {
    board_frame: egui::Color32,
    coord_text: egui::Color32,
    land_light: egui::Color32,
    land_dark: egui::Color32,
    water_light: egui::Color32,
    water_dark: egui::Color32,
    trap_p1: egui::Color32,
    trap_p2: egui::Color32,
    den_p1: egui::Color32,
    den_p2: egui::Color32,
    grid_line: egui::Color32,
    p1_fill: egui::Color32,
    p1_border: egui::Color32,
    p1_text: egui::Color32,
    p2_fill: egui::Color32,
    p2_border: egui::Color32,
    p2_text: egui::Color32,
    selected_ring: egui::Color32,
    last_move_tint: egui::Color32,
    thinking_from_tint: egui::Color32,
    thinking_to_tint: egui::Color32,
    thinking_accent: egui::Color32,
    legal_quiet: egui::Color32,
    legal_rep_warn: egui::Color32,
    legal_capture: egui::Color32,
    legal_win: egui::Color32,
    panel_card_bg: egui::Color32,
    badge_text: egui::Color32,
    ep_empty_cell: egui::Color32,
    ep_grid_border: egui::Color32,
    ep_zero_warn: egui::Color32,
    ep_gain_badge: egui::Color32,
    setup_banner: egui::Color32,
    ironman_accent: egui::Color32,
    classic_accent: egui::Color32,
    rats_accent: egui::Color32,
}

#[derive(Clone)]
struct MoveRecord {
    #[allow(dead_code)]
    side: Color,
    mv: Move,
    piece: PieceKind,
    captured: Option<PieceKind>,
    rep_marked: bool,
}

#[derive(Clone)]
struct Snapshot {
    state: EngineState,
    move_log: Vec<MoveRecord>,
    last_move: Option<Move>,
}

struct PendingSearch {
    generation: u64,
    rx: Receiver<SearchResult>,
    progress_rx: Option<Receiver<SearchProgress>>,
    latest_progress: Option<SearchProgress>,
    stop_flag: Arc<AtomicBool>,
    stop_requested: bool,
    started_at: Instant,
}

#[derive(Clone)]
struct SetupState {
    piece_sq: [u8; 16],
    side_to_move: Color,
    ep: [u8; 2],
    brush_color: Color,
    brush_kind: PieceKind,
    chord_consumed: bool,
    status_msg: String,
}

impl SetupState {
    fn from_state(state: &EngineState) -> Self {
        Self {
            piece_sq: state.piece_sq(),
            side_to_move: state.side_to_move(),
            ep: state.ep(),
            brush_color: Color::P1,
            brush_kind: PieceKind::Elephant,
            chord_consumed: false,
            status_msg: "L-click: selected color | R-click: other color | L+R (or M-click): remove"
                .to_owned(),
        }
    }

    fn clear_board(&mut self) {
        self.piece_sq = [CAPTURED; 16];
        self.status_msg = "Board cleared.".to_owned();
    }

    fn reset_start(&mut self) {
        self.piece_sq = [CAPTURED; 16];
        for &(color, kind, sq) in &INITIAL_PIECES {
            self.piece_sq[color.idx() * 8 + kind.idx()] = sq.0;
        }
        self.side_to_move = Color::P1;
        self.ep = START_EP;
        self.status_msg = "Reset to standard starting position.".to_owned();
    }

    fn piece_at(&self, sq: Square) -> Option<usize> {
        self.piece_sq.iter().position(|&s| s == sq.0)
    }

    fn remove_at(&mut self, sq: Square) {
        if let Some(pid) = self.piece_at(sq) {
            self.piece_sq[pid] = CAPTURED;
            let c = if pid < 8 { Color::P1 } else { Color::P2 };
            let k = PieceKind::from_idx(pid & 7);
            self.status_msg = format!("Removed {} {} from {}.", c, piece_name(k), sq);
        }
    }

    fn place_piece(&mut self, color: Color, kind: PieceKind, sq: Square) {
        if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
            self.status_msg = format!("Cannot place any piece inside a Den ({})!", sq);
            return;
        }
        if (sq.bit() & WATER_MASK) != 0 && !kind.can_enter_water() {
            self.status_msg = format!(
                "Only Rats can be placed in water! ({} cannot enter {})",
                piece_name(kind),
                sq
            );
            return;
        }

        if let Some(existing_pid) = self.piece_at(sq) {
            self.piece_sq[existing_pid] = CAPTURED;
        }

        let pid = color.idx() * 8 + kind.idx();
        self.piece_sq[pid] = sq.0;
        self.status_msg = format!("Placed {} {} on {}.", color, piece_name(kind), sq);
    }

    fn side_occ(&self, side: usize) -> u64 {
        let base = side * 8;
        let mut m = 0u64;
        for k in 0..8 {
            let s = self.piece_sq[base + k];
            if s != CAPTURED {
                m |= 1u64 << s;
            }
        }
        m
    }

    fn validate(&self) -> Result<(), &'static str> {
        validate_piece_array(&self.piece_sq)
    }

    fn to_pieces_vec(&self) -> Vec<(Color, PieceKind, Square)> {
        let mut out = Vec::with_capacity(16);
        for (pid, &s) in self.piece_sq.iter().enumerate() {
            if s != CAPTURED {
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                out.push((color, kind, Square(s)));
            }
        }
        out
    }
}

fn validate_piece_array(piece_sq: &[u8; 16]) -> Result<(), &'static str> {
    let mut p1_cnt = 0usize;
    let mut p2_cnt = 0usize;
    let mut occ = 0u64;
    for (pid, &s) in piece_sq.iter().enumerate() {
        if s == CAPTURED {
            continue;
        }
        if s >= 63 {
            return Err("Invalid square index.");
        }
        let sq = Square(s);
        let bit = sq.bit();
        if (occ & bit) != 0 {
            return Err("Two pieces occupy the same square.");
        }
        occ |= bit;
        if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
            return Err("No piece may be inside a Den.");
        }
        let kind = PieceKind::from_idx(pid & 7);
        if !kind.can_enter_water() && (bit & WATER_MASK) != 0 {
            return Err("Only Rats may stand in water.");
        }
        if pid < 8 {
            p1_cnt += 1;
        } else {
            p2_cnt += 1;
        }
    }
    if p1_cnt == 0 {
        return Err("P1 must have at least 1 piece.");
    }
    if p2_cnt == 0 {
        return Err("P2 must have at least 1 piece.");
    }
    Ok(())
}

fn inspect_autosave_summary(variant: GameVariant) -> Option<AutosaveSummary> {
    let path = variant.autosave_path();
    let text = std::fs::read_to_string(&path).ok()?;
    let mut lines = text.lines();
    if lines.next().map(|l| l.trim()) != Some(AUTOSAVE_VERSION) {
        return None;
    }
    let mut is_custom = false;
    let mut depth_val = 8usize;
    let mut time_limit_ms: Option<u64> = None;
    let mut plies = 0usize;

    for line in lines {
        let Some((k, v)) = line.split_once('=') else {
            continue;
        };
        let v = v.trim();
        match k.trim() {
            "origin_custom" => is_custom = v == "1",
            "depth" => {
                if v.eq_ignore_ascii_case("unlimited") {
                    depth_val = UNLIMITED_DEPTH_VAL;
                } else if let Ok(d) = v.parse::<usize>() {
                    depth_val = d.clamp(1, MAX_FINITE_DEPTH);
                }
            }
            "time_limit_ms" => {
                if v.eq_ignore_ascii_case("unlimited") {
                    time_limit_ms = None;
                } else if let Ok(ms) = v.parse::<u64>() {
                    time_limit_ms = Some(ms);
                }
            }
            "time_limit" => {
                if v.eq_ignore_ascii_case("unlimited") {
                    time_limit_ms = None;
                } else if let Ok(s) = v.parse::<u64>() {
                    time_limit_ms = Some(s.saturating_mul(1000));
                }
            }
            "moves" => {
                plies = v.split_whitespace().count();
            }
            _ => {}
        }
    }

    if plies == 0 && !is_custom {
        return None;
    }

    Some(AutosaveSummary {
        moves: plies.div_ceil(2),
        plies,
        depth_val,
        time_limit_ms,
        is_custom,
    })
}

/// Active Fischer chess clocks for a Timed IronMan match.
#[derive(Clone, Debug)]
struct TimedMatchClock {
    base_mins: u16,
    inc_secs: u16,
    rem_ms: [u64; 2],
    turn_started_at: Instant,
    flagged_winner: Option<Color>,
}

impl TimedMatchClock {
    fn new(base_mins: u16, inc_secs: u16) -> Self {
        let base_ms = (base_mins as u64) * 60_000;
        Self {
            base_mins,
            inc_secs,
            rem_ms: [base_ms, base_ms],
            turn_started_at: Instant::now(),
            flagged_winner: None,
        }
    }

    fn live_remaining_ms(&self, side: Color, active_side: Color, ongoing: bool) -> u64 {
        let stored = self.rem_ms[side.idx()];
        if ongoing && self.flagged_winner.is_none() && side == active_side {
            let elapsed = self.turn_started_at.elapsed().as_millis() as u64;
            stored.saturating_sub(elapsed)
        } else {
            stored
        }
    }

    /// Commits the elapsed time for `mover`, adds Fischer increment, and starts next turn's clock.
    fn commit_move(&mut self, mover: Color, elapsed_ms: u64) {
        let idx = mover.idx();
        let after_deduct = self.rem_ms[idx].saturating_sub(elapsed_ms);
        self.rem_ms[idx] = after_deduct.saturating_add((self.inc_secs as u64) * 1000);
        self.turn_started_at = Instant::now();
    }

    /// Computes a dynamic, **zero-timeout** time allocation (in milliseconds) for the engine.
    ///
    /// Guarantees the engine NEVER flags:
    /// - Reserves a strict safety margin (`380 ms`) for OS thread wakeup & GUI polling.
    /// - Scales move budget dynamically based on remaining reserve, Fischer increment,
    ///   piece count (complexity), and ply number.
    fn allocate_engine_budget_ms(&self, engine_side: Color, plies: usize, total_pieces: u32) -> u64 {
        const SAFETY_MARGIN_MS: u64 = 380;

        let rem_ms = self.rem_ms[engine_side.idx()];
        let inc_ms = (self.inc_secs as u64) * 1000;

        // Hard ceiling strictly below remaining reserve so flagging is impossible
        let safe_avail = rem_ms.saturating_sub(SAFETY_MARGIN_MS);
        if safe_avail <= 120 {
            return safe_avail.max(40);
        }

        // Estimate moves remaining: slightly higher budget in complex midgame battles,
        // conservative early in opening and late when reserves run low.
        let base_horizon: u64 = if plies < 8 {
            34
        } else if total_pieces >= 10 {
            24
        } else {
            20
        };

        // Target Fischer allocation: share of reserve + 78% of increment
        let target_ms = (safe_avail / base_horizon) + (inc_ms * 78 / 100);

        // Never spend more than 35% of safe remaining reserve on a single move
        let max_share = (safe_avail * 35 / 100).max(inc_ms * 75 / 100);
        let hard_cap = safe_avail.min(max_share).max(60);

        // Remember Searcher's soft-stop triggers at 55% of `max_time` and hard-stop at 100%,
        // so passing `budget_ms` clamped to `hard_cap` keeps actual runtime strictly <= `hard_cap`!
        target_ms.clamp(60, hard_cap)
    }
}

#[derive(Clone)]
enum IronManKind {
    Depth { start_depth: usize, min_depth: usize },
    Timed(TimedMatchClock),
}

#[derive(Clone)]
struct IronManState {
    kind: IronManKind,
    recorded_this_game: bool,
}

#[derive(Clone)]
enum PendingHofRecord {
    Depth(HallOfFameEntry, usize),
    Timed(TimedHofEntry, usize),
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum HofTab {
    Depth,
    Timed,
}

pub struct DsqGuiApp {
    variant: GameVariant,
    origin: GameOrigin,
    state: EngineState,
    move_log: Vec<MoveRecord>,
    undo_stack: Vec<Snapshot>,
    redo_stack: Vec<Snapshot>,
    last_move: Option<Move>,

    setup: Option<SetupState>,
    ironman: Option<IronManState>,
    hof: HallOfFame,
    hof_status: Option<String>,
    timed_hof: TimedHallOfFame,
    timed_hof_status: Option<String>,
    hof_tab: HofTab,

    show_hof_window: bool,
    show_help_window: bool,
    show_ironman_setup_confirm: bool,
    show_enter_ironman_confirm: bool,
    enter_ironman_is_timed: bool,
    enter_ironman_depth_choice: usize,
    enter_ironman_base_idx: usize,
    enter_ironman_inc_idx: usize,
    show_new_game_leave_ironman_confirm: bool,
    show_gui_import_overwrite_confirm: bool,
    import_dialog: Option<ImportDialogState>,

    pending_hof_record: Option<PendingHofRecord>,
    hof_name_input: String,

    pending_import_confirm: Option<(ImportRequest, AutosaveSummary)>,

    human_side: Color,
    /// `1..=60` for finite depth, or `UNLIMITED_DEPTH_VAL (61)` for Unlimited.
    search_depth: usize,
    time_limit_idx: usize,
    piece_set: PieceSet,
    theme: ColorTheme,
    rotation: u8,
    show_legal_moves: bool,
    show_thinking: bool,
    show_eval: bool,

    selected_sq: Option<Square>,
    pending_search: Option<PendingSearch>,
    search_generation: u64,
    last_engine_info: String,
    last_move_report: Option<EngineMoveReport>,
    copied_until: Option<Instant>,

    show_quit_confirm: bool,
    allow_close: bool,
}

impl DsqGuiApp {
    fn new(
        cc: &eframe::CreationContext<'_>,
        variant: GameVariant,
        ironman_launch: Option<IronManLaunch>,
        import_req: Option<ImportRequest>,
    ) -> Self {
        install_system_symbol_fonts(&cc.egui_ctx);
        cc.egui_ctx.set_visuals(egui::Visuals::dark());

        let (hof, hof_status) = match HallOfFame::load_from_path(&variant.hof_path()) {
            Ok(h) => (h, None),
            Err(err) => (HallOfFame::default(), Some(err)),
        };
        let (timed_hof, timed_hof_status) =
            match TimedHallOfFame::load_from_path(&variant.timed_hof_path()) {
                Ok(h) => (h, None),
                Err(err) => (TimedHallOfFame::default(), Some(err)),
            };

        let state = EngineState::new_start(variant);

        let (ironman, human_side, search_depth, rotation, show_legal_moves, show_eval, hof_tab, info) =
            match ironman_launch {
                Some(IronManLaunch::Depth(d)) => {
                    let d = d.clamp(MIN_IRONMAN_DEPTH, MAX_FINITE_DEPTH);
                    (
                        Some(IronManState {
                            kind: IronManKind::Depth {
                                start_depth: d,
                                min_depth: d,
                            },
                            recorded_this_game: false,
                        }),
                        Color::P2,
                        d,
                        2u8,
                        false,
                        false,
                        HofTab::Depth,
                        format!(
                            "IRONMAN {} (Depth {}). You play P2. Engine moves first...",
                            variant.display_name(),
                            d
                        ),
                    )
                }
                Some(IronManLaunch::Timed {
                    base_mins,
                    inc_secs,
                }) => (
                    Some(IronManState {
                        kind: IronManKind::Timed(TimedMatchClock::new(base_mins, inc_secs)),
                        recorded_this_game: false,
                    }),
                    Color::P2,
                    UNLIMITED_DEPTH_VAL,
                    2u8,
                    false,
                    false,
                    HofTab::Timed,
                    format!(
                        "IRONMAN TIMED {} ({}+{}). You play P2. Engine moves first...",
                        variant.display_name(),
                        base_mins,
                        inc_secs
                    ),
                ),
                None => (
                    None,
                    Color::P1,
                    8usize,
                    0u8,
                    true,
                    true,
                    HofTab::Depth,
                    format!("Ready ({}). Your move as P1.", variant.display_name()),
                ),
            };

        // Default GUI timed IronMan picker to 15+10 (base idx 8 = 15m, inc idx 5 = 10s)
        let default_base_idx = ALLOWED_TIMED_BASE_MINS
            .iter()
            .position(|&m| m == 15)
            .unwrap_or(0);
        let default_inc_idx = ALLOWED_TIMED_INC_SECS
            .iter()
            .position(|&s| s == 10)
            .unwrap_or(0);

        let mut app = Self {
            variant,
            origin: GameOrigin::standard(),
            state,
            move_log: Vec::new(),
            undo_stack: Vec::new(),
            redo_stack: Vec::new(),
            last_move: None,
            setup: None,
            ironman,
            hof,
            hof_status,
            timed_hof,
            timed_hof_status,
            hof_tab,
            show_hof_window: false,
            show_help_window: false,
            show_ironman_setup_confirm: false,
            show_enter_ironman_confirm: false,
            enter_ironman_is_timed: false,
            enter_ironman_depth_choice: MIN_IRONMAN_DEPTH,
            enter_ironman_base_idx: default_base_idx,
            enter_ironman_inc_idx: default_inc_idx,
            show_new_game_leave_ironman_confirm: false,
            show_gui_import_overwrite_confirm: false,
            import_dialog: None,
            pending_hof_record: None,
            hof_name_input: String::new(),
            pending_import_confirm: None,
            human_side,
            search_depth,
            time_limit_idx: UNLIMITED_TIME_IDX,
            piece_set: PieceSet::Letters,
            theme: ColorTheme::Night,
            rotation,
            show_legal_moves,
            show_thinking: false,
            show_eval,
            selected_sq: None,
            pending_search: None,
            search_generation: 0,
            last_engine_info: info,
            last_move_report: None,
            copied_until: None,
            show_quit_confirm: false,
            allow_close: false,
        };

        if app.is_ironman() {
            app.start_engine_search(&cc.egui_ctx);
        } else if let Some(req) = import_req {
            if let Some(summary) = inspect_autosave_summary(variant) {
                app.pending_import_confirm = Some((req, summary));
            } else {
                app.apply_import(req);
            }
        } else if app.try_autoload(&cc.egui_ctx) {
            app.apply_theme(&cc.egui_ctx);
        }

        app
    }

    fn is_ironman(&self) -> bool {
        self.ironman.is_some()
    }

    fn is_timed_ironman(&self) -> bool {
        matches!(
            self.ironman.as_ref().map(|im| &im.kind),
            Some(IronManKind::Timed(_))
        )
    }

    fn is_setup(&self) -> bool {
        self.setup.is_some()
    }

    fn eval_visible(&self) -> bool {
        !self.is_ironman() && self.show_eval
    }

    fn current_time_limit_ms(&self) -> Option<u64> {
        if self.is_ironman() {
            None
        } else {
            TIME_PRESETS_MS[self.time_limit_idx.min(UNLIMITED_TIME_IDX)]
        }
    }

    fn effective_game_result(&self) -> GameResult {
        if let Some(IronManState {
            kind: IronManKind::Timed(clk),
            ..
        }) = &self.ironman
        {
            if let Some(w) = clk.flagged_winner {
                return GameResult::Win(w);
            }
        }
        self.state.game_result()
    }

    fn any_modal_open(&self) -> bool {
        self.show_quit_confirm
            || self.show_ironman_setup_confirm
            || self.show_enter_ironman_confirm
            || self.show_new_game_leave_ironman_confirm
            || self.show_gui_import_overwrite_confirm
            || self.import_dialog.is_some()
            || self.show_hof_window
            || self.show_help_window
            || self.pending_hof_record.is_some()
            || self.pending_import_confirm.is_some()
    }

    fn update_window_title(&self, ctx: &egui::Context) {
        let title = match &self.ironman {
            Some(im) => match &im.kind {
                IronManKind::Depth { start_depth, .. } => format!(
                    "Dou Shou Qi ({}) — IRONMAN MODE (Depth {}+)",
                    self.variant.display_name(),
                    start_depth
                ),
                IronManKind::Timed(clk) => format!(
                    "Dou Shou Qi ({}) — IRONMAN TIMED ({}+{})",
                    self.variant.display_name(),
                    clk.base_mins,
                    clk.inc_secs
                ),
            },
            None => format!("Dou Shou Qi ({})", self.variant.display_name()),
        };
        ctx.send_viewport_cmd(egui::ViewportCommand::Title(title));
    }

    fn reload_hofs_for_variant(&mut self) {
        match HallOfFame::load_from_path(&self.variant.hof_path()) {
            Ok(h) => {
                self.hof = h;
                self.hof_status = None;
            }
            Err(e) => {
                self.hof = HallOfFame::default();
                self.hof_status = Some(e);
            }
        }
        match TimedHallOfFame::load_from_path(&self.variant.timed_hof_path()) {
            Ok(h) => {
                self.timed_hof = h;
                self.timed_hof_status = None;
            }
            Err(e) => {
                self.timed_hof = TimedHallOfFame::default();
                self.timed_hof_status = Some(e);
            }
        }
    }

    fn has_running_game(&self) -> bool {
        if self.effective_game_result() != GameResult::Ongoing {
            return false;
        }
        !self.move_log.is_empty() || self.origin.is_custom
    }

    fn switch_variant(&mut self, new_variant: GameVariant, ctx: &egui::Context) {
        if self.is_ironman() || self.is_setup() || self.variant == new_variant {
            return;
        }
        self.cancel_search();
        self.save_autosave();

        self.variant = new_variant;
        self.reload_hofs_for_variant();

        let prev_piece_set = self.piece_set;
        let prev_theme = self.theme;
        let prev_show_eval = self.show_eval;

        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(new_variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;
        self.human_side = Color::P1;
        self.rotation = 0;
        self.last_engine_info = format!(
            "Switched to {}. Your move as P1.",
            new_variant.display_name()
        );

        if self.try_autoload(ctx) {
            self.apply_theme(ctx);
        } else {
            self.piece_set = prev_piece_set;
            self.theme = prev_theme;
            self.show_eval = prev_show_eval;
        }
        self.update_window_title(ctx);
    }

    fn apply_import_with_variant(
        &mut self,
        target_variant: GameVariant,
        req: ImportRequest,
        ctx: &egui::Context,
    ) {
        self.cancel_search();
        if self.variant != target_variant {
            self.variant = target_variant;
            self.reload_hofs_for_variant();
        }
        self.apply_import(req);
        self.update_window_title(ctx);
    }

    fn enter_ironman_mode(&mut self, launch: IronManLaunch, ctx: &egui::Context) {
        self.cancel_search();
        self.save_autosave();

        self.setup = None;
        self.import_dialog = None;
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;

        self.human_side = Color::P2;
        self.rotation = 2;
        self.time_limit_idx = UNLIMITED_TIME_IDX;
        self.show_legal_moves = false;
        self.show_thinking = false;
        self.show_eval = false;

        match launch {
            IronManLaunch::Depth(d) => {
                let d = d.clamp(MIN_IRONMAN_DEPTH, MAX_FINITE_DEPTH);
                self.ironman = Some(IronManState {
                    kind: IronManKind::Depth {
                        start_depth: d,
                        min_depth: d,
                    },
                    recorded_this_game: false,
                });
                self.search_depth = d;
                self.hof_tab = HofTab::Depth;
                self.last_engine_info = format!(
                    "IRONMAN {} (Depth {}). You play P2. Engine moves first...",
                    self.variant.display_name(),
                    d
                );
            }
            IronManLaunch::Timed {
                base_mins,
                inc_secs,
            } => {
                self.ironman = Some(IronManState {
                    kind: IronManKind::Timed(TimedMatchClock::new(base_mins, inc_secs)),
                    recorded_this_game: false,
                });
                self.search_depth = UNLIMITED_DEPTH_VAL;
                self.hof_tab = HofTab::Timed;
                self.last_engine_info = format!(
                    "IRONMAN TIMED {} ({}+{}). You play P2. Engine moves first...",
                    self.variant.display_name(),
                    base_mins,
                    inc_secs
                );
            }
        }

        self.update_window_title(ctx);
        self.start_engine_search(ctx);
    }

    fn leave_ironman_to_new_normal_game(&mut self, ctx: &egui::Context) {
        self.cancel_search();
        self.ironman = None;
        self.pending_hof_record = None;
        self.setup = None;
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;
        self.human_side = Color::P1;
        self.rotation = 0;
        if self.search_depth >= UNLIMITED_DEPTH_VAL {
            self.search_depth = 8;
        }
        self.show_legal_moves = true;
        self.show_eval = true;
        self.last_engine_info = format!(
            "Exited IronMan Mode. New {} game started (You play P1).",
            self.variant.display_name()
        );
        self.update_window_title(ctx);
    }

    fn apply_import(&mut self, req: ImportRequest) {
        self.cancel_search();
        self.setup = None;
        let pieces = req.origin.to_pieces_vec();
        self.state = EngineState::from_custom(
            self.variant,
            &pieces,
            req.origin.side_to_move,
            req.origin.ep,
        );
        self.origin = req.origin;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;

        let mut timeline: Vec<Snapshot> = Vec::with_capacity(req.moves.len() + 1);
        timeline.push(self.current_snapshot());

        for &mv in &req.moves {
            let mover = self.state.side_to_move();
            let att_pid = self.state.board_piece(mv.from().idx()) as usize;
            let att_kind = PieceKind::from_idx(att_pid & 7);
            let cap_pid = self.state.board_piece(mv.to().idx());
            let captured = if cap_pid != EMPTY_SQ {
                Some(PieceKind::from_idx((cap_pid as usize) & 7))
            } else {
                None
            };
            let rep_marked = self.state.apply_move(mv);
            self.move_log.push(MoveRecord {
                side: mover,
                mv,
                piece: att_kind,
                captured,
                rep_marked,
            });
            self.last_move = Some(mv);
            timeline.push(self.current_snapshot());
        }

        match req.open_at {
            ImportPosition::End => {
                let end_snap = timeline.pop().unwrap();
                self.undo_stack = timeline;
                self.redo_stack.clear();
                self.restore_snapshot(end_snap);
            }
            ImportPosition::Start => {
                let start_snap = timeline.remove(0);
                timeline.reverse();
                self.undo_stack.clear();
                self.redo_stack = timeline;
                self.restore_snapshot(start_snap);
            }
        }

        self.human_side = self.state.side_to_move();
        self.rotation = if self.human_side == Color::P1 { 0 } else { 2 };

        let pos_label = match req.open_at {
            ImportPosition::Start => "start",
            ImportPosition::End => "end",
        };
        let setup_tag = if self.origin.is_custom {
            ", custom setup"
        } else {
            ""
        };
        self.last_engine_info = format!(
            "Imported '{}' as {} ({} plies{}, opened at {}). You play {}.",
            req.filename,
            self.variant.display_name(),
            req.moves.len(),
            setup_tag,
            pos_label,
            self.human_side
        );
    }

    fn save_autosave(&self) {
        if self.is_ironman() || self.pending_import_confirm.is_some() {
            return;
        }
        let path = self.variant.autosave_path();
        if !self.has_running_game() {
            let _ = std::fs::remove_file(&path);
            return;
        }

        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }

        let pieces_str: String = self
            .origin
            .piece_sq
            .iter()
            .map(|v| v.to_string())
            .collect::<Vec<_>>()
            .join(",");

        let moves_str: String = self
            .move_log
            .iter()
            .map(|r| r.mv.to_string())
            .collect::<Vec<_>>()
            .join(" ");

        let depth_str = if self.search_depth >= UNLIMITED_DEPTH_VAL {
            "unlimited".to_owned()
        } else {
            self.search_depth.to_string()
        };

        let time_ms_str = match self.current_time_limit_ms() {
            Some(ms) => ms.to_string(),
            None => "unlimited".to_owned(),
        };

        let content = format!(
            "{}\n\
             origin_custom={}\n\
             origin_pieces={}\n\
             origin_stm={}\n\
             origin_ep={},{}\n\
             human_side={}\n\
             depth={}\n\
             time_limit_ms={}\n\
             piece_set={}\n\
             theme={}\n\
             rotation={}\n\
             show_legal={}\n\
             show_thinking={}\n\
             show_eval={}\n\
             moves={}\n",
            AUTOSAVE_VERSION,
            if self.origin.is_custom { 1 } else { 0 },
            pieces_str,
            self.origin.side_to_move.idx(),
            self.origin.ep[0],
            self.origin.ep[1],
            self.human_side.idx(),
            depth_str,
            time_ms_str,
            self.piece_set.as_str(),
            self.theme.as_str(),
            self.rotation % 4,
            if self.show_legal_moves { 1 } else { 0 },
            if self.show_thinking { 1 } else { 0 },
            if self.show_eval { 1 } else { 0 },
            moves_str
        );

        let _ = std::fs::write(&path, content);
    }

    fn try_autoload(&mut self, ctx: &egui::Context) -> bool {
        let path = self.variant.autosave_path();
        let Ok(text) = std::fs::read_to_string(&path) else {
            return false;
        };

        let mut lines = text.lines();
        if lines.next().map(|l| l.trim()) != Some(AUTOSAVE_VERSION) {
            return false;
        }

        let mut origin_custom = false;
        let mut origin_pieces: Option<[u8; 16]> = None;
        let mut origin_stm = Color::P1;
        let mut origin_ep = START_EP;
        let mut human_side = Color::P1;
        let mut depth = self.search_depth;
        let mut time_limit_idx = UNLIMITED_TIME_IDX;
        let mut piece_set = self.piece_set;
        let mut theme = self.theme;
        let mut rotation = 0u8;
        let mut show_legal = true;
        let mut show_thinking = false;
        let mut show_eval = true;
        let mut moves_line = String::new();

        for line in lines {
            let Some((k, v)) = line.split_once('=') else {
                continue;
            };
            let v = v.trim();
            match k.trim() {
                "origin_custom" => origin_custom = v == "1",
                "origin_pieces" => {
                    let nums: Vec<u8> = v.split(',').filter_map(|s| s.parse().ok()).collect();
                    if nums.len() == 16 {
                        let mut arr = [CAPTURED; 16];
                        arr.copy_from_slice(&nums);
                        origin_pieces = Some(arr);
                    }
                }
                "origin_stm" => {
                    origin_stm = if v == "1" { Color::P2 } else { Color::P1 };
                }
                "origin_ep" => {
                    if let Some((a, b)) = v.split_once(',') {
                        if let (Ok(e0), Ok(e1)) = (a.parse::<u8>(), b.parse::<u8>()) {
                            if e0 <= MAX_EP && e1 <= MAX_EP {
                                origin_ep = [e0, e1];
                            }
                        }
                    }
                }
                "human_side" => {
                    human_side = if v == "1" { Color::P2 } else { Color::P1 };
                }
                "depth" => {
                    if v.eq_ignore_ascii_case("unlimited") {
                        depth = UNLIMITED_DEPTH_VAL;
                    } else if let Ok(d) = v.parse::<usize>() {
                        depth = d.clamp(1, MAX_FINITE_DEPTH);
                    }
                }
                "time_limit_ms" => {
                    if v.eq_ignore_ascii_case("unlimited") {
                        time_limit_idx = UNLIMITED_TIME_IDX;
                    } else if let Ok(ms) = v.parse::<u64>() {
                        time_limit_idx = time_idx_from_ms(Some(ms));
                    }
                }
                "time_limit" => {
                    if v.eq_ignore_ascii_case("unlimited") {
                        time_limit_idx = UNLIMITED_TIME_IDX;
                    } else if let Ok(s) = v.parse::<u64>() {
                        time_limit_idx = time_idx_from_ms(Some(s.saturating_mul(1000)));
                    }
                }
                "piece_set" => {
                    if let Some(ps) = PieceSet::from_str(v) {
                        piece_set = ps;
                    }
                }
                "theme" => {
                    if let Some(th) = ColorTheme::from_str(v) {
                        theme = th;
                    }
                }
                "rotation" => {
                    if let Ok(r) = v.parse::<u8>() {
                        rotation = r % 4;
                    }
                }
                "show_legal" => show_legal = v != "0",
                "show_thinking" => show_thinking = v == "1",
                "show_eval" => show_eval = v != "0",
                "moves" => moves_line = v.to_owned(),
                _ => {}
            }
        }

        let Some(piece_sq) = origin_pieces else {
            return false;
        };
        if validate_piece_array(&piece_sq).is_err() {
            return false;
        }

        let origin = GameOrigin {
            piece_sq,
            side_to_move: origin_stm,
            ep: origin_ep,
            is_custom: origin_custom,
        };
        let pieces_vec = origin.to_pieces_vec();
        let start_state = EngineState::from_custom(self.variant, &pieces_vec, origin_stm, origin_ep);

        let mut parsed_moves = Vec::new();
        for tok in moves_line.split_whitespace() {
            let Some(mv) = parse_alg_move(tok) else {
                return false;
            };
            parsed_moves.push(mv);
        }

        self.origin = origin;
        self.state = start_state;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;
        self.human_side = human_side;
        self.search_depth = depth;
        self.time_limit_idx = time_limit_idx;
        self.piece_set = piece_set;
        self.theme = theme;
        self.rotation = rotation;
        self.show_legal_moves = show_legal;
        self.show_thinking = show_thinking;
        self.show_eval = show_eval;

        for mv in parsed_moves {
            let legal = self.state.gen_legal_moves();
            if !legal.contains(&mv) {
                self.origin = GameOrigin::standard();
                self.state = EngineState::new_start(self.variant);
                self.move_log.clear();
                self.undo_stack.clear();
                self.redo_stack.clear();
                self.last_move = None;
                return false;
            }
            self.play_move(mv, None);
        }

        if self.state.game_result() != GameResult::Ongoing {
            let _ = std::fs::remove_file(&path);
            self.origin = GameOrigin::standard();
            self.state = EngineState::new_start(self.variant);
            self.move_log.clear();
            self.undo_stack.clear();
            self.redo_stack.clear();
            self.last_move = None;
            return false;
        }

        self.last_engine_info = format!(
            "Auto-loaded saved {} game ({} plies). You play {}.",
            self.variant.display_name(),
            self.move_log.len(),
            self.human_side
        );

        if self.state.side_to_move() != self.human_side {
            self.start_engine_search(ctx);
        }

        true
    }

    fn current_snapshot(&self) -> Snapshot {
        Snapshot {
            state: self.state.clone(),
            move_log: self.move_log.clone(),
            last_move: self.last_move,
        }
    }

    fn restore_snapshot(&mut self, snap: Snapshot) {
        self.state = snap.state;
        self.move_log = snap.move_log;
        self.last_move = snap.last_move;
        self.selected_sq = None;
    }

    fn apply_theme(&self, ctx: &egui::Context) {
        match self.theme {
            ColorTheme::Night => ctx.set_visuals(egui::Visuals::dark()),
            ColorTheme::Day => ctx.set_visuals(egui::Visuals::light()),
        }
    }

    fn enter_setup(&mut self) {
        self.cancel_search();
        self.selected_sq = None;
        self.last_move_report = None;
        self.setup = Some(SetupState::from_state(&self.state));
    }

    fn cancel_setup(&mut self) {
        self.setup = None;
        self.last_engine_info = "Cancelled setup mode.".to_owned();
    }

    fn finish_setup(&mut self, ctx: &egui::Context) {
        let Some(setup) = self.setup.clone() else {
            return;
        };
        if setup.validate().is_err() {
            return;
        }
        let pieces = setup.to_pieces_vec();
        let new_state =
            EngineState::from_custom(self.variant, &pieces, setup.side_to_move, setup.ep);

        self.setup = None;
        self.origin = GameOrigin::from_custom(setup.piece_sq, setup.side_to_move, setup.ep);
        self.state = new_state;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;

        self.last_engine_info = format!(
            "Custom position ready! Turn: {} | You play {}.",
            self.state.side_to_move(),
            self.human_side
        );

        if self.state.game_result() == GameResult::Ongoing
            && self.state.side_to_move() != self.human_side
        {
            self.start_engine_search(ctx);
        }
    }

    fn new_game(&mut self, ctx: &egui::Context) {
        self.setup = None;
        self.cancel_search();
        self.origin = GameOrigin::standard();
        self.state = EngineState::new_start(self.variant);
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.last_move_report = None;
        self.selected_sq = None;

        self.last_engine_info = format!(
            "New {} game started. You play {}.",
            self.variant.display_name(),
            self.human_side
        );

        if self.state.side_to_move() != self.human_side {
            self.start_engine_search(ctx);
        }
    }

    fn cancel_search(&mut self) {
        if let Some(p) = &self.pending_search {
            p.stop_flag.store(true, Ordering::Relaxed);
        }
        self.search_generation = self.search_generation.wrapping_add(1);
        self.pending_search = None;
    }

    fn request_stop_and_play(&mut self) {
        if self.is_ironman() {
            return;
        }
        if let Some(p) = &mut self.pending_search {
            if !p.stop_requested {
                p.stop_flag.store(true, Ordering::Relaxed);
                p.stop_requested = true;
                self.last_move_report = None;
                self.last_engine_info = "Stopping search — playing best completed move...".to_owned();
            }
        }
    }

    fn undo_move(&mut self) {
        if self.is_ironman() {
            return;
        }
        self.cancel_search();
        self.selected_sq = None;
        self.last_move_report = None;

        while let Some(snap) = self.undo_stack.pop() {
            let cur = self.current_snapshot();
            self.redo_stack.push(cur);
            self.restore_snapshot(snap);
            if self.state.side_to_move() == self.human_side {
                break;
            }
        }
        self.last_engine_info = "Undid move.".to_owned();
    }

    fn redo_move(&mut self) {
        if self.is_ironman() {
            return;
        }
        self.cancel_search();
        self.selected_sq = None;
        self.last_move_report = None;

        while let Some(snap) = self.redo_stack.pop() {
            let cur = self.current_snapshot();
            self.undo_stack.push(cur);
            self.restore_snapshot(snap);
            if self.state.side_to_move() == self.human_side {
                break;
            }
        }
        self.last_engine_info = "Redid move.".to_owned();
    }

    fn switch_sides(&mut self, ctx: &egui::Context) {
        if self.is_ironman() {
            return;
        }
        self.cancel_search();
        self.selected_sq = None;
        self.last_move_report = None;
        self.human_side = self.human_side.opp();
        self.rotation = (self.rotation + 2) % 4;

        if !self.is_setup()
            && self.state.game_result() == GameResult::Ongoing
            && self.state.side_to_move() != self.human_side
        {
            self.start_engine_search(ctx);
        } else {
            self.last_engine_info = format!("Switched sides. You now play {}.", self.human_side);
        }
    }

    /// Executes `mv` and updates the Fischer clock if in a Timed IronMan match.
    fn play_move(&mut self, mv: Move, explicit_elapsed_ms: Option<u64>) {
        if !self.is_ironman() {
            let snap = self.current_snapshot();
            self.undo_stack.push(snap);
            self.redo_stack.clear();
        }

        let mover = self.state.side_to_move();

        // Update Fischer clock before switching turns (if Timed IronMan)
        if let Some(IronManState {
            kind: IronManKind::Timed(clk),
            ..
        }) = &mut self.ironman
        {
            if clk.flagged_winner.is_none() {
                let elapsed = explicit_elapsed_ms
                    .unwrap_or_else(|| clk.turn_started_at.elapsed().as_millis() as u64);
                clk.commit_move(mover, elapsed);
            }
        }

        let opp_idx = mover.opp().idx();
        let att_pid = self.state.board_piece(mv.from().idx()) as usize;
        let att_kind = PieceKind::from_idx(att_pid & 7);
        let cap_pid = self.state.board_piece(mv.to().idx());
        let captured = if cap_pid != EMPTY_SQ {
            Some(PieceKind::from_idx((cap_pid as usize) & 7))
        } else {
            None
        };

        let rep_marked = self.state.apply_move(mv);

        self.move_log.push(MoveRecord {
            side: mover,
            mv,
            piece: att_kind,
            captured,
            rep_marked,
        });
        self.last_move = Some(mv);
        self.selected_sq = None;

        if let GameResult::Win(winner) = self.state.game_result() {
            let end_code = if self.state.winner().is_some() {
                if mv.to() == DEN_SQ[opp_idx] {
                    EndCode::Goal
                } else {
                    EndCode::Elimination
                }
            } else {
                EndCode::Immobilization
            };
            self.record_ironman_finish(winner, end_code);
        }
    }

    fn tick_timed_ironman_clock(&mut self) {
        if self.effective_game_result() != GameResult::Ongoing {
            return;
        }
        let active_side = self.state.side_to_move();

        // Extra watchdog: if engine is thinking and clock approaches 200ms, force immediate stop!
        if active_side != self.human_side {
            if let Some(IronManState {
                kind: IronManKind::Timed(clk),
                ..
            }) = &self.ironman
            {
                let live_rem = clk.live_remaining_ms(active_side, active_side, true);
                if live_rem <= 200 {
                    if let Some(p) = &self.pending_search {
                        p.stop_flag.store(true, Ordering::Relaxed);
                    }
                }
            }
            return;
        }

        // Check human clock expiration
        let mut human_flagged = false;
        if let Some(IronManState {
            kind: IronManKind::Timed(clk),
            ..
        }) = &mut self.ironman
        {
            if clk.live_remaining_ms(self.human_side, active_side, true) == 0 {
                clk.rem_ms[self.human_side.idx()] = 0;
                clk.flagged_winner = Some(self.human_side.opp());
                human_flagged = true;
            }
        }

        if human_flagged {
            self.cancel_search();
            self.selected_sq = None;
            let winner = self.human_side.opp();
            self.record_ironman_finish(winner, EndCode::Timeout);
        }
    }

    fn record_ironman_finish(&mut self, winner: Color, end_code: EndCode) {
        let Some(im) = &mut self.ironman else {
            return;
        };
        if im.recorded_this_game {
            return;
        }
        im.recorded_this_game = true;
        self.last_move_report = None;

        let plies = self.move_log.len();
        let moves = plies.div_ceil(2);
        let human_won = winner == self.human_side;
        let army_strength = self.state.side_army_strength(self.human_side);
        let outcome_str = if human_won { "VICTORY" } else { "DEFEAT" };

        match &im.kind {
            IronManKind::Depth { start_depth, .. } => {
                let start_depth = *start_depth;
                let candidate = HallOfFameEntry {
                    timestamp_secs: now_unix_secs(),
                    player_name: String::new(),
                    human_won,
                    start_depth,
                    end_depth: self.search_depth.min(MAX_FINITE_DEPTH),
                    moves,
                    plies,
                    end_code,
                    army_strength,
                };
                if let Some(rank) = self.hof.would_qualify(&candidate) {
                    self.pending_hof_record = Some(PendingHofRecord::Depth(candidate, rank));
                    self.last_engine_info = format!(
                        "NEW HALL OF FAME RECORD (#{}): {} (d{}, {} moves, Army {}, {})! Enter your name.",
                        rank,
                        outcome_str,
                        start_depth,
                        moves,
                        army_strength,
                        end_code.code_char()
                    );
                } else {
                    self.last_engine_info = format!(
                        "IronMan {}: d{}, {} moves, Army {} ({}) — did not qualify for Top {}/depth or Top {}.",
                        outcome_str,
                        start_depth,
                        moves,
                        army_strength,
                        end_code.code_char(),
                        MAX_ENTRIES_PER_DEPTH,
                        MAX_TOTAL_ENTRIES
                    );
                }
            }
            IronManKind::Timed(clk) => {
                let base_mins = clk.base_mins;
                let inc_secs = clk.inc_secs;
                let candidate = TimedHofEntry {
                    timestamp_secs: now_unix_secs(),
                    player_name: String::new(),
                    base_mins,
                    inc_secs,
                    human_won,
                    moves,
                    plies,
                    end_code,
                    army_strength,
                };
                if let Some(rank) = self.timed_hof.would_qualify(&candidate) {
                    self.pending_hof_record = Some(PendingHofRecord::Timed(candidate, rank));
                    self.last_engine_info = format!(
                        "NEW TIMED HALL OF FAME RECORD (#{} in {}+{}): {} ({} moves, Army {}, {})! Enter your name.",
                        rank,
                        base_mins,
                        inc_secs,
                        outcome_str,
                        moves,
                        army_strength,
                        end_code.code_char()
                    );
                } else {
                    self.last_engine_info = format!(
                        "Timed IronMan {} ({}+{}): {} moves, Army {} ({}) — did not qualify for Top {}.",
                        outcome_str,
                        base_mins,
                        inc_secs,
                        moves,
                        army_strength,
                        end_code.code_char(),
                        MAX_TIMED_ENTRIES_PER_TC
                    );
                }
            }
        }
    }

    fn commit_pending_hof_record(&mut self) {
        let Some(pending) = self.pending_hof_record.take() else {
            return;
        };
        let clean_name = sanitize_player_name(&self.hof_name_input);
        self.hof_name_input = clean_name.clone();

        match pending {
            PendingHofRecord::Depth(mut entry, _) => {
                entry.player_name = clean_name.clone();
                let outcome_str = if entry.human_won { "VICTORY" } else { "DEFEAT" };
                let sd = entry.start_depth;
                let moves = entry.moves;
                let army = entry.army_strength;
                let code = entry.end_code.code_char();

                if let Some(rank) = self.hof.add_entry(entry) {
                    match self.hof.save_to_path(&self.variant.hof_path()) {
                        Ok(()) => {
                            self.hof_status = None;
                            self.last_move_report = None;
                            self.last_engine_info = format!(
                                "HALL OF FAME #{}: {} — {} (d{}, {} moves, Army {}, {}) saved!",
                                rank, clean_name, outcome_str, sd, moves, army, code
                            );
                        }
                        Err(e) => self.hof_status = Some(e),
                    }
                }
            }
            PendingHofRecord::Timed(mut entry, _) => {
                entry.player_name = clean_name.clone();
                let outcome_str = if entry.human_won { "VICTORY" } else { "DEFEAT" };
                let tc = entry.tc_label();
                let moves = entry.moves;
                let army = entry.army_strength;
                let code = entry.end_code.code_char();

                if let Some(rank) = self.timed_hof.add_entry(entry) {
                    match self.timed_hof.save_to_path(&self.variant.timed_hof_path()) {
                        Ok(()) => {
                            self.timed_hof_status = None;
                            self.last_move_report = None;
                            self.last_engine_info = format!(
                                "TIMED HOF #{} ({}): {} — {} ({} moves, Army {}, {}) saved!",
                                rank, tc, clean_name, outcome_str, moves, army, code
                            );
                        }
                        Err(e) => self.timed_hof_status = Some(e),
                    }
                }
            }
        }
    }

    fn start_engine_search(&mut self, ctx: &egui::Context) {
        if self.effective_game_result() != GameResult::Ongoing {
            return;
        }
        self.cancel_search();
        self.last_move_report = None;
        let generation = self.search_generation;

        // Compute search limits according to mode (Normal, Depth IronMan, or Timed IronMan)
        let (limits, limit_desc) = if let Some(IronManState {
            kind: IronManKind::Timed(clk),
            ..
        }) = &self.ironman
        {
            let engine_side = self.state.side_to_move();
            let budget_ms = clk.allocate_engine_budget_ms(
                engine_side,
                self.move_log.len(),
                self.state.total_pieces(),
            );
            (
                SearchLimits {
                    max_depth: MAX_PLY - 1,
                    max_time: Some(Duration::from_millis(budget_ms)),
                    max_nodes: None,
                },
                format!("timed match {}+{}", clk.base_mins, clk.inc_secs),
            )
        } else {
            let max_depth = if self.search_depth >= UNLIMITED_DEPTH_VAL {
                MAX_PLY - 1
            } else {
                self.search_depth.clamp(1, MAX_FINITE_DEPTH)
            };
            let max_time_ms = self.current_time_limit_ms();
            let desc = match (self.search_depth >= UNLIMITED_DEPTH_VAL, max_time_ms) {
                (true, None) => "Unlimited (press Space or Stop)".to_owned(),
                (true, Some(ms)) => format!("Unlimited depth, max {}", format_time_limit_ms(Some(ms))),
                (false, None) => format!("depth {}", max_depth),
                (false, Some(ms)) => {
                    format!("depth {}, max {}", max_depth, format_time_limit_ms(Some(ms)))
                }
            };
            (
                SearchLimits {
                    max_depth,
                    max_time: max_time_ms.map(Duration::from_millis),
                    max_nodes: None,
                },
                desc,
            )
        };

        let ctx_clone = ctx.clone();
        let state_clone = self.state.clone();
        let stop_flag = Arc::new(AtomicBool::new(false));
        let stop_clone = Arc::clone(&stop_flag);

        let (prog_tx, prog_rx) = if self.is_ironman() {
            (None, None)
        } else {
            let (tx, rx) = mpsc::channel();
            (Some(tx), Some(rx))
        };

        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            let res = match state_clone {
                EngineState::Ep(pos, mut hist) => {
                    let mut searcher = Searcher::with_tt_mb(32);
                    searcher.search_with_hooks(
                        &pos,
                        &mut hist,
                        limits,
                        Some(stop_clone),
                        prog_tx,
                    )
                }
                EngineState::Classic(pos, mut hist) => {
                    let mut searcher = ClassicSearcher::with_tt_mb(32);
                    searcher.search_with_hooks(
                        &pos,
                        &mut hist,
                        limits,
                        Some(stop_clone),
                        prog_tx,
                    )
                }
                EngineState::Rats(pos, mut hist) => {
                    let mut searcher = RatsSearcher::with_tt_mb(32);
                    searcher.search_with_hooks(
                        &pos,
                        &mut hist,
                        limits,
                        Some(stop_clone),
                        prog_tx,
                    )
                }
            };
            let _ = tx.send(res);
            ctx_clone.request_repaint();
        });

        self.pending_search = Some(PendingSearch {
            generation,
            rx,
            progress_rx: prog_rx,
            latest_progress: None,
            stop_flag,
            stop_requested: false,
            started_at: Instant::now(),
        });
        self.last_engine_info = format!("Engine thinking ({})...", limit_desc);
    }

    fn poll_engine(&mut self) {
        if let Some(pending) = &mut self.pending_search {
            if let Some(prx) = &pending.progress_rx {
                while let Ok(p) = prx.try_recv() {
                    pending.latest_progress = Some(p);
                }
            }
        }

        let Some(pending) = &self.pending_search else {
            return;
        };
        if let Ok(res) = pending.rx.try_recv() {
            let gen = pending.generation;
            let was_stopped = pending.stop_requested;
            let wall_ms = pending.started_at.elapsed().as_millis() as u64;
            self.pending_search = None;
            if gen != self.search_generation || self.is_setup() {
                return;
            }
            if res.best_move != Move::NULL {
                let legal = self.state.gen_legal_moves();
                if legal.contains(&res.best_move) {
                    self.last_move_report = Some(EngineMoveReport {
                        mv: res.best_move,
                        depth: res.depth,
                        score: res.score,
                        nodes: res.nodes,
                        elapsed_secs: res.elapsed.as_secs_f64(),
                        stopped: was_stopped,
                    });
                    self.play_move(res.best_move, Some(wall_ms));
                }
            }
        }
    }

    fn current_engine_info_line(&self) -> String {
        if let Some(rep) = self.last_move_report {
            if self.is_ironman() {
                format!(
                    "Engine played {} (d{}, {:.2}s)",
                    rep.mv, rep.depth, rep.elapsed_secs
                )
            } else {
                let stop_tag = if rep.stopped { " [stopped]" } else { "" };
                if self.eval_visible() {
                    format!(
                        "Engine played {} | d{} | {} | {} nodes ({:.2}s){}",
                        rep.mv,
                        rep.depth,
                        format_score(rep.score),
                        rep.nodes,
                        rep.elapsed_secs,
                        stop_tag
                    )
                } else {
                    format!(
                        "Engine played {} | d{} | {} nodes ({:.2}s){}",
                        rep.mv, rep.depth, rep.nodes, rep.elapsed_secs, stop_tag
                    )
                }
            }
        } else {
            self.last_engine_info.clone()
        }
    }

    fn visible_thinking(&self) -> Option<SearchProgress> {
        if self.is_ironman() || self.is_setup() || !self.show_thinking {
            return None;
        }
        self.pending_search
            .as_ref()
            .and_then(|p| p.latest_progress)
    }

    fn board_to_visual(&self, r: usize, c: usize) -> (usize, usize) {
        board_to_visual_rot(self.rotation, r, c)
    }

    fn visual_to_board(&self, vx: usize, vy: usize) -> (usize, usize) {
        visual_to_board_rot(self.rotation, vx, vy)
    }

    fn visual_dims(&self) -> (usize, usize) {
        if self.rotation % 2 == 0 {
            (COLS, ROWS)
        } else {
            (ROWS, COLS)
        }
    }

    fn format_movelist(&self) -> String {
        let mut out = String::new();
        for (i, rec) in self.move_log.iter().enumerate() {
            if i % 2 == 0 {
                if i > 0 {
                    out.push('\n');
                }
                out.push_str(&format!("{:>3}. ", i / 2 + 1));
            } else {
                out.push_str("   ");
            }
            let cap_sym = if rec.captured.is_some() { "x" } else { "-" };
            let rep_sym = if rec.rep_marked { "*" } else { "" };
            let p_ch = piece_letter(rec.piece);
            out.push_str(&format!(
                "{}:{}{}{}{}",
                p_ch,
                rec.mv.from(),
                cap_sym,
                rec.mv.to(),
                rep_sym
            ));
        }
        out
    }

    /// Exports movelist with `# Mode:` header AND custom `# Setup:` / `# Turn:` / `# EP:`
    /// headers whenever the game started from a custom board setup.
    fn format_movelist_for_export(&self) -> String {
        let mut out = format!("{}\n", self.variant.export_header());
        if self.origin.is_custom {
            out.push_str(&self.origin.format_setup_headers(self.variant.uses_ep()));
        }
        let body = self.format_movelist();
        if !body.is_empty() {
            out.push_str(&body);
            out.push('\n');
        }
        out
    }

    fn draw_piece_disc(
        &self,
        painter: &egui::Painter,
        center: egui::Pos2,
        radius: f32,
        color: Color,
        kind: PieceKind,
        pal: &Palette,
    ) {
        let (fill, border, text_col) = match color {
            Color::P1 => (pal.p1_fill, pal.p1_border, pal.p1_text),
            Color::P2 => (pal.p2_fill, pal.p2_border, pal.p2_text),
        };

        painter.circle_filled(center, radius, fill);
        painter.circle_stroke(
            center,
            radius,
            egui::Stroke::new((radius * 0.11).max(1.5), border),
        );

        let rank_str = kind.rank().to_string();
        match self.piece_set {
            PieceSet::Numbers => {
                painter.text(
                    center,
                    egui::Align2::CENTER_CENTER,
                    rank_str,
                    egui::FontId::proportional(radius * 1.18),
                    text_col,
                );
            }
            PieceSet::Letters => {
                let main_pos = egui::pos2(center.x - radius * 0.10, center.y - radius * 0.02);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_letter(kind),
                    egui::FontId::proportional(radius * 1.08),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.56, center.y + radius * 0.52);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.48).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Unicode => {
                let main_pos = egui::pos2(center.x - radius * 0.08, center.y - radius * 0.03);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_unicode_symbol(kind),
                    egui::FontId::proportional(radius * 1.12),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.58, center.y + radius * 0.54);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.44).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Animals => {
                let art_center = egui::pos2(center.x - radius * 0.08, center.y - radius * 0.05);
                draw_animal_icon(painter, art_center, radius * 0.58, kind, text_col, fill);
                let num_pos = egui::pos2(center.x + radius * 0.62, center.y + radius * 0.58);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.45).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Chinese => {
                let art_center = egui::pos2(center.x - radius * 0.10, center.y - radius * 0.04);
                draw_chinese_char(painter, art_center, radius * 0.54, kind, text_col);
                let num_pos = egui::pos2(center.x + radius * 0.62, center.y + radius * 0.58);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.45).max(8.0)),
                    text_col,
                );
            }
        }
    }

    fn handle_global_shortcuts(&mut self, ctx: &egui::Context) {
        let wants_kb = ctx.wants_keyboard_input();
        let (f1_pressed, esc_pressed, space_pressed) = ctx.input(|i| {
            (
                i.key_pressed(egui::Key::F1),
                i.key_pressed(egui::Key::Escape),
                i.key_pressed(egui::Key::Space),
            )
        });

        if f1_pressed {
            self.show_help_window = !self.show_help_window;
            return;
        }

        if space_pressed && !wants_kb && !self.is_ironman() && !self.is_setup() && !self.any_modal_open() {
            if self
                .pending_search
                .as_ref()
                .map(|p| !p.stop_requested)
                .unwrap_or(false)
            {
                self.request_stop_and_play();
                return;
            }
        }

        if esc_pressed {
            if self.show_help_window {
                self.show_help_window = false;
            } else if self.show_hof_window {
                self.show_hof_window = false;
            } else if self.import_dialog.is_some() {
                self.import_dialog = None;
            } else if self.show_gui_import_overwrite_confirm {
                self.show_gui_import_overwrite_confirm = false;
            } else if self.show_quit_confirm {
                self.show_quit_confirm = false;
            } else if self.show_enter_ironman_confirm {
                self.show_enter_ironman_confirm = false;
            } else if self.show_ironman_setup_confirm {
                self.show_ironman_setup_confirm = false;
            } else if self.show_new_game_leave_ironman_confirm {
                self.show_new_game_leave_ironman_confirm = false;
            } else if self.pending_hof_record.is_none() && self.pending_import_confirm.is_none() {
                self.show_quit_confirm = true;
            }
        }
    }

    fn ui_gui_import_overwrite_confirm(&mut self, ctx: &egui::Context) {
        if !self.show_gui_import_overwrite_confirm {
            return;
        }

        let plies = self.move_log.len();
        let moves = plies.div_ceil(2);
        let mut proceed = false;
        let mut cancel = false;

        egui::Window::new("Overwrite Current Game?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.strong("A game is currently in progress!");
                ui.label(format!(
                    "Current game ({}): {} moves ({} plies){}",
                    self.variant.display_name(),
                    moves,
                    plies,
                    if self.origin.is_custom {
                        " [custom setup]"
                    } else {
                        ""
                    }
                ));
                ui.small("Importing a game log will overwrite the current game in the GUI.");
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Continue to Import").clicked() {
                        proceed = true;
                    }
                    if ui.button("Cancel").clicked() {
                        cancel = true;
                    }
                });
                ui.add_space(4.0);
            });

        if proceed {
            self.show_gui_import_overwrite_confirm = false;
            self.import_dialog = Some(ImportDialogState::new());
        } else if cancel {
            self.show_gui_import_overwrite_confirm = false;
        }
    }

    fn ui_import_dialog(&mut self, ctx: &egui::Context, pal: &Palette) {
        if self.import_dialog.is_none() {
            return;
        }

        let mut open = true;
        let mut cancel_clicked = false;
        let mut loaded_result: Option<(GameVariant, ImportRequest)> = None;

        if let Some(dlg) = &mut self.import_dialog {
            if let Some(rx) = &dlg.browse_rx {
                if let Ok(maybe_path) = rx.try_recv() {
                    dlg.browse_rx = None;
                    if let Some(p) = maybe_path {
                        dlg.path_input = p.to_string_lossy().into_owned();
                        dlg.use_paste = false;
                        dlg.error_msg = None;
                    }
                }
            }
        }

        egui::Window::new("Import Game Log")
            .open(&mut open)
            .resizable(true)
            .default_size([520.0, 400.0])
            .min_size([420.0, 290.0])
            .show(ctx, |ui| {
                let dlg = self.import_dialog.as_mut().unwrap();

                ui.horizontal(|ui| {
                    ui.label("Source:");
                    ui.selectable_value(&mut dlg.use_paste, false, "From File");
                    ui.selectable_value(&mut dlg.use_paste, true, "Paste Text");
                });
                ui.separator();

                if !dlg.use_paste {
                    ui.horizontal(|ui| {
                        ui.label("File:");
                        ui.add(
                            egui::TextEdit::singleline(&mut dlg.path_input)
                                .desired_width(280.0)
                                .hint_text("e.g. game.txt or /path/to/log.txt"),
                        );
                        let browsing = dlg.browse_rx.is_some();
                        if ui
                            .add_enabled(!browsing, egui::Button::new("Browse..."))
                            .on_hover_text("Open system file picker (zenity)")
                            .clicked()
                        {
                            let (tx, rx) = mpsc::channel();
                            let ctx_c = ctx.clone();
                            thread::spawn(move || {
                                let chosen = Command::new("zenity")
                                    .args([
                                        "--file-selection",
                                        "--title=Select Dou Shou Qi Move List",
                                    ])
                                    .output()
                                    .ok()
                                    .filter(|o| o.status.success())
                                    .map(|o| {
                                        String::from_utf8_lossy(&o.stdout).trim().to_owned()
                                    })
                                    .filter(|s| !s.is_empty())
                                    .map(PathBuf::from);
                                let _ = tx.send(chosen);
                                ctx_c.request_repaint();
                            });
                            dlg.browse_rx = Some(rx);
                        }
                    });

                    ui.add_space(6.0);
                    ui.horizontal(|ui| {
                        ui.small("Files in current directory (.txt / .dsq / .log):");
                        if ui.small_button("Refresh").clicked() {
                            dlg.refresh_dir_files();
                        }
                    });

                    egui::Frame::none()
                        .fill(pal.panel_card_bg)
                        .rounding(egui::Rounding::same(5.0))
                        .inner_margin(egui::Margin::same(6.0))
                        .show(ui, |ui| {
                            egui::ScrollArea::vertical()
                                .max_height(130.0)
                                .auto_shrink([false, false])
                                .show(ui, |ui| {
                                    if dlg.dir_files.is_empty() {
                                        ui.colored_label(
                                            pal.coord_text,
                                            "(No .txt / .dsq / .log files found in current directory)",
                                        );
                                    } else {
                                        for fname in &dlg.dir_files {
                                            let selected = dlg.path_input == *fname;
                                            if ui.selectable_label(selected, fname).clicked() {
                                                dlg.path_input = fname.clone();
                                                dlg.error_msg = None;
                                            }
                                        }
                                    }
                                });
                        });
                } else {
                    ui.small(
                        "Paste exported movelist text below (supports '# Mode:' and custom '# Setup:' headers):",
                    );
                    egui::ScrollArea::vertical()
                        .max_height(175.0)
                        .auto_shrink([false, false])
                        .show(ui, |ui| {
                            ui.add_sized(
                                [ui.available_width(), 165.0],
                                egui::TextEdit::multiline(&mut dlg.paste_input)
                                    .font(egui::TextStyle::Monospace)
                                    .hint_text("# Mode: EP+SuperKo\n  1. R:g3-g4   R:a7-a6"),
                            );
                        });
                }

                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    ui.label("Open imported game at:");
                    ui.selectable_value(&mut dlg.open_at, ImportPosition::End, "End (last move)");
                    ui.selectable_value(
                        &mut dlg.open_at,
                        ImportPosition::Start,
                        "Start (ply 0)",
                    );
                });
                ui.small(
                    "Game mode and any custom starting setup are automatically detected.",
                );

                if let Some(err) = &dlg.error_msg {
                    ui.add_space(6.0);
                    ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", err));
                }

                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    if ui.button("✓ Import Game").clicked() {
                        let source_res: Result<(String, String), String> = if dlg.use_paste {
                            if dlg.paste_input.trim().is_empty() {
                                Err("Please paste a movelist first.".to_owned())
                            } else {
                                Ok(("pasted movelist".to_owned(), dlg.paste_input.clone()))
                            }
                        } else {
                            let raw_path = dlg.path_input.trim();
                            if raw_path.is_empty() {
                                Err("Please select or enter a file path.".to_owned())
                            } else {
                                let p = Path::new(raw_path);
                                let resolved = if p.is_absolute() {
                                    p.to_path_buf()
                                } else if let Ok(cwd) = std::env::current_dir() {
                                    let cand = cwd.join(p);
                                    if cand.exists() {
                                        cand
                                    } else {
                                        p.to_path_buf()
                                    }
                                } else {
                                    p.to_path_buf()
                                };
                                std::fs::read_to_string(&resolved)
                                    .map(|txt| (raw_path.to_owned(), txt))
                                    .map_err(|e| {
                                        format!("Could not read '{}': {}", resolved.display(), e)
                                    })
                            }
                        };

                        match source_res {
                            Ok((label, content)) => {
                                match parse_and_detect_import(label, &content, dlg.open_at) {
                                    Ok(res) => loaded_result = Some(res),
                                    Err(e) => dlg.error_msg = Some(e),
                                }
                            }
                            Err(e) => dlg.error_msg = Some(e),
                        }
                    }

                    if ui.button("Cancel").clicked() {
                        cancel_clicked = true;
                    }
                });
            });

        if let Some((variant, req)) = loaded_result {
            self.import_dialog = None;
            self.apply_import_with_variant(variant, req, ctx);
        } else if !open || cancel_clicked {
            self.import_dialog = None;
        }
    }

    fn ui_rules_help_window(&mut self, ctx: &egui::Context, pal: &Palette) {
        if !self.show_help_window {
            return;
        }

        let mut open = true;
        let title = format!("Rules & Help — {}  [Esc to close]", self.variant.display_name());

        egui::Window::new(title)
            .open(&mut open)
            .resizable(true)
            .default_size([630.0, 540.0])
            .min_size([440.0, 320.0])
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        ui.heading(format!("Current Mode: {}", self.variant.display_name()));
                        ui.add_space(4.0);

                        egui::Frame::none()
                            .fill(pal.panel_card_bg)
                            .rounding(egui::Rounding::same(6.0))
                            .inner_margin(egui::Margin::same(10.0))
                            .show(ui, |ui| match self.variant {
                                GameVariant::EpSuperKo => {
                                    ui.strong("EP + SuperKo Rules (Active Mode)");
                                    ui.label("• Starting Energy Points (EP): P1 starts with 4 EP, P2 starts with 5 EP (max 10 EP).");
                                    ui.label("• SuperKo Repetition: Repeating ANY prior board piece layout (ignoring side-to-move and EP) costs 1 EP.");
                                    ui.label("• With 0 EP, repeating any prior position is ILLEGAL.");
                                    ui.label("• Gaining EP: At the start of your turn, if you already have at least 1 piece on a LAND tile in the opponent's last 4 rows, you gain +1 EP (capped at 10) before moving.");
                                    ui.label("• Water Captures: Captures are strictly same-medium only (land→land or water→water).");
                                }
                                GameVariant::ClassicSuperKo => {
                                    ui.colored_label(
                                        pal.classic_accent,
                                        egui::RichText::new("Classic SuperKo Rules — Arimaa 3-Fold Ban (Active Mode)").strong(),
                                    );
                                    ui.label("• No Energy Points (EP) are used in this mode.");
                                    ui.label("• 3rd-Occurrence Ban: A move that would recreate any prior (board layout + same side-to-move) state for the 3rd time is ILLEGAL.");
                                    ui.label("• A 2nd occurrence is allowed (marked with '*' in the Move List).");
                                    ui.label("• Water Captures: Captures are strictly same-medium only (land→land or water→water).");
                                }
                                GameVariant::MonsterRats => {
                                    ui.colored_label(
                                        pal.rats_accent,
                                        egui::RichText::new("Monster Rats Rules (Active Mode)").strong(),
                                    );
                                    ui.label("• MONSTER RAT AMBUSH: A Rat standing in WATER CAN directly capture adjacent enemy Elephants and enemy Rats on LAND!");
                                    ui.label("• WATER SANCTUARY: Capturing FROM land INTO water is STILL FORBIDDEN — land Rats and all other land pieces cannot attack a Rat inside water!");
                                    ui.label("• Uses full EP + SuperKo rules: P1 starts with 4 EP, P2 with 5 EP (max 10 EP); repeating any prior board layout costs 1 EP (illegal at 0 EP); land piece in opponent's last 4 rows grants +1 EP at start of turn.");
                                }
                            });

                        ui.add_space(10.0);
                        ui.heading("Core Dou Shou Qi Rules");
                        ui.label("• Win Conditions: (G) Reach the opponent's Den, (E) Capture all opponent pieces, (M) Leave the opponent with zero legal moves, or (T) Opponent clock timeout in Timed IronMan.");
                        ui.label("• Piece Ranks (strongest to weakest): 8 Elephant (E) > 7 Lion (L) > 6 Tiger (T) > 5 Leopard (P) > 4 Wolf (W) > 3 Dog (D) > 2 Cat (C) > 1 Rat (R).");
                        ui.label("• Equal rank captures equal rank. Special rule: Rat (1) captures Elephant (8), while Elephant (8) CANNOT capture Rat (1) unless the Rat is trapped.");
                        ui.label("• Movement: All pieces move 1 square orthogonally. No piece may enter its own Den.");
                        ui.label("• Water & River Jumping: Only Rats may enter water tiles (~). Lions and Tigers may jump orthogonally across water onto the opposite bank, UNLESS any Rat (friendly or enemy) sits in the intervening water squares.");
                        ui.label("• Traps: Stepping onto an opponent's Trap (#) weakens that piece to strength 0 (capturable by ANY enemy piece, including Elephant vs trapped Rat, and unable to capture out of the trap). Your own traps do not weaken your own pieces.");

                        ui.add_space(10.0);
                        ui.heading("IronMan Challenge Mode (Depth & Timed Fischer)");
                        ui.label("• You always play as P2 (second mover) with Undo/Redo, Switch Sides, Import, Show Legal Moves, Show Thinking, Show Eval, and Stop disabled.");
                        ui.label("• Depth Challenge: Engine starts at depth >= 12 (may be increased, never decreased); ranked in the encrypted Depth Hall of Fame (Top 50, max 5 per start depth).");
                        ui.label("• Timed Match: Both sides share identical Fischer time control (base reserve + increment/move); ranked in the separate encrypted Timed Hall of Fame (sections per played time control).");
                        ui.label("• Leave IronMan Mode anytime via 'New Game' or 'Setup Board' (both ask confirmation).");

                        ui.add_space(10.0);
                        ui.heading("Controls & Shortcuts");
                        ui.label("• [F1]    Toggle this Rules & Help window.");
                        ui.label("• [Space] Stop engine thinking and immediately play best move found (non-IronMan).");
                        ui.label("• [Esc]   Close active Help/Dialog window, or open Quit Confirmation on the main screen.");
                        ui.label("• Setup Mode: Left-click = selected color, Right-click = opposite color, Left+Right (or Middle-click) = remove piece.");
                    });
            });

        if !open {
            self.show_help_window = false;
        }
    }

    fn ui_enter_ironman_confirm(&mut self, ctx: &egui::Context, pal: &Palette) {
        if !self.show_enter_ironman_confirm {
            return;
        }

        let mut start_launch: Option<IronManLaunch> = None;
        let mut cancelled = false;

        egui::Window::new("Start IronMan Challenge?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.colored_label(
                    pal.ironman_accent,
                    egui::RichText::new(format!(
                        "Enter IronMan Mode ({})",
                        self.variant.display_name()
                    ))
                    .strong(),
                );
                ui.add_space(4.0);
                ui.label("You always play P2 (second mover). Aids (Undo/Redo, Switch Sides, Import, Legal Moves, Show Thinking, Show Eval, Stop) are disabled.");
                ui.small("Your current normal game (if any) will be auto-saved safely.");
                ui.add_space(8.0);

                ui.horizontal(|ui| {
                    ui.label("Challenge Type:");
                    ui.selectable_value(&mut self.enter_ironman_is_timed, false, "Depth Challenge");
                    ui.selectable_value(
                        &mut self.enter_ironman_is_timed,
                        true,
                        "Timed Match (Fischer)",
                    );
                });
                ui.separator();

                if !self.enter_ironman_is_timed {
                    ui.horizontal(|ui| {
                        ui.label("Starting IronMan Depth (>= 12):");
                        if ui.small_button("-").clicked()
                            && self.enter_ironman_depth_choice > MIN_IRONMAN_DEPTH
                        {
                            self.enter_ironman_depth_choice -= 1;
                        }
                        ui.add(
                            egui::Slider::new(
                                &mut self.enter_ironman_depth_choice,
                                MIN_IRONMAN_DEPTH..=MAX_FINITE_DEPTH,
                            )
                            .show_value(true)
                            .clamping(egui::SliderClamping::Always),
                        );
                        if ui.small_button("+").clicked()
                            && self.enter_ironman_depth_choice < MAX_FINITE_DEPTH
                        {
                            self.enter_ironman_depth_choice += 1;
                        }
                    });
                } else {
                    let base_m = ALLOWED_TIMED_BASE_MINS[self.enter_ironman_base_idx];
                    let inc_s = ALLOWED_TIMED_INC_SECS[self.enter_ironman_inc_idx];

                    ui.strong(format!(
                        "Selected Time Control: {} min reserve + {} sec/move",
                        base_m, inc_s
                    ));
                    ui.add_space(4.0);

                    ui.small("Quick presets:");
                    ui.horizontal_wrapped(|ui| {
                        for &(bm, is) in &TIMED_IRONMAN_QUICK_PRESETS {
                            let is_sel = base_m == bm && inc_s == is;
                            if ui
                                .selectable_label(is_sel, format!("{}+{}", bm, is))
                                .clicked()
                            {
                                if let Some(bi) =
                                    ALLOWED_TIMED_BASE_MINS.iter().position(|&m| m == bm)
                                {
                                    self.enter_ironman_base_idx = bi;
                                }
                                if let Some(ii) =
                                    ALLOWED_TIMED_INC_SECS.iter().position(|&s| s == is)
                                {
                                    self.enter_ironman_inc_idx = ii;
                                }
                            }
                        }
                    });

                    ui.add_space(6.0);
                    ui.small("Or choose any allowed Fischer combination:");
                    let max_b = ALLOWED_TIMED_BASE_MINS.len() - 1;
                    let max_i = ALLOWED_TIMED_INC_SECS.len() - 1;

                    ui.horizontal(|ui| {
                        ui.label("Base reserve:");
                        if ui.small_button("-").clicked() && self.enter_ironman_base_idx > 0 {
                            self.enter_ironman_base_idx -= 1;
                        }
                        ui.add(
                            egui::Slider::new(&mut self.enter_ironman_base_idx, 0..=max_b)
                                .custom_formatter(|n, _| {
                                    let idx = (n.round() as usize).min(max_b);
                                    format!("{} min", ALLOWED_TIMED_BASE_MINS[idx])
                                })
                                .clamping(egui::SliderClamping::Always),
                        );
                        if ui.small_button("+").clicked() && self.enter_ironman_base_idx < max_b {
                            self.enter_ironman_base_idx += 1;
                        }
                    });

                    ui.horizontal(|ui| {
                        ui.label("Fischer inc:  ");
                        if ui.small_button("-").clicked() && self.enter_ironman_inc_idx > 0 {
                            self.enter_ironman_inc_idx -= 1;
                        }
                        ui.add(
                            egui::Slider::new(&mut self.enter_ironman_inc_idx, 0..=max_i)
                                .custom_formatter(|n, _| {
                                    let idx = (n.round() as usize).min(max_i);
                                    format!("+{} sec", ALLOWED_TIMED_INC_SECS[idx])
                                })
                                .clamping(egui::SliderClamping::Always),
                        );
                        if ui.small_button("+").clicked() && self.enter_ironman_inc_idx < max_i {
                            self.enter_ironman_inc_idx += 1;
                        }
                    });
                }

                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("⚔ Start IronMan Mode").clicked() {
                        if self.enter_ironman_is_timed {
                            start_launch = Some(IronManLaunch::Timed {
                                base_mins: ALLOWED_TIMED_BASE_MINS[self.enter_ironman_base_idx],
                                inc_secs: ALLOWED_TIMED_INC_SECS[self.enter_ironman_inc_idx],
                            });
                        } else {
                            start_launch = Some(IronManLaunch::Depth(self.enter_ironman_depth_choice));
                        }
                    }
                    if ui.button("Cancel").clicked() {
                        cancelled = true;
                    }
                });
                ui.add_space(4.0);
            });

        if let Some(launch) = start_launch {
            self.show_enter_ironman_confirm = false;
            self.enter_ironman_mode(launch, ctx);
        } else if cancelled {
            self.show_enter_ironman_confirm = false;
        }
    }

    fn ui_new_game_leave_ironman_confirm(&mut self, ctx: &egui::Context) {
        if !self.show_new_game_leave_ironman_confirm {
            return;
        }

        let mut leave_confirmed = false;
        let mut cancelled = false;

        egui::Window::new("Leave IronMan Mode?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.label("Starting a new game will END IronMan Mode and return to standard (non-IronMan) mode.");
                ui.small("Any unfinished IronMan run will not be recorded in the Hall of Fame.");
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Leave IronMan & Start Normal Game").clicked() {
                        leave_confirmed = true;
                    }
                    if ui.button("Stay in IronMan Mode").clicked() {
                        cancelled = true;
                    }
                });
                ui.add_space(4.0);
            });

        if leave_confirmed {
            self.show_new_game_leave_ironman_confirm = false;
            self.leave_ironman_to_new_normal_game(ctx);
        } else if cancelled {
            self.show_new_game_leave_ironman_confirm = false;
        }
    }

    fn ui_import_overwrite_confirm(&mut self, ctx: &egui::Context) {
        let Some((req, summary)) = self.pending_import_confirm.clone() else {
            return;
        };

        let mut choice: Option<bool> = None;

        egui::Window::new("Existing Saved Game Found")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.strong(format!(
                    "Importing '{}' will overwrite your existing saved {} game!",
                    req.filename,
                    self.variant.display_name()
                ));
                ui.add_space(6.0);
                ui.label(format!(
                    "Previous saved game: {} moves ({} plies){}",
                    summary.moves,
                    summary.plies,
                    if summary.is_custom { " [custom setup]" } else { "" }
                ));
                ui.label(format!(
                    "Previous settings: Depth {}  |  Max Time: {}",
                    format_depth_val(summary.depth_val),
                    format_time_limit_ms(summary.time_limit_ms)
                ));
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Overwrite & Import").clicked() {
                        choice = Some(true);
                    }
                    if ui.button("Cancel (Keep Saved Game)").clicked() {
                        choice = Some(false);
                    }
                });
                ui.add_space(4.0);
            });

        if let Some(do_overwrite) = choice {
            self.pending_import_confirm = None;
            if do_overwrite {
                self.apply_import(req);
            } else if self.try_autoload(ctx) {
                self.apply_theme(ctx);
            }
        }
    }

    fn ui_hof_name_prompt(&mut self, ctx: &egui::Context, pal: &Palette) {
        let Some(pending) = self.pending_hof_record.clone() else {
            return;
        };

        let (human_won, rank, summary_line) = match &pending {
            PendingHofRecord::Depth(e, r) => (
                e.human_won,
                *r,
                format!(
                    "{} | {} | {} moves | Army {} | {}",
                    if e.human_won { "VICTORY" } else { "DEFEAT" },
                    e.formatted_depth(),
                    e.moves,
                    e.army_strength,
                    e.end_code.label()
                ),
            ),
            PendingHofRecord::Timed(e, r) => (
                e.human_won,
                *r,
                format!(
                    "{} | Timed {} | {} moves | Army {} | {}",
                    if e.human_won { "VICTORY" } else { "DEFEAT" },
                    e.tc_label(),
                    e.moves,
                    e.army_strength,
                    e.end_code.label()
                ),
            ),
        };

        let mut submit = false;
        let title = if rank == 1 {
            "New #1 Hall of Fame Record!"
        } else {
            "New Hall of Fame Record!"
        };

        egui::Window::new(title)
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                let rank_color = if human_won {
                    pal.ep_gain_badge
                } else {
                    pal.ironman_accent
                };
                ui.colored_label(
                    rank_color,
                    egui::RichText::new(format!(
                        "Congratulations! You qualified for Hall of Fame Rank #{}!",
                        rank
                    ))
                    .strong(),
                );
                ui.add_space(4.0);
                ui.monospace(&summary_line);
                ui.add_space(8.0);
                ui.label("Enter your name for the Hall of Fame:");
                let resp = ui.add(
                    egui::TextEdit::singleline(&mut self.hof_name_input)
                        .char_limit(MAX_PLAYER_NAME_LEN)
                        .desired_width(260.0)
                        .hint_text("Your name (or blank for Anonymous)"),
                );
                if resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                    submit = true;
                }
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    if ui.button("Save to Hall of Fame").clicked() {
                        submit = true;
                    }
                });
                ui.add_space(4.0);
            });

        if submit {
            self.commit_pending_hof_record();
        }
    }

    fn ui_quit_confirmation(&mut self, ctx: &egui::Context) {
        if !self.show_quit_confirm {
            return;
        }

        let in_ironman = self.is_ironman();
        let running = self.has_running_game();
        egui::Window::new("Confirm Quit")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                if in_ironman {
                    ui.label("Are you sure you want to quit IronMan Mode?");
                    if running {
                        ui.small("This unfinished IronMan run will NOT be saved.");
                    }
                } else if running {
                    ui.label("Are you sure you want to quit?");
                    ui.small("Your running game will be auto-saved and restored next time you open this mode.");
                } else {
                    ui.label("Are you sure you want to quit Dou Shou Qi?");
                }
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    let quit_label = if !in_ironman && running {
                        "Save & Quit"
                    } else {
                        "Quit"
                    };
                    if ui.button(quit_label).clicked() {
                        self.cancel_search();
                        self.save_autosave();
                        self.allow_close = true;
                        self.show_quit_confirm = false;
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                    if !in_ironman && running && ui.button("Quit Without Saving").clicked() {
                        self.cancel_search();
                        let _ = std::fs::remove_file(self.variant.autosave_path());
                        self.allow_close = true;
                        self.show_quit_confirm = false;
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                    if ui.button("Cancel").clicked() {
                        self.show_quit_confirm = false;
                    }
                });
                ui.add_space(4.0);
            });
    }

    fn ui_ironman_setup_confirm(&mut self, ctx: &egui::Context) {
        if !self.show_ironman_setup_confirm {
            return;
        }

        egui::Window::new("Leave IronMan Mode?")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.label("Opening Setup Mode for analysis will permanently END IronMan Mode for this session.");
                ui.small("This game will not be eligible for the IronMan Hall of Fame.");
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("End IronMan & Open Setup").clicked() {
                        self.show_ironman_setup_confirm = false;
                        self.ironman = None;
                        if self.search_depth >= UNLIMITED_DEPTH_VAL {
                            self.search_depth = 8;
                        }
                        self.show_legal_moves = true;
                        self.show_eval = true;
                        self.update_window_title(ctx);
                        self.enter_setup();
                    }
                    if ui.button("Stay in IronMan Mode").clicked() {
                        self.show_ironman_setup_confirm = false;
                    }
                });
                ui.add_space(4.0);
            });
    }

    fn ui_hall_of_fame_window(&mut self, ctx: &egui::Context, pal: &Palette) {
        if !self.show_hof_window {
            return;
        }

        let mut open = true;
        let mut reload_clicked = false;
        let title = format!("IronMan Hall of Fame — {}", self.variant.display_name());

        egui::Window::new(title)
            .open(&mut open)
            .resizable(true)
            .default_size([750.0, 460.0])
            .min_size([560.0, 280.0])
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.selectable_value(&mut self.hof_tab, HofTab::Depth, "Depth Challenge");
                    ui.selectable_value(&mut self.hof_tab, HofTab::Timed, "Timed Matches");
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button("Reload").clicked() {
                            reload_clicked = true;
                        }
                    });
                });
                ui.separator();

                match self.hof_tab {
                    HofTab::Depth => {
                        ui.strong(format!(
                            "Encrypted {} Depth IronMan Top {} (max {} per start depth)",
                            self.variant.display_name(),
                            MAX_TOTAL_ENTRIES,
                            MAX_ENTRIES_PER_DEPTH
                        ));
                        ui.small("Ranking: Wins > Defeats | Higher start depth | Moves (shorter win / longer defeat) | Surviving Army");
                        ui.small("End-codes: G = Goal (Den) | E = Elimination | M = Immobilization");
                        if let Some(err) = &self.hof_status {
                            ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", err));
                        }
                        ui.add_space(4.0);

                        let wins = self.hof.entries.iter().filter(|e| e.human_won).count();
                        let losses = self.hof.entries.len() - wins;
                        ui.label(format!(
                            "Entries: {}/{}  |  Wins: {}  |  Defeats: {}",
                            self.hof.entries.len(),
                            MAX_TOTAL_ENTRIES,
                            wins,
                            losses
                        ));
                        ui.add_space(6.0);

                        if self.hof.entries.is_empty() {
                            ui.colored_label(
                                pal.coord_text,
                                "No completed Depth IronMan games yet. Click '⚔ IronMan' to start!",
                            );
                        } else {
                            egui::ScrollArea::vertical()
                                .auto_shrink([false, false])
                                .show(ui, |ui| {
                                    egui::Grid::new("hof_depth_grid")
                                        .striped(true)
                                        .spacing([12.0, 5.0])
                                        .show(ui, |ui| {
                                            ui.strong("#");
                                            ui.strong("Player");
                                            ui.strong("Result");
                                            ui.strong("Depth");
                                            ui.strong("Moves");
                                            ui.strong("Army");
                                            ui.strong("Code");
                                            ui.strong("Date (UTC)");
                                            ui.end_row();

                                            for (idx, e) in self.hof.entries.iter().enumerate() {
                                                ui.monospace(format!("{:>2}", idx + 1));
                                                ui.label(&e.player_name);
                                                if e.human_won {
                                                    ui.colored_label(
                                                        pal.ep_gain_badge,
                                                        egui::RichText::new("WIN").strong(),
                                                    );
                                                } else {
                                                    ui.colored_label(
                                                        pal.ep_zero_warn,
                                                        egui::RichText::new("LOSS").strong(),
                                                    );
                                                }
                                                ui.monospace(e.formatted_depth());
                                                ui.monospace(format!("{} ({}p)", e.moves, e.plies));
                                                ui.monospace(format!("{:>4}", e.army_strength));
                                                ui.monospace(e.end_code.label());
                                                ui.monospace(e.formatted_date_utc());
                                                ui.end_row();
                                            }
                                        });
                                });
                        }
                    }
                    HofTab::Timed => {
                        ui.strong(format!(
                            "Encrypted {} Timed IronMan Leaderboards (max {} per time control)",
                            self.variant.display_name(),
                            MAX_TIMED_ENTRIES_PER_TC
                        ));
                        ui.small("Each played Fischer time control has its own section. Ranking within each section: Wins > Defeats | Moves | Surviving Army.");
                        ui.small("End-codes: G = Goal (Den) | E = Elimination | M = Immobilization | T = Timeout");
                        if let Some(err) = &self.timed_hof_status {
                            ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", err));
                        }
                        ui.add_space(4.0);

                        let sections = self.timed_hof.sections_by_tc();
                        let wins = self.timed_hof.entries.iter().filter(|e| e.human_won).count();
                        let losses = self.timed_hof.entries.len() - wins;
                        ui.label(format!(
                            "Played Time Controls: {}  |  Total Entries: {}  |  Wins: {}  |  Defeats: {}",
                            sections.len(),
                            self.timed_hof.entries.len(),
                            wins,
                            losses
                        ));
                        ui.add_space(6.0);

                        if sections.is_empty() {
                            ui.colored_label(
                                pal.coord_text,
                                "No completed Timed IronMan matches yet. Click '⚔ IronMan' -> 'Timed Match (Fischer)' to start!",
                            );
                        } else {
                            egui::ScrollArea::vertical()
                                .auto_shrink([false, false])
                                .show(ui, |ui| {
                                    for ((bm, is), entries) in &sections {
                                        let sw = entries.iter().filter(|e| e.human_won).count();
                                        let sl = entries.len() - sw;
                                        let hdr = format!(
                                            "{}+{} ({} min + {}s/move)   —   {}W / {}L",
                                            bm, is, bm, is, sw, sl
                                        );
                                        egui::Frame::none()
                                            .fill(pal.panel_card_bg)
                                            .rounding(egui::Rounding::same(6.0))
                                            .inner_margin(egui::Margin::same(8.0))
                                            .show(ui, |ui| {
                                                egui::CollapsingHeader::new(
                                                    egui::RichText::new(hdr).strong(),
                                                )
                                                .id_salt(format!("thof_sec_{}_{}", bm, is))
                                                .default_open(true)
                                                .show(ui, |ui| {
                                                    egui::Grid::new(format!(
                                                        "thof_grid_{}_{}",
                                                        bm, is
                                                    ))
                                                    .striped(true)
                                                    .spacing([12.0, 5.0])
                                                    .show(ui, |ui| {
                                                        ui.strong("#");
                                                        ui.strong("Player");
                                                        ui.strong("Result");
                                                        ui.strong("Moves");
                                                        ui.strong("Army");
                                                        ui.strong("Code");
                                                        ui.strong("Date (UTC)");
                                                        ui.end_row();

                                                        for (r_idx, e) in entries.iter().enumerate() {
                                                            ui.monospace(format!("{:>2}", r_idx + 1));
                                                            ui.label(&e.player_name);
                                                            if e.human_won {
                                                                ui.colored_label(
                                                                    pal.ep_gain_badge,
                                                                    egui::RichText::new("WIN")
                                                                        .strong(),
                                                                );
                                                            } else {
                                                                ui.colored_label(
                                                                    pal.ep_zero_warn,
                                                                    egui::RichText::new("LOSS")
                                                                        .strong(),
                                                                );
                                                            }
                                                            ui.monospace(format!(
                                                                "{} ({}p)",
                                                                e.moves, e.plies
                                                            ));
                                                            ui.monospace(format!(
                                                                "{:>4}",
                                                                e.army_strength
                                                            ));
                                                            ui.monospace(e.end_code.label());
                                                            ui.monospace(e.formatted_date_utc());
                                                            ui.end_row();
                                                        }
                                                    });
                                                });
                                            });
                                        ui.add_space(6.0);
                                    }
                                });
                        }
                    }
                }
            });

        if reload_clicked {
            self.reload_hofs_for_variant();
        }
        if !open {
            self.show_hof_window = false;
        }
    }

    fn ui_top_toolbar(&mut self, ctx: &egui::Context, pal: &Palette) {
        let in_setup = self.is_setup();
        let in_ironman = self.is_ironman();
        let in_timed_ironman = self.is_timed_ironman();
        let mut switch_to_variant: Option<GameVariant> = None;

        egui::TopBottomPanel::top("top_toolbar").show(ctx, |ui| {
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing.x = 7.0;

                if !in_setup {
                    ui.add_enabled_ui(!in_ironman, |ui| {
                        let mode_label = format!("Mode: {} ▾", self.variant.display_name());
                        ui.menu_button(mode_label, |ui| {
                            for v in GameVariant::ALL {
                                let selected = self.variant == v;
                                if ui.selectable_label(selected, v.display_name()).clicked() {
                                    if !selected {
                                        switch_to_variant = Some(v);
                                    }
                                    ui.close_menu();
                                }
                            }
                        });
                    });

                    if let Some(im) = &self.ironman {
                        let badge = match &im.kind {
                            IronManKind::Depth { .. } => "⚔ IRONMAN".to_owned(),
                            IronManKind::Timed(c) => {
                                format!("⚔ IRONMAN {}+{}", c.base_mins, c.inc_secs)
                            }
                        };
                        ui.colored_label(pal.ironman_accent, egui::RichText::new(badge).strong());
                    } else if ui
                        .button("⚔ IronMan")
                        .on_hover_text(
                            "Enter competitive IronMan Mode (Depth >= 12 or Timed Fischer Match)",
                        )
                        .clicked()
                    {
                        self.enter_ironman_depth_choice =
                            self.search_depth.clamp(MIN_IRONMAN_DEPTH, MAX_FINITE_DEPTH);
                        self.show_enter_ironman_confirm = true;
                    }
                    ui.separator();
                }

                if in_setup {
                    let valid = self
                        .setup
                        .as_ref()
                        .map(|s| s.validate().is_ok())
                        .unwrap_or(false);
                    if ui
                        .add_enabled(valid, egui::Button::new("✓ End Setup"))
                        .clicked()
                    {
                        self.finish_setup(ctx);
                        return;
                    }
                    if ui.button("✕ Cancel Setup").clicked() {
                        self.cancel_setup();
                        return;
                    }
                    if ui.button("Clear Board").clicked() {
                        if let Some(s) = &mut self.setup {
                            s.clear_board();
                        }
                    }
                    if ui.button("Reset Start").clicked() {
                        if let Some(s) = &mut self.setup {
                            s.reset_start();
                        }
                    }
                } else {
                    if ui.button("New Game").clicked() {
                        if in_ironman {
                            self.show_new_game_leave_ironman_confirm = true;
                        } else {
                            self.new_game(ctx);
                        }
                    }

                    let can_undo = !in_ironman && !self.undo_stack.is_empty();
                    if ui.add_enabled(can_undo, egui::Button::new("Undo")).clicked() {
                        self.undo_move();
                    }

                    let can_redo = !in_ironman && !self.redo_stack.is_empty();
                    if ui.add_enabled(can_redo, egui::Button::new("Redo")).clicked() {
                        self.redo_move();
                    }

                    if ui.button("Setup Board").clicked() {
                        if in_ironman {
                            self.show_ironman_setup_confirm = true;
                        } else {
                            self.enter_setup();
                            return;
                        }
                    }

                    if ui
                        .add_enabled(!in_ironman, egui::Button::new("Import"))
                        .on_hover_text("Import an exported game log (auto-detects mode & setup)")
                        .clicked()
                    {
                        if self.has_running_game() {
                            self.show_gui_import_overwrite_confirm = true;
                        } else {
                            self.import_dialog = Some(ImportDialogState::new());
                        }
                    }

                    if ui
                        .add_enabled(
                            !in_ironman,
                            egui::Button::new(format!("Switch Sides ({})", self.human_side)),
                        )
                        .clicked()
                    {
                        self.switch_sides(ctx);
                    }
                }

                if ui
                    .button(format!("Rotate ↻ ({}°)", self.rotation as u16 * 90))
                    .clicked()
                {
                    self.rotation = (self.rotation + 1) % 4;
                }

                if ui.button("Hall of Fame").clicked() {
                    self.show_hof_window = !self.show_hof_window;
                }

                let pieces_btn = format!("Pieces: {} ▾", self.piece_set.label());
                ui.menu_button(pieces_btn, |ui| {
                    for ps in PieceSet::ALL {
                        let selected = self.piece_set == ps;
                        if ui.selectable_label(selected, ps.label()).clicked() {
                            self.piece_set = ps;
                            ui.close_menu();
                        }
                    }
                });

                let theme_label = match self.theme {
                    ColorTheme::Night => "Night",
                    ColorTheme::Day => "Day",
                };
                if ui.button(theme_label).clicked() {
                    self.theme = match self.theme {
                        ColorTheme::Night => ColorTheme::Day,
                        ColorTheme::Day => ColorTheme::Night,
                    };
                    self.apply_theme(ctx);
                }

                if ui
                    .button("? Help (F1)")
                    .on_hover_text("Show rules for current game mode (F1)")
                    .clicked()
                {
                    self.show_help_window = !self.show_help_window;
                }

                ui.separator();

                // Depth slider:
                // - Normal mode: 1..=60 + Unlimited (61)
                // - IronMan Depth mode: min_depth..=60 (monotonic, cannot decrease)
                // - IronMan Timed mode: disabled (controlled by match clock)
                let (min_depth, max_depth) = match self.ironman.as_ref().map(|im| &im.kind) {
                    Some(IronManKind::Depth { min_depth, .. }) => (*min_depth, MAX_FINITE_DEPTH),
                    Some(IronManKind::Timed(_)) => (UNLIMITED_DEPTH_VAL, UNLIMITED_DEPTH_VAL),
                    None => (1, UNLIMITED_DEPTH_VAL),
                };

                ui.label("Depth:");
                ui.add_enabled_ui(!in_timed_ironman, |ui| {
                    let can_dec = !in_ironman && self.search_depth > 1;
                    if ui.add_enabled(can_dec, egui::Button::new("-").small()).clicked() {
                        self.search_depth -= 1;
                    }
                    ui.add(
                        egui::Slider::new(&mut self.search_depth, min_depth..=max_depth)
                            .custom_formatter(|n, _| format_depth_val(n.round() as usize))
                            .clamping(egui::SliderClamping::Always),
                    );
                    if ui
                        .add_enabled(
                            self.search_depth < max_depth,
                            egui::Button::new("+").small(),
                        )
                        .clicked()
                    {
                        self.search_depth += 1;
                    }
                });

                if let Some(IronManState {
                    kind: IronManKind::Depth { min_depth, .. },
                    ..
                }) = &mut self.ironman
                {
                    if self.search_depth < *min_depth {
                        self.search_depth = *min_depth;
                    } else if self.search_depth > MAX_FINITE_DEPTH {
                        self.search_depth = MAX_FINITE_DEPTH;
                    } else if self.search_depth > *min_depth {
                        *min_depth = self.search_depth;
                    }
                }

                ui.separator();

                if in_ironman {
                    self.time_limit_idx = UNLIMITED_TIME_IDX;
                }
                ui.label("Max Time:");
                ui.add_enabled_ui(!in_ironman, |ui| {
                    if ui
                        .add_enabled(self.time_limit_idx > 0, egui::Button::new("-").small())
                        .clicked()
                    {
                        self.time_limit_idx -= 1;
                    }
                    ui.add(
                        egui::Slider::new(&mut self.time_limit_idx, 0..=UNLIMITED_TIME_IDX)
                            .custom_formatter(|n, _| {
                                let idx = (n.round() as usize).min(UNLIMITED_TIME_IDX);
                                format_time_limit_ms(TIME_PRESETS_MS[idx])
                            })
                            .clamping(egui::SliderClamping::Always),
                    );
                    if ui
                        .add_enabled(
                            self.time_limit_idx < UNLIMITED_TIME_IDX,
                            egui::Button::new("+").small(),
                        )
                        .clicked()
                    {
                        self.time_limit_idx += 1;
                    }
                });

                if !in_setup {
                    let can_stop = !in_ironman
                        && self
                            .pending_search
                            .as_ref()
                            .map(|p| !p.stop_requested)
                            .unwrap_or(false);
                    if ui
                        .add_enabled(can_stop, egui::Button::new("⏹ Stop [Space]"))
                        .on_hover_text(
                            "Stop thinking (or press Space) to immediately play best move found",
                        )
                        .clicked()
                    {
                        self.request_stop_and_play();
                    }

                    ui.separator();
                    if in_ironman {
                        self.show_legal_moves = false;
                        self.show_thinking = false;
                        self.show_eval = false;
                    }
                    ui.add_enabled(
                        !in_ironman,
                        egui::Checkbox::new(&mut self.show_legal_moves, "Legal Moves"),
                    );
                    let eval_label = if self.show_eval {
                        "Show Eval: ON"
                    } else {
                        "Show Eval: OFF"
                    };
                    if ui
                        .add_enabled(
                            !in_ironman,
                            egui::SelectableLabel::new(self.show_eval, eval_label),
                        )
                        .on_hover_text("Show or hide the engine's position evaluation score")
                        .clicked()
                    {
                        self.show_eval = !self.show_eval;
                    }
                    let think_label = if self.show_thinking {
                        "Show Thinking: ON"
                    } else {
                        "Show Thinking: OFF"
                    };
                    if ui
                        .add_enabled(
                            !in_ironman,
                            egui::SelectableLabel::new(self.show_thinking, think_label),
                        )
                        .on_hover_text("Highlight engine's current best move while thinking")
                        .clicked()
                    {
                        self.show_thinking = !self.show_thinking;
                    }
                }
            });
            ui.add_space(4.0);
        });

        if let Some(new_v) = switch_to_variant {
            self.switch_variant(new_v, ctx);
        }
    }

    fn ui_ep_grid_row(
        &self,
        ui: &mut egui::Ui,
        side: Color,
        ep: u8,
        gaining: bool,
        is_turn: bool,
        pal: &Palette,
    ) {
        let fill_color = match side {
            Color::P1 => pal.p1_fill,
            Color::P2 => pal.p2_fill,
        };
        let label_text = match side {
            Color::P1 => "P1",
            Color::P2 => "P2",
        };

        ui.horizontal(|ui| {
            let tag = if is_turn {
                format!("▶ {}:", label_text)
            } else {
                format!("   {}:", label_text)
            };
            ui.colored_label(fill_color, egui::RichText::new(tag).strong().monospace());

            let count_color = if ep == 0 {
                pal.ep_zero_warn
            } else {
                pal.badge_text
            };
            ui.colored_label(
                count_color,
                egui::RichText::new(format!("{:>2}/{}", ep, MAX_EP))
                    .monospace()
                    .strong(),
            );

            if gaining {
                ui.colored_label(
                    pal.ep_gain_badge,
                    egui::RichText::new("+1/turn").small().strong(),
                );
            } else if ep == 0 {
                ui.colored_label(
                    pal.ep_zero_warn,
                    egui::RichText::new("NO REPEAT").small().strong(),
                );
            }
        });

        let cells = MAX_EP as usize;
        let avail_w = ui.available_width().max(120.0);
        let cell_h = 15.0;
        let gap = 2.0;
        let cell_w = ((avail_w - gap * (cells as f32 - 1.0)) / cells as f32).max(8.0);

        let (rect, _) =
            ui.allocate_exact_size(egui::vec2(avail_w, cell_h), egui::Sense::hover());
        let painter = ui.painter_at(rect);

        for i in 0..cells {
            let x0 = rect.left() + i as f32 * (cell_w + gap);
            let cell_rect = egui::Rect::from_min_size(
                egui::pos2(x0, rect.top()),
                egui::vec2(cell_w, cell_h),
            );
            let filled = (i as u8) < ep;
            let bg = if filled {
                fill_color
            } else {
                pal.ep_empty_cell
            };
            let stroke_col = if ep == 0 {
                pal.ep_zero_warn
            } else {
                pal.ep_grid_border
            };

            painter.rect_filled(cell_rect, egui::Rounding::same(2.5), bg);
            painter.rect_stroke(
                cell_rect,
                egui::Rounding::same(2.5),
                egui::Stroke::new(1.0, stroke_col),
            );
        }
    }

    fn ui_right_panel(&mut self, ctx: &egui::Context, pal: &Palette) {
        egui::SidePanel::right("right_panel")
            .resizable(true)
            .default_width(315.0)
            .min_width(235.0)
            .max_width(540.0)
            .show(ctx, |ui| {
                ui.add_space(6.0);

                if self.is_setup() {
                    self.ui_right_panel_setup(ctx, ui, pal);
                } else {
                    self.ui_right_panel_play(ui, pal);
                }
            });
    }

    fn ui_right_panel_play(&mut self, ui: &mut egui::Ui, pal: &Palette) {
        let thinking = self.visible_thinking();
        let eval_visible = self.eval_visible();
        let info_line = self.current_engine_info_line();
        let result = self.effective_game_result();
        let ongoing = result == GameResult::Ongoing;

        egui::Frame::none()
            .fill(pal.panel_card_bg)
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(egui::Margin::same(8.0))
            .show(ui, |ui| {
                if let Some(im) = &self.ironman {
                    match &im.kind {
                        IronManKind::Depth { start_depth, .. } => {
                            ui.colored_label(
                                pal.ironman_accent,
                                egui::RichText::new(format!(
                                    "IRONMAN {} (Start d{}, Current d{})",
                                    self.variant.display_name(),
                                    start_depth,
                                    self.search_depth
                                ))
                                .strong()
                                .small(),
                            );
                        }
                        IronManKind::Timed(clk) => {
                            ui.colored_label(
                                pal.ironman_accent,
                                egui::RichText::new(format!(
                                    "IRONMAN TIMED {} ({}+{} Fischer)",
                                    self.variant.display_name(),
                                    clk.base_mins,
                                    clk.inc_secs
                                ))
                                .strong()
                                .small(),
                            );
                            ui.add_space(4.0);
                            let active = self.state.side_to_move();
                            let p1_ms = clk.live_remaining_ms(Color::P1, active, ongoing);
                            let p2_ms = clk.live_remaining_ms(Color::P2, active, ongoing);
                            ui.horizontal(|ui| {
                                let p1_col = if p1_ms <= 15_000 {
                                    pal.ep_zero_warn
                                } else {
                                    pal.p1_fill
                                };
                                let p2_col = if p2_ms <= 15_000 {
                                    pal.ep_zero_warn
                                } else {
                                    pal.p2_fill
                                };
                                let p1_tag = if ongoing && active == Color::P1 {
                                    "▶ P1 (Bot):"
                                } else {
                                    "P1 (Bot):"
                                };
                                let p2_tag = if ongoing && active == Color::P2 {
                                    "▶ P2 (You):"
                                } else {
                                    "P2 (You):"
                                };
                                ui.colored_label(
                                    p1_col,
                                    egui::RichText::new(format!(
                                        "{} {}",
                                        p1_tag,
                                        format_clock_ms(p1_ms)
                                    ))
                                    .monospace()
                                    .strong(),
                                );
                                ui.separator();
                                ui.colored_label(
                                    p2_col,
                                    egui::RichText::new(format!(
                                        "{} {}",
                                        p2_tag,
                                        format_clock_ms(p2_ms)
                                    ))
                                    .monospace()
                                    .strong(),
                                );
                            });
                            ui.add_space(3.0);
                        }
                    }
                }

                let status_line = match result {
                    GameResult::Win(w) => {
                        let by_time = matches!(
                            &self.ironman,
                            Some(IronManState {
                                kind: IronManKind::Timed(c),
                                ..
                            }) if c.flagged_winner.is_some()
                        );
                        if by_time {
                            format!("GAME OVER: {} WINS ON TIME!", w)
                        } else {
                            format!("GAME OVER: {} WINS!", w)
                        }
                    }
                    GameResult::Ongoing => {
                        if let Some(p) = &self.pending_search {
                            format!(
                                "Turn: {} (Engine thinking {:.1}s...)",
                                self.state.side_to_move(),
                                p.started_at.elapsed().as_secs_f32()
                            )
                        } else {
                            format!("Turn: {} (Your move)", self.state.side_to_move())
                        }
                    }
                };
                ui.strong(status_line);
                ui.small(&info_line);

                if let Some(tp) = thinking {
                    ui.add_space(4.0);
                    let think_text = if eval_visible {
                        format!(
                            "Thinking: {}  |  eval {}  |  d{} ({} nodes)",
                            tp.best_move,
                            format_score(tp.score),
                            tp.depth,
                            tp.nodes
                        )
                    } else {
                        format!(
                            "Thinking: {}  |  d{} ({} nodes)",
                            tp.best_move, tp.depth, tp.nodes
                        )
                    };
                    ui.colored_label(
                        pal.thinking_accent,
                        egui::RichText::new(think_text).monospace().strong().small(),
                    );
                }

                if self.variant == GameVariant::MonsterRats {
                    ui.add_space(4.0);
                    ui.colored_label(
                        pal.rats_accent,
                        egui::RichText::new("Monster Rats: Water → Land ambush active!")
                            .strong()
                            .small(),
                    );
                }

                if self.variant.uses_ep() {
                    ui.add_space(6.0);
                    ui.label(egui::RichText::new("Energy Points (EP)").strong());
                    ui.add_space(2.0);
                    let ep = self.state.ep();
                    let p1_gain = (self.state.occ_side(0) & INVASION_LAND_MASK[0]) != 0;
                    let p2_gain = (self.state.occ_side(1) & INVASION_LAND_MASK[1]) != 0;
                    self.ui_ep_grid_row(
                        ui,
                        Color::P1,
                        ep[0],
                        p1_gain,
                        self.state.side_to_move() == Color::P1 && ongoing,
                        pal,
                    );
                    ui.add_space(5.0);
                    self.ui_ep_grid_row(
                        ui,
                        Color::P2,
                        ep[1],
                        p2_gain,
                        self.state.side_to_move() == Color::P2 && ongoing,
                        pal,
                    );
                } else {
                    ui.add_space(6.0);
                    ui.colored_label(
                        pal.classic_accent,
                        egui::RichText::new("Classic SuperKo (Arimaa 3-Fold Ban)").strong(),
                    );
                    ui.small("No EP. Repeating a position (same side to move) for the 3rd time is illegal.");
                }
            });

        ui.add_space(8.0);

        ui.heading("Piece Graveyard");
        egui::Frame::none()
            .fill(pal.panel_card_bg)
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(egui::Margin::same(8.0))
            .show(ui, |ui| {
                let sqs = self.state.piece_sq();
                self.ui_piece_tray_row(ui, &sqs, Color::P1, "Captured P1:", false, pal);
                ui.add_space(6.0);
                self.ui_piece_tray_row(ui, &sqs, Color::P2, "Captured P2:", false, pal);
            });

        ui.add_space(10.0);

        ui.horizontal(|ui| {
            ui.heading("Move List");
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                let copied_active = self
                    .copied_until
                    .map(|t| Instant::now() < t)
                    .unwrap_or(false);
                let btn_text = if copied_active { "Copied!" } else { "Copy" };
                if ui.button(btn_text).clicked() {
                    let text = self.format_movelist_for_export();
                    ui.ctx().copy_text(text);
                    self.copied_until = Some(Instant::now() + std::time::Duration::from_secs(2));
                }
            });
        });

        let legend = if self.variant.uses_ep() {
            "(* = paid 1 EP for SuperKo repetition, x = capture)"
        } else {
            "(* = 2nd identical occurrence, x = capture)"
        };
        ui.small(legend);
        ui.add_space(4.0);

        let movelist_str = self.format_movelist();
        let mut ro_str: &str = if movelist_str.is_empty() {
            "(No moves played yet)"
        } else {
            &movelist_str
        };

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .stick_to_bottom(true)
            .show(ui, |ui| {
                ui.add_sized(
                    ui.available_size(),
                    egui::TextEdit::multiline(&mut ro_str)
                        .font(egui::TextStyle::Monospace)
                        .desired_width(f32::INFINITY),
                );
            });
    }

    fn ui_right_panel_setup(&mut self, ctx: &egui::Context, ui: &mut egui::Ui, pal: &Palette) {
        let mut finish_clicked = false;
        let mut cancel_clicked = false;
        let mut picked_from_reservoir: Option<(Color, PieceKind)> = None;
        let uses_ep = self.variant.uses_ep();

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                let (ep_p1, ep_p2, p1_gain, p2_gain, stm, status_msg, validation) = {
                    let s = self.setup.as_ref().unwrap();
                    (
                        s.ep[0],
                        s.ep[1],
                        (s.side_occ(0) & INVASION_LAND_MASK[0]) != 0,
                        (s.side_occ(1) & INVASION_LAND_MASK[1]) != 0,
                        s.side_to_move,
                        s.status_msg.clone(),
                        s.validate(),
                    )
                };

                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        ui.colored_label(
                            pal.setup_banner,
                            egui::RichText::new(format!(
                                "SETUP MODE ({})",
                                self.variant.display_name()
                            ))
                            .strong()
                            .size(15.0),
                        );
                        ui.small(&status_msg);

                        if uses_ep {
                            ui.add_space(6.0);
                            ui.label(egui::RichText::new("Configure Energy Points (EP)").strong());
                            ui.add_space(2.0);
                            self.ui_ep_grid_row(
                                ui,
                                Color::P1,
                                ep_p1,
                                p1_gain,
                                stm == Color::P1,
                                pal,
                            );
                            ui.horizontal(|ui| {
                                ui.small("P1 EP:");
                                let s = self.setup.as_mut().unwrap();
                                if ui.small_button("-").clicked() && s.ep[0] > 0 {
                                    s.ep[0] -= 1;
                                }
                                ui.add(
                                    egui::Slider::new(&mut s.ep[0], 0..=MAX_EP)
                                        .show_value(false)
                                        .clamping(egui::SliderClamping::Always),
                                );
                                if ui.small_button("+").clicked() && s.ep[0] < MAX_EP {
                                    s.ep[0] += 1;
                                }
                            });

                            ui.add_space(4.0);
                            self.ui_ep_grid_row(
                                ui,
                                Color::P2,
                                ep_p2,
                                p2_gain,
                                stm == Color::P2,
                                pal,
                            );
                            ui.horizontal(|ui| {
                                ui.small("P2 EP:");
                                let s = self.setup.as_mut().unwrap();
                                if ui.small_button("-").clicked() && s.ep[1] > 0 {
                                    s.ep[1] -= 1;
                                }
                                ui.add(
                                    egui::Slider::new(&mut s.ep[1], 0..=MAX_EP)
                                        .show_value(false)
                                        .clamping(egui::SliderClamping::Always),
                                );
                                if ui.small_button("+").clicked() && s.ep[1] < MAX_EP {
                                    s.ep[1] += 1;
                                }
                            });
                        } else {
                            ui.add_space(4.0);
                            ui.colored_label(
                                pal.classic_accent,
                                "Classic SuperKo: No EP reserves (3rd identical position banned).",
                            );
                        }
                    });

                ui.add_space(8.0);

                ui.heading("Piece Reservoir");
                ui.small("Unplaced pieces (click any piece to select it as your brush):");
                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        let sqs = self.setup.as_ref().unwrap().piece_sq;
                        if let Some(k) =
                            self.ui_piece_tray_row(ui, &sqs, Color::P1, "P1 Reservoir:", true, pal)
                        {
                            picked_from_reservoir = Some((Color::P1, k));
                        }
                        ui.add_space(6.0);
                        if let Some(k) =
                            self.ui_piece_tray_row(ui, &sqs, Color::P2, "P2 Reservoir:", true, pal)
                        {
                            picked_from_reservoir = Some((Color::P2, k));
                        }
                    });

                ui.add_space(8.0);

                ui.heading("Setup Controls");
                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        {
                            let s = self.setup.as_mut().unwrap();

                            ui.horizontal(|ui| {
                                ui.label("Left-click color:");
                                ui.selectable_value(&mut s.brush_color, Color::P1, "P1");
                                ui.selectable_value(&mut s.brush_color, Color::P2, "P2");
                            });
                            ui.small(format!(
                                "(Right-click places {}; L+R click or Middle-click removes)",
                                s.brush_color.opp()
                            ));

                            ui.add_space(6.0);
                            ui.label("Select piece to place:");
                            ui.horizontal_wrapped(|ui| {
                                for &kind in PieceKind::ALL.iter().rev() {
                                    let label = format!("{} ({})", piece_name(kind), kind.rank());
                                    ui.selectable_value(&mut s.brush_kind, kind, label);
                                }
                            });

                            ui.add_space(8.0);
                            ui.separator();
                            ui.add_space(4.0);

                            ui.horizontal(|ui| {
                                ui.label("Side to move:");
                                ui.selectable_value(&mut s.side_to_move, Color::P1, "P1");
                                ui.selectable_value(&mut s.side_to_move, Color::P2, "P2");
                            });
                        }

                        ui.horizontal(|ui| {
                            ui.label("You play as:");
                            ui.selectable_value(&mut self.human_side, Color::P1, "P1");
                            ui.selectable_value(&mut self.human_side, Color::P2, "P2");
                        });

                        ui.add_space(8.0);
                        ui.horizontal(|ui| {
                            let s = self.setup.as_mut().unwrap();
                            if ui.button("Clear Board").clicked() {
                                s.clear_board();
                            }
                            if ui.button("Reset Start").clicked() {
                                s.reset_start();
                            }
                        });

                        ui.add_space(8.0);
                        if let Err(reason) = validation {
                            ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", reason));
                        } else {
                            ui.colored_label(pal.ep_gain_badge, "✓ Position is valid.");
                        }

                        ui.add_space(4.0);
                        ui.horizontal(|ui| {
                            if ui
                                .add_enabled(validation.is_ok(), egui::Button::new("✓ End Setup"))
                                .clicked()
                            {
                                finish_clicked = true;
                            }
                            if ui.button("✕ Cancel").clicked() {
                                cancel_clicked = true;
                            }
                        });
                    });
            });

        if let Some((color, kind)) = picked_from_reservoir {
            if let Some(s) = &mut self.setup {
                s.brush_color = color;
                s.brush_kind = kind;
                s.status_msg = format!("Selected {} {} for placement.", color, piece_name(kind));
            }
        }
        if finish_clicked {
            self.finish_setup(ctx);
        } else if cancel_clicked {
            self.cancel_setup();
        }
    }

    fn ui_piece_tray_row(
        &self,
        ui: &mut egui::Ui,
        piece_sq: &[u8; 16],
        side: Color,
        label: &str,
        clickable: bool,
        pal: &Palette,
    ) -> Option<PieceKind> {
        let base = side.idx() * 8;
        let mut unplaced = Vec::new();
        for k in (0..8usize).rev() {
            if piece_sq[base + k] == CAPTURED {
                unplaced.push(PieceKind::from_idx(k));
            }
        }

        ui.small(label);
        if unplaced.is_empty() {
            ui.colored_label(
                pal.coord_text,
                if clickable {
                    "  (all pieces placed)"
                } else {
                    "  (none)"
                },
            );
            return None;
        }

        let disc_size = 30.0;
        let spacing = 5.0;
        let avail_w = ui.available_width().max(disc_size);
        let per_row = ((avail_w + spacing) / (disc_size + spacing))
            .floor()
            .max(1.0) as usize;
        let rows = unplaced.len().div_ceil(per_row);
        let total_h = rows as f32 * (disc_size + spacing);

        let sense = if clickable {
            egui::Sense::click()
        } else {
            egui::Sense::hover()
        };
        let (rect, response) = ui.allocate_exact_size(egui::vec2(avail_w, total_h), sense);
        let painter = ui.painter_at(rect);

        let active_brush = self
            .setup
            .as_ref()
            .map(|s| (s.brush_color, s.brush_kind));

        let mut clicked_kind = None;
        let click_pos = if clickable && response.clicked() {
            response.interact_pointer_pos()
        } else {
            None
        };

        for (i, &kind) in unplaced.iter().enumerate() {
            let col = i % per_row;
            let row = i / per_row;
            let cx = rect.left() + col as f32 * (disc_size + spacing) + disc_size * 0.5;
            let cy = rect.top() + row as f32 * (disc_size + spacing) + disc_size * 0.5;
            let center = egui::pos2(cx, cy);
            let r = disc_size * 0.45;

            self.draw_piece_disc(&painter, center, r, side, kind, pal);

            if clickable && active_brush == Some((side, kind)) {
                painter.circle_stroke(
                    center,
                    r + 2.5,
                    egui::Stroke::new(2.2, pal.selected_ring),
                );
            }

            if let Some(p) = click_pos {
                if (p - center).length() <= r + 3.0 {
                    clicked_kind = Some(kind);
                }
            }
        }

        clicked_kind
    }

    fn ui_board_panel(&mut self, ctx: &egui::Context, pal: &Palette) {
        let thinking = self.visible_thinking();

        egui::CentralPanel::default().show(ctx, |ui| {
            let avail = ui.available_size();
            let (vis_cols, vis_rows) = self.visual_dims();
            let rotation = self.rotation;

            let margin = 26.0;
            let max_w = (avail.x - margin * 2.0).max(100.0);
            let max_h = (avail.y - margin * 2.0).max(100.0);
            let tile = (max_w / vis_cols as f32).min(max_h / vis_rows as f32);

            let board_w = tile * vis_cols as f32;
            let board_h = tile * vis_rows as f32;
            let total_w = board_w + margin * 2.0;
            let total_h = board_h + margin * 2.0;

            let (full_rect, response) =
                ui.allocate_exact_size(avail, egui::Sense::click_and_drag());
            let origin = egui::pos2(
                full_rect.center().x - total_w * 0.5,
                full_rect.center().y - total_h * 0.5,
            );
            let frame_rect = egui::Rect::from_min_size(origin, egui::vec2(total_w, total_h));
            let board_origin = egui::pos2(origin.x + margin, origin.y + margin);

            let painter = ui.painter_at(full_rect);

            painter.rect_filled(frame_rect, egui::Rounding::same(10.0), pal.board_frame);
            if self.is_setup() {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.5, pal.setup_banner),
                );
            } else if self.is_ironman() {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.5, pal.ironman_accent),
                );
            } else if self.variant == GameVariant::ClassicSuperKo {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.0, pal.classic_accent),
                );
            } else if self.variant == GameVariant::MonsterRats {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.0, pal.rats_accent),
                );
            }

            let coord_font = egui::FontId::monospace((tile * 0.24).clamp(10.0, 18.0));
            for vx in 0..vis_cols {
                let (r_top, c_top) = self.visual_to_board(vx, 0);
                let label = if rotation % 2 == 0 {
                    ((b'a' + c_top as u8) as char).to_string()
                } else {
                    (r_top + 1).to_string()
                };
                let cx = board_origin.x + (vx as f32 + 0.5) * tile;
                painter.text(
                    egui::pos2(cx, origin.y + margin * 0.5),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
                painter.text(
                    egui::pos2(cx, board_origin.y + board_h + margin * 0.5),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
            }
            for vy in 0..vis_rows {
                let (r_left, c_left) = self.visual_to_board(0, vy);
                let label = if rotation % 2 == 0 {
                    (r_left + 1).to_string()
                } else {
                    ((b'a' + c_left as u8) as char).to_string()
                };
                let cy = board_origin.y + (vy as f32 + 0.5) * tile;
                painter.text(
                    egui::pos2(origin.x + margin * 0.5, cy),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
                painter.text(
                    egui::pos2(board_origin.x + board_w + margin * 0.5, cy),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
            }

            let active_piece_sq: [u8; 16] = match &self.setup {
                Some(s) => s.piece_sq,
                None => self.state.piece_sq(),
            };

            let selected_moves: Vec<Move> = if !self.is_setup()
                && self.effective_game_result() == GameResult::Ongoing
                && self.state.side_to_move() == self.human_side
                && self.pending_search.is_none()
            {
                if let Some(sel) = self.selected_sq {
                    self.state
                        .gen_legal_moves()
                        .into_iter()
                        .filter(|m| m.from() == sel)
                        .collect()
                } else {
                    Vec::new()
                }
            } else {
                Vec::new()
            };

            let thinking_mv = thinking.map(|t| t.best_move);

            for r in 0..ROWS {
                for c in 0..COLS {
                    let sq = Square::from_rc(r, c);
                    let bit = sq.bit();
                    let (vx, vy) = self.board_to_visual(r, c);
                    let tile_rect = egui::Rect::from_min_size(
                        egui::pos2(
                            board_origin.x + vx as f32 * tile,
                            board_origin.y + vy as f32 * tile,
                        ),
                        egui::vec2(tile, tile),
                    );

                    let checker = (r + c) % 2 == 0;
                    let fill = if sq == DEN_SQ[0] {
                        pal.den_p1
                    } else if sq == DEN_SQ[1] {
                        pal.den_p2
                    } else if (bit & TRAPS_MASK[0]) != 0 {
                        pal.trap_p1
                    } else if (bit & TRAPS_MASK[1]) != 0 {
                        pal.trap_p2
                    } else if (bit & WATER_MASK) != 0 {
                        if checker {
                            pal.water_light
                        } else {
                            pal.water_dark
                        }
                    } else if checker {
                        pal.land_light
                    } else {
                        pal.land_dark
                    };

                    painter.rect_filled(tile_rect, egui::Rounding::ZERO, fill);
                    painter.rect_stroke(
                        tile_rect,
                        egui::Rounding::ZERO,
                        egui::Stroke::new(1.0, pal.grid_line),
                    );

                    let marker_font = egui::FontId::proportional((tile * 0.22).clamp(9.0, 16.0));
                    if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "DEN",
                            marker_font,
                            pal.badge_text.linear_multiply(0.65),
                        );
                    } else if (bit & (TRAPS_MASK[0] | TRAPS_MASK[1])) != 0 {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "TRAP",
                            egui::FontId::proportional((tile * 0.18).clamp(8.0, 13.0)),
                            pal.badge_text.linear_multiply(0.55),
                        );
                    } else if (bit & WATER_MASK) != 0 {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "~",
                            egui::FontId::proportional((tile * 0.34).clamp(11.0, 22.0)),
                            egui::Color32::from_rgba_unmultiplied(200, 235, 255, 65),
                        );
                    }

                    if !self.is_setup() {
                        if let Some(lm) = self.last_move {
                            if lm.from() == sq || lm.to() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.last_move_tint,
                                );
                            }
                        }

                        if let Some(tmv) = thinking_mv {
                            if tmv.from() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.thinking_from_tint,
                                );
                                painter.rect_stroke(
                                    tile_rect.shrink(2.0),
                                    egui::Rounding::same(4.0),
                                    egui::Stroke::new(3.0, pal.thinking_accent),
                                );
                            } else if tmv.to() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.thinking_to_tint,
                                );
                                painter.rect_stroke(
                                    tile_rect.shrink(2.0),
                                    egui::Rounding::same(4.0),
                                    egui::Stroke::new(3.0, pal.thinking_accent),
                                );
                            }
                        }

                        if self.selected_sq == Some(sq) {
                            painter.rect_stroke(
                                tile_rect.shrink(2.0),
                                egui::Rounding::same(4.0),
                                egui::Stroke::new(3.0, pal.selected_ring),
                            );
                        }
                    }
                }
            }

            let piece_radius = tile * 0.39;
            for (pid, &sq_u8) in active_piece_sq.iter().enumerate() {
                if sq_u8 == CAPTURED {
                    continue;
                }
                let sq = Square(sq_u8);
                let (vx, vy) = self.board_to_visual(sq.row(), sq.col());
                let center = egui::pos2(
                    board_origin.x + (vx as f32 + 0.5) * tile,
                    board_origin.y + (vy as f32 + 0.5) * tile,
                );
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                self.draw_piece_disc(&painter, center, piece_radius, color, kind, pal);
            }

            if let Some(tmv) = thinking_mv {
                let from = tmv.from();
                let to = tmv.to();
                let (fvx, fvy) = self.board_to_visual(from.row(), from.col());
                let (tvx, tvy) = self.board_to_visual(to.row(), to.col());
                let p_from = egui::pos2(
                    board_origin.x + (fvx as f32 + 0.5) * tile,
                    board_origin.y + (fvy as f32 + 0.5) * tile,
                );
                let p_to = egui::pos2(
                    board_origin.x + (tvx as f32 + 0.5) * tile,
                    board_origin.y + (tvy as f32 + 0.5) * tile,
                );
                draw_thinking_arrow(&painter, p_from, p_to, tile, pal.thinking_accent);
            }

            if !self.is_setup() && !self.is_ironman() && self.show_legal_moves {
                let opp_den = DEN_SQ[self.state.side_to_move().opp().idx()];
                for &mv in &selected_moves {
                    let to = mv.to();
                    let (vx, vy) = self.board_to_visual(to.row(), to.col());
                    let center = egui::pos2(
                        board_origin.x + (vx as f32 + 0.5) * tile,
                        board_origin.y + (vy as f32 + 0.5) * tile,
                    );
                    let is_capture = self.state.board_piece(to.idx()) != EMPTY_SQ;
                    if to == opp_den {
                        painter.circle_stroke(
                            center,
                            tile * 0.42,
                            egui::Stroke::new(4.0, pal.legal_win),
                        );
                    } else if is_capture {
                        painter.circle_stroke(
                            center,
                            tile * 0.42,
                            egui::Stroke::new(3.5, pal.legal_capture),
                        );
                    } else if self.state.move_has_rep_warning(mv) {
                        painter.circle_filled(center, tile * 0.16, pal.legal_rep_warn);
                    } else {
                        painter.circle_filled(center, tile * 0.14, pal.legal_quiet);
                    }
                }
            }

            if self.any_modal_open() {
                return;
            }

            let px_to_sq = move |pos_px: egui::Pos2| -> Option<Square> {
                let rel_x = pos_px.x - board_origin.x;
                let rel_y = pos_px.y - board_origin.y;
                if rel_x >= 0.0 && rel_x < board_w && rel_y >= 0.0 && rel_y < board_h {
                    let vx = (rel_x / tile) as usize;
                    let vy = (rel_y / tile) as usize;
                    if vx < vis_cols && vy < vis_rows {
                        let (r, c) = visual_to_board_rot(rotation, vx, vy);
                        return Some(Square::from_rc(r, c));
                    }
                }
                None
            };

            if self.is_setup() {
                self.handle_setup_board_input(ctx, &response, &px_to_sq);
            } else if response.clicked() {
                if let Some(pos_px) = response.interact_pointer_pos() {
                    if let Some(clicked_sq) = px_to_sq(pos_px) {
                        self.handle_square_click(clicked_sq, &selected_moves, ctx);
                    } else {
                        self.selected_sq = None;
                    }
                }
            }
        });
    }

    fn handle_setup_board_input<F>(
        &mut self,
        ctx: &egui::Context,
        response: &egui::Response,
        px_to_sq: &F,
    ) where
        F: Fn(egui::Pos2) -> Option<Square>,
    {
        let (primary_down, secondary_down, primary_released, secondary_released, middle_clicked, ptr) =
            ctx.input(|i| {
                (
                    i.pointer.primary_down(),
                    i.pointer.secondary_down(),
                    i.pointer.primary_released(),
                    i.pointer.secondary_released(),
                    i.pointer.button_clicked(egui::PointerButton::Middle),
                    i.pointer.interact_pos(),
                )
            });

        let Some(setup) = self.setup.as_mut() else {
            return;
        };

        if primary_down && secondary_down {
            if !setup.chord_consumed {
                if let Some(p) = ptr {
                    if response.rect.contains(p) {
                        if let Some(sq) = px_to_sq(p) {
                            setup.remove_at(sq);
                        }
                    }
                }
                setup.chord_consumed = true;
            }
            return;
        }

        if middle_clicked {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        setup.remove_at(sq);
                    }
                }
            }
            return;
        }

        if setup.chord_consumed {
            if !primary_down && !secondary_down {
                setup.chord_consumed = false;
            }
            return;
        }

        if primary_released {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        let color = setup.brush_color;
                        let kind = setup.brush_kind;
                        setup.place_piece(color, kind, sq);
                    }
                }
            }
        } else if secondary_released {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        let color = setup.brush_color.opp();
                        let kind = setup.brush_kind;
                        setup.place_piece(color, kind, sq);
                    }
                }
            }
        }
    }

    fn handle_square_click(
        &mut self,
        clicked_sq: Square,
        selected_moves: &[Move],
        ctx: &egui::Context,
    ) {
        if self.pending_search.is_some()
            || self.state.side_to_move() != self.human_side
            || self.effective_game_result() != GameResult::Ongoing
        {
            return;
        }

        if let Some(&mv) = selected_moves.iter().find(|m| m.to() == clicked_sq) {
            self.play_move(mv, None);
            if self.effective_game_result() == GameResult::Ongoing
                && self.state.side_to_move() != self.human_side
            {
                self.start_engine_search(ctx);
            }
            return;
        }

        let pid = self.state.board_piece(clicked_sq.idx());
        if pid != EMPTY_SQ {
            let color = if pid < 8 { Color::P1 } else { Color::P2 };
            if color == self.human_side {
                if self.selected_sq == Some(clicked_sq) {
                    self.selected_sq = None;
                } else {
                    self.selected_sq = Some(clicked_sq);
                }
                return;
            }
        }

        self.selected_sq = None;
    }
}

impl eframe::App for DsqGuiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if ctx.input(|i| i.viewport().close_requested()) && !self.allow_close {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.show_quit_confirm = true;
        }

        self.handle_global_shortcuts(ctx);
        self.poll_engine();
        self.tick_timed_ironman_clock();

        let browsing = self
            .import_dialog
            .as_ref()
            .and_then(|d| d.browse_rx.as_ref())
            .is_some();
        let active_timed_clock =
            self.is_timed_ironman() && self.effective_game_result() == GameResult::Ongoing;

        if self.pending_search.is_some()
            || self.copied_until.is_some()
            || browsing
            || active_timed_clock
        {
            ctx.request_repaint_after(Duration::from_millis(50));
            if let Some(t) = self.copied_until {
                if Instant::now() >= t {
                    self.copied_until = None;
                }
            }
        }

        let pal = self.theme.palette();
        self.ui_top_toolbar(ctx, &pal);
        self.ui_right_panel(ctx, &pal);
        self.ui_board_panel(ctx, &pal);
        self.ui_rules_help_window(ctx, &pal);
        self.ui_hall_of_fame_window(ctx, &pal);
        self.ui_hof_name_prompt(ctx, &pal);
        self.ui_import_overwrite_confirm(ctx);
        self.ui_gui_import_overwrite_confirm(ctx);
        self.ui_import_dialog(ctx, &pal);
        self.ui_enter_ironman_confirm(ctx, &pal);
        self.ui_new_game_leave_ironman_confirm(ctx);
        self.ui_ironman_setup_confirm(ctx);
        self.ui_quit_confirmation(ctx);
    }

    fn on_exit(&mut self, _gl: Option<&eframe::glow::Context>) {
        self.cancel_search();
        if !self.allow_close {
            self.save_autosave();
        }
    }
}

fn draw_thinking_arrow(
    painter: &egui::Painter,
    from: egui::Pos2,
    to: egui::Pos2,
    tile: f32,
    color: egui::Color32,
) {
    let delta = to - from;
    let len = delta.length();
    if len < 4.0 {
        return;
    }
    let dir = delta / len;
    let perp = egui::vec2(-dir.y, dir.x);
    let start = from + dir * (tile * 0.22);
    let tip = to - dir * (tile * 0.16);
    let head_len = (tile * 0.26).clamp(8.0, 22.0);
    let head_w = head_len * 0.55;
    let shaft_end = tip - dir * (head_len * 0.75);

    let line_col = egui::Color32::from_rgba_unmultiplied(color.r(), color.g(), color.b(), 215);
    painter.line_segment(
        [start, shaft_end],
        egui::Stroke::new((tile * 0.10).clamp(3.0, 7.0), line_col),
    );
    painter.add(egui::Shape::convex_polygon(
        vec![
            tip,
            tip - dir * head_len + perp * head_w,
            tip - dir * head_len - perp * head_w,
        ],
        line_col,
        egui::Stroke::NONE,
    ));
}

fn parse_alg_move(s: &str) -> Option<Move> {
    if s.len() != 4 {
        return None;
    }
    let from = Square::from_alg(&s[0..2])?;
    let to = Square::from_alg(&s[2..4])?;
    Some(Move::new(from, to))
}

fn board_to_visual_rot(rotation: u8, r: usize, c: usize) -> (usize, usize) {
    match rotation % 4 {
        0 => (c, (ROWS - 1) - r),
        1 => (r, c),
        2 => ((COLS - 1) - c, r),
        _ => ((ROWS - 1) - r, (COLS - 1) - c),
    }
}

fn visual_to_board_rot(rotation: u8, vx: usize, vy: usize) -> (usize, usize) {
    match rotation % 4 {
        0 => ((ROWS - 1) - vy, vx),
        1 => (vx, vy),
        2 => (vy, (COLS - 1) - vx),
        _ => ((ROWS - 1) - vx, (COLS - 1) - vy),
    }
}

fn piece_letter(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Rat => "R",
        PieceKind::Cat => "C",
        PieceKind::Dog => "D",
        PieceKind::Wolf => "W",
        PieceKind::Leopard => "P",
        PieceKind::Tiger => "T",
        PieceKind::Lion => "L",
        PieceKind::Elephant => "E",
    }
}

fn piece_name(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Rat => "Rat",
        PieceKind::Cat => "Cat",
        PieceKind::Dog => "Dog",
        PieceKind::Wolf => "Wolf",
        PieceKind::Leopard => "Leopard",
        PieceKind::Tiger => "Tiger",
        PieceKind::Lion => "Lion",
        PieceKind::Elephant => "Elephant",
    }
}

fn piece_unicode_symbol(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Elephant => "\u{265A}", // ♚ (Rank 8)
        PieceKind::Lion => "\u{265B}",     // ♛ (Rank 7)
        PieceKind::Tiger => "\u{265C}",    // ♜ (Rank 6)
        PieceKind::Leopard => "\u{265D}",  // ♝ (Rank 5)
        PieceKind::Wolf => "\u{265E}",     // ♞ (Rank 4)
        PieceKind::Dog => "\u{265F}",      // ♟ (Rank 3)
        PieceKind::Cat => "\u{2666}",      // ♦ (Rank 2)
        PieceKind::Rat => "\u{2605}",      // ★ (Rank 1)
    }
}

fn format_score(score: i32) -> String {
    if score.abs() >= 28_000 {
        let plies = SCORE_WIN - score.abs();
        if score > 0 {
            format!("WIN in {}", plies)
        } else {
            format!("LOSS in {}", plies)
        }
    } else {
        format!("{:+.2}", score as f64 / 100.0)
    }
}

fn install_system_symbol_fonts(ctx: &egui::Context) {
    let symbol_candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansSymbols2-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansSymbols-Regular.ttf",
    ];

    let mut fonts = egui::FontDefinitions::default();
    let mut loaded_any = false;

    for (idx, path) in symbol_candidates.iter().enumerate() {
        if let Ok(bytes) = std::fs::read(path) {
            let name = format!("sys_sym_{}", idx);
            fonts
                .font_data
                .insert(name.clone(), egui::FontData::from_owned(bytes));
            fonts
                .families
                .entry(egui::FontFamily::Proportional)
                .or_default()
                .push(name.clone());
            fonts
                .families
                .entry(egui::FontFamily::Monospace)
                .or_default()
                .push(name);
            loaded_any = true;
        }
    }

    if loaded_any {
        ctx.set_fonts(fonts);
    }
}

pub fn run_gui(
    variant: GameVariant,
    ironman_launch: Option<IronManLaunch>,
    import_req: Option<ImportRequest>,
) -> Result<(), eframe::Error> {
    let title = match (&ironman_launch, &import_req) {
        (Some(IronManLaunch::Depth(d)), _) => format!(
            "Dou Shou Qi ({}) — IRONMAN MODE (Depth {}+)",
            variant.display_name(),
            (*d).max(MIN_IRONMAN_DEPTH)
        ),
        (
            Some(IronManLaunch::Timed {
                base_mins,
                inc_secs,
            }),
            _,
        ) => format!(
            "Dou Shou Qi ({}) — IRONMAN TIMED ({}+{})",
            variant.display_name(),
            base_mins,
            inc_secs
        ),
        (None, Some(req)) => format!(
            "Dou Shou Qi ({}) — Imported: {}",
            variant.display_name(),
            req.filename
        ),
        (None, None) => format!("Dou Shou Qi ({})", variant.display_name()),
    };

    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title(title.clone())
            .with_inner_size([1260.0, 860.0])
            .with_min_inner_size([780.0, 540.0]),
        ..Default::default()
    };

    eframe::run_native(
        &title,
        options,
        Box::new(move |cc| {
            Ok(Box::new(DsqGuiApp::new(
                cc,
                variant,
                ironman_launch,
                import_req,
            )))
        }),
    )
}

#[cfg(test)]
mod tests {
//!     use super::*;

//!     #[test]
//!     fn test_custom_setup_export_and_import_roundtrip() {
//!         let mut piece_sq = [CAPTURED; 16];
//!         piece_sq[PieceKind::Lion.idx()] = Square::from_alg("d4").unwrap().0;
//!         piece_sq[8 + PieceKind::Elephant.idx()] = Square::from_alg("g7").unwrap().0;
//!         let origin = GameOrigin::from_custom(piece_sq, Color::P2, [2, 7]);

//!         let exported = format!(
//!             "{}\n{}  1. e
}

