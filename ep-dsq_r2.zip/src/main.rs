use dsq_engine::core::board_bb::BitboardPos;
use dsq_engine::core::board_ref::RefGame;
use dsq_engine::core::{Color, GameResult, Move, Rng, Square};
use dsq_engine::eval::SCORE_WIN;
use dsq_engine::search::{SearchLimits, Searcher};
use std::env;
use std::io::{self, Write};
use std::time::Instant;

fn parse_move(input: &str) -> Option<Move> {
    let s = input.trim().to_ascii_lowercase();
    if s.len() != 4 {
        return None;
    }
    let from = Square::from_alg(&s[0..2])?;
    let to = Square::from_alg(&s[2..4])?;
    Some(Move::new(from, to))
}

fn format_score(score: i32) -> String {
    if score.abs() >= 28_000 {
        let plies = SCORE_WIN - score.abs();
        if score > 0 {
            format!("WIN in {} plies", plies)
        } else {
            format!("LOSS in {} plies", plies)
        }
    } else {
        format!("{:+.2} ({} cp)", score as f64 / 100.0, score)
    }
}

fn run_play(human_side: Color, think_ms: u64) {
    let mut ref_g = RefGame::new_start();
    let (mut bb, mut hist) = BitboardPos::new_start();
    let mut searcher = Searcher::with_tt_mb(64);
    searcher.verbose = true;

    println!(
        "Starting game! You play {} | Engine thinks {} ms/move.",
        human_side, think_ms
    );
    println!("Enter moves like 'a3a4', or type 'moves' to list legal moves, 'quit' to exit.\n");

    loop {
        println!("{}", ref_g.render());
        match bb.game_result(&hist) {
            GameResult::Win(w) => {
                println!("=== GAME OVER: {} WINS! ===", w);
                break;
            }
            GameResult::Ongoing => {}
        }

        let legal = bb.gen_legal_moves(&hist);

        let chosen = if bb.side_to_move == human_side {
            loop {
                print!("Your move ({}): ", human_side);
                io::stdout().flush().unwrap();
                let mut line = String::new();
                if io::stdin().read_line(&mut line).is_err() {
                    return;
                }
                let trimmed = line.trim();
                if trimmed.eq_ignore_ascii_case("quit") || trimmed.eq_ignore_ascii_case("exit") {
                    return;
                }
                if trimmed.eq_ignore_ascii_case("moves") {
                    let mut ms: Vec<String> =
                        legal.as_slice().iter().map(|m| m.to_string()).collect();
                    ms.sort();
                    println!("Legal moves ({}): {}", ms.len(), ms.join(" "));
                    continue;
                }
                if let Some(mv) = parse_move(trimmed) {
                    if legal.as_slice().contains(&mv) {
                        break mv;
                    } else {
                        println!("Illegal move '{}'. Type 'moves' to see legal moves.", trimmed);
                    }
                } else {
                    println!("Invalid format. Use 4 chars like 'a3a4' (or 'moves' / 'quit').");
                }
            }
        } else {
            println!("Engine ({}) thinking...", bb.side_to_move);
            let res = searcher.search(&bb, &mut hist, SearchLimits::time_ms(think_ms));
            println!(
                "Engine plays: {} | depth {} | score {} | {} nodes in {:.2}s\n",
                res.best_move,
                res.depth,
                format_score(res.score),
                res.nodes,
                res.elapsed.as_secs_f64()
            );
            assert!(
                legal.as_slice().contains(&res.best_move),
                "BUG: Engine returned illegal move {}!",
                res.best_move
            );
            res.best_move
        };

        ref_g = ref_g.make_move(chosen);
        bb = bb.make_move(chosen, &mut hist);
        assert_eq!(ref_g.ep, bb.ep, "BUG: EP desync!");
        assert_eq!(ref_g.winner, bb.winner, "BUG: Winner desync!");
    }
}

fn run_bench(depth: usize) {
    let (bb, mut hist) = BitboardPos::new_start();
    let mut searcher = Searcher::with_tt_mb(64);
    searcher.verbose = true;

    println!("Benchmarking search from starting position to depth {}:", depth);
    let res = searcher.search(&bb, &mut hist, SearchLimits::depth(depth));
    let secs = res.elapsed.as_secs_f64();
    let nps = if secs > 0.0 {
        (res.nodes as f64 / secs) as u64
    } else {
        0
    };
    println!(
        "\nResult: best={} score={} depth={} nodes={} time={:.3}s nps={}",
        res.best_move,
        format_score(res.score),
        res.depth,
        res.nodes,
        secs,
        nps
    );
}

fn run_verify_search(num_games: usize, nodes_per_move: u64) {
    let mut searcher = Searcher::with_tt_mb(16);
    let mut rng = Rng::new(0x9876_5432_10FE_DCBA);
    let mut total_plies = 0u64;
    let mut p1_wins = 0u64;
    let mut p2_wins = 0u64;
    let mut timeouts = 0u64;
    let t0 = Instant::now();

    for g in 0..num_games {
        searcher.clear_tables();
        let mut ref_g = RefGame::new_start();
        let (mut bb, mut hist) = BitboardPos::new_start();

        for _ in 0..4 {
            let moves = bb.gen_legal_moves(&hist);
            if moves.is_empty() {
                break;
            }
            let mv = moves.as_slice()[rng.gen_range(moves.len())];
            ref_g = ref_g.make_move(mv);
            bb = bb.make_move(mv, &mut hist);
        }

        let mut finished = false;
        for _ply in 0..300 {
            let mut rm = ref_g.legal_moves();
            let mut bm = bb.gen_legal_moves(&hist).as_slice().to_vec();
            rm.sort();
            bm.sort();
            assert_eq!(rm, bm, "Move mismatch in verify-search game {}", g);
            assert_eq!(ref_g.ep, bb.ep, "EP mismatch in verify-search game {}", g);

            match bb.game_result(&hist) {
                GameResult::Win(Color::P1) => {
                    assert_eq!(ref_g.game_result(), GameResult::Win(Color::P1));
                    p1_wins += 1;
                    finished = true;
                    break;
                }
                GameResult::Win(Color::P2) => {
                    assert_eq!(ref_g.game_result(), GameResult::Win(Color::P2));
                    p2_wins += 1;
                    finished = true;
                    break;
                }
                GameResult::Ongoing => {}
            }

            let res = searcher.search(&bb, &mut hist, SearchLimits::nodes(nodes_per_move));
            assert!(
                bm.contains(&res.best_move),
                "ILLEGAL SEARCH MOVE {} in game {}!\n{}",
                res.best_move,
                g,
                ref_g.render()
            );

            ref_g = ref_g.make_move(res.best_move);
            bb = bb.make_move(res.best_move, &mut hist);
            total_plies += 1;
        }

        if !finished {
            timeouts += 1;
        }
    }

    println!(
        "VERIFIED {} self-play games ({} plies, P1={}, P2={}, max-ply-cap={}) in {:.2}s — ZERO bugs!",
        num_games,
        total_plies,
        p1_wins,
        p2_wins,
        timeouts,
        t0.elapsed().as_secs_f64()
    );
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let cmd = args.get(1).map(|s| s.as_str()).unwrap_or("gui");

    match cmd {
        "gui" => {
            if let Err(e) = dsq_engine::gui::run_gui() {
                eprintln!("GUI error: {}", e);
                std::process::exit(1);
            }
        }
        "show" => {
            let g = RefGame::new_start();
            println!("{}", g.render());
            println!("Initial legal moves: {}", g.legal_moves().len());
        }
        "perft" => {
            let max_depth: u32 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(5);
            let (bb, mut hist) = BitboardPos::new_start();
            println!(
                "Running Bitboard perft from starting position up to depth {}:",
                max_depth
            );
            for d in 1..=max_depth {
                let t0 = Instant::now();
                let nodes = bb.perft(&mut hist, d);
                let dt = t0.elapsed();
                let secs = dt.as_secs_f64();
                let nps = if secs > 0.0 {
                    (nodes as f64 / secs) as u64
                } else {
                    0
                };
                println!(
                    "  depth {}: {:>12} nodes | {:>8.3} s | {:>12} nodes/s",
                    d, nodes, secs, nps
                );
            }
        }
        "fuzz" => {
            let games: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(500);
            let mut rng = Rng::new(0x2025_0101_ABCD_EF01);
            let mut total_plies: u64 = 0;
            let mut repetitions_triggered: u64 = 0;
            let mut wins_p1: u64 = 0;
            let mut wins_p2: u64 = 0;
            let t0 = Instant::now();

            for g_idx in 0..games {
                let mut ref_g = RefGame::new_start();
                let (mut bb, mut hist) = BitboardPos::new_start();

                for _ply in 0..400 {
                    let mut rm = ref_g.legal_moves();
                    let mut bm = bb.gen_legal_moves(&hist).as_slice().to_vec();
                    rm.sort();
                    bm.sort();

                    if rm != bm || ref_g.ep != bb.ep || ref_g.winner != bb.winner {
                        eprintln!("MISMATCH on game {}!\n{}", g_idx, ref_g.render());
                        std::process::exit(1);
                    }

                    if bm.is_empty() {
                        match bb.game_result(&hist) {
                            GameResult::Win(Color::P1) => wins_p1 += 1,
                            GameResult::Win(Color::P2) => wins_p2 += 1,
                            _ => unreachable!(),
                        }
                        break;
                    }

                    let ep_before = bb.ep[bb.side_to_move.idx()];
                    let chosen = bm[rng.gen_range(bm.len())];
                    let mover = bb.side_to_move.idx();

                    ref_g = ref_g.make_move(chosen);
                    bb = bb.make_move(chosen, &mut hist);
                    if bb.ep[mover] < ep_before {
                        repetitions_triggered += 1;
                    }
                    total_plies += 1;
                }
            }

            println!(
                "PASSED {} random games ({} plies, {} EP-paid repetitions, P1 wins={}, P2 wins={}) in {:.2}s — ZERO discrepancies!",
                games,
                total_plies,
                repetitions_triggered,
                wins_p1,
                wins_p2,
                t0.elapsed().as_secs_f64()
            );
        }
        "bench" => {
            let depth: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(9);
            run_bench(depth);
        }
        "verify-search" => {
            let games: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(40);
            let nodes: u64 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(8_000);
            run_verify_search(games, nodes);
        }
        "play" => {
            let side = match args.get(2).map(|s| s.to_ascii_lowercase()).as_deref() {
                Some("p2") | Some("2") => Color::P2,
                _ => Color::P1,
            };
            let ms: u64 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(1500);
            run_play(side, ms);
        }
        _ => {
            println!("Dou Shou Qi Engine (EP + SuperKo)");
            println!("Commands:");
            println!("  cargo run --release              (launches the GUI)");
            println!("  cargo run --release -- gui");
            println!("  cargo run --release -- show");
            println!("  cargo run --release -- perft [depth]");
            println!("  cargo run --release -- fuzz [num_games]");
            println!("  cargo run --release -- bench [depth]");
            println!("  cargo run --release -- verify-search [games] [nodes_per_move]");
            println!("  cargo run --release -- play [p1|p2] [think_ms]");
        }
    }
}

