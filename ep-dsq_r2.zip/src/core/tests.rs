use crate::core::board_bb::{BitboardPos, History};
use crate::core::board_ref::RefGame;
use crate::core::{Color, GameResult, Move, PieceKind, Rng, Square, MAX_EP};

fn sq(s: &str) -> Square {
    Square::from_alg(s).unwrap()
}

fn mv(a: &str, b: &str) -> Move {
    Move::new(sq(a), sq(b))
}

fn sorted_moves(mut v: Vec<Move>) -> Vec<Move> {
    v.sort();
    v
}

/// Asserts that the Reference Engine and Bitboard Engine agree 100% on state & legal moves.
fn assert_engines_agree(ref_g: &RefGame, bb: &BitboardPos, hist: &History) {
    bb.assert_valid();
    assert_eq!(ref_g.side_to_move, bb.side_to_move, "side_to_move mismatch");
    assert_eq!(ref_g.ep, bb.ep, "EP mismatch");
    assert_eq!(ref_g.winner, bb.winner, "winner mismatch");
    assert_eq!(ref_g.history.len(), hist.len(), "history len mismatch");

    let ref_moves = sorted_moves(ref_g.legal_moves());
    let bb_moves = sorted_moves(bb.gen_legal_moves(hist).as_slice().to_vec());
    assert_eq!(
        ref_moves,
        bb_moves,
        "Legal move mismatch!\n{}",
        ref_g.render()
    );
    assert_eq!(ref_g.game_result(), bb.game_result(hist));
}

#[test]
fn test_start_position_and_initial_moves() {
    let ref_g = RefGame::new_start();
    let (bb, hist) = BitboardPos::new_start();
    assert_engines_agree(&ref_g, &bb, &hist);

    // P1 pieces at start:
    // T(a1): 2, L(g1): 2, C(b2): 4, D(f2): 4, E(a3): 3, W(c3): 3 (up is water),
    // P(e3): 3 (up is water), R(g3): 3 => total 24 legal moves!
    assert_eq!(ref_g.legal_moves().len(), 24);
}

#[test]
fn test_medium_capture_rules() {
    // P1 Rat in water at b4, P2 Elephant on land at a4, P2 Rat on land at b3, P2 Rat in water at c4
    let pieces = [
        (Color::P1, PieceKind::Rat, sq("b4")),
        (Color::P2, PieceKind::Elephant, sq("a4")),
        (Color::P2, PieceKind::Rat, sq("c4")),
    ];
    let ref_g = RefGame::from_custom(&pieces, Color::P1, [4, 5]);
    let (bb, hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
    assert_engines_agree(&ref_g, &bb, &hist);

    let moves = bb.gen_legal_moves(&hist);
    let m = moves.as_slice();
    // Rat in water (b4) CANNOT capture Elephant on land (a4), CAN capture Rat in water (c4),
    // CAN move to empty land (b3) and empty water (b5).
    assert!(!m.contains(&mv("b4", "a4")), "Water rat captured land elephant!");
    assert!(m.contains(&mv("b4", "c4")), "Water rat failed to capture water rat!");
    assert!(m.contains(&mv("b4", "b3")), "Water rat failed to step onto empty land!");
    assert!(m.contains(&mv("b4", "b5")), "Water rat failed to step in water!");

    // Land Rat (a4) vs Water Rat (b4) and Land Elephant (a5)
    let pieces2 = [
        (Color::P1, PieceKind::Rat, sq("a4")),
        (Color::P2, PieceKind::Rat, sq("b4")),
        (Color::P2, PieceKind::Elephant, sq("a5")),
    ];
    let ref_g2 = RefGame::from_custom(&pieces2, Color::P1, [4, 5]);
    let (bb2, hist2) = BitboardPos::from_custom(&pieces2, Color::P1, [4, 5]);
    assert_engines_agree(&ref_g2, &bb2, &hist2);

    let m2 = bb2.gen_legal_moves(&hist2);
    assert!(!m2.as_slice().contains(&mv("a4", "b4")), "Land rat captured water rat!");
    assert!(m2.as_slice().contains(&mv("a4", "a5")), "Land rat failed to capture land elephant!");
}

#[test]
fn test_river_jumps_and_blocking() {
    // P1 Lion on d4 (center bank between both rivers), P2 Rat in left river at b4,
    // P1 Tiger on f3 (below right river), P1 Rat in right river at e5 (does NOT block col f!)
    let pieces = [
        (Color::P1, PieceKind::Lion, sq("d4")),
        (Color::P1, PieceKind::Tiger, sq("f3")),
        (Color::P1, PieceKind::Rat, sq("e5")),
        (Color::P2, PieceKind::Rat, sq("b4")),
        (Color::P2, PieceKind::Elephant, sq("g4")), // Lion can't capture Elephant across river
        (Color::P2, PieceKind::Wolf, sq("f7")),     // Tiger CAN capture Wolf across river
    ];
    let ref_g = RefGame::from_custom(&pieces, Color::P1, [4, 5]);
    let (bb, hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
    assert_engines_agree(&ref_g, &bb, &hist);

    let m = bb.gen_legal_moves(&hist);
    let s = m.as_slice();
    // Lion d4 -> a4 blocked by P2 rat on b4
    assert!(!s.contains(&mv("d4", "a4")));
    // Lion d4 -> g4 not blocked by rat, but Elephant (8) > Lion (7)
    assert!(!s.contains(&mv("d4", "g4")));
    // Tiger f3 -> f7 NOT blocked by rat on e5 (different column!) and Wolf (4) <= Tiger (6)
    assert!(s.contains(&mv("f3", "f7")));

    // Now put P1's own Rat on f5 -> blocks Tiger's jump!
    let pieces2 = [
        (Color::P1, PieceKind::Tiger, sq("f3")),
        (Color::P1, PieceKind::Rat, sq("f5")),
        (Color::P2, PieceKind::Wolf, sq("f7")),
    ];
    let ref_g2 = RefGame::from_custom(&pieces2, Color::P1, [4, 5]);
    let (bb2, hist2) = BitboardPos::from_custom(&pieces2, Color::P1, [4, 5]);
    assert_engines_agree(&ref_g2, &bb2, &hist2);
    assert!(!bb2.gen_legal_moves(&hist2).as_slice().contains(&mv("f3", "f7")));
}

#[test]
fn test_traps_and_dens() {
    // P2 Rat in P1 trap (d2) -> P1 Elephant on d3 CAN capture it!
    // P1 Cat in P1 own trap (c1) -> NOT weakened, so P2 Rat on c2 CANNOT capture Cat!
    let pieces = [
        (Color::P1, PieceKind::Elephant, sq("d3")),
        (Color::P1, PieceKind::Cat, sq("c1")),
        (Color::P2, PieceKind::Rat, sq("d2")),
        (Color::P2, PieceKind::Dog, sq("b1")),
    ];
    let ref_g = RefGame::from_custom(&pieces, Color::P1, [4, 5]);
    let (bb, hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
    assert_engines_agree(&ref_g, &bb, &hist);

    let m = bb.gen_legal_moves(&hist);
    assert!(m.as_slice().contains(&mv("d3", "d2")), "Elephant must capture trapped Rat");
    assert!(!m.as_slice().contains(&mv("c1", "d1")), "P1 cannot enter own den d1");

    // Trapped P2 Rat on d2: cannot capture P1 Elephant on d3 (strength 0), CAN enter d1 to win!
    let ref_g2 = RefGame::from_custom(&pieces, Color::P2, [4, 5]);
    let (bb2, hist2) = BitboardPos::from_custom(&pieces, Color::P2, [4, 5]);
    assert_engines_agree(&ref_g2, &bb2, &hist2);
    let m2 = bb2.gen_legal_moves(&hist2);
    assert!(!m2.as_slice().contains(&mv("d2", "d3")), "Trapped Rat has strength 0");
    assert!(m2.as_slice().contains(&mv("d2", "d1")), "Trapped piece can still win on enemy den");

    let mut hist2_mut = hist2;
    let after_win = bb2.make_move(mv("d2", "d1"), &mut hist2_mut);
    let ref_after_win = ref_g2.make_move(mv("d2", "d1"));
    assert_engines_agree(&ref_after_win, &after_win, &hist2_mut);
    assert_eq!(after_win.game_result(&hist2_mut), GameResult::Win(Color::P2));
}

#[test]
fn test_full_capture_matrix() {
    for &att in &PieceKind::ALL {
        for &def in &PieceKind::ALL {
            let pieces = [
                (Color::P1, att, sq("d3")),
                (Color::P2, def, sq("d4")),
            ];
            let ref_g = RefGame::from_custom(&pieces, Color::P1, [4, 5]);
            let (bb, hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
            assert_engines_agree(&ref_g, &bb, &hist);

            let can = bb.gen_legal_moves(&hist).as_slice().contains(&mv("d3", "d4"));
            let expected = match (att, def) {
                (PieceKind::Rat, PieceKind::Elephant) => true,
                (PieceKind::Elephant, PieceKind::Rat) => false,
                (a, d) => a.rank() >= d.rank(),
            };
            assert_eq!(can, expected, "Capture mismatch {:?} vs {:?}", att, def);
        }
    }
}

#[test]
fn test_superko_ep_cost_and_zero_ep_loss() {
    // P1 Cat trapped in corner a1, blocked by P1 Elephant on b1? No, simpler:
    // P1 Cat on a1, P1 Elephant on b1, P2 Lion on a3, P2 Elephant on b2 -> Cat only has a2!
    // Even simpler: P1 Cat on a1 (can go a2 or b1), put P1 Wolf on b1 -> Cat can only go a2,
    // wait: Wolf can also move. Use single P1 piece on a1 vs P2 Elephant on b1 (can't capture)
    // and P2 Lion on a3 (not adjacent).
    // P1 Rat on a1, P2 Dog on b1 (Rat cannot capture Dog!), P2 Cat on b2.
    // Rat's ONLY move from a1 is a1->a2.
    // Then P2 moves Cat b2->b3, Rat moves a2->a1 (REPEATS ply 0? Wait: P2 moved Cat so board changed!).
    // Instead, test direct repetition back to ply 0 AND EP=0 lockout:
    let pieces = [
        (Color::P1, PieceKind::Cat, sq("a1")),
        (Color::P2, PieceKind::Cat, sq("g9")),
    ];
    let mut ref_g = RefGame::from_custom(&pieces, Color::P1, [1, 1]);
    let (mut bb, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [1, 1]);

    // Ply 1: P1 a1->a2 (no repeat, EP stays [1,1])
    ref_g = ref_g.make_move(mv("a1", "a2"));
    bb = bb.make_move(mv("a1", "a2"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep, [1, 1]);

    // Ply 2: P2 g9->g8 (no repeat, EP stays [1,1])
    ref_g = ref_g.make_move(mv("g9", "g8"));
    bb = bb.make_move(mv("g9", "g8"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep, [1, 1]);

    // Ply 3: P1 a2->a1 (board is a1, g8: not seen yet, EP stays [1,1])
    ref_g = ref_g.make_move(mv("a2", "a1"));
    bb = bb.make_move(mv("a2", "a1"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep, [1, 1]);

    // Ply 4: P2 g8->g9 -> REPEATS PLY 0 (a1, g9), even though ply 0 had P1 to move and ply 4 results in P1 to move!
    // Costs P2 1 EP -> EP becomes [1, 0]!
    ref_g = ref_g.make_move(mv("g8", "g9"));
    bb = bb.make_move(mv("g8", "g9"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep, [1, 0]);

    // Ply 5: P1 a1->a2 -> REPEATS PLY 1! Costs P1 1 EP -> EP becomes [0, 0]!
    ref_g = ref_g.make_move(mv("a1", "a2"));
    bb = bb.make_move(mv("a1", "a2"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep, [0, 0]);

    // Now P2 has 0 EP: g9->g8 would repeat ply 2 (a2, g8), so g9->g8 MUST BE ILLEGAL!
    // Whereas g9->f9 is legal!
    let p2_moves = bb.gen_legal_moves(&hist);
    assert!(!p2_moves.as_slice().contains(&mv("g9", "g8")), "0 EP allowed repetition!");
    assert!(p2_moves.as_slice().contains(&mv("g9", "f9")), "Non-repeating move missing!");
}

#[test]
fn test_superko_ignores_side_to_move() {
    // Triangulation: P1 moves a1->a2->b2->a1 while P2 shuffles g9->g8->g9
    // Ply 0 (P1): a1, g9
    // Ply 1 (P2): a2, g9  (P1: a1->a2)
    // Ply 2 (P1): a2, g8  (P2: g9->g8)
    // Ply 3 (P2): b2, g8  (P1: a2->b2)
    // Ply 4 (P1): b2, g9  (P2: g8->g9)
    // Ply 5 (P2): a2, g9  (P1: b2->a2) -> SAME board as Ply 1 (where P2 was to move, and now P2 is to move!)
    // Better: check when ply N has OPPOSITE side to move!
    // Ply 0 (P1 to move): P1 at a1, P2 at g9
    // Ply 1 (P2 to move): P1 at a2, P2 at g9
    // Ply 2 (P1 to move): P1 at a2, P2 at f9
    // Ply 3 (P2 to move): P1 at b2, P2 at f9
    // Ply 4 (P1 to move): P1 at b2, P2 at g9
    // Ply 5 (P2 to move): P1 at a1, P2 at g9  <-- Board == Ply 0, EXCEPT Ply 0 had P1 to move and Ply 5 has P2 to move!
    let pieces = [
        (Color::P1, PieceKind::Cat, sq("a1")),
        (Color::P2, PieceKind::Cat, sq("g9")),
    ];
    let mut ref_g = RefGame::from_custom(&pieces, Color::P1, [2, 2]);
    let (mut bb, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [2, 2]);

    let seq = [
        mv("a1", "a2"),
        mv("g9", "f9"),
        mv("a2", "b2"),
        mv("f9", "g9"),
    ];
    for m in seq {
        ref_g = ref_g.make_move(m);
        bb = bb.make_move(m, &mut hist);
        assert_engines_agree(&ref_g, &bb, &hist);
    }
    assert_eq!(bb.ep, [2, 2]);

    // Now P1 plays b2->a2 (repeats ply 1) vs b2->a1? Not adjacent, so use b1:
    // Let's do a 3-step triangle a1 -> a2 -> b2 -> b1 -> a1!
    let mut ref_g2 = RefGame::from_custom(&pieces, Color::P1, [2, 2]);
    let (mut bb2, mut hist2) = BitboardPos::from_custom(&pieces, Color::P1, [2, 2]);
    let seq2 = [
        mv("a1", "a2"), // ply 1 (P2): a2, g9
        mv("g9", "f9"), // ply 2 (P1): a2, f9
        mv("a2", "b2"), // ply 3 (P2): b2, f9
        mv("f9", "f8"), // ply 4 (P1): b2, f8
        mv("b2", "b1"), // ply 5 (P2): b1, f8
        mv("f8", "g8"), // ply 6 (P1): b1, g8
        mv("b1", "a1"), // ply 7 (P2): a1, g8
        mv("g8", "g9"), // ply 8 (P1): a1, g9 (same side)
    ];
    for m in seq2 {
        ref_g2 = ref_g2.make_move(m);
        bb2 = bb2.make_move(m, &mut hist2);
        assert_engines_agree(&ref_g2, &bb2, &hist2);
    }
    assert_eq!(bb2.ep, [2, 1], "Ply 8 repeated ply 0, costing P2 1 EP");

    // True opposite-side repetition via P1 odd-length loop? On a bipartite grid, any single piece
    // returning to its own square takes an EVEN number of moves; to change parity of board layout,
    // two pieces can swap? No, pieces are distinct! Wait: P1 takes 2 moves and P2 takes 3 moves?
    // Wait: players strictly alternate turns! So if P1 makes K moves and P2 makes K moves (even ply),
    // total moves is even. If P1 makes K+1 moves and P2 makes K moves (odd ply), can a bipartite board
    // repeat? No—each piece moves 1 square on a bipartite checkerboard (except horizontal river jumps
    // of distance 3 = odd, and vertical river jumps of distance 4 = EVEN!).
    // AHA! A vertical river jump changes square parity!
    // Let's test opposite-side-to-move repetition using a Lion's vertical jump!
    let pieces3 = [
        (Color::P1, PieceKind::Lion, sq("b3")), // can jump vertically b3->b7 (dist 4 = even!)
        (Color::P2, PieceKind::Cat, sq("g9")),
    ];
    let mut ref_g3 = RefGame::from_custom(&pieces3, Color::P1, [2, 2]);
    let (mut bb3, mut hist3) = BitboardPos::from_custom(&pieces3, Color::P1, [2, 2]);
    // P1 goes b3 -> b7 (1 move), then walks back around river: b7->a7->a6->a5->a4->a3->b3 (6 moves) = 7 moves (ODD!)
    // Meanwhile P2 does 6 moves (g9<->f9 x3) so P2 is back at g9 on ply 13!
    // At ply 13 (P2 to move!), board is (Lion b3, Cat g9) == ply 0 (P1 to move!)!
    let seq3 = [
        mv("b3", "b7"), // 1: P1 invades row 6!
        mv("g9", "f9"), // 2: P1 gains +1 EP at start of ply 3 (P1 EP: 2->3)
        mv("b7", "a7"), // 3
        mv("f9", "g9"), // 4: P1 gains +1 EP (3->4)
        mv("a7", "a6"), // 5
        mv("g9", "f9"), // 6: P1 gains +1 EP (4->5)
        mv("a6", "a5"), // 7 (now on neutral row 4, no more EP gain)
        mv("f9", "g9"), // 8
        mv("a5", "a4"), // 9
        mv("g9", "f9"), // 10
        mv("a4", "a3"), // 11
        mv("f9", "g9"), // 12
    ];
    for m in seq3 {
        ref_g3 = ref_g3.make_move(m);
        bb3 = bb3.make_move(m, &mut hist3);
        assert_engines_agree(&ref_g3, &bb3, &hist3);
    }
    let ep_before = bb3.ep[0];
    // Ply 13: P1 moves a3->b3 -> EXACT SAME board as ply 0, with OPPOSITE side to move!
    ref_g3 = ref_g3.make_move(mv("a3", "b3"));
    bb3 = bb3.make_move(mv("a3", "b3"), &mut hist3);
    assert_engines_agree(&ref_g3, &bb3, &hist3);
    assert_eq!(
        bb3.ep[0],
        ep_before - 1,
        "Opposite-side-to-move SuperKo repetition must cost 1 EP!"
    );
}

#[test]
fn test_ep_gain_rules_and_cap() {
    // 1. Neutral row 4 (rank 5) gives NO EP; water on row 5 (rank 6) gives NO EP;
    //    land on row 5 (rank 6) DOES give EP; cap at 10; 0 EP + gain allows immediate repeat!
    let pieces = [
        (Color::P1, PieceKind::Rat, sq("b6")), // Water on row 5 -> NO EP gain!
        (Color::P2, PieceKind::Cat, sq("g9")),
    ];
    let mut ref_g = RefGame::from_custom(&pieces, Color::P2, [0, 5]);
    let (mut bb, mut hist) = BitboardPos::from_custom(&pieces, Color::P2, [0, 5]);

    // P2 moves -> start of P1's turn: P1 Rat is in WATER on b6 -> must NOT gain EP!
    ref_g = ref_g.make_move(mv("g9", "f9"));
    bb = bb.make_move(mv("g9", "f9"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep[0], 0, "Rat in water must not grant EP!");

    // Now P1 Rat steps onto land a6 (row 5 land!) -> P2 moves back -> P1 starts turn with +1 EP!
    ref_g = ref_g.make_move(mv("b6", "a6"));
    bb = bb.make_move(mv("b6", "a6"), &mut hist);
    ref_g = ref_g.make_move(mv("f9", "g9"));
    bb = bb.make_move(mv("f9", "g9"), &mut hist);
    assert_engines_agree(&ref_g, &bb, &hist);
    assert_eq!(bb.ep[0], 1, "Land tile on row 5 must grant +1 EP!");

    // Test EP cap at 10
    let pieces_cap = [
        (Color::P1, PieceKind::Cat, sq("a7")), // invasion land
        (Color::P2, PieceKind::Cat, sq("g9")),
    ];
    let ref_c = RefGame::from_custom(&pieces_cap, Color::P2, [MAX_EP, 5]);
    let (bb_c, mut hist_c) = BitboardPos::from_custom(&pieces_cap, Color::P2, [MAX_EP, 5]);
    let ref_c2 = ref_c.make_move(mv("g9", "f9"));
    let bb_c2 = bb_c.make_move(mv("g9", "f9"), &mut hist_c);
    assert_engines_agree(&ref_c2, &bb_c2, &hist_c);
    assert_eq!(bb_c2.ep[0], MAX_EP, "EP must cap at 10");
}

#[test]
fn test_perft_agrees_with_reference() {
    let ref_g = RefGame::new_start();
    let (bb, mut hist) = BitboardPos::new_start();

    for depth in 1..=4 {
        let r_nodes = ref_g.perft(depth);
        let b_nodes = bb.perft(&mut hist, depth);
        assert_eq!(r_nodes, b_nodes, "Perft mismatch at depth {}", depth);
        assert_eq!(hist.len(), 1, "History stack leaked during perft!");
    }
}

#[test]
fn test_perft_tricky_ep_zero_and_water_position() {
    // Low EP, water rats, jumpable rivers, traps nearby
    let pieces = [
        (Color::P1, PieceKind::Lion, sq("d4")),
        (Color::P1, PieceKind::Rat, sq("b5")),
        (Color::P1, PieceKind::Elephant, sq("d3")),
        (Color::P2, PieceKind::Tiger, sq("f3")),
        (Color::P2, PieceKind::Rat, sq("c4")),
        (Color::P2, PieceKind::Wolf, sq("d2")), // in P1 trap!
    ];
    let ref_g = RefGame::from_custom(&pieces, Color::P1, [0, 0]);
    let (bb, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [0, 0]);

    for depth in 1..=4 {
        let r_nodes = ref_g.perft(depth);
        let b_nodes = bb.perft(&mut hist, depth);
        assert_eq!(r_nodes, b_nodes, "Tricky perft mismatch at depth {}", depth);
        assert_eq!(hist.len(), 1);
    }
}

#[test]
fn test_differential_fuzz_full_games() {
    let mut rng = Rng::new(0x1234_5678_9ABC_DEF0);

    for _game in 0..80 {
        let mut ref_g = RefGame::new_start();
        let (mut bb, mut hist) = BitboardPos::new_start();

        for _ply in 0..200 {
            assert_engines_agree(&ref_g, &bb, &hist);
            let moves = bb.gen_legal_moves(&hist);
            if moves.is_empty() {
                break;
            }
            let chosen = moves.as_slice()[rng.gen_range(moves.len())];
            ref_g = ref_g.make_move(chosen);
            bb = bb.make_move(chosen, &mut hist);
        }
    }
}

#[test]
fn test_differential_fuzz_endgame_superko_stress() {
    let mut rng = Rng::new(0xCAFE_BABE_DEAD_BEEF);

    // Generate 200 random sparse endgames with low EP (0..=2) to heavily trigger
    // SuperKo blocks, EP=0 losses, water captures, jumps, and trap captures!
    for _case in 0..200 {
        let mut used = [false; 63];
        let mut pieces = Vec::new();
        let n_p1 = 1 + rng.gen_range(3);
        let n_p2 = 1 + rng.gen_range(3);

        for (color, count) in [(Color::P1, n_p1), (Color::P2, n_p2)] {
            let mut used_kind = [false; 8];
            let mut placed = 0;
            while placed < count {
                let k_idx = rng.gen_range(8);
                if used_kind[k_idx] {
                    continue;
                }
                let kind = PieceKind::from_idx(k_idx);
                let s_idx = rng.gen_range(63);
                let s = Square(s_idx as u8);
                if used[s_idx] {
                    continue;
                }
                if !kind.can_enter_water() && RefGame::is_water(s.row(), s.col()) {
                    continue;
                }
                // Don't start inside either den
                if RefGame::is_den(Color::P1, s.row(), s.col())
                    || RefGame::is_den(Color::P2, s.row(), s.col())
                {
                    continue;
                }
                used[s_idx] = true;
                used_kind[k_idx] = true;
                pieces.push((color, kind, s));
                placed += 1;
            }
        }

        let ep = [rng.gen_range(3) as u8, rng.gen_range(3) as u8];
        let stm = if rng.gen_range(2) == 0 {
            Color::P1
        } else {
            Color::P2
        };

        let mut ref_g = RefGame::from_custom(&pieces, stm, ep);
        let (mut bb, mut hist) = BitboardPos::from_custom(&pieces, stm, ep);

        for _ply in 0..150 {
            assert_engines_agree(&ref_g, &bb, &hist);
            let moves = bb.gen_legal_moves(&hist);
            if moves.is_empty() {
                break;
            }
            let chosen = moves.as_slice()[rng.gen_range(moves.len())];
            ref_g = ref_g.make_move(chosen);
            bb = bb.make_move(chosen, &mut hist);
        }
    }
}

