//! Dead-simple 9x7 array Reference Engine.
//!
//! Written as a literal translation of the formal specification with NO bitboard
//! tricks and NO capture-based history pruning. Serves as the ground-truth oracle
//! for differential testing against the fast Bitboard Engine.

use crate::core::{
    Color, GameResult, Move, PieceKind, Square, COLS, INITIAL_PIECES, MAX_EP, ROWS, START_EP,
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RefPiece {
    pub color: Color,
    pub kind: PieceKind,
}

pub type RefGrid = [[Option<RefPiece>; COLS]; ROWS];

#[derive(Clone, Debug)]
pub struct RefGame {
    pub grid: RefGrid,
    pub side_to_move: Color,
    pub ep: [u8; 2],
    pub winner: Option<Color>,
    /// Full game history of board layouts from ply 0 (no pruning!).
    pub history: Vec<RefGrid>,
}

impl RefGame {
    pub fn new_start() -> Self {
        Self::from_custom(&INITIAL_PIECES, Color::P1, START_EP)
    }

    pub fn from_custom(
        pieces: &[(Color, PieceKind, Square)],
        side_to_move: Color,
        ep: [u8; 2],
    ) -> Self {
        let mut grid: RefGrid = [[None; COLS]; ROWS];
        for &(color, kind, sq) in pieces {
            assert!(
                grid[sq.row()][sq.col()].is_none(),
                "Duplicate piece on square {}",
                sq
            );
            grid[sq.row()][sq.col()] = Some(RefPiece { color, kind });
        }
        assert!(ep[0] <= MAX_EP && ep[1] <= MAX_EP);
        RefGame {
            grid,
            side_to_move,
            ep,
            winner: None,
            history: vec![grid],
        }
    }

    pub fn is_water(r: usize, c: usize) -> bool {
        (3..=5).contains(&r) && (c == 1 || c == 2 || c == 4 || c == 5)
    }

    pub fn is_den(color: Color, r: usize, c: usize) -> bool {
        match color {
            Color::P1 => r == 0 && c == 3,
            Color::P2 => r == 8 && c == 3,
        }
    }

    pub fn is_trap(color: Color, r: usize, c: usize) -> bool {
        match color {
            Color::P1 => (r == 0 && c == 2) || (r == 0 && c == 4) || (r == 1 && c == 3),
            Color::P2 => (r == 8 && c == 2) || (r == 8 && c == 4) || (r == 7 && c == 3),
        }
    }

    pub fn is_invasion_land(color: Color, r: usize, c: usize) -> bool {
        if Self::is_water(r, c) {
            return false;
        }
        match color {
            Color::P1 => r >= 5, // rows 5, 6, 7, 8
            Color::P2 => r <= 3, // rows 0, 1, 2, 3
        }
    }

    fn can_capture(&self, att: RefPiece, fr: usize, fc: usize, def: RefPiece, tr: usize, tc: usize) -> bool {
        debug_assert!(att.color != def.color);

        // Rule A1: same medium only (land-land or water-water)
        if Self::is_water(fr, fc) != Self::is_water(tr, tc) {
            return false;
        }

        // Rule A3: enemy trap weakens opposing piece down to strength 0 (below rat)
        let att_trapped = Self::is_trap(att.color.opp(), fr, fc);
        let def_trapped = Self::is_trap(def.color.opp(), tr, tc);

        if att_trapped {
            return false;
        }
        if def_trapped {
            return true;
        }

        // Standard hierarchy + Rat/Elephant exception
        match (att.kind, def.kind) {
            (PieceKind::Rat, PieceKind::Elephant) => true,
            (PieceKind::Elephant, PieceKind::Rat) => false,
            (a, d) => a.rank() >= d.rank(),
        }
    }

    fn has_repeated(&self, candidate_grid: &RefGrid) -> bool {
        self.history.iter().any(|past| past == candidate_grid)
    }

    fn count_pieces(&self, color: Color) -> usize {
        let mut n = 0;
        for r in 0..ROWS {
            for c in 0..COLS {
                if let Some(p) = self.grid[r][c] {
                    if p.color == color {
                        n += 1;
                    }
                }
            }
        }
        n
    }

    fn has_invasion_piece(&self, color: Color) -> bool {
        for r in 0..ROWS {
            for c in 0..COLS {
                if Self::is_invasion_land(color, r, c) {
                    if let Some(p) = self.grid[r][c] {
                        if p.color == color {
                            return true;
                        }
                    }
                }
            }
        }
        false
    }

    pub fn legal_moves(&self) -> Vec<Move> {
        if self.winner.is_some() {
            return Vec::new();
        }

        let stm = self.side_to_move;
        let opp = stm.opp();
        let mut moves = Vec::with_capacity(32);
        let dirs: [(isize, isize); 4] = [(-1, 0), (1, 0), (0, -1), (0, 1)];

        for r in 0..ROWS {
            for c in 0..COLS {
                let Some(piece) = self.grid[r][c] else {
                    continue;
                };
                if piece.color != stm {
                    continue;
                }

                for &(dr, dc) in &dirs {
                    let nr = r as isize + dr;
                    let nc = c as isize + dc;
                    if nr < 0 || nr >= ROWS as isize || nc < 0 || nc >= COLS as isize {
                        continue;
                    }
                    let mut tr = nr as usize;
                    let mut tc = nc as usize;

                    // Handle water entry / Lion & Tiger river jumping
                    if Self::is_water(tr, tc) {
                        if piece.kind.can_enter_water() {
                            // Rat steps directly into water
                        } else if piece.kind.can_jump() {
                            // Jump across contiguous water squares if no Rat blocks
                            let mut blocked = false;
                            while Self::is_water(tr, tc) {
                                if let Some(wp) = self.grid[tr][tc] {
                                    debug_assert_eq!(wp.kind, PieceKind::Rat);
                                    blocked = true;
                                    break;
                                }
                                tr = (tr as isize + dr) as usize;
                                tc = (tc as isize + dc) as usize;
                            }
                            if blocked {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    }

                    // Cannot enter own den
                    if Self::is_den(stm, tr, tc) {
                        continue;
                    }

                    // Check destination occupancy
                    if let Some(target) = self.grid[tr][tc] {
                        if target.color == stm {
                            continue;
                        }
                        if !self.can_capture(piece, r, c, target, tr, tc) {
                            continue;
                        }
                    }

                    // Check SuperKo legality if EP == 0
                    let is_den_win = Self::is_den(opp, tr, tc);
                    let is_capture = self.grid[tr][tc].is_some();
                    if self.ep[stm.idx()] == 0 && !is_den_win && !is_capture {
                        let mut next_grid = self.grid;
                        next_grid[r][c] = None;
                        next_grid[tr][tc] = Some(piece);
                        if self.has_repeated(&next_grid) {
                            continue;
                        }
                    }

                    moves.push(Move::new(Square::from_rc(r, c), Square::from_rc(tr, tc)));
                }
            }
        }

        moves
    }

    pub fn make_move(&self, mv: Move) -> RefGame {
        debug_assert!(self.winner.is_none());
        let stm = self.side_to_move;
        let opp = stm.opp();
        let from = mv.from();
        let to = mv.to();

        let piece = self.grid[from.row()][from.col()].expect("No piece on from square");
        debug_assert_eq!(piece.color, stm);

        let mut next = self.clone();
        next.grid[from.row()][from.col()] = None;
        next.grid[to.row()][to.col()] = Some(piece);

        // Check immediate win conditions
        if Self::is_den(opp, to.row(), to.col()) || next.count_pieces(opp) == 0 {
            next.winner = Some(stm);
            next.history.push(next.grid);
            next.side_to_move = opp;
            return next;
        }

        // Check SuperKo repetition against full history
        if self.has_repeated(&next.grid) {
            assert!(
                next.ep[stm.idx()] > 0,
                "Reference engine attempted illegal repetition at 0 EP!"
            );
            next.ep[stm.idx()] -= 1;
        }

        next.history.push(next.grid);
        next.side_to_move = opp;

        // Start-of-turn EP gain for the new moving player
        if next.has_invasion_piece(opp) && next.ep[opp.idx()] < MAX_EP {
            next.ep[opp.idx()] += 1;
        }

        next
    }

    pub fn game_result(&self) -> GameResult {
        if let Some(w) = self.winner {
            return GameResult::Win(w);
        }
        if self.legal_moves().is_empty() {
            return GameResult::Win(self.side_to_move.opp());
        }
        GameResult::Ongoing
    }

    pub fn perft(&self, depth: u32) -> u64 {
        if depth == 0 {
            return 1;
        }
        let moves = self.legal_moves();
        if depth == 1 {
            return moves.len() as u64;
        }
        let mut nodes = 0u64;
        for mv in moves {
            let child = self.make_move(mv);
            nodes += child.perft(depth - 1);
        }
        nodes
    }

    pub fn render(&self) -> String {
        let mut out = String::new();
        out.push_str("    a b c d e f g\n");
        out.push_str("  +---------------+\n");
        for r in (0..ROWS).rev() {
            out.push_str(&format!("{} | ", r + 1));
            for c in 0..COLS {
                let ch = if let Some(p) = self.grid[r][c] {
                    p.kind.to_char(p.color)
                } else if Self::is_den(Color::P1, r, c) || Self::is_den(Color::P2, r, c) {
                    '@'
                } else if Self::is_trap(Color::P1, r, c) || Self::is_trap(Color::P2, r, c) {
                    '#'
                } else if Self::is_water(r, c) {
                    '~'
                } else {
                    '.'
                };
                out.push(ch);
                out.push(' ');
            }
            out.push_str(&format!("| {}\n", r + 1));
        }
        out.push_str("  +---------------+\n");
        out.push_str("    a b c d e f g\n");
        out.push_str(&format!(
            "Turn: {} | EP: P1={}, P2={} | History plies: {}\n",
            self.side_to_move,
            self.ep[0],
            self.ep[1],
            self.history.len()
        ));
        out
    }
}

