pub mod board_bb;
pub mod board_ref;

#[cfg(test)]
mod tests;

use std::fmt;

pub const ROWS: usize = 9;
pub const COLS: usize = 7;
pub const NUM_SQUARES: usize = ROWS * COLS; // 63
pub const ALL_SQUARES_MASK: u64 = (1u64 << NUM_SQUARES) - 1;

pub const MAX_EP: u8 = 10;
pub const START_EP: [u8; 2] = [4, 5];

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(u8)]
pub enum Color {
    P1 = 0,
    P2 = 1,
}

impl Color {
    #[inline]
    pub const fn idx(self) -> usize {
        self as usize
    }

    #[inline]
    pub const fn opp(self) -> Color {
        match self {
            Color::P1 => Color::P2,
            Color::P2 => Color::P1,
        }
    }
}

impl fmt::Display for Color {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Color::P1 => write!(f, "P1"),
            Color::P2 => write!(f, "P2"),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(u8)]
pub enum PieceKind {
    Rat = 0,      // Rank 1 (R)
    Cat = 1,      // Rank 2 (C)
    Dog = 2,      // Rank 3 (D)
    Wolf = 3,     // Rank 4 (W)
    Leopard = 4,  // Rank 5 (P)
    Tiger = 5,    // Rank 6 (T)
    Lion = 6,     // Rank 7 (L)
    Elephant = 7, // Rank 8 (E)
}

impl PieceKind {
    pub const ALL: [PieceKind; 8] = [
        PieceKind::Rat,
        PieceKind::Cat,
        PieceKind::Dog,
        PieceKind::Wolf,
        PieceKind::Leopard,
        PieceKind::Tiger,
        PieceKind::Lion,
        PieceKind::Elephant,
    ];

    #[inline]
    pub const fn idx(self) -> usize {
        self as usize
    }

    #[inline]
    pub const fn from_idx(i: usize) -> PieceKind {
        Self::ALL[i]
    }

    #[inline]
    pub const fn rank(self) -> u8 {
        (self as u8) + 1
    }

    #[inline]
    pub const fn can_jump(self) -> bool {
        matches!(self, PieceKind::Tiger | PieceKind::Lion)
    }

    #[inline]
    pub const fn can_enter_water(self) -> bool {
        matches!(self, PieceKind::Rat)
    }

    pub const fn to_char(self, color: Color) -> char {
        let ch = match self {
            PieceKind::Rat => 'R',
            PieceKind::Cat => 'C',
            PieceKind::Dog => 'D',
            PieceKind::Wolf => 'W',
            PieceKind::Leopard => 'P',
            PieceKind::Tiger => 'T',
            PieceKind::Lion => 'L',
            PieceKind::Elephant => 'E',
        };
        match color {
            Color::P1 => ch,
            Color::P2 => ch.to_ascii_lowercase(),
        }
    }
}

/// Square index in `0..63`, where `idx = row * 7 + col`.
/// Row 0 is rank 1 (P1 back rank), Row 8 is rank 9 (P2 back rank).
/// Col 0 is file 'a', Col 6 is file 'g'.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Square(pub u8);

impl Square {
    #[inline]
    pub const fn from_rc(row: usize, col: usize) -> Square {
        debug_assert!(row < ROWS && col < COLS);
        Square((row * COLS + col) as u8)
    }

    #[inline]
    pub const fn idx(self) -> usize {
        self.0 as usize
    }

    #[inline]
    pub const fn row(self) -> usize {
        (self.0 as usize) / COLS
    }

    #[inline]
    pub const fn col(self) -> usize {
        (self.0 as usize) % COLS
    }

    #[inline]
    pub const fn bit(self) -> u64 {
        1u64 << self.0
    }

    pub fn from_alg(s: &str) -> Option<Square> {
        let bytes = s.as_bytes();
        if bytes.len() != 2 {
            return None;
        }
        let col = bytes[0].wrapping_sub(b'a') as usize;
        let row = bytes[1].wrapping_sub(b'1') as usize;
        if row < ROWS && col < COLS {
            Some(Square::from_rc(row, col))
        } else {
            None
        }
    }
}

impl fmt::Display for Square {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let file = (b'a' + self.col() as u8) as char;
        let rank = (b'1' + self.row() as u8) as char;
        write!(f, "{}{}", file, rank)
    }
}

/// Canonical move packed into 16 bits: bits 0..6 = from, bits 6..12 = to.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Move(u16);

impl Move {
    pub const NULL: Move = Move(0);

    #[inline]
    pub const fn new(from: Square, to: Square) -> Move {
        Move((from.0 as u16) | ((to.0 as u16) << 6))
    }

    #[inline]
    pub const fn from(self) -> Square {
        Square((self.0 & 0x3F) as u8)
    }

    #[inline]
    pub const fn to(self) -> Square {
        Square(((self.0 >> 6) & 0x3F) as u8)
    }
}

impl fmt::Display for Move {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}{}", self.from(), self.to())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GameResult {
    Ongoing,
    Win(Color),
}

// ============================================================================
// Standard Starting Setup (180-degree rotationally symmetric)
// ============================================================================

pub const INITIAL_PIECES: [(Color, PieceKind, Square); 16] = [
    // Player 1 (bottom, rows 0..=2)
    (Color::P1, PieceKind::Tiger, Square::from_rc(0, 0)),
    (Color::P1, PieceKind::Lion, Square::from_rc(0, 6)),
    (Color::P1, PieceKind::Cat, Square::from_rc(1, 1)),
    (Color::P1, PieceKind::Dog, Square::from_rc(1, 5)),
    (Color::P1, PieceKind::Elephant, Square::from_rc(2, 0)),
    (Color::P1, PieceKind::Wolf, Square::from_rc(2, 2)),
    (Color::P1, PieceKind::Leopard, Square::from_rc(2, 4)),
    (Color::P1, PieceKind::Rat, Square::from_rc(2, 6)),
    // Player 2 (top, rows 6..=8)
    (Color::P2, PieceKind::Lion, Square::from_rc(8, 0)),
    (Color::P2, PieceKind::Tiger, Square::from_rc(8, 6)),
    (Color::P2, PieceKind::Dog, Square::from_rc(7, 1)),
    (Color::P2, PieceKind::Cat, Square::from_rc(7, 5)),
    (Color::P2, PieceKind::Rat, Square::from_rc(6, 0)),
    (Color::P2, PieceKind::Leopard, Square::from_rc(6, 2)),
    (Color::P2, PieceKind::Wolf, Square::from_rc(6, 4)),
    (Color::P2, PieceKind::Elephant, Square::from_rc(6, 6)),
];

// ============================================================================
// Compile-Time Board Masks & Lookup Tables
// ============================================================================

const fn sq_bit(r: usize, c: usize) -> u64 {
    1u64 << (r * COLS + c)
}

pub const DEN_SQ: [Square; 2] = [Square::from_rc(0, 3), Square::from_rc(8, 3)];

pub const OWN_DEN_MASK: [u64; 2] = [sq_bit(0, 3), sq_bit(8, 3)];

pub const TRAPS_MASK: [u64; 2] = [
    // P1's traps (weaken P2 pieces)
    sq_bit(0, 2) | sq_bit(0, 4) | sq_bit(1, 3),
    // P2's traps (weaken P1 pieces)
    sq_bit(8, 2) | sq_bit(8, 4) | sq_bit(7, 3),
];

pub const WATER_MASK: u64 = {
    let mut m = 0u64;
    let mut r = 3;
    while r <= 5 {
        m |= sq_bit(r, 1) | sq_bit(r, 2) | sq_bit(r, 4) | sq_bit(r, 5);
        r += 1;
    }
    m
};

/// Opponent's last 4 rows, excluding water tiles (traps count as land).
/// P1 invades rows 5, 6, 7, 8; P2 invades rows 0, 1, 2, 3. Row 4 is neutral.
pub const INVASION_LAND_MASK: [u64; 2] = {
    let mut p1 = 0u64;
    let mut r = 5;
    while r <= 8 {
        let mut c = 0;
        while c < COLS {
            p1 |= sq_bit(r, c);
            c += 1;
        }
        r += 1;
    }
    let mut p2 = 0u64;
    let mut r = 0;
    while r <= 3 {
        let mut c = 0;
        while c < COLS {
            p2 |= sq_bit(r, c);
            c += 1;
        }
        r += 1;
    }
    [p1 & !WATER_MASK, p2 & !WATER_MASK]
};

pub const ORTHO_ADJ: [u64; NUM_SQUARES] = {
    let mut tbl = [0u64; NUM_SQUARES];
    let mut r = 0;
    while r < ROWS {
        let mut c = 0;
        while c < COLS {
            let mut m = 0u64;
            if r > 0 {
                m |= sq_bit(r - 1, c);
            }
            if r + 1 < ROWS {
                m |= sq_bit(r + 1, c);
            }
            if c > 0 {
                m |= sq_bit(r, c - 1);
            }
            if c + 1 < COLS {
                m |= sq_bit(r, c + 1);
            }
            tbl[r * COLS + c] = m;
            c += 1;
        }
        r += 1;
    }
    tbl
};

#[derive(Clone, Copy, Debug)]
pub struct JumpInfo {
    pub to: u8,
    pub water_mask: u64,
}

impl JumpInfo {
    const EMPTY: JumpInfo = JumpInfo {
        to: 63,
        water_mask: 0,
    };
}

pub const JUMPS: [[JumpInfo; 2]; NUM_SQUARES] = build_jumps().0;
pub const JUMP_COUNT: [u8; NUM_SQUARES] = build_jumps().1;

const fn build_jumps() -> ([[JumpInfo; 2]; NUM_SQUARES], [u8; NUM_SQUARES]) {
    let mut jumps = [[JumpInfo::EMPTY; 2]; NUM_SQUARES];
    let mut counts = [0u8; NUM_SQUARES];

    // Helper macro-like inline logic via closures isn't const, so write directly:
    // Vertical jumps over rows 3, 4, 5 on water columns 1, 2, 4, 5
    let v_cols = [1usize, 2, 4, 5];
    let mut i = 0;
    while i < 4 {
        let c = v_cols[i];
        let wmask = sq_bit(3, c) | sq_bit(4, c) | sq_bit(5, c);
        let s_bot = 2 * COLS + c;
        let s_top = 6 * COLS + c;

        jumps[s_bot][counts[s_bot] as usize] = JumpInfo {
            to: s_top as u8,
            water_mask: wmask,
        };
        counts[s_bot] += 1;

        jumps[s_top][counts[s_top] as usize] = JumpInfo {
            to: s_bot as u8,
            water_mask: wmask,
        };
        counts[s_top] += 1;

        i += 1;
    }

    // Horizontal jumps over cols (1,2) and (4,5) on rows 3, 4, 5
    let mut r = 3;
    while r <= 5 {
        // Left river: col 0 <-> col 3
        let wmask_l = sq_bit(r, 1) | sq_bit(r, 2);
        let s0 = r * COLS;
        let s3 = r * COLS + 3;
        jumps[s0][counts[s0] as usize] = JumpInfo {
            to: s3 as u8,
            water_mask: wmask_l,
        };
        counts[s0] += 1;

        jumps[s3][counts[s3] as usize] = JumpInfo {
            to: s0 as u8,
            water_mask: wmask_l,
        };
        counts[s3] += 1;

        // Right river: col 3 <-> col 6
        let wmask_r = sq_bit(r, 4) | sq_bit(r, 5);
        let s6 = r * COLS + 6;
        jumps[s3][counts[s3] as usize] = JumpInfo {
            to: s6 as u8,
            water_mask: wmask_r,
        };
        counts[s3] += 1;

        jumps[s6][counts[s6] as usize] = JumpInfo {
            to: s3 as u8,
            water_mask: wmask_r,
        };
        counts[s6] += 1;

        r += 1;
    }

    (jumps, counts)
}

/// Normal (non-trapped, same-medium) capture matrix: `CAN_CAPTURE_NORMAL[attacker][defender]`.
pub const CAN_CAPTURE_NORMAL: [[bool; 8]; 8] = {
    let mut tbl = [[false; 8]; 8];
    let mut a = 0;
    while a < 8 {
        let mut d = 0;
        while d < 8 {
            tbl[a][d] = if a == 0 && d == 7 {
                true // Rat captures Elephant
            } else if a == 7 && d == 0 {
                false // Elephant cannot capture Rat
            } else {
                a >= d
            };
            d += 1;
        }
        a += 1;
    }
    tbl
};

// ============================================================================
// Deterministic Compile-Time Zobrist Keys & Fast PRNG
// ============================================================================

#[inline]
pub const fn splitmix64_step(mut state: u64) -> (u64, u64) {
    state = state.wrapping_add(0x9e37_79b9_7f4a_7c15);
    let mut z = state;
    z = (z ^ (z >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    (z ^ (z >> 31), state)
}

pub struct Rng(u64);

impl Rng {
    pub fn new(seed: u64) -> Self {
        Self(seed)
    }

    #[inline]
    pub fn next_u64(&mut self) -> u64 {
        let (val, next) = splitmix64_step(self.0);
        self.0 = next;
        val
    }

    #[inline]
    pub fn gen_range(&mut self, upper: usize) -> usize {
        (self.next_u64() as usize) % upper
    }
}

pub struct Zobrist {
    /// Piece keys indexed by `[piece_id 0..16][square 0..63]`.
    pub piece: [[u64; NUM_SQUARES]; 16],
    /// XORed when side_to_move == Color::P2.
    pub side: u64,
    /// EP keys indexed by `[color 0..2][ep 0..=10]`.
    pub ep: [[u64; (MAX_EP as usize) + 1]; 2],
}

pub const ZOBRIST: Zobrist = {
    let mut state = 0xD005_4000_0123_4567u64;
    let mut piece = [[0u64; NUM_SQUARES]; 16];
    let mut p = 0;
    while p < 16 {
        let mut s = 0;
        while s < NUM_SQUARES {
            let (val, next) = splitmix64_step(state);
            state = next;
            piece[p][s] = val;
            s += 1;
        }
        p += 1;
    }
    let (side, next) = splitmix64_step(state);
    state = next;

    let mut ep = [[0u64; (MAX_EP as usize) + 1]; 2];
    let mut c = 0;
    while c < 2 {
        let mut e = 0;
        while e <= MAX_EP as usize {
            let (val, next) = splitmix64_step(state);
            state = next;
            ep[c][e] = val;
            e += 1;
        }
        c += 1;
    }

    Zobrist { piece, side, ep }
};

