//! Mouse-driven desktop GUI for Dou Shou Qi (EP + SuperKo) using eframe/egui.
//!
//! Features:
//! - Auto-save running game on exit & auto-load on startup (exact SuperKo history preserved!)
//! - Quit confirmation dialog when closing the window
//! - Play Mode & Full Setup Mode (configure board, side-to-move, and both EP reserves)
//! - Setup controls: Left-click = selected color, Right-click = opposite color,
//!   Left+Right click (or Middle-click) = remove piece; live rule validation
//! - Night-mode (default) and Day-mode color themes
//! - Selectable search depth (1..=60) with non-blocking background engine thread
//! - Undo and Redo buttons with full snapshot restoration
//! - Switch sides with automatic 180° board rotation and automatic engine move
//! - 4 Piece sets: Animals (Unicode), Symbols (Unicode), Numbers, Letters (with tiny rank numbers)
//! - 90° clockwise board rotation with full coordinate adaptation
//! - Legal-move highlight toggle (quiet, capture, SuperKo EP-cost, den win)
//! - Graphical 10-cell gridded EP display above Piece Graveyard / Piece Reservoir,
//!   plus scrollable + selectable + one-click copyable Move List

use crate::core::board_bb::{BitboardPos, History, CAPTURED, EMPTY_SQ};
use crate::core::{
    Color, GameResult, Move, PieceKind, Square, COLS, DEN_SQ, INITIAL_PIECES, INVASION_LAND_MASK,
    MAX_EP, ROWS, START_EP, TRAPS_MASK, WATER_MASK,
};
use crate::eval::SCORE_WIN;
use crate::search::{SearchLimits, SearchResult, Searcher};
use eframe::egui;
use std::path::PathBuf;
use std::sync::mpsc::{self, Receiver};
use std::thread;
use std::time::Instant;

const MAX_GUI_DEPTH: usize = 60;
const AUTOSAVE_VERSION: &str = "DSQ_SAVE_V1";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PieceSet {
    Animals,
    Unicode,
    Numbers,
    Letters,
}

impl PieceSet {
    fn as_str(self) -> &'static str {
        match self {
            PieceSet::Animals => "animals",
            PieceSet::Unicode => "unicode",
            PieceSet::Numbers => "numbers",
            PieceSet::Letters => "letters",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        match s {
            "animals" => Some(PieceSet::Animals),
            "unicode" => Some(PieceSet::Unicode),
            "numbers" => Some(PieceSet::Numbers),
            "letters" => Some(PieceSet::Letters),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ColorTheme {
    Night,
    Day,
}

impl ColorTheme {
    fn as_str(self) -> &'static str {
        match self {
            ColorTheme::Night => "night",
            ColorTheme::Day => "day",
        }
    }

    fn from_str(s: &str) -> Option<Self> {
        match s {
            "night" => Some(ColorTheme::Night),
            "day" => Some(ColorTheme::Day),
            _ => None,
        }
    }

    fn palette(self) -> Palette {
        match self {
            ColorTheme::Night => Palette {
                board_frame: egui::Color32::from_rgb(20, 23, 30),
                coord_text: egui::Color32::from_rgb(155, 165, 185),
                land_light: egui::Color32::from_rgb(46, 52, 64),
                land_dark: egui::Color32::from_rgb(38, 43, 54),
                water_light: egui::Color32::from_rgb(22, 62, 92),
                water_dark: egui::Color32::from_rgb(18, 52, 78),
                trap_p1: egui::Color32::from_rgb(82, 54, 44),
                trap_p2: egui::Color32::from_rgb(44, 62, 86),
                den_p1: egui::Color32::from_rgb(112, 74, 34),
                den_p2: egui::Color32::from_rgb(36, 78, 114),
                grid_line: egui::Color32::from_rgb(24, 28, 36),
                p1_fill: egui::Color32::from_rgb(218, 148, 52),
                p1_border: egui::Color32::from_rgb(255, 224, 150),
                p1_text: egui::Color32::from_rgb(24, 16, 8),
                p2_fill: egui::Color32::from_rgb(56, 138, 212),
                p2_border: egui::Color32::from_rgb(180, 225, 255),
                p2_text: egui::Color32::from_rgb(245, 250, 255),
                selected_ring: egui::Color32::from_rgb(110, 240, 140),
                last_move_tint: egui::Color32::from_rgba_unmultiplied(240, 210, 80, 52),
                legal_quiet: egui::Color32::from_rgba_unmultiplied(100, 230, 130, 190),
                legal_ep_cost: egui::Color32::from_rgba_unmultiplied(255, 175, 50, 220),
                legal_capture: egui::Color32::from_rgba_unmultiplied(255, 85, 85, 230),
                legal_win: egui::Color32::from_rgba_unmultiplied(255, 230, 60, 240),
                panel_card_bg: egui::Color32::from_rgb(30, 34, 43),
                badge_text: egui::Color32::from_rgb(215, 222, 235),
                ep_empty_cell: egui::Color32::from_rgb(44, 49, 60),
                ep_grid_border: egui::Color32::from_rgb(20, 23, 30),
                ep_zero_warn: egui::Color32::from_rgb(235, 82, 82),
                ep_gain_badge: egui::Color32::from_rgb(100, 225, 135),
                setup_banner: egui::Color32::from_rgb(160, 115, 245),
            },
            ColorTheme::Day => Palette {
                board_frame: egui::Color32::from_rgb(218, 210, 196),
                coord_text: egui::Color32::from_rgb(68, 62, 54),
                land_light: egui::Color32::from_rgb(236, 221, 192),
                land_dark: egui::Color32::from_rgb(220, 202, 168),
                water_light: egui::Color32::from_rgb(115, 186, 230),
                water_dark: egui::Color32::from_rgb(98, 172, 218),
                trap_p1: egui::Color32::from_rgb(228, 180, 162),
                trap_p2: egui::Color32::from_rgb(168, 194, 226),
                den_p1: egui::Color32::from_rgb(224, 152, 112),
                den_p2: egui::Color32::from_rgb(122, 168, 222),
                grid_line: egui::Color32::from_rgb(165, 148, 122),
                p1_fill: egui::Color32::from_rgb(196, 56, 44),
                p1_border: egui::Color32::from_rgb(110, 22, 18),
                p1_text: egui::Color32::from_rgb(255, 248, 240),
                p2_fill: egui::Color32::from_rgb(36, 90, 168),
                p2_border: egui::Color32::from_rgb(16, 46, 96),
                p2_text: egui::Color32::from_rgb(245, 250, 255),
                selected_ring: egui::Color32::from_rgb(22, 160, 68),
                last_move_tint: egui::Color32::from_rgba_unmultiplied(230, 190, 20, 80),
                legal_quiet: egui::Color32::from_rgba_unmultiplied(26, 150, 68, 190),
                legal_ep_cost: egui::Color32::from_rgba_unmultiplied(220, 120, 10, 225),
                legal_capture: egui::Color32::from_rgba_unmultiplied(215, 35, 35, 235),
                legal_win: egui::Color32::from_rgba_unmultiplied(230, 170, 0, 245),
                panel_card_bg: egui::Color32::from_rgb(238, 234, 226),
                badge_text: egui::Color32::from_rgb(38, 36, 32),
                ep_empty_cell: egui::Color32::from_rgb(214, 208, 198),
                ep_grid_border: egui::Color32::from_rgb(165, 156, 142),
                ep_zero_warn: egui::Color32::from_rgb(195, 32, 32),
                ep_gain_badge: egui::Color32::from_rgb(24, 138, 58),
                setup_banner: egui::Color32::from_rgb(110, 56, 185),
            },
        }
    }
}

struct Palette {
    board_frame: egui::Color32,
    coord_text: egui::Color32,
    land_light: egui::Color32,
    land_dark: egui::Color32,
    water_light: egui::Color32,
    water_dark: egui::Color32,
    trap_p1: egui::Color32,
    trap_p2: egui::Color32,
    den_p1: egui::Color32,
    den_p2: egui::Color32,
    grid_line: egui::Color32,
    p1_fill: egui::Color32,
    p1_border: egui::Color32,
    p1_text: egui::Color32,
    p2_fill: egui::Color32,
    p2_border: egui::Color32,
    p2_text: egui::Color32,
    selected_ring: egui::Color32,
    last_move_tint: egui::Color32,
    legal_quiet: egui::Color32,
    legal_ep_cost: egui::Color32,
    legal_capture: egui::Color32,
    legal_win: egui::Color32,
    panel_card_bg: egui::Color32,
    badge_text: egui::Color32,
    ep_empty_cell: egui::Color32,
    ep_grid_border: egui::Color32,
    ep_zero_warn: egui::Color32,
    ep_gain_badge: egui::Color32,
    setup_banner: egui::Color32,
}

#[derive(Clone)]
struct MoveRecord {
    #[allow(dead_code)]
    side: Color,
    mv: Move,
    piece: PieceKind,
    captured: Option<PieceKind>,
    paid_ep: bool,
}

#[derive(Clone)]
struct Snapshot {
    pos: BitboardPos,
    history: History,
    move_log: Vec<MoveRecord>,
    last_move: Option<Move>,
}

/// Captures the starting state of the current game (standard or custom setup)
/// so saving + replaying `move_log` restores exact SuperKo history and undo stack.
#[derive(Clone)]
struct GameOrigin {
    piece_sq: [u8; 16],
    side_to_move: Color,
    ep: [u8; 2],
    is_custom: bool,
}

impl GameOrigin {
    fn standard() -> Self {
        let mut piece_sq = [CAPTURED; 16];
        for &(c, k, sq) in &INITIAL_PIECES {
            piece_sq[c.idx() * 8 + k.idx()] = sq.0;
        }
        Self {
            piece_sq,
            side_to_move: Color::P1,
            ep: START_EP,
            is_custom: false,
        }
    }

    fn from_custom(piece_sq: [u8; 16], side_to_move: Color, ep: [u8; 2]) -> Self {
        Self {
            piece_sq,
            side_to_move,
            ep,
            is_custom: true,
        }
    }

    fn to_pieces_vec(&self) -> Vec<(Color, PieceKind, Square)> {
        let mut out = Vec::with_capacity(16);
        for (pid, &s) in self.piece_sq.iter().enumerate() {
            if s != CAPTURED {
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                out.push((color, kind, Square(s)));
            }
        }
        out
    }
}

struct PendingSearch {
    generation: u64,
    rx: Receiver<SearchResult>,
    started_at: Instant,
}

#[derive(Clone)]
struct SetupState {
    piece_sq: [u8; 16],
    side_to_move: Color,
    ep: [u8; 2],
    brush_color: Color,
    brush_kind: PieceKind,
    chord_consumed: bool,
    status_msg: String,
}

impl SetupState {
    fn from_pos(pos: &BitboardPos) -> Self {
        Self {
            piece_sq: pos.piece_sq,
            side_to_move: pos.side_to_move,
            ep: pos.ep,
            brush_color: Color::P1,
            brush_kind: PieceKind::Elephant,
            chord_consumed: false,
            status_msg: "L-click: selected color | R-click: other color | L+R (or M-click): remove"
                .to_owned(),
        }
    }

    fn clear_board(&mut self) {
        self.piece_sq = [CAPTURED; 16];
        self.status_msg = "Board cleared.".to_owned();
    }

    fn reset_start(&mut self) {
        self.piece_sq = [CAPTURED; 16];
        for &(color, kind, sq) in &INITIAL_PIECES {
            self.piece_sq[color.idx() * 8 + kind.idx()] = sq.0;
        }
        self.side_to_move = Color::P1;
        self.ep = START_EP;
        self.status_msg = "Reset to standard starting position.".to_owned();
    }

    fn piece_at(&self, sq: Square) -> Option<usize> {
        self.piece_sq.iter().position(|&s| s == sq.0)
    }

    fn remove_at(&mut self, sq: Square) {
        if let Some(pid) = self.piece_at(sq) {
            self.piece_sq[pid] = CAPTURED;
            let c = if pid < 8 { Color::P1 } else { Color::P2 };
            let k = PieceKind::from_idx(pid & 7);
            self.status_msg = format!("Removed {} {} from {}.", c, piece_name(k), sq);
        }
    }

    fn place_piece(&mut self, color: Color, kind: PieceKind, sq: Square) {
        if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
            self.status_msg = format!("Cannot place any piece inside a Den ({})!", sq);
            return;
        }
        if (sq.bit() & WATER_MASK) != 0 && !kind.can_enter_water() {
            self.status_msg = format!(
                "Only Rats can be placed in water! ({} cannot enter {})",
                piece_name(kind),
                sq
            );
            return;
        }

        if let Some(existing_pid) = self.piece_at(sq) {
            self.piece_sq[existing_pid] = CAPTURED;
        }

        let pid = color.idx() * 8 + kind.idx();
        self.piece_sq[pid] = sq.0;
        self.status_msg = format!("Placed {} {} on {}.", color, piece_name(kind), sq);
    }

    fn side_occ(&self, side: usize) -> u64 {
        let base = side * 8;
        let mut m = 0u64;
        for k in 0..8 {
            let s = self.piece_sq[base + k];
            if s != CAPTURED {
                m |= 1u64 << s;
            }
        }
        m
    }

    fn validate(&self) -> Result<(), &'static str> {
        validate_piece_array(&self.piece_sq)
    }

    fn to_pieces_vec(&self) -> Vec<(Color, PieceKind, Square)> {
        let mut out = Vec::with_capacity(16);
        for (pid, &s) in self.piece_sq.iter().enumerate() {
            if s != CAPTURED {
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                out.push((color, kind, Square(s)));
            }
        }
        out
    }
}

fn validate_piece_array(piece_sq: &[u8; 16]) -> Result<(), &'static str> {
    let mut p1_cnt = 0usize;
    let mut p2_cnt = 0usize;
    let mut occ = 0u64;
    for (pid, &s) in piece_sq.iter().enumerate() {
        if s == CAPTURED {
            continue;
        }
        if s >= 63 {
            return Err("Invalid square index.");
        }
        let sq = Square(s);
        let bit = sq.bit();
        if (occ & bit) != 0 {
            return Err("Two pieces occupy the same square.");
        }
        occ |= bit;
        if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
            return Err("No piece may be inside a Den.");
        }
        let kind = PieceKind::from_idx(pid & 7);
        if !kind.can_enter_water() && (bit & WATER_MASK) != 0 {
            return Err("Only Rats may stand in water.");
        }
        if pid < 8 {
            p1_cnt += 1;
        } else {
            p2_cnt += 1;
        }
    }
    if p1_cnt == 0 {
        return Err("P1 must have at least 1 piece.");
    }
    if p2_cnt == 0 {
        return Err("P2 must have at least 1 piece.");
    }
    Ok(())
}

pub struct DsqGuiApp {
    origin: GameOrigin,
    pos: BitboardPos,
    history: History,
    move_log: Vec<MoveRecord>,
    undo_stack: Vec<Snapshot>,
    redo_stack: Vec<Snapshot>,
    last_move: Option<Move>,

    setup: Option<SetupState>,

    human_side: Color,
    search_depth: usize,
    piece_set: PieceSet,
    theme: ColorTheme,
    rotation: u8,
    show_legal_moves: bool,

    selected_sq: Option<Square>,
    pending_search: Option<PendingSearch>,
    search_generation: u64,
    last_engine_info: String,
    copied_until: Option<Instant>,

    /// Quit confirmation dialog state
    show_quit_confirm: bool,
    allow_close: bool,
}

impl DsqGuiApp {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        install_system_symbol_fonts(&cc.egui_ctx);
        cc.egui_ctx.set_visuals(egui::Visuals::dark());

        let (pos, history) = BitboardPos::new_start();
        let mut app = Self {
            origin: GameOrigin::standard(),
            pos,
            history,
            move_log: Vec::new(),
            undo_stack: Vec::new(),
            redo_stack: Vec::new(),
            last_move: None,
            setup: None,
            human_side: Color::P1,
            search_depth: 8,
            piece_set: PieceSet::Letters,
            theme: ColorTheme::Night,
            rotation: 0,
            show_legal_moves: true,
            selected_sq: None,
            pending_search: None,
            search_generation: 0,
            last_engine_info: "Ready. Your move as P1.".to_owned(),
            copied_until: None,
            show_quit_confirm: false,
            allow_close: false,
        };

        // Attempt automatic load of previously saved running game
        if app.try_autoload(&cc.egui_ctx) {
            app.apply_theme(&cc.egui_ctx);
        }

        app
    }

    fn autosave_path() -> PathBuf {
        if let Ok(xdg) = std::env::var("XDG_DATA_HOME") {
            if !xdg.is_empty() {
                return PathBuf::from(xdg).join("dsq_engine").join("autosave.txt");
            }
        }
        if let Ok(home) = std::env::var("HOME") {
            if !home.is_empty() {
                return PathBuf::from(home)
                    .join(".local")
                    .join("share")
                    .join("dsq_engine")
                    .join("autosave.txt");
            }
        }
        PathBuf::from("dsq_autosave.txt")
    }

    /// True if there is an active, unfinished game worth auto-saving.
    fn has_running_game(&self) -> bool {
        if self.pos.game_result(&self.history) != GameResult::Ongoing {
            return false;
        }
        !self.move_log.is_empty() || self.origin.is_custom
    }

    fn save_autosave(&self) {
        let path = Self::autosave_path();
        if !self.has_running_game() {
            // Game is finished or untouched at start: remove stale autosave
            let _ = std::fs::remove_file(&path);
            return;
        }

        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }

        let pieces_str: String = self
            .origin
            .piece_sq
            .iter()
            .map(|v| v.to_string())
            .collect::<Vec<_>>()
            .join(",");

        let moves_str: String = self
            .move_log
            .iter()
            .map(|r| r.mv.to_string())
            .collect::<Vec<_>>()
            .join(" ");

        let content = format!(
            "{}\n\
             origin_custom={}\n\
             origin_pieces={}\n\
             origin_stm={}\n\
             origin_ep={},{}\n\
             human_side={}\n\
             depth={}\n\
             piece_set={}\n\
             theme={}\n\
             rotation={}\n\
             show_legal={}\n\
             moves={}\n",
            AUTOSAVE_VERSION,
            if self.origin.is_custom { 1 } else { 0 },
            pieces_str,
            self.origin.side_to_move.idx(),
            self.origin.ep[0],
            self.origin.ep[1],
            self.human_side.idx(),
            self.search_depth,
            self.piece_set.as_str(),
            self.theme.as_str(),
            self.rotation % 4,
            if self.show_legal_moves { 1 } else { 0 },
            moves_str
        );

        let _ = std::fs::write(&path, content);
    }

    fn try_autoload(&mut self, ctx: &egui::Context) -> bool {
        let path = Self::autosave_path();
        let Ok(text) = std::fs::read_to_string(&path) else {
            return false;
        };

        let mut lines = text.lines();
        if lines.next().map(|l| l.trim()) != Some(AUTOSAVE_VERSION) {
            return false;
        }

        let mut origin_custom = false;
        let mut origin_pieces: Option<[u8; 16]> = None;
        let mut origin_stm = Color::P1;
        let mut origin_ep = START_EP;
        let mut human_side = Color::P1;
        let mut depth = self.search_depth;
        let mut piece_set = self.piece_set;
        let mut theme = self.theme;
        let mut rotation = 0u8;
        let mut show_legal = true;
        let mut moves_line = String::new();

        for line in lines {
            let Some((k, v)) = line.split_once('=') else {
                continue;
            };
            let v = v.trim();
            match k.trim() {
                "origin_custom" => origin_custom = v == "1",
                "origin_pieces" => {
                    let nums: Vec<u8> = v.split(',').filter_map(|s| s.parse().ok()).collect();
                    if nums.len() == 16 {
                        let mut arr = [CAPTURED; 16];
                        arr.copy_from_slice(&nums);
                        origin_pieces = Some(arr);
                    }
                }
                "origin_stm" => {
                    origin_stm = if v == "1" { Color::P2 } else { Color::P1 };
                }
                "origin_ep" => {
                    if let Some((a, b)) = v.split_once(',') {
                        if let (Ok(e0), Ok(e1)) = (a.parse::<u8>(), b.parse::<u8>()) {
                            if e0 <= MAX_EP && e1 <= MAX_EP {
                                origin_ep = [e0, e1];
                            }
                        }
                    }
                }
                "human_side" => {
                    human_side = if v == "1" { Color::P2 } else { Color::P1 };
                }
                "depth" => {
                    if let Ok(d) = v.parse::<usize>() {
                        depth = d.clamp(1, MAX_GUI_DEPTH);
                    }
                }
                "piece_set" => {
                    if let Some(ps) = PieceSet::from_str(v) {
                        piece_set = ps;
                    }
                }
                "theme" => {
                    if let Some(th) = ColorTheme::from_str(v) {
                        theme = th;
                    }
                }
                "rotation" => {
                    if let Ok(r) = v.parse::<u8>() {
                        rotation = r % 4;
                    }
                }
                "show_legal" => show_legal = v != "0",
                "moves" => moves_line = v.to_owned(),
                _ => {}
            }
        }

        let Some(piece_sq) = origin_pieces else {
            return false;
        };
        if validate_piece_array(&piece_sq).is_err() {
            return false;
        }

        let origin = GameOrigin {
            piece_sq,
            side_to_move: origin_stm,
            ep: origin_ep,
            is_custom: origin_custom,
        };
        let pieces_vec = origin.to_pieces_vec();
        let (start_pos, start_hist) = BitboardPos::from_custom(&pieces_vec, origin_stm, origin_ep);

        // Parse and validate every saved move before applying
        let mut parsed_moves = Vec::new();
        for tok in moves_line.split_whitespace() {
            let Some(mv) = parse_alg_move(tok) else {
                return false;
            };
            parsed_moves.push(mv);
        }

        // Apply loaded origin and replay moves to rebuild exact SuperKo history + undo stack
        self.origin = origin;
        self.pos = start_pos;
        self.history = start_hist;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;
        self.human_side = human_side;
        self.search_depth = depth;
        self.piece_set = piece_set;
        self.theme = theme;
        self.rotation = rotation;
        self.show_legal_moves = show_legal;

        for mv in parsed_moves {
            let legal = self.pos.gen_legal_moves(&self.history);
            if !legal.as_slice().contains(&mv) {
                // Corrupted save: safely fall back to standard start
                let (p, h) = BitboardPos::new_start();
                self.origin = GameOrigin::standard();
                self.pos = p;
                self.history = h;
                self.move_log.clear();
                self.undo_stack.clear();
                self.redo_stack.clear();
                self.last_move = None;
                return false;
            }
            self.play_move(mv);
        }

        // If the loaded game was somehow already finished, start fresh instead
        if self.pos.game_result(&self.history) != GameResult::Ongoing {
            let _ = std::fs::remove_file(&path);
            let (p, h) = BitboardPos::new_start();
            self.origin = GameOrigin::standard();
            self.pos = p;
            self.history = h;
            self.move_log.clear();
            self.undo_stack.clear();
            self.redo_stack.clear();
            self.last_move = None;
            return false;
        }

        self.last_engine_info = format!(
            "Auto-loaded saved game ({} plies). You play {}.",
            self.move_log.len(),
            self.human_side
        );

        if self.pos.side_to_move != self.human_side {
            self.start_engine_search(ctx);
        }

        true
    }

    fn is_setup(&self) -> bool {
        self.setup.is_some()
    }

    fn current_snapshot(&self) -> Snapshot {
        Snapshot {
            pos: self.pos,
            history: self.history.clone(),
            move_log: self.move_log.clone(),
            last_move: self.last_move,
        }
    }

    fn restore_snapshot(&mut self, snap: Snapshot) {
        self.pos = snap.pos;
        self.history = snap.history;
        self.move_log = snap.move_log;
        self.last_move = snap.last_move;
        self.selected_sq = None;
    }

    fn apply_theme(&self, ctx: &egui::Context) {
        match self.theme {
            ColorTheme::Night => ctx.set_visuals(egui::Visuals::dark()),
            ColorTheme::Day => ctx.set_visuals(egui::Visuals::light()),
        }
    }

    fn enter_setup(&mut self) {
        self.cancel_search();
        self.selected_sq = None;
        self.setup = Some(SetupState::from_pos(&self.pos));
    }

    fn cancel_setup(&mut self) {
        self.setup = None;
        self.last_engine_info = "Cancelled setup mode.".to_owned();
    }

    fn finish_setup(&mut self, ctx: &egui::Context) {
        let Some(setup) = self.setup.clone() else {
            return;
        };
        if setup.validate().is_err() {
            return;
        }
        let pieces = setup.to_pieces_vec();
        let (new_pos, new_hist) = BitboardPos::from_custom(&pieces, setup.side_to_move, setup.ep);

        self.setup = None;
        self.origin = GameOrigin::from_custom(setup.piece_sq, setup.side_to_move, setup.ep);
        self.pos = new_pos;
        self.history = new_hist;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;

        self.last_engine_info = format!(
            "Custom position ready! Turn: {} | You play {}.",
            self.pos.side_to_move, self.human_side
        );

        if self.pos.game_result(&self.history) == GameResult::Ongoing
            && self.pos.side_to_move != self.human_side
        {
            self.start_engine_search(ctx);
        }
    }

    fn new_game(&mut self, ctx: &egui::Context) {
        self.setup = None;
        self.cancel_search();
        let (pos, history) = BitboardPos::new_start();
        self.origin = GameOrigin::standard();
        self.pos = pos;
        self.history = history;
        self.move_log.clear();
        self.undo_stack.clear();
        self.redo_stack.clear();
        self.last_move = None;
        self.selected_sq = None;
        self.last_engine_info = format!("New game started. You play {}.", self.human_side);

        if self.pos.side_to_move != self.human_side {
            self.start_engine_search(ctx);
        }
    }

    fn cancel_search(&mut self) {
        self.search_generation = self.search_generation.wrapping_add(1);
        self.pending_search = None;
    }

    fn undo_move(&mut self) {
        self.cancel_search();
        self.selected_sq = None;

        while let Some(snap) = self.undo_stack.pop() {
            let cur = self.current_snapshot();
            self.redo_stack.push(cur);
            self.restore_snapshot(snap);
            if self.pos.side_to_move == self.human_side {
                break;
            }
        }
        self.last_engine_info = "Undid move.".to_owned();
    }

    fn redo_move(&mut self) {
        self.cancel_search();
        self.selected_sq = None;

        while let Some(snap) = self.redo_stack.pop() {
            let cur = self.current_snapshot();
            self.undo_stack.push(cur);
            self.restore_snapshot(snap);
            if self.pos.side_to_move == self.human_side {
                break;
            }
        }
        self.last_engine_info = "Redid move.".to_owned();
    }

    fn switch_sides(&mut self, ctx: &egui::Context) {
        self.cancel_search();
        self.selected_sq = None;
        self.human_side = self.human_side.opp();
        self.rotation = (self.rotation + 2) % 4;

        if !self.is_setup()
            && self.pos.game_result(&self.history) == GameResult::Ongoing
            && self.pos.side_to_move != self.human_side
        {
            self.start_engine_search(ctx);
        } else {
            self.last_engine_info = format!("Switched sides. You now play {}.", self.human_side);
        }
    }

    fn play_move(&mut self, mv: Move) {
        let snap = self.current_snapshot();
        self.undo_stack.push(snap);
        self.redo_stack.clear();

        let mover = self.pos.side_to_move;
        let mover_idx = mover.idx();
        let ep_before = self.pos.ep[mover_idx];
        let att_pid = self.pos.board_piece[mv.from().idx()] as usize;
        let att_kind = PieceKind::from_idx(att_pid & 7);
        let cap_pid = self.pos.board_piece[mv.to().idx()];
        let captured = if cap_pid != EMPTY_SQ {
            Some(PieceKind::from_idx((cap_pid as usize) & 7))
        } else {
            None
        };

        self.pos = self.pos.make_move(mv, &mut self.history);
        let paid_ep = self.pos.ep[mover_idx] < ep_before;

        self.move_log.push(MoveRecord {
            side: mover,
            mv,
            piece: att_kind,
            captured,
            paid_ep,
        });
        self.last_move = Some(mv);
        self.selected_sq = None;
    }

    fn start_engine_search(&mut self, ctx: &egui::Context) {
        if self.pos.game_result(&self.history) != GameResult::Ongoing {
            return;
        }
        self.search_generation = self.search_generation.wrapping_add(1);
        let generation = self.search_generation;
        let pos_copy = self.pos;
        let mut hist_copy = self.history.clone();
        let depth = self.search_depth;
        let ctx_clone = ctx.clone();

        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            let mut searcher = Searcher::with_tt_mb(32);
            let res = searcher.search(&pos_copy, &mut hist_copy, SearchLimits::depth(depth));
            let _ = tx.send(res);
            ctx_clone.request_repaint();
        });

        self.pending_search = Some(PendingSearch {
            generation,
            rx,
            started_at: Instant::now(),
        });
        self.last_engine_info = format!("Engine thinking (depth {})...", depth);
    }

    fn poll_engine(&mut self) {
        let Some(pending) = &self.pending_search else {
            return;
        };
        if let Ok(res) = pending.rx.try_recv() {
            let gen = pending.generation;
            self.pending_search = None;
            if gen != self.search_generation || self.is_setup() {
                return;
            }
            if res.best_move != Move::NULL {
                let legal = self.pos.gen_legal_moves(&self.history);
                if legal.as_slice().contains(&res.best_move) {
                    let score_str = format_score(res.score);
                    self.last_engine_info = format!(
                        "Engine played {} | d{} | {} | {} nodes ({:.2}s)",
                        res.best_move,
                        res.depth,
                        score_str,
                        res.nodes,
                        res.elapsed.as_secs_f64()
                    );
                    self.play_move(res.best_move);
                }
            }
        }
    }

    fn board_to_visual(&self, r: usize, c: usize) -> (usize, usize) {
        board_to_visual_rot(self.rotation, r, c)
    }

    fn visual_to_board(&self, vx: usize, vy: usize) -> (usize, usize) {
        visual_to_board_rot(self.rotation, vx, vy)
    }

    fn visual_dims(&self) -> (usize, usize) {
        if self.rotation % 2 == 0 {
            (COLS, ROWS)
        } else {
            (ROWS, COLS)
        }
    }

    fn format_movelist(&self) -> String {
        let mut out = String::new();
        for (i, rec) in self.move_log.iter().enumerate() {
            if i % 2 == 0 {
                if i > 0 {
                    out.push('\n');
                }
                out.push_str(&format!("{:>3}. ", i / 2 + 1));
            } else {
                out.push_str("   ");
            }
            let cap_sym = if rec.captured.is_some() { "x" } else { "-" };
            let ep_sym = if rec.paid_ep { "*" } else { "" };
            let p_ch = piece_letter(rec.piece);
            out.push_str(&format!(
                "{}:{}{}{}{}",
                p_ch,
                rec.mv.from(),
                cap_sym,
                rec.mv.to(),
                ep_sym
            ));
        }
        out
    }

    fn move_costs_ep(&self, mv: Move) -> bool {
        let opp_den = DEN_SQ[self.pos.side_to_move.opp().idx()].0;
        if mv.to().0 == opp_den || self.pos.board_piece[mv.to().idx()] != EMPTY_SQ {
            return false;
        }
        let pid = self.pos.board_piece[mv.from().idx()] as usize;
        let mut next_sq = self.pos.piece_sq;
        next_sq[pid] = mv.to().0;
        self.history.contains(u128::from_ne_bytes(next_sq))
    }

    fn draw_piece_disc(
        &self,
        painter: &egui::Painter,
        center: egui::Pos2,
        radius: f32,
        color: Color,
        kind: PieceKind,
        pal: &Palette,
    ) {
        let (fill, border, text_col) = match color {
            Color::P1 => (pal.p1_fill, pal.p1_border, pal.p1_text),
            Color::P2 => (pal.p2_fill, pal.p2_border, pal.p2_text),
        };

        painter.circle_filled(center, radius, fill);
        painter.circle_stroke(
            center,
            radius,
            egui::Stroke::new((radius * 0.11).max(1.5), border),
        );

        let rank_str = kind.rank().to_string();
        match self.piece_set {
            PieceSet::Numbers => {
                painter.text(
                    center,
                    egui::Align2::CENTER_CENTER,
                    rank_str,
                    egui::FontId::proportional(radius * 1.18),
                    text_col,
                );
            }
            PieceSet::Letters => {
                let main_pos = egui::pos2(center.x - radius * 0.10, center.y - radius * 0.02);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_letter(kind),
                    egui::FontId::proportional(radius * 1.08),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.56, center.y + radius * 0.52);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.48).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Unicode => {
                let main_pos = egui::pos2(center.x - radius * 0.08, center.y - radius * 0.03);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_unicode_symbol(kind),
                    egui::FontId::proportional(radius * 1.12),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.58, center.y + radius * 0.54);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.44).max(8.0)),
                    text_col,
                );
            }
            PieceSet::Animals => {
                let main_pos = egui::pos2(center.x - radius * 0.10, center.y - radius * 0.04);
                painter.text(
                    main_pos,
                    egui::Align2::CENTER_CENTER,
                    piece_unicode_animal(kind),
                    egui::FontId::proportional(radius * 1.04),
                    text_col,
                );
                let num_pos = egui::pos2(center.x + radius * 0.58, center.y + radius * 0.54);
                painter.text(
                    num_pos,
                    egui::Align2::RIGHT_BOTTOM,
                    rank_str,
                    egui::FontId::proportional((radius * 0.46).max(8.0)),
                    text_col,
                );
            }
        }
    }

    fn ui_quit_confirmation(&mut self, ctx: &egui::Context) {
        if !self.show_quit_confirm {
            return;
        }

        let running = self.has_running_game();
        egui::Window::new("Confirm Quit")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.add_space(4.0);
                if running {
                    ui.label("Are you sure you want to quit?");
                    ui.small("Your running game will be auto-saved and restored next time you open the app.");
                } else {
                    ui.label("Are you sure you want to quit Dou Shou Qi?");
                }
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    let quit_label = if running { "Save & Quit" } else { "Quit" };
                    if ui.button(quit_label).clicked() {
                        self.save_autosave();
                        self.allow_close = true;
                        self.show_quit_confirm = false;
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                    if running && ui.button("Quit Without Saving").clicked() {
                        let _ = std::fs::remove_file(Self::autosave_path());
                        self.allow_close = true;
                        self.show_quit_confirm = false;
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                    if ui.button("Cancel").clicked() {
                        self.show_quit_confirm = false;
                    }
                });
                ui.add_space(4.0);
            });
    }

    fn ui_top_toolbar(&mut self, ctx: &egui::Context) {
        let in_setup = self.is_setup();
        egui::TopBottomPanel::top("top_toolbar").show(ctx, |ui| {
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing.x = 7.0;

                if in_setup {
                    let valid = self
                        .setup
                        .as_ref()
                        .map(|s| s.validate().is_ok())
                        .unwrap_or(false);
                    if ui
                        .add_enabled(valid, egui::Button::new("✓ End Setup"))
                        .clicked()
                    {
                        self.finish_setup(ctx);
                        return;
                    }
                    if ui.button("✕ Cancel Setup").clicked() {
                        self.cancel_setup();
                        return;
                    }
                    if ui.button("Clear Board").clicked() {
                        if let Some(s) = &mut self.setup {
                            s.clear_board();
                        }
                    }
                    if ui.button("Reset Start").clicked() {
                        if let Some(s) = &mut self.setup {
                            s.reset_start();
                        }
                    }
                } else {
                    if ui.button("New Game").clicked() {
                        self.new_game(ctx);
                    }

                    let can_undo = !self.undo_stack.is_empty();
                    if ui.add_enabled(can_undo, egui::Button::new("Undo")).clicked() {
                        self.undo_move();
                    }

                    let can_redo = !self.redo_stack.is_empty();
                    if ui.add_enabled(can_redo, egui::Button::new("Redo")).clicked() {
                        self.redo_move();
                    }

                    if ui.button("Setup Board").clicked() {
                        self.enter_setup();
                        return;
                    }

                    if ui
                        .button(format!("Switch Sides (You: {})", self.human_side))
                        .clicked()
                    {
                        self.switch_sides(ctx);
                    }
                }

                if ui
                    .button(format!("Rotate 90° ↻ ({}°)", self.rotation as u16 * 90))
                    .clicked()
                {
                    self.rotation = (self.rotation + 1) % 4;
                }

                ui.separator();

                ui.label("Depth:");
                if ui.small_button("-").clicked() && self.search_depth > 1 {
                    self.search_depth -= 1;
                }
                ui.add(
                    egui::Slider::new(&mut self.search_depth, 1..=MAX_GUI_DEPTH)
                        .show_value(true)
                        .clamping(egui::SliderClamping::Always),
                );
                if ui.small_button("+").clicked() && self.search_depth < MAX_GUI_DEPTH {
                    self.search_depth += 1;
                }

                ui.separator();

                ui.label("Pieces:");
                ui.selectable_value(&mut self.piece_set, PieceSet::Animals, "Animals");
                ui.selectable_value(&mut self.piece_set, PieceSet::Unicode, "Unicode");
                ui.selectable_value(&mut self.piece_set, PieceSet::Numbers, "Numbers");
                ui.selectable_value(&mut self.piece_set, PieceSet::Letters, "Letters");

                ui.separator();

                let theme_label = match self.theme {
                    ColorTheme::Night => "Theme: Night",
                    ColorTheme::Day => "Theme: Day",
                };
                if ui.button(theme_label).clicked() {
                    self.theme = match self.theme {
                        ColorTheme::Night => ColorTheme::Day,
                        ColorTheme::Day => ColorTheme::Night,
                    };
                    self.apply_theme(ctx);
                }

                if !in_setup {
                    ui.separator();
                    ui.checkbox(&mut self.show_legal_moves, "Show Legal Moves");
                }
            });
            ui.add_space(4.0);
        });
    }

    fn ui_ep_grid_row(
        &self,
        ui: &mut egui::Ui,
        side: Color,
        ep: u8,
        gaining: bool,
        is_turn: bool,
        pal: &Palette,
    ) {
        let fill_color = match side {
            Color::P1 => pal.p1_fill,
            Color::P2 => pal.p2_fill,
        };
        let label_text = match side {
            Color::P1 => "P1",
            Color::P2 => "P2",
        };

        ui.horizontal(|ui| {
            let tag = if is_turn {
                format!("▶ {}:", label_text)
            } else {
                format!("   {}:", label_text)
            };
            ui.colored_label(fill_color, egui::RichText::new(tag).strong().monospace());

            let count_color = if ep == 0 {
                pal.ep_zero_warn
            } else {
                pal.badge_text
            };
            ui.colored_label(
                count_color,
                egui::RichText::new(format!("{:>2}/{}", ep, MAX_EP))
                    .monospace()
                    .strong(),
            );

            if gaining {
                ui.colored_label(
                    pal.ep_gain_badge,
                    egui::RichText::new("+1/turn").small().strong(),
                );
            } else if ep == 0 {
                ui.colored_label(
                    pal.ep_zero_warn,
                    egui::RichText::new("NO REPEAT").small().strong(),
                );
            }
        });

        let cells = MAX_EP as usize;
        let avail_w = ui.available_width().max(120.0);
        let cell_h = 15.0;
        let gap = 2.0;
        let cell_w = ((avail_w - gap * (cells as f32 - 1.0)) / cells as f32).max(8.0);

        let (rect, _) =
            ui.allocate_exact_size(egui::vec2(avail_w, cell_h), egui::Sense::hover());
        let painter = ui.painter_at(rect);

        for i in 0..cells {
            let x0 = rect.left() + i as f32 * (cell_w + gap);
            let cell_rect = egui::Rect::from_min_size(
                egui::pos2(x0, rect.top()),
                egui::vec2(cell_w, cell_h),
            );
            let filled = (i as u8) < ep;
            let bg = if filled {
                fill_color
            } else {
                pal.ep_empty_cell
            };
            let stroke_col = if ep == 0 {
                pal.ep_zero_warn
            } else {
                pal.ep_grid_border
            };

            painter.rect_filled(cell_rect, egui::Rounding::same(2.5), bg);
            painter.rect_stroke(
                cell_rect,
                egui::Rounding::same(2.5),
                egui::Stroke::new(1.0, stroke_col),
            );
        }
    }

    fn ui_right_panel(&mut self, ctx: &egui::Context, pal: &Palette) {
        egui::SidePanel::right("right_panel")
            .resizable(true)
            .default_width(315.0)
            .min_width(235.0)
            .max_width(540.0)
            .show(ctx, |ui| {
                ui.add_space(6.0);

                if self.is_setup() {
                    self.ui_right_panel_setup(ctx, ui, pal);
                } else {
                    self.ui_right_panel_play(ui, pal);
                }
            });
    }

    fn ui_right_panel_play(&mut self, ui: &mut egui::Ui, pal: &Palette) {
        egui::Frame::none()
            .fill(pal.panel_card_bg)
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(egui::Margin::same(8.0))
            .show(ui, |ui| {
                let result = self.pos.game_result(&self.history);
                let status_line = match result {
                    GameResult::Win(w) => format!("GAME OVER: {} WINS!", w),
                    GameResult::Ongoing => {
                        if let Some(p) = &self.pending_search {
                            format!(
                                "Turn: {} (Engine thinking {:.1}s...)",
                                self.pos.side_to_move,
                                p.started_at.elapsed().as_secs_f32()
                            )
                        } else {
                            format!("Turn: {} (Your move)", self.pos.side_to_move)
                        }
                    }
                };
                ui.strong(status_line);
                ui.small(&self.last_engine_info);
                ui.add_space(6.0);

                ui.label(egui::RichText::new("Energy Points (EP)").strong());
                ui.add_space(2.0);
                let p1_gain = (self.pos.occ_side[0] & INVASION_LAND_MASK[0]) != 0;
                let p2_gain = (self.pos.occ_side[1] & INVASION_LAND_MASK[1]) != 0;
                self.ui_ep_grid_row(
                    ui,
                    Color::P1,
                    self.pos.ep[0],
                    p1_gain,
                    self.pos.side_to_move == Color::P1 && self.pos.winner.is_none(),
                    pal,
                );
                ui.add_space(5.0);
                self.ui_ep_grid_row(
                    ui,
                    Color::P2,
                    self.pos.ep[1],
                    p2_gain,
                    self.pos.side_to_move == Color::P2 && self.pos.winner.is_none(),
                    pal,
                );
            });

        ui.add_space(8.0);

        ui.heading("Piece Graveyard");
        egui::Frame::none()
            .fill(pal.panel_card_bg)
            .rounding(egui::Rounding::same(6.0))
            .inner_margin(egui::Margin::same(8.0))
            .show(ui, |ui| {
                let sqs = self.pos.piece_sq;
                self.ui_piece_tray_row(ui, &sqs, Color::P1, "Captured P1:", false, pal);
                ui.add_space(6.0);
                self.ui_piece_tray_row(ui, &sqs, Color::P2, "Captured P2:", false, pal);
            });

        ui.add_space(10.0);

        ui.horizontal(|ui| {
            ui.heading("Move List");
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                let copied_active = self
                    .copied_until
                    .map(|t| Instant::now() < t)
                    .unwrap_or(false);
                let btn_text = if copied_active { "Copied!" } else { "Copy" };
                if ui.button(btn_text).clicked() {
                    let text = self.format_movelist();
                    ui.ctx().copy_text(text);
                    self.copied_until = Some(Instant::now() + std::time::Duration::from_secs(2));
                }
            });
        });

        ui.small("(* = paid 1 EP for SuperKo repetition, x = capture)");
        ui.add_space(4.0);

        let movelist_str = self.format_movelist();
        let mut ro_str: &str = if movelist_str.is_empty() {
            "(No moves played yet)"
        } else {
            &movelist_str
        };

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .stick_to_bottom(true)
            .show(ui, |ui| {
                ui.add_sized(
                    ui.available_size(),
                    egui::TextEdit::multiline(&mut ro_str)
                        .font(egui::TextStyle::Monospace)
                        .desired_width(f32::INFINITY),
                );
            });
    }

    fn ui_right_panel_setup(&mut self, ctx: &egui::Context, ui: &mut egui::Ui, pal: &Palette) {
        let mut finish_clicked = false;
        let mut cancel_clicked = false;
        let mut picked_from_reservoir: Option<(Color, PieceKind)> = None;

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                let (ep_p1, ep_p2, p1_gain, p2_gain, stm, status_msg, validation) = {
                    let s = self.setup.as_ref().unwrap();
                    (
                        s.ep[0],
                        s.ep[1],
                        (s.side_occ(0) & INVASION_LAND_MASK[0]) != 0,
                        (s.side_occ(1) & INVASION_LAND_MASK[1]) != 0,
                        s.side_to_move,
                        s.status_msg.clone(),
                        s.validate(),
                    )
                };

                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        ui.colored_label(
                            pal.setup_banner,
                            egui::RichText::new("SETUP MODE").strong().size(15.0),
                        );
                        ui.small(&status_msg);
                        ui.add_space(6.0);

                        ui.label(egui::RichText::new("Configure Energy Points (EP)").strong());
                        ui.add_space(2.0);
                        self.ui_ep_grid_row(ui, Color::P1, ep_p1, p1_gain, stm == Color::P1, pal);
                        ui.horizontal(|ui| {
                            ui.small("P1 EP:");
                            let s = self.setup.as_mut().unwrap();
                            if ui.small_button("-").clicked() && s.ep[0] > 0 {
                                s.ep[0] -= 1;
                            }
                            ui.add(
                                egui::Slider::new(&mut s.ep[0], 0..=MAX_EP)
                                    .show_value(false)
                                    .clamping(egui::SliderClamping::Always),
                            );
                            if ui.small_button("+").clicked() && s.ep[0] < MAX_EP {
                                s.ep[0] += 1;
                            }
                        });

                        ui.add_space(4.0);
                        self.ui_ep_grid_row(ui, Color::P2, ep_p2, p2_gain, stm == Color::P2, pal);
                        ui.horizontal(|ui| {
                            ui.small("P2 EP:");
                            let s = self.setup.as_mut().unwrap();
                            if ui.small_button("-").clicked() && s.ep[1] > 0 {
                                s.ep[1] -= 1;
                            }
                            ui.add(
                                egui::Slider::new(&mut s.ep[1], 0..=MAX_EP)
                                    .show_value(false)
                                    .clamping(egui::SliderClamping::Always),
                            );
                            if ui.small_button("+").clicked() && s.ep[1] < MAX_EP {
                                s.ep[1] += 1;
                            }
                        });
                    });

                ui.add_space(8.0);

                ui.heading("Piece Reservoir");
                ui.small("Unplaced pieces (click any piece to select it as your brush):");
                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        let sqs = self.setup.as_ref().unwrap().piece_sq;
                        if let Some(k) =
                            self.ui_piece_tray_row(ui, &sqs, Color::P1, "P1 Reservoir:", true, pal)
                        {
                            picked_from_reservoir = Some((Color::P1, k));
                        }
                        ui.add_space(6.0);
                        if let Some(k) =
                            self.ui_piece_tray_row(ui, &sqs, Color::P2, "P2 Reservoir:", true, pal)
                        {
                            picked_from_reservoir = Some((Color::P2, k));
                        }
                    });

                ui.add_space(8.0);

                ui.heading("Setup Controls");
                egui::Frame::none()
                    .fill(pal.panel_card_bg)
                    .rounding(egui::Rounding::same(6.0))
                    .inner_margin(egui::Margin::same(8.0))
                    .show(ui, |ui| {
                        {
                            let s = self.setup.as_mut().unwrap();

                            ui.horizontal(|ui| {
                                ui.label("Left-click color:");
                                ui.selectable_value(&mut s.brush_color, Color::P1, "P1");
                                ui.selectable_value(&mut s.brush_color, Color::P2, "P2");
                            });
                            ui.small(format!(
                                "(Right-click places {}; L+R click or Middle-click removes)",
                                s.brush_color.opp()
                            ));

                            ui.add_space(6.0);
                            ui.label("Select piece to place:");
                            ui.horizontal_wrapped(|ui| {
                                for &kind in PieceKind::ALL.iter().rev() {
                                    let label = format!("{} ({})", piece_name(kind), kind.rank());
                                    ui.selectable_value(&mut s.brush_kind, kind, label);
                                }
                            });

                            ui.add_space(8.0);
                            ui.separator();
                            ui.add_space(4.0);

                            ui.horizontal(|ui| {
                                ui.label("Side to move:");
                                ui.selectable_value(&mut s.side_to_move, Color::P1, "P1");
                                ui.selectable_value(&mut s.side_to_move, Color::P2, "P2");
                            });
                        }

                        ui.horizontal(|ui| {
                            ui.label("You play as:");
                            ui.selectable_value(&mut self.human_side, Color::P1, "P1");
                            ui.selectable_value(&mut self.human_side, Color::P2, "P2");
                        });

                        ui.add_space(8.0);
                        ui.horizontal(|ui| {
                            let s = self.setup.as_mut().unwrap();
                            if ui.button("Clear Board").clicked() {
                                s.clear_board();
                            }
                            if ui.button("Reset Start").clicked() {
                                s.reset_start();
                            }
                        });

                        ui.add_space(8.0);
                        if let Err(reason) = validation {
                            ui.colored_label(pal.ep_zero_warn, format!("⚠ {}", reason));
                        } else {
                            ui.colored_label(pal.ep_gain_badge, "✓ Position is valid.");
                        }

                        ui.add_space(4.0);
                        ui.horizontal(|ui| {
                            if ui
                                .add_enabled(validation.is_ok(), egui::Button::new("✓ End Setup"))
                                .clicked()
                            {
                                finish_clicked = true;
                            }
                            if ui.button("✕ Cancel").clicked() {
                                cancel_clicked = true;
                            }
                        });
                    });
            });

        if let Some((color, kind)) = picked_from_reservoir {
            if let Some(s) = &mut self.setup {
                s.brush_color = color;
                s.brush_kind = kind;
                s.status_msg = format!("Selected {} {} for placement.", color, piece_name(kind));
            }
        }
        if finish_clicked {
            self.finish_setup(ctx);
        } else if cancel_clicked {
            self.cancel_setup();
        }
    }

    fn ui_piece_tray_row(
        &self,
        ui: &mut egui::Ui,
        piece_sq: &[u8; 16],
        side: Color,
        label: &str,
        clickable: bool,
        pal: &Palette,
    ) -> Option<PieceKind> {
        let base = side.idx() * 8;
        let mut unplaced = Vec::new();
        for k in (0..8usize).rev() {
            if piece_sq[base + k] == CAPTURED {
                unplaced.push(PieceKind::from_idx(k));
            }
        }

        ui.small(label);
        if unplaced.is_empty() {
            ui.colored_label(
                pal.coord_text,
                if clickable {
                    "  (all pieces placed)"
                } else {
                    "  (none)"
                },
            );
            return None;
        }

        let disc_size = 30.0;
        let spacing = 5.0;
        let avail_w = ui.available_width().max(disc_size);
        let per_row = ((avail_w + spacing) / (disc_size + spacing))
            .floor()
            .max(1.0) as usize;
        let rows = unplaced.len().div_ceil(per_row);
        let total_h = rows as f32 * (disc_size + spacing);

        let sense = if clickable {
            egui::Sense::click()
        } else {
            egui::Sense::hover()
        };
        let (rect, response) = ui.allocate_exact_size(egui::vec2(avail_w, total_h), sense);
        let painter = ui.painter_at(rect);

        let active_brush = self
            .setup
            .as_ref()
            .map(|s| (s.brush_color, s.brush_kind));

        let mut clicked_kind = None;
        let click_pos = if clickable && response.clicked() {
            response.interact_pointer_pos()
        } else {
            None
        };

        for (i, &kind) in unplaced.iter().enumerate() {
            let col = i % per_row;
            let row = i / per_row;
            let cx = rect.left() + col as f32 * (disc_size + spacing) + disc_size * 0.5;
            let cy = rect.top() + row as f32 * (disc_size + spacing) + disc_size * 0.5;
            let center = egui::pos2(cx, cy);
            let r = disc_size * 0.45;

            self.draw_piece_disc(&painter, center, r, side, kind, pal);

            if clickable && active_brush == Some((side, kind)) {
                painter.circle_stroke(
                    center,
                    r + 2.5,
                    egui::Stroke::new(2.2, pal.selected_ring),
                );
            }

            if let Some(p) = click_pos {
                if (p - center).length() <= r + 3.0 {
                    clicked_kind = Some(kind);
                }
            }
        }

        clicked_kind
    }

    fn ui_board_panel(&mut self, ctx: &egui::Context, pal: &Palette) {
        egui::CentralPanel::default().show(ctx, |ui| {
            let avail = ui.available_size();
            let (vis_cols, vis_rows) = self.visual_dims();
            let rotation = self.rotation;

            let margin = 26.0;
            let max_w = (avail.x - margin * 2.0).max(100.0);
            let max_h = (avail.y - margin * 2.0).max(100.0);
            let tile = (max_w / vis_cols as f32).min(max_h / vis_rows as f32);

            let board_w = tile * vis_cols as f32;
            let board_h = tile * vis_rows as f32;
            let total_w = board_w + margin * 2.0;
            let total_h = board_h + margin * 2.0;

            let (full_rect, response) =
                ui.allocate_exact_size(avail, egui::Sense::click_and_drag());
            let origin = egui::pos2(
                full_rect.center().x - total_w * 0.5,
                full_rect.center().y - total_h * 0.5,
            );
            let frame_rect = egui::Rect::from_min_size(origin, egui::vec2(total_w, total_h));
            let board_origin = egui::pos2(origin.x + margin, origin.y + margin);

            let painter = ui.painter_at(full_rect);

            painter.rect_filled(frame_rect, egui::Rounding::same(10.0), pal.board_frame);
            if self.is_setup() {
                painter.rect_stroke(
                    frame_rect,
                    egui::Rounding::same(10.0),
                    egui::Stroke::new(2.5, pal.setup_banner),
                );
            }

            let coord_font = egui::FontId::monospace((tile * 0.24).clamp(10.0, 18.0));
            for vx in 0..vis_cols {
                let (r_top, c_top) = self.visual_to_board(vx, 0);
                let label = if rotation % 2 == 0 {
                    ((b'a' + c_top as u8) as char).to_string()
                } else {
                    (r_top + 1).to_string()
                };
                let cx = board_origin.x + (vx as f32 + 0.5) * tile;
                painter.text(
                    egui::pos2(cx, origin.y + margin * 0.5),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
                painter.text(
                    egui::pos2(cx, board_origin.y + board_h + margin * 0.5),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
            }
            for vy in 0..vis_rows {
                let (r_left, c_left) = self.visual_to_board(0, vy);
                let label = if rotation % 2 == 0 {
                    (r_left + 1).to_string()
                } else {
                    ((b'a' + c_left as u8) as char).to_string()
                };
                let cy = board_origin.y + (vy as f32 + 0.5) * tile;
                painter.text(
                    egui::pos2(origin.x + margin * 0.5, cy),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
                painter.text(
                    egui::pos2(board_origin.x + board_w + margin * 0.5, cy),
                    egui::Align2::CENTER_CENTER,
                    &label,
                    coord_font.clone(),
                    pal.coord_text,
                );
            }

            let active_piece_sq: [u8; 16] = match &self.setup {
                Some(s) => s.piece_sq,
                None => self.pos.piece_sq,
            };

            let selected_moves: Vec<Move> = if !self.is_setup()
                && self.pos.game_result(&self.history) == GameResult::Ongoing
                && self.pos.side_to_move == self.human_side
                && self.pending_search.is_none()
            {
                if let Some(sel) = self.selected_sq {
                    self.pos
                        .gen_legal_moves(&self.history)
                        .as_slice()
                        .iter()
                        .copied()
                        .filter(|m| m.from() == sel)
                        .collect()
                } else {
                    Vec::new()
                }
            } else {
                Vec::new()
            };

            for r in 0..ROWS {
                for c in 0..COLS {
                    let sq = Square::from_rc(r, c);
                    let bit = sq.bit();
                    let (vx, vy) = self.board_to_visual(r, c);
                    let tile_rect = egui::Rect::from_min_size(
                        egui::pos2(
                            board_origin.x + vx as f32 * tile,
                            board_origin.y + vy as f32 * tile,
                        ),
                        egui::vec2(tile, tile),
                    );

                    let checker = (r + c) % 2 == 0;
                    let fill = if sq == DEN_SQ[0] {
                        pal.den_p1
                    } else if sq == DEN_SQ[1] {
                        pal.den_p2
                    } else if (bit & TRAPS_MASK[0]) != 0 {
                        pal.trap_p1
                    } else if (bit & TRAPS_MASK[1]) != 0 {
                        pal.trap_p2
                    } else if (bit & WATER_MASK) != 0 {
                        if checker {
                            pal.water_light
                        } else {
                            pal.water_dark
                        }
                    } else if checker {
                        pal.land_light
                    } else {
                        pal.land_dark
                    };

                    painter.rect_filled(tile_rect, egui::Rounding::ZERO, fill);
                    painter.rect_stroke(
                        tile_rect,
                        egui::Rounding::ZERO,
                        egui::Stroke::new(1.0, pal.grid_line),
                    );

                    let marker_font = egui::FontId::proportional((tile * 0.22).clamp(9.0, 16.0));
                    if sq == DEN_SQ[0] || sq == DEN_SQ[1] {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "DEN",
                            marker_font,
                            pal.badge_text.linear_multiply(0.65),
                        );
                    } else if (bit & (TRAPS_MASK[0] | TRAPS_MASK[1])) != 0 {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "TRAP",
                            egui::FontId::proportional((tile * 0.18).clamp(8.0, 13.0)),
                            pal.badge_text.linear_multiply(0.55),
                        );
                    } else if (bit & WATER_MASK) != 0 {
                        painter.text(
                            tile_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            "~",
                            egui::FontId::proportional((tile * 0.34).clamp(11.0, 22.0)),
                            egui::Color32::from_rgba_unmultiplied(200, 235, 255, 65),
                        );
                    }

                    if !self.is_setup() {
                        if let Some(lm) = self.last_move {
                            if lm.from() == sq || lm.to() == sq {
                                painter.rect_filled(
                                    tile_rect,
                                    egui::Rounding::ZERO,
                                    pal.last_move_tint,
                                );
                            }
                        }

                        if self.selected_sq == Some(sq) {
                            painter.rect_stroke(
                                tile_rect.shrink(2.0),
                                egui::Rounding::same(4.0),
                                egui::Stroke::new(3.0, pal.selected_ring),
                            );
                        }
                    }
                }
            }

            let piece_radius = tile * 0.39;
            for (pid, &sq_u8) in active_piece_sq.iter().enumerate() {
                if sq_u8 == CAPTURED {
                    continue;
                }
                let sq = Square(sq_u8);
                let (vx, vy) = self.board_to_visual(sq.row(), sq.col());
                let center = egui::pos2(
                    board_origin.x + (vx as f32 + 0.5) * tile,
                    board_origin.y + (vy as f32 + 0.5) * tile,
                );
                let color = if pid < 8 { Color::P1 } else { Color::P2 };
                let kind = PieceKind::from_idx(pid & 7);
                self.draw_piece_disc(&painter, center, piece_radius, color, kind, pal);
            }

            if !self.is_setup() && self.show_legal_moves {
                let opp_den = DEN_SQ[self.pos.side_to_move.opp().idx()];
                for &mv in &selected_moves {
                    let to = mv.to();
                    let (vx, vy) = self.board_to_visual(to.row(), to.col());
                    let center = egui::pos2(
                        board_origin.x + (vx as f32 + 0.5) * tile,
                        board_origin.y + (vy as f32 + 0.5) * tile,
                    );
                    let is_capture = self.pos.board_piece[to.idx()] != EMPTY_SQ;
                    if to == opp_den {
                        painter.circle_stroke(
                            center,
                            tile * 0.42,
                            egui::Stroke::new(4.0, pal.legal_win),
                        );
                    } else if is_capture {
                        painter.circle_stroke(
                            center,
                            tile * 0.42,
                            egui::Stroke::new(3.5, pal.legal_capture),
                        );
                    } else if self.move_costs_ep(mv) {
                        painter.circle_filled(center, tile * 0.16, pal.legal_ep_cost);
                    } else {
                        painter.circle_filled(center, tile * 0.14, pal.legal_quiet);
                    }
                }
            }

            // Ignore board clicks while quit confirmation modal is open
            if self.show_quit_confirm {
                return;
            }

            let px_to_sq = move |pos_px: egui::Pos2| -> Option<Square> {
                let rel_x = pos_px.x - board_origin.x;
                let rel_y = pos_px.y - board_origin.y;
                if rel_x >= 0.0 && rel_x < board_w && rel_y >= 0.0 && rel_y < board_h {
                    let vx = (rel_x / tile) as usize;
                    let vy = (rel_y / tile) as usize;
                    if vx < vis_cols && vy < vis_rows {
                        let (r, c) = visual_to_board_rot(rotation, vx, vy);
                        return Some(Square::from_rc(r, c));
                    }
                }
                None
            };

            if self.is_setup() {
                self.handle_setup_board_input(ctx, &response, &px_to_sq);
            } else if response.clicked() {
                if let Some(pos_px) = response.interact_pointer_pos() {
                    if let Some(clicked_sq) = px_to_sq(pos_px) {
                        self.handle_square_click(clicked_sq, &selected_moves, ctx);
                    } else {
                        self.selected_sq = None;
                    }
                }
            }
        });
    }

    fn handle_setup_board_input<F>(
        &mut self,
        ctx: &egui::Context,
        response: &egui::Response,
        px_to_sq: &F,
    ) where
        F: Fn(egui::Pos2) -> Option<Square>,
    {
        let (primary_down, secondary_down, primary_released, secondary_released, middle_clicked, ptr) =
            ctx.input(|i| {
                (
                    i.pointer.primary_down(),
                    i.pointer.secondary_down(),
                    i.pointer.primary_released(),
                    i.pointer.secondary_released(),
                    i.pointer.button_clicked(egui::PointerButton::Middle),
                    i.pointer.interact_pos(),
                )
            });

        let Some(setup) = self.setup.as_mut() else {
            return;
        };

        if primary_down && secondary_down {
            if !setup.chord_consumed {
                if let Some(p) = ptr {
                    if response.rect.contains(p) {
                        if let Some(sq) = px_to_sq(p) {
                            setup.remove_at(sq);
                        }
                    }
                }
                setup.chord_consumed = true;
            }
            return;
        }

        if middle_clicked {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        setup.remove_at(sq);
                    }
                }
            }
            return;
        }

        if setup.chord_consumed {
            if !primary_down && !secondary_down {
                setup.chord_consumed = false;
            }
            return;
        }

        if primary_released {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        let color = setup.brush_color;
                        let kind = setup.brush_kind;
                        setup.place_piece(color, kind, sq);
                    }
                }
            }
        } else if secondary_released {
            if let Some(p) = ptr {
                if response.rect.contains(p) {
                    if let Some(sq) = px_to_sq(p) {
                        let color = setup.brush_color.opp();
                        let kind = setup.brush_kind;
                        setup.place_piece(color, kind, sq);
                    }
                }
            }
        }
    }

    fn handle_square_click(
        &mut self,
        clicked_sq: Square,
        selected_moves: &[Move],
        ctx: &egui::Context,
    ) {
        if self.pending_search.is_some()
            || self.pos.side_to_move != self.human_side
            || self.pos.game_result(&self.history) != GameResult::Ongoing
        {
            return;
        }

        if let Some(&mv) = selected_moves.iter().find(|m| m.to() == clicked_sq) {
            self.play_move(mv);
            if self.pos.game_result(&self.history) == GameResult::Ongoing
                && self.pos.side_to_move != self.human_side
            {
                self.start_engine_search(ctx);
            }
            return;
        }

        let pid = self.pos.board_piece[clicked_sq.idx()];
        if pid != EMPTY_SQ {
            let color = if pid < 8 { Color::P1 } else { Color::P2 };
            if color == self.human_side {
                if self.selected_sq == Some(clicked_sq) {
                    self.selected_sq = None;
                } else {
                    self.selected_sq = Some(clicked_sq);
                }
                return;
            }
        }

        self.selected_sq = None;
    }
}

impl eframe::App for DsqGuiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Intercept window close button for Quit Confirmation
        if ctx.input(|i| i.viewport().close_requested()) && !self.allow_close {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.show_quit_confirm = true;
        }

        self.poll_engine();

        if self.pending_search.is_some() || self.copied_until.is_some() {
            ctx.request_repaint_after(std::time::Duration::from_millis(100));
            if let Some(t) = self.copied_until {
                if Instant::now() >= t {
                    self.copied_until = None;
                }
            }
        }

        let pal = self.theme.palette();
        self.ui_top_toolbar(ctx);
        self.ui_right_panel(ctx, &pal);
        self.ui_board_panel(ctx, &pal);
        self.ui_quit_confirmation(ctx);
    }

    fn on_exit(&mut self, _gl: Option<&eframe::glow::Context>) {
        // Safety net: if OS forces exit without the confirmation buttons, still auto-save running game
        if !self.allow_close {
            self.save_autosave();
        }
    }
}

fn parse_alg_move(s: &str) -> Option<Move> {
    if s.len() != 4 {
        return None;
    }
    let from = Square::from_alg(&s[0..2])?;
    let to = Square::from_alg(&s[2..4])?;
    Some(Move::new(from, to))
}

fn board_to_visual_rot(rotation: u8, r: usize, c: usize) -> (usize, usize) {
    match rotation % 4 {
        0 => (c, (ROWS - 1) - r),
        1 => (r, c),
        2 => ((COLS - 1) - c, r),
        _ => ((ROWS - 1) - r, (COLS - 1) - c),
    }
}

fn visual_to_board_rot(rotation: u8, vx: usize, vy: usize) -> (usize, usize) {
    match rotation % 4 {
        0 => ((ROWS - 1) - vy, vx),
        1 => (vx, vy),
        2 => (vy, (COLS - 1) - vx),
        _ => ((ROWS - 1) - vx, (COLS - 1) - vy),
    }
}

fn piece_letter(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Rat => "R",
        PieceKind::Cat => "C",
        PieceKind::Dog => "D",
        PieceKind::Wolf => "W",
        PieceKind::Leopard => "P",
        PieceKind::Tiger => "T",
        PieceKind::Lion => "L",
        PieceKind::Elephant => "E",
    }
}

fn piece_name(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Rat => "Rat",
        PieceKind::Cat => "Cat",
        PieceKind::Dog => "Dog",
        PieceKind::Wolf => "Wolf",
        PieceKind::Leopard => "Leopard",
        PieceKind::Tiger => "Tiger",
        PieceKind::Lion => "Lion",
        PieceKind::Elephant => "Elephant",
    }
}

fn piece_unicode_symbol(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Elephant => "\u{265A}", // ♚ (Rank 8)
        PieceKind::Lion => "\u{265B}",     // ♛ (Rank 7)
        PieceKind::Tiger => "\u{265C}",    // ♜ (Rank 6)
        PieceKind::Leopard => "\u{265D}",  // ♝ (Rank 5)
        PieceKind::Wolf => "\u{265E}",     // ♞ (Rank 4)
        PieceKind::Dog => "\u{265F}",      // ♟ (Rank 3)
        PieceKind::Cat => "\u{2666}",      // ♦ (Rank 2)
        PieceKind::Rat => "\u{2605}",      // ★ (Rank 1)
    }
}

fn piece_unicode_animal(kind: PieceKind) -> &'static str {
    match kind {
        PieceKind::Elephant => "\u{1F418}", // 🐘 (Rank 8)
        PieceKind::Lion => "\u{1F981}",     // 🦁 (Rank 7)
        PieceKind::Tiger => "\u{1F42F}",    // 🐯 (Rank 6)
        PieceKind::Leopard => "\u{1F406}",  // 🐆 (Rank 5)
        PieceKind::Wolf => "\u{1F43A}",     // 🐺 (Rank 4)
        PieceKind::Dog => "\u{1F436}",      // 🐶 (Rank 3)
        PieceKind::Cat => "\u{1F431}",      // 🐱 (Rank 2)
        PieceKind::Rat => "\u{1F400}",      // 🐀 (Rank 1)
    }
}

fn format_score(score: i32) -> String {
    if score.abs() >= 28_000 {
        let plies = SCORE_WIN - score.abs();
        if score > 0 {
            format!("WIN in {}", plies)
        } else {
            format!("LOSS in {}", plies)
        }
    } else {
        format!("{:+.2}", score as f64 / 100.0)
    }
}

fn install_system_symbol_fonts(ctx: &egui::Context) {
    let candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/noto/NotoEmoji-Regular.ttf",
        "/usr/share/fonts/truetype/ancient-scripts/Symbola_hint.ttf",
        "/usr/share/fonts/truetype/symbola/Symbola.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansSymbols2-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansSymbols-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ];

    let mut fonts = egui::FontDefinitions::default();
    let mut loaded_any = false;

    for (idx, path) in candidates.iter().enumerate() {
        if let Ok(bytes) = std::fs::read(path) {
            let name = format!("sys_font_{}", idx);
            fonts
                .font_data
                .insert(name.clone(), egui::FontData::from_owned(bytes));
            fonts
                .families
                .entry(egui::FontFamily::Proportional)
                .or_default()
                .push(name.clone());
            fonts
                .families
                .entry(egui::FontFamily::Monospace)
                .or_default()
                .push(name);
            loaded_any = true;
        }
    }

    if loaded_any {
        ctx.set_fonts(fonts);
    }
}

pub fn run_gui() -> Result<(), eframe::Error> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Dou Shou Qi (EP + SuperKo)")
            .with_inner_size([1180.0, 860.0])
            .with_min_inner_size([760.0, 540.0]),
        ..Default::default()
    };

    eframe::run_native(
        "Dou Shou Qi (EP + SuperKo)",
        options,
        Box::new(|cc| Ok(Box::new(DsqGuiApp::new(cc)))),
    )
}

