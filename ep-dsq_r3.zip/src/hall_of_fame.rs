//! Authenticated-encrypted Hall of Fame storage for IronMan Mode.
//!
//! Uses pure-Rust ChaCha20 (20-round stream cipher) + keyed SipHash-2-4 MAC
//! (Encrypt-then-MAC) with a fresh 96-bit nonce per save. Any tampering with the
//! encrypted file on disk is detected and rejected cleanly.

use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

const MAGIC: &[u8; 4] = b"DSQH";
const FORMAT_VERSION: u8 = 1;
const RECORD_VERSION: &str = "HOF_V1";

/// 256-bit encryption key (ChaCha20).
const ENC_KEY: [u8; 32] = [
    0x7B, 0x3E, 0x91, 0xA4, 0x52, 0xC8, 0x0F, 0x6D,
    0xE1, 0x4A, 0x89, 0x23, 0xB7, 0x60, 0xD5, 0x1C,
    0x94, 0x2F, 0xA8, 0x73, 0x19, 0xE6, 0x5B, 0xC0,
    0x38, 0xF2, 0x6A, 0x41, 0x8D, 0x0E, 0xB5, 0x97,
];

/// 128-bit authentication key (SipHash-2-4 MAC).
const MAC_KEY: [u64; 2] = [0x9C4E_71A2_5B30_D8F6, 0x3A81_E5C9_2047_BF1D];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EndCode {
    /// G: Goal (opponent Den reached)
    Goal,
    /// E: Elimination (all opponent pieces captured)
    Elimination,
    /// M: Immobilization (no legal moves left)
    Immobilization,
}

impl EndCode {
    pub const fn code_char(self) -> char {
        match self {
            EndCode::Goal => 'G',
            EndCode::Elimination => 'E',
            EndCode::Immobilization => 'M',
        }
    }

    pub const fn label(self) -> &'static str {
        match self {
            EndCode::Goal => "G (Goal/Den)",
            EndCode::Elimination => "E (Elimination)",
            EndCode::Immobilization => "M (Immobilization)",
        }
    }

    pub fn from_char(c: char) -> Option<Self> {
        match c.to_ascii_uppercase() {
            'G' => Some(EndCode::Goal),
            'E' => Some(EndCode::Elimination),
            'M' => Some(EndCode::Immobilization),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct HallOfFameEntry {
    pub timestamp_secs: u64,
    pub human_won: bool,
    pub start_depth: usize,
    pub end_depth: usize,
    pub moves: usize,
    pub plies: usize,
    pub end_code: EndCode,
}

impl HallOfFameEntry {
    pub fn formatted_date_utc(&self) -> String {
        format_unix_utc(self.timestamp_secs)
    }
}

#[derive(Clone, Debug, Default)]
pub struct HallOfFame {
    pub entries: Vec<HallOfFameEntry>,
}

impl HallOfFame {
    pub fn default_path() -> PathBuf {
        if let Ok(xdg) = std::env::var("XDG_DATA_HOME") {
            if !xdg.is_empty() {
                return PathBuf::from(xdg).join("dsq_engine").join("ironman_hof.dat");
            }
        }
        if let Ok(home) = std::env::var("HOME") {
            if !home.is_empty() {
                return PathBuf::from(home)
                    .join(".local")
                    .join("share")
                    .join("dsq_engine")
                    .join("ironman_hof.dat");
            }
        }
        PathBuf::from("ironman_hof.dat")
    }

    pub fn load_default() -> Result<Self, String> {
        Self::load_from_path(&Self::default_path())
    }

    pub fn save_default(&self) -> Result<(), String> {
        self.save_to_path(&Self::default_path())
    }

    pub fn add_entry(&mut self, entry: HallOfFameEntry) {
        self.entries.push(entry);
        self.sort_ranked();
    }

    /// Ranks entries: Human wins first (highest start_depth, then fewest plies, then newest),
    /// followed by losses (highest start_depth, then longest survival in plies, then newest).
    pub fn sort_ranked(&mut self) {
        self.entries.sort_by(|a, b| {
            b.human_won
                .cmp(&a.human_won)
                .then_with(|| b.start_depth.cmp(&a.start_depth))
                .then_with(|| {
                    if a.human_won {
                        a.plies.cmp(&b.plies)
                    } else {
                        b.plies.cmp(&a.plies)
                    }
                })
                .then_with(|| b.timestamp_secs.cmp(&a.timestamp_secs))
        });
    }

    pub fn load_from_path(path: &Path) -> Result<Self, String> {
        let data = match std::fs::read(path) {
            Ok(d) => d,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Self::default()),
            Err(e) => return Err(format!("Failed to read Hall of Fame: {}", e)),
        };
        let plaintext = decrypt_authenticated(&data)?;
        let text = String::from_utf8(plaintext)
            .map_err(|_| "Corrupted Hall of Fame encoding.".to_owned())?;
        Self::parse_plaintext(&text)
    }

    pub fn save_to_path(&self, path: &Path) -> Result<(), String> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Failed to create Hall of Fame directory: {}", e))?;
        }
        let text = self.to_plaintext();
        let nonce = generate_nonce();
        let blob = encrypt_authenticated(text.as_bytes(), &nonce);
        std::fs::write(path, blob)
            .map_err(|e| format!("Failed to write Hall of Fame: {}", e))
    }

    fn to_plaintext(&self) -> String {
        let mut out = String::new();
        out.push_str(RECORD_VERSION);
        out.push('\n');
        for e in &self.entries {
            out.push_str(&format!(
                "{}|{}|{}|{}|{}|{}|{}\n",
                e.timestamp_secs,
                if e.human_won { 1 } else { 0 },
                e.start_depth,
                e.end_depth,
                e.moves,
                e.plies,
                e.end_code.code_char()
            ));
        }
        out
    }

    fn parse_plaintext(text: &str) -> Result<Self, String> {
        let mut lines = text.lines();
        if lines.next().map(|l| l.trim()) != Some(RECORD_VERSION) {
            return Err("Unsupported Hall of Fame version.".to_owned());
        }
        let mut entries = Vec::new();
        for line in lines {
            let trimmed = line.trim();
            if trimmed.is_empty() {
                continue;
            }
            let parts: Vec<&str> = trimmed.split('|').collect();
            if parts.len() != 7 {
                return Err("Malformed Hall of Fame record.".to_owned());
            }
            let timestamp_secs = parts[0]
                .parse::<u64>()
                .map_err(|_| "Bad timestamp".to_owned())?;
            let human_won = match parts[1] {
                "1" => true,
                "0" => false,
                _ => return Err("Bad result flag".to_owned()),
            };
            let start_depth = parts[2]
                .parse::<usize>()
                .map_err(|_| "Bad start depth".to_owned())?;
            let end_depth = parts[3]
                .parse::<usize>()
                .map_err(|_| "Bad end depth".to_owned())?;
            let moves = parts[4]
                .parse::<usize>()
                .map_err(|_| "Bad move count".to_owned())?;
            let plies = parts[5]
                .parse::<usize>()
                .map_err(|_| "Bad ply count".to_owned())?;
            let code_ch = parts[6]
                .chars()
                .next()
                .ok_or_else(|| "Missing end code".to_owned())?;
            let end_code =
                EndCode::from_char(code_ch).ok_or_else(|| "Invalid end code".to_owned())?;

            entries.push(HallOfFameEntry {
                timestamp_secs,
                human_won,
                start_depth,
                end_depth,
                moves,
                plies,
                end_code,
            });
        }
        let mut hof = Self { entries };
        hof.sort_ranked();
        Ok(hof)
    }
}

pub fn now_unix_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

// ============================================================================
// Pure-Rust Authenticated Encryption: ChaCha20 + SipHash-2-4 (Encrypt-then-MAC)
// Format: MAGIC (4B) || VERSION (1B) || NONCE (12B) || CIPHERTEXT (NB) || MAC (8B)
// ============================================================================

fn generate_nonce() -> [u8; 12] {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let pid = std::process::id() as u64;
    let lo = (nanos as u64) ^ pid.wrapping_mul(0x9E37_79B9_7F4A_7C15);
    let hi = ((nanos >> 64) as u64).wrapping_add(lo.rotate_left(17));
    let mut nonce = [0u8; 12];
    nonce[0..8].copy_from_slice(&lo.to_le_bytes());
    nonce[8..12].copy_from_slice(&(hi as u32).to_le_bytes());
    nonce
}

fn encrypt_authenticated(plaintext: &[u8], nonce: &[u8; 12]) -> Vec<u8> {
    let mut out = Vec::with_capacity(4 + 1 + 12 + plaintext.len() + 8);
    out.extend_from_slice(MAGIC);
    out.push(FORMAT_VERSION);
    out.extend_from_slice(nonce);

    let mut ciphertext = plaintext.to_vec();
    chacha20_xor(&ENC_KEY, nonce, 1, &mut ciphertext);
    out.extend_from_slice(&ciphertext);

    let tag = siphash24(MAC_KEY[0], MAC_KEY[1], &out);
    out.extend_from_slice(&tag.to_le_bytes());
    out
}

fn decrypt_authenticated(blob: &[u8]) -> Result<Vec<u8>, String> {
    if blob.len() < 4 + 1 + 12 + 8 {
        return Err("Hall of Fame file is truncated or invalid.".to_owned());
    }
    if &blob[0..4] != MAGIC {
        return Err("Hall of Fame file header mismatch.".to_owned());
    }
    if blob[4] != FORMAT_VERSION {
        return Err("Unsupported Hall of Fame file format.".to_owned());
    }

    let payload_end = blob.len() - 8;
    let stored_tag = u64::from_le_bytes(blob[payload_end..].try_into().unwrap());
    let computed_tag = siphash24(MAC_KEY[0], MAC_KEY[1], &blob[..payload_end]);

    // Constant-time comparison
    if (stored_tag ^ computed_tag) != 0 {
        return Err("Hall of Fame integrity check failed (file tampered or corrupted).".to_owned());
    }

    let mut nonce = [0u8; 12];
    nonce.copy_from_slice(&blob[5..17]);

    let mut plain = blob[17..payload_end].to_vec();
    chacha20_xor(&ENC_KEY, &nonce, 1, &mut plain);
    Ok(plain)
}

#[inline]
fn quarter_round(s: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize) {
    s[a] = s[a].wrapping_add(s[b]);
    s[d] = (s[d] ^ s[a]).rotate_left(16);
    s[c] = s[c].wrapping_add(s[d]);
    s[b] = (s[b] ^ s[c]).rotate_left(12);
    s[a] = s[a].wrapping_add(s[b]);
    s[d] = (s[d] ^ s[a]).rotate_left(8);
    s[c] = s[c].wrapping_add(s[d]);
    s[b] = (s[b] ^ s[c]).rotate_left(7);
}

fn chacha20_block(key: &[u8; 32], counter: u32, nonce: &[u8; 12]) -> [u8; 64] {
    let mut state = [0u32; 16];
    state[0] = 0x6170_7865;
    state[1] = 0x3320_646e;
    state[2] = 0x7962_2d32;
    state[3] = 0x6b20_6574;
    for i in 0..8 {
        state[4 + i] = u32::from_le_bytes(key[i * 4..i * 4 + 4].try_into().unwrap());
    }
    state[12] = counter;
    state[13] = u32::from_le_bytes(nonce[0..4].try_into().unwrap());
    state[14] = u32::from_le_bytes(nonce[4..8].try_into().unwrap());
    state[15] = u32::from_le_bytes(nonce[8..12].try_into().unwrap());

    let mut working = state;
    for _ in 0..10 {
        // Column rounds
        quarter_round(&mut working, 0, 4, 8, 12);
        quarter_round(&mut working, 1, 5, 9, 13);
        quarter_round(&mut working, 2, 6, 10, 14);
        quarter_round(&mut working, 3, 7, 11, 15);
        // Diagonal rounds
        quarter_round(&mut working, 0, 5, 10, 15);
        quarter_round(&mut working, 1, 6, 11, 12);
        quarter_round(&mut working, 2, 7, 8, 13);
        quarter_round(&mut working, 3, 4, 9, 14);
    }

    let mut out = [0u8; 64];
    for i in 0..16 {
        let word = working[i].wrapping_add(state[i]).to_le_bytes();
        out[i * 4..i * 4 + 4].copy_from_slice(&word);
    }
    out
}

fn chacha20_xor(key: &[u8; 32], nonce: &[u8; 12], initial_counter: u32, data: &mut [u8]) {
    let mut counter = initial_counter;
    for chunk in data.chunks_mut(64) {
        let ks = chacha20_block(key, counter, nonce);
        for (b, k) in chunk.iter_mut().zip(ks.iter()) {
            *b ^= *k;
        }
        counter = counter.wrapping_add(1);
    }
}

#[inline]
fn sip_round(v0: &mut u64, v1: &mut u64, v2: &mut u64, v3: &mut u64) {
    *v0 = v0.wrapping_add(*v1);
    *v1 = v1.rotate_left(13);
    *v1 ^= *v0;
    *v0 = v0.rotate_left(32);
    *v2 = v2.wrapping_add(*v3);
    *v3 = v3.rotate_left(16);
    *v3 ^= *v2;
    *v0 = v0.wrapping_add(*v3);
    *v3 = v3.rotate_left(21);
    *v3 ^= *v0;
    *v2 = v2.wrapping_add(*v1);
    *v1 = v1.rotate_left(17);
    *v1 ^= *v2;
    *v2 = v2.rotate_left(32);
}

fn siphash24(k0: u64, k1: u64, data: &[u8]) -> u64 {
    let mut v0 = 0x736f_6d65_7073_6575u64 ^ k0;
    let mut v1 = 0x646f_7261_6e64_6f6du64 ^ k1;
    let mut v2 = 0x6c79_6765_6e65_7261u64 ^ k0;
    let mut v3 = 0x7465_6462_7974_6573u64 ^ k1;

    let mut chunks = data.chunks_exact(8);
    for chunk in &mut chunks {
        let m = u64::from_le_bytes(chunk.try_into().unwrap());
        v3 ^= m;
        sip_round(&mut v0, &mut v1, &mut v2, &mut v3);
        sip_round(&mut v0, &mut v1, &mut v2, &mut v3);
        v0 ^= m;
    }

    let rem = chunks.remainder();
    let mut last = ((data.len() & 0xFF) as u64) << 56;
    for (i, &b) in rem.iter().enumerate() {
        last |= (b as u64) << (i * 8);
    }

    v3 ^= last;
    sip_round(&mut v0, &mut v1, &mut v2, &mut v3);
    sip_round(&mut v0, &mut v1, &mut v2, &mut v3);
    v0 ^= last;

    v2 ^= 0xFF;
    for _ in 0..4 {
        sip_round(&mut v0, &mut v1, &mut v2, &mut v3);
    }

    v0 ^ v1 ^ v2 ^ v3
}

/// Pure-Rust UTC date-time formatter (`YYYY-MM-DD HH:MM`) using Hinnant's civil calendar algorithm.
fn format_unix_utc(secs: u64) -> String {
    let days = (secs / 86_400) as i64;
    let rem = secs % 86_400;
    let hour = rem / 3600;
    let min = (rem % 3600) / 60;

    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = (z - era * 146_097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let mut y = (yoe as i64) + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    if m <= 2 {
        y += 1;
    }
    format!("{:04}-{:02}-{:02} {:02}:{:02}", y, m, d, hour, min)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encrypt_decrypt_roundtrip_and_tamper_detection() {
        let mut hof = HallOfFame::default();
        hof.add_entry(HallOfFameEntry {
            timestamp_secs: 1_700_000_000,
            human_won: true,
            start_depth: 14,
            end_depth: 16,
            moves: 42,
            plies: 84,
            end_code: EndCode::Goal,
        });
        hof.add_entry(HallOfFameEntry {
            timestamp_secs: 1_700_001_000,
            human_won: false,
            start_depth: 12,
            end_depth: 12,
            moves: 31,
            plies: 61,
            end_code: EndCode::Immobilization,
        });

        let plain = hof.to_plaintext();
        let nonce = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        let mut enc = encrypt_authenticated(plain.as_bytes(), &nonce);

        // Plaintext markers must not leak in ciphertext
        assert!(!enc.windows(6).any(|w| w == b"HOF_V1"));

        // Valid decryption restores exact entries
        let dec = decrypt_authenticated(&enc).expect("Valid ciphertext must decrypt");
        let parsed = HallOfFame::parse_plaintext(&String::from_utf8(dec).unwrap()).unwrap();
        assert_eq!(parsed.entries, hof.entries);

        // Flipping a single bit anywhere must fail authentication!
        enc[20] ^= 0x01;
        assert!(
            decrypt_authenticated(&enc).is_err(),
            "Tampered ciphertext must be rejected!"
        );
    }

    #[test]
    fn test_ranking_order() {
        let mut hof = HallOfFame::default();
        hof.add_entry(HallOfFameEntry {
            timestamp_secs: 100,
            human_won: false,
            start_depth: 16,
            end_depth: 16,
            moves: 50,
            plies: 99,
            end_code: EndCode::Elimination,
        });
        hof.add_entry(HallOfFameEntry {
            timestamp_secs: 200,
            human_won: true,
            start_depth: 12,
            end_depth: 12,
            moves: 30,
            plies: 60,
            end_code: EndCode::Goal,
        });
        hof.add_entry(HallOfFameEntry {
            timestamp_secs: 300,
            human_won: true,
            start_depth: 16,
            end_depth: 16,
            moves: 40,
            plies: 80,
            end_code: EndCode::Goal,
        });

        assert!(hof.entries[0].human_won && hof.entries[0].start_depth == 16);
        assert!(hof.entries[1].human_won && hof.entries[1].start_depth == 12);
        assert!(!hof.entries[2].human_won);
    }

    #[test]
    fn test_date_formatting() {
        assert_eq!(format_unix_utc(0), "1970-01-01 00:00");
        assert_eq!(format_unix_utc(1_700_000_000), "2023-11-14 22:13");
    }
}

