//! Advanced handcrafted evaluation for Dou Shou Qi (EP + SuperKo).
//!
//! Strategic features:
//! - Exact compile-time BFS shortest-path distances to enemy Den for all 3 movement
//!   classes: Rat (swims), Land (walks around rivers), and Jumper (Lion/Tiger river jumps)
//! - Tapered Midgame / Endgame evaluation with enemy corner-pocket deterrence
//! - O(1) bitboard Heavy-Piece Safe-Mobility & Corner-Cage detector (prevents heavy pieces
//!   from being herded/boxed into corners, and rewards cornering enemy heavy pieces)
//! - Dynamic Dou Shou Qi predator-prey hierarchy (Rat hunting Elephant, invincible Elephant,
//!   uncontested top predator bonuses)
//! - Live River-Jump blocking detection (rewards Rats blocking enemy Lion/Tiger bank jumps)
//! - Den gatekeeper / trap-control & undefended-trap vulnerability awareness
//! - EP reserve + invasion-dominance & opponent EP-starvation scoring

use crate::core::board_bb::{BitboardPos, CAPTURED};
use crate::core::{
    Color, PieceKind, Square, COLS, DEN_SQ, INVASION_LAND_MASK, JUMPS, JUMP_COUNT, MAX_EP,
    NUM_SQUARES, ORTHO_ADJ, OWN_DEN_MASK, ROWS, TRAPS_MASK, WATER_MASK,
};

pub const SCORE_INF: i32 = 30_000;
pub const SCORE_WIN: i32 = 29_000;
pub const SCORE_WIN_THRESHOLD: i32 = 28_000;
pub const EVAL_CLAMP: i32 = 20_000;

/// Base material values indexed by `PieceKind::idx()` (Rat=0 .. Elephant=7).
pub const PIECE_VALUE: [i32; 8] = [
    245, // Rat: sole water piece & Elephant killer
    145, // Cat
    215, // Dog
    300, // Wolf
    420, // Leopard
    680, // Tiger: river jumper
    910, // Lion: dominant jumper
    975, // Elephant: dominates Lion & Tiger
];

/// Phase contribution per piece (max total phase across both sides = 48).
const PIECE_PHASE: [i32; 8] = [2, 1, 1, 2, 3, 4, 5, 6];
const MAX_PHASE: i32 = 48;

/// Non-linear value of current EP reserve `0..=10`.
const EP_VALUE: [i32; (MAX_EP as usize) + 1] = [
    -95, // 0 EP: acute SuperKo lockout / zugzwang danger
    -15, // 1 EP: fragile
    18,  // 2 EP
    36,  // 3 EP
    50,  // 4 EP
    60,  // 5 EP
    68,  // 6 EP
    74,  // 7 EP
    79,  // 8 EP
    83,  // 9 EP
    86,  // 10 EP
];

const TEMPO_BONUS: i32 = 18;

const fn sq_bit(r: usize, c: usize) -> u64 {
    1u64 << (r * COLS + c)
}

/// Opponent's back-rank corner pockets where heavy pieces get strategically boxed in.
/// P1 invading P2 corners: {a9, b9, a8, g9, f9, g8}.
/// P2 invading P1 corners: {g1, f1, g2, a1, b1, a2} (exact 180° rotation).
const OPP_CORNER_POCKET_MASK: [u64; 2] = [
    sq_bit(8, 0) | sq_bit(8, 1) | sq_bit(7, 0) | sq_bit(8, 6) | sq_bit(8, 5) | sq_bit(7, 6),
    sq_bit(0, 6) | sq_bit(0, 5) | sq_bit(1, 6) | sq_bit(0, 0) | sq_bit(0, 1) | sq_bit(1, 0),
];

/// River bank squares from which Lion & Tiger can jump across water.
const RIVER_BANK_MASK: u64 = {
    let mut m = 0u64;
    let v_cols = [1usize, 2, 4, 5];
    let mut i = 0;
    while i < 4 {
        let c = v_cols[i];
        m |= sq_bit(2, c) | sq_bit(6, c);
        i += 1;
    }
    let mut r = 3;
    while r <= 5 {
        m |= sq_bit(r, 0) | sq_bit(r, 3) | sq_bit(r, 6);
        r += 1;
    }
    m
};

/// Center corridor between the two rivers (d4, d5, d6) — key strategic highway.
const CENTER_CORRIDOR_MASK: u64 = sq_bit(3, 3) | sq_bit(4, 3) | sq_bit(5, 3);

/// Squares within Manhattan distance 2 of each player's own den (defensive zone).
const OWN_DEN_ZONE: [u64; 2] = {
    let mut zones = [0u64; 2];
    let mut side = 0;
    while side < 2 {
        let dr = DEN_SQ[side].row();
        let dc = DEN_SQ[side].col();
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let dist = r.abs_diff(dr) + c.abs_diff(dc);
                if dist >= 1 && dist <= 2 {
                    zones[side] |= sq_bit(r, c);
                }
                c += 1;
            }
            r += 1;
        }
        side += 1;
    }
    zones
};

/// Exact shortest-path distance (in moves) to opponent's Den computed at compile time.
/// mode 0 = Rat (can walk through water),
/// mode 1 = Land piece (must walk around rivers),
/// mode 2 = Jumper (Lion/Tiger: cannot enter water, can jump across rivers).
const fn build_bfs_den_dist(mode: u8) -> [[i32; NUM_SQUARES]; 2] {
    let mut tbl = [[20i32; NUM_SQUARES]; 2];
    let mut side = 0;
    while side < 2 {
        let opp = side ^ 1;
        let opp_den = DEN_SQ[opp].idx();
        let own_den_mask = OWN_DEN_MASK[side];
        tbl[side][opp_den] = 0;

        let mut pass = 0;
        while pass < 20 {
            let mut sq = 0;
            while sq < NUM_SQUARES {
                let bit = 1u64 << sq;
                let invalid = (bit & own_den_mask) != 0 || (mode != 0 && (bit & WATER_MASK) != 0);
                if !invalid {
                    let mut best = tbl[side][sq];
                    let mut adj = ORTHO_ADJ[sq] & !own_den_mask;
                    if mode != 0 {
                        adj &= !WATER_MASK;
                    }
                    while adj != 0 {
                        let to = adj.trailing_zeros() as usize;
                        adj &= adj - 1;
                        let cand = tbl[side][to] + 1;
                        if cand < best {
                            best = cand;
                        }
                    }
                    if mode == 2 {
                        let jc = JUMP_COUNT[sq] as usize;
                        let mut j = 0;
                        while j < jc {
                            let to = JUMPS[sq][j].to as usize;
                            let cand = tbl[side][to] + 1;
                            if cand < best {
                                best = cand;
                            }
                            j += 1;
                        }
                    }
                    tbl[side][sq] = best;
                }
                sq += 1;
            }
            pass += 1;
        }
        side += 1;
    }
    tbl
}

const DIST_RAT: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(0);
const DIST_LAND: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(1);
const DIST_JUMPER: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(2);

/// Midgame Piece-Square Tables indexed by `[kind 0..8][p1_sq 0..63]`.
const PST_MG: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let center_file = 3 - c.abs_diff(3) as i32; // 0..=3
                let advance = r as i32; // 0..=8
                let dist = if k == 0 {
                    DIST_RAT[0][sq]
                } else if k == 5 || k == 6 {
                    DIST_JUMPER[0][sq]
                } else {
                    DIST_LAND[0][sq]
                };

                let mut val = match k {
                    0 => {
                        let mut v = advance * 5 + center_file * 4;
                        if (sq_bit & WATER_MASK) != 0 {
                            v += 34;
                        }
                        v
                    }
                    1 => advance * 6 + center_file * 3,
                    2 => advance * 7 + center_file * 4,
                    3 => advance * 8 + center_file * 5,
                    4 => advance * 9 + center_file * 5,
                    5 => {
                        let mut v = advance * 10 + center_file * 6;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 26;
                        }
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 22;
                        }
                        v
                    }
                    6 => {
                        let mut v = advance * 11 + center_file * 7;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 32;
                        }
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 26;
                        }
                        v
                    }
                    7 => {
                        let mut v = advance * 10 + center_file * 8;
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 16;
                        }
                        v
                    }
                    _ => 0,
                };

                // Discourage heavy pieces (Leopard, Tiger, Lion, Elephant) from diving into
                // opponent's dead-end back corners & corner-pocket edge tiles.
                if k >= 4 {
                    if r == 8 && (c == 0 || c == 6) {
                        val -= 58;
                    } else if (r == 8 && (c == 1 || c == 5)) || (r == 7 && (c == 0 || c == 6)) {
                        val -= 26;
                    } else if r >= 6 && (c == 0 || c == 6) {
                        val -= 10;
                    }
                }

                if dist <= 4 {
                    val += (5 - dist) * 20;
                }
                if dist == 1 {
                    val += 30;
                }

                if k <= 4 && (sq_bit & TRAPS_MASK[0]) != 0 {
                    val += 10;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

/// Endgame Piece-Square Tables: strongly driven by exact shortest-path distance to enemy Den!
const PST_EG: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let dist = if k == 0 {
                    DIST_RAT[0][sq]
                } else if k == 5 || k == 6 {
                    DIST_JUMPER[0][sq]
                } else {
                    DIST_LAND[0][sq]
                };

                let progress = if 12 > dist { 12 - dist } else { 0 };
                let weight = match k {
                    0 => 14,
                    1 => 13,
                    2 => 14,
                    3 => 15,
                    4 => 16,
                    5 => 20,
                    6 => 22,
                    7 => 19,
                    _ => 14,
                };
                let mut val = progress * weight;

                if k >= 4 {
                    if r == 8 && (c == 0 || c == 6) {
                        val -= 45;
                    } else if (r == 8 && (c == 1 || c == 5)) || (r == 7 && (c == 0 || c == 6)) {
                        val -= 20;
                    }
                }

                if dist <= 3 {
                    val += (4 - dist) * 35;
                }
                if (k == 5 || k == 6) && (sq_bit & RIVER_BANK_MASK) != 0 {
                    val += 18;
                }
                if k == 0 && (sq_bit & WATER_MASK) != 0 {
                    val += 16;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

/// Penalty scales for boxed-in / cornered heavy pieces (`[0]=Leopard, [1]=Tiger, [2]=Lion, [3]=Elephant`).
const HEAVY_CAGE_ZERO_SAFE: [i32; 4] = [95, 130, 165, 180];
const HEAVY_CAGE_ONE_SAFE_POCKET: [i32; 4] = [38, 52, 68, 76];
const HEAVY_CAGE_ONE_SAFE_OPEN: [i32; 4] = [14, 18, 22, 26];

#[inline]
const fn manhattan(sq_a: u8, sq_b: u8) -> i32 {
    let ra = (sq_a as usize) / COLS;
    let ca = (sq_a as usize) % COLS;
    let rb = (sq_b as usize) / COLS;
    let cb = (sq_b as usize) % COLS;
    (ra.abs_diff(rb) + ca.abs_diff(cb)) as i32
}

/// Evaluates `pos` from the perspective of `pos.side_to_move`.
#[inline]
pub fn evaluate(pos: &BitboardPos) -> i32 {
    if let Some(w) = pos.winner {
        return if w == pos.side_to_move {
            SCORE_WIN
        } else {
            -SCORE_WIN
        };
    }

    let mut phase = 0i32;
    for k in 0..8usize {
        if pos.piece_sq[k] != CAPTURED {
            phase += PIECE_PHASE[k];
        }
        if pos.piece_sq[8 + k] != CAPTURED {
            phase += PIECE_PHASE[k];
        }
    }
    let mg_w = phase.min(MAX_PHASE);
    let eg_w = MAX_PHASE - mg_w;

    let (p1_mg, p1_eg) = eval_side(pos, 0);
    let (p2_mg, p2_eg) = eval_side(pos, 1);

    let mg_diff = p1_mg - p2_mg;
    let eg_diff = p1_eg - p2_eg;
    let blended = (mg_diff * mg_w + eg_diff * eg_w) / MAX_PHASE;

    let stm_score = match pos.side_to_move {
        Color::P1 => blended + TEMPO_BONUS,
        Color::P2 => -blended + TEMPO_BONUS,
    };

    stm_score.clamp(-EVAL_CLAMP, EVAL_CLAMP)
}

#[inline]
fn eval_side(pos: &BitboardPos, side: usize) -> (i32, i32) {
    let opp = side ^ 1;
    let base = side * 8;
    let opp_base = opp * 8;

    let mut mg = 0i32;
    let mut eg = 0i32;
    let mut min_den_dist = 20i32;
    let mut second_den_dist = 20i32;
    let mut highest_alive = -1i32;
    let mut opp_highest_alive = -1i32;

    // 1. Material + Tapered PST + Exact BFS Den-Race distances
    for k in 0..8usize {
        if pos.piece_sq[opp_base + k] != CAPTURED {
            opp_highest_alive = k as i32;
        }
        let sq = pos.piece_sq[base + k];
        if sq == CAPTURED {
            continue;
        }
        highest_alive = k as i32;
        let sq_idx = sq as usize;
        let pst_sq = if side == 0 { sq_idx } else { 62 - sq_idx };

        let mat = PIECE_VALUE[k];
        mg += mat + PST_MG[k][pst_sq];
        eg += mat + PST_EG[k][pst_sq];

        let d = if k == 0 {
            DIST_RAT[side][sq_idx]
        } else if k == 5 || k == 6 {
            DIST_JUMPER[side][sq_idx]
        } else {
            DIST_LAND[side][sq_idx]
        };

        if d < min_den_dist {
            second_den_dist = min_den_dist;
            min_den_dist = d;
        } else if d < second_den_dist {
            second_den_dist = d;
        }
    }

    // 2. Dynamic Dou Shou Qi Predator-Prey Hierarchy
    let own_rat = pos.piece_sq[base + PieceKind::Rat.idx()];
    let own_leo = pos.piece_sq[base + PieceKind::Leopard.idx()];
    let own_tiger = pos.piece_sq[base + PieceKind::Tiger.idx()];
    let own_lion = pos.piece_sq[base + PieceKind::Lion.idx()];
    let own_ele = pos.piece_sq[base + PieceKind::Elephant.idx()];

    let opp_rat = pos.piece_sq[opp_base + PieceKind::Rat.idx()];
    let opp_leo = pos.piece_sq[opp_base + PieceKind::Leopard.idx()];
    let opp_tiger = pos.piece_sq[opp_base + PieceKind::Tiger.idx()];
    let opp_lion = pos.piece_sq[opp_base + PieceKind::Lion.idx()];
    let opp_ele = pos.piece_sq[opp_base + PieceKind::Elephant.idx()];

    if own_ele != CAPTURED && opp_rat == CAPTURED {
        mg += 220;
        eg += 280;
    }
    if own_rat != CAPTURED && opp_ele != CAPTURED {
        mg += 115;
        eg += 130;
        let d_re = manhattan(own_rat, opp_ele);
        let hunt = (10 - d_re).max(0) * 7;
        mg += hunt;
        eg += hunt + 4;
    }
    if own_lion != CAPTURED && opp_ele == CAPTURED {
        mg += 170;
        eg += 220;
    }
    if own_tiger != CAPTURED && opp_ele == CAPTURED && opp_lion == CAPTURED {
        mg += 160;
        eg += 210;
    }
    if highest_alive > opp_highest_alive && highest_alive >= 2 {
        eg += 95;
    }

    // 3. O(1) Bitboard Heavy-Piece Safe-Mobility & Corner-Cage Detector
    // Prevents Elephant, Lion, Tiger, and Leopard from being strategically cornered/boxed in.
    let own_occ = pos.occ_side[side];
    let opp_occ = pos.occ_side[opp];
    let own_den = OWN_DEN_MASK[side];
    let opp_traps = TRAPS_MASK[opp];
    let opp_pocket = OPP_CORNER_POCKET_MASK[side];

    let mut all_rats = 0u64;
    if own_rat != CAPTURED {
        all_rats |= 1u64 << own_rat;
    }
    if opp_rat != CAPTURED {
        all_rats |= 1u64 << opp_rat;
    }

    // Build enemy predator occupancy & orthogonal attack zones incrementally (E -> L -> T -> P)
    let mut hi_occ = 0u64;
    let mut hi_atk = 0u64;
    if opp_ele != CAPTURED {
        hi_occ |= 1u64 << opp_ele;
        hi_atk |= ORTHO_ADJ[opp_ele as usize];
    }

    // Elephant (k=7): threatened by enemy Elephant and enemy land Rat
    if own_ele != CAPTURED {
        let mut ele_pred_occ = hi_occ;
        let mut ele_pred_atk = hi_atk;
        if opp_rat != CAPTURED {
            let r_bit = 1u64 << opp_rat;
            if (r_bit & WATER_MASK) == 0 {
                ele_pred_occ |= r_bit;
                ele_pred_atk |= ORTHO_ADJ[opp_rat as usize];
            }
        }
        let pen = heavy_cage_penalty(
            own_ele,
            3,
            false,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            ele_pred_occ,
            ele_pred_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Lion (k=6): threatened by enemy Elephant & Lion
    if opp_lion != CAPTURED {
        hi_occ |= 1u64 << opp_lion;
        hi_atk |= ORTHO_ADJ[opp_lion as usize];
    }
    if own_lion != CAPTURED {
        let pen = heavy_cage_penalty(
            own_lion,
            2,
            true,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            hi_occ,
            hi_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Tiger (k=5): threatened by enemy Elephant, Lion & Tiger
    if opp_tiger != CAPTURED {
        hi_occ |= 1u64 << opp_tiger;
        hi_atk |= ORTHO_ADJ[opp_tiger as usize];
    }
    if own_tiger != CAPTURED {
        let pen = heavy_cage_penalty(
            own_tiger,
            1,
            true,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            hi_occ,
            hi_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Leopard (k=4): threatened by enemy Elephant, Lion, Tiger & Leopard
    if opp_leo != CAPTURED {
        hi_occ |= 1u64 << opp_leo;
        hi_atk |= ORTHO_ADJ[opp_leo as usize];
    }
    if own_leo != CAPTURED {
        let pen = heavy_cage_penalty(
            own_leo,
            0,
            false,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            hi_occ,
            hi_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // 4. Live River-Jump Blocking (own Rat in water actively blocking enemy Lion/Tiger bank jumps)
    if own_rat != CAPTURED {
        let rat_bit = 1u64 << own_rat;
        if (rat_bit & WATER_MASK) != 0 {
            for &jumper_sq in &[opp_lion, opp_tiger] {
                if jumper_sq != CAPTURED {
                    let jc = JUMP_COUNT[jumper_sq as usize] as usize;
                    for j in 0..jc {
                        if (rat_bit & JUMPS[jumper_sq as usize][j].water_mask) != 0 {
                            mg += 28;
                            eg += 22;
                        }
                    }
                }
            }
        }
    }

    // 5. Closest-Piece & Dual-Threat Den-Race Evaluation
    if min_den_dist <= 5 {
        let bonus = (6 - min_den_dist) * 20;
        mg += bonus;
        eg += bonus * 2;
    }
    if second_den_dist <= 4 {
        let duo = (5 - second_den_dist) * 16;
        mg += duo;
        eg += duo + 20;
    }

    // 6. Den Defense & Trap Control
    let opp_invading = (opp_occ & INVASION_LAND_MASK[opp]) != 0;
    let own_defenders = (own_occ & OWN_DEN_ZONE[side]).count_ones() as i32;
    let opp_defenders = (opp_occ & OWN_DEN_ZONE[opp]).count_ones() as i32;

    if opp_invading {
        if own_defenders == 0 {
            mg -= 65;
            eg -= 95;
        } else {
            mg += own_defenders.min(2) * 20;
            eg += own_defenders.min(2) * 16;
        }
    }

    if min_den_dist <= 3 && opp_defenders == 0 {
        mg += 70;
        eg += 130;
    }

    // Vulnerable piece standing on an enemy trap while enemy has defenders nearby
    let trapped_own = own_occ & opp_traps;
    if trapped_own != 0 {
        let sq = trapped_own.trailing_zeros() as usize;
        if (ORTHO_ADJ[sq] & opp_occ) != 0 {
            mg -= 110;
            eg -= 120;
        } else if opp_defenders > 0 {
            mg -= 25;
            eg -= 25;
        }
    }

    // 7. Energy Points (EP), Invasion Dominance & Opponent EP Starvation
    let own_ep = pos.ep[side] as usize;
    let opp_ep = pos.ep[opp] as usize;
    mg += EP_VALUE[own_ep];
    eg += EP_VALUE[own_ep] + (EP_VALUE[own_ep] / 3);

    let own_invaders = (own_occ & INVASION_LAND_MASK[side]).count_ones() as i32;
    if own_invaders > 0 {
        let base_inv = if own_ep <= 2 { 55 } else { 26 };
        let extra_inv = (own_invaders - 1).min(2) * 14;
        mg += base_inv + extra_inv;
        eg += base_inv + extra_inv + 12;

        if !opp_invading {
            let squeeze = if opp_ep <= 1 {
                75
            } else if opp_ep <= 3 {
                45
            } else {
                22
            };
            mg += squeeze;
            eg += squeeze + 20;
        }
    }

    // 8. Piece count bonus
    let piece_count = own_occ.count_ones() as i32;
    mg += piece_count * 12;
    eg += piece_count * 18;

    (mg, eg)
}

#[allow(clippy::too_many_arguments)]
#[inline]
fn heavy_cage_penalty(
    sq: u8,
    tier: usize, // 0=Leopard, 1=Tiger, 2=Lion, 3=Elephant
    can_jump: bool,
    own_occ: u64,
    own_den: u64,
    opp_traps: u64,
    opp_pocket: u64,
    pred_occ: u64,
    pred_atk: u64,
    all_rats: u64,
) -> i32 {
    let sq_bit = 1u64 << sq;
    // Skip if piece is standing directly on opponent's trap (handled by trap/den-win logic)
    if (sq_bit & opp_traps) != 0 {
        return 0;
    }

    let mut exits = ORTHO_ADJ[sq as usize] & !WATER_MASK & !own_den;
    if can_jump {
        let jc = JUMP_COUNT[sq as usize] as usize;
        for j in 0..jc {
            let jump = JUMPS[sq as usize][j];
            if (all_rats & jump.water_mask) == 0 {
                exits |= 1u64 << jump.to;
            }
        }
    }

    let unblocked = exits & !own_occ & !pred_occ;
    let safe = unblocked & !pred_atk;
    let n_safe = safe.count_ones();
    if n_safe >= 2 {
        return 0;
    }

    let in_opp_pocket = (sq_bit & opp_pocket) != 0;
    if n_safe == 0 {
        let mut pen = HEAVY_CAGE_ZERO_SAFE[tier];
        if unblocked == 0 {
            pen += 75; // Completely entombed (zero legal escapes)
        }
        if in_opp_pocket {
            pen += 60; // Boxed into opponent's corner pocket
        }
        pen
    } else {
        // n_safe == 1: narrow escape lane (strongly warn inside opponent's corner pocket)
        if in_opp_pocket {
            HEAVY_CAGE_ONE_SAFE_POCKET[tier]
        } else {
            HEAVY_CAGE_ONE_SAFE_OPEN[tier]
        }
    }
}

/// Fast MVV-LVA victim/attacker value for move ordering in search.
#[inline]
pub const fn mvv_lva_value(kind_idx: usize) -> i32 {
    PIECE_VALUE[kind_idx]
}

/// Helper to check if a square is inside a given side's enemy traps.
#[inline]
pub const fn is_trapped_at(side: Color, sq: Square) -> bool {
    (sq.bit() & TRAPS_MASK[side.opp().idx()]) != 0
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::Square;

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    #[test]
    fn test_bfs_distance_tables_exact_and_symmetric() {
        for s in 0..NUM_SQUARES {
            assert_eq!(DIST_RAT[0][s], DIST_RAT[1][62 - s], "Rat dist asym at {}", s);
            assert_eq!(
                DIST_LAND[0][s],
                DIST_LAND[1][62 - s],
                "Land dist asym at {}",
                s
            );
            assert_eq!(
                DIST_JUMPER[0][s],
                DIST_JUMPER[1][62 - s],
                "Jumper dist asym at {}",
                s
            );
        }

        let b3 = sq("b3").idx();
        assert_eq!(DIST_JUMPER[0][b3], 5);
        assert_eq!(DIST_RAT[0][b3], 8);
        assert_eq!(DIST_LAND[0][b3], 8);

        let d8 = sq("d8").idx();
        assert_eq!(DIST_RAT[0][d8], 1);
        assert_eq!(DIST_LAND[0][d8], 1);
        assert_eq!(DIST_JUMPER[0][d8], 1);
    }

    #[test]
    fn test_start_position_eval_is_sane() {
        let (pos, _hist) = BitboardPos::new_start();
        let s = evaluate(&pos);
        assert!(
            s > -50 && s < 50,
            "Start position eval should be near 0, got {}",
            s
        );
    }

    #[test]
    fn test_eval_rotational_symmetry() {
        let p1_pieces = [
            (Color::P1, PieceKind::Lion, sq("g9")),      // cornered in enemy corner!
            (Color::P1, PieceKind::Rat, sq("b5")),
            (Color::P1, PieceKind::Elephant, sq("a8")),  // in enemy corner pocket!
            (Color::P2, PieceKind::Elephant, sq("f8")),  // boxing Lion in!
            (Color::P2, PieceKind::Rat, sq("b7")),       // herding Elephant!
            (Color::P2, PieceKind::Cat, sq("d2")),
        ];
        let p2_pieces: Vec<(Color, PieceKind, Square)> = p1_pieces
            .iter()
            .map(|&(c, k, s)| (c.opp(), k, Square(62 - s.0)))
            .collect();

        let (pos1, _) = BitboardPos::from_custom(&p1_pieces, Color::P1, [2, 6]);
        let (pos2, _) = BitboardPos::from_custom(&p2_pieces, Color::P2, [6, 2]);

        assert_eq!(
            evaluate(&pos1),
            evaluate(&pos2),
            "Evaluation must be perfectly rotationally symmetric!"
        );
    }

    #[test]
    fn test_heavy_piece_cornered_penalty() {
        // P1 Elephant boxed into enemy corner a9 by P2 Rat on b8 vs free Elephant in center d6
        let cornered = [
            (Color::P1, PieceKind::Elephant, sq("a9")),
            (Color::P2, PieceKind::Rat, sq("b8")),
            (Color::P2, PieceKind::Dog, sq("g7")),
        ];
        let free = [
            (Color::P1, PieceKind::Elephant, sq("d6")),
            (Color::P2, PieceKind::Rat, sq("b8")),
            (Color::P2, PieceKind::Dog, sq("g7")),
        ];
        let (pos_c, _) = BitboardPos::from_custom(&cornered, Color::P1, [4, 4]);
        let (pos_f, _) = BitboardPos::from_custom(&free, Color::P1, [4, 4]);
        assert!(
            evaluate(&pos_f) > evaluate(&pos_c) + 250,
            "Cornered Elephant must be strongly penalized! free={}, cornered={}",
            evaluate(&pos_f),
            evaluate(&pos_c)
        );

        // P1 Lion boxed into g9 by P2 Elephant on f8 vs free Lion on d6
        let lion_cornered = [
            (Color::P1, PieceKind::Lion, sq("g9")),
            (Color::P2, PieceKind::Elephant, sq("f8")),
        ];
        let lion_free = [
            (Color::P1, PieceKind::Lion, sq("d6")),
            (Color::P2, PieceKind::Elephant, sq("f8")),
        ];
        let (pos_lc, _) = BitboardPos::from_custom(&lion_cornered, Color::P1, [4, 4]);
        let (pos_lf, _) = BitboardPos::from_custom(&lion_free, Color::P1, [4, 4]);
        assert!(
            evaluate(&pos_lf) > evaluate(&pos_lc) + 250,
            "Cornered Lion must be strongly penalized! free={}, cornered={}",
            evaluate(&pos_lf),
            evaluate(&pos_lc)
        );
    }

    #[test]
    fn test_material_ep_and_starvation_dynamics() {
        let pieces_a = [
            (Color::P1, PieceKind::Lion, sq("d4")),
            (Color::P2, PieceKind::Cat, sq("d6")),
        ];
        let (pos_a, _) = BitboardPos::from_custom(&pieces_a, Color::P1, [4, 4]);
        assert!(evaluate(&pos_a) > 600);

        let pieces_starve = [
            (Color::P1, PieceKind::Cat, sq("a7")),
            (Color::P2, PieceKind::Cat, sq("g8")),
        ];
        let (pos_starve, _) = BitboardPos::from_custom(&pieces_starve, Color::P1, [4, 0]);
        let (pos_even, _) = BitboardPos::from_custom(&pieces_starve, Color::P1, [4, 4]);
        assert!(evaluate(&pos_starve) > evaluate(&pos_even) + 150);
    }
}

