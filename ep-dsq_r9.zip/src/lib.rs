pub mod classic;
pub mod core;
pub mod eval;
pub mod gui;
pub mod hall_of_fame;
pub mod search;

