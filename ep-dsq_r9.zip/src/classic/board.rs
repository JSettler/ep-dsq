//! Dedicated Classic SuperKo Bitboard Engine (Arimaa-style 3-fold repetition ban).
//!
//! Completely isolated from the EP-DSQ engine:
//! - No Energy Points (EP) exist in this mode.
//! - A move that would recreate any prior `(board layout, side-to-move)` state for
//!   the **3rd time** is illegal.
//! - Every `(board layout, side-to-move)` maps bijectively to a single `u128`
//!   (each piece square uses bits 0..5, so bit 7 of byte 0 encodes `side_to_move`
//!   with zero hash collisions).
//! - Includes an independent 9x7 array Reference Oracle (`ClassicRefGame`) and
//!   differential fuzz + perft tests proving 100% rule correctness.

use crate::core::{
    Color, GameResult, Move, PieceKind, Square, ALL_SQUARES_MASK, CAN_CAPTURE_NORMAL, DEN_SQ,
    INITIAL_PIECES, JUMPS, JUMP_COUNT, NUM_SQUARES, ORTHO_ADJ, OWN_DEN_MASK, TRAPS_MASK,
    WATER_MASK, ZOBRIST,
};

pub const CAPTURED: u8 = 63;
pub const EMPTY_SQ: u8 = 255;

/// Stack-allocated move list (theoretical max moves in DSQ is 32).
#[derive(Clone, Debug)]
pub struct ClassicMoveList {
    moves: [Move; 40],
    len: usize,
}

impl ClassicMoveList {
    #[inline]
    pub const fn new() -> Self {
        Self {
            moves: [Move::NULL; 40],
            len: 0,
        }
    }

    #[inline]
    pub fn push(&mut self, mv: Move) {
        debug_assert!(self.len < self.moves.len());
        self.moves[self.len] = mv;
        self.len += 1;
    }

    #[inline]
    pub fn as_slice(&self) -> &[Move] {
        &self.moves[..self.len]
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }
}

/// Collision-free Arimaa-style repetition history stack.
///
/// Tracks exact `u128` `(board_layout, side_to_move)` keys within the capture-pruned
/// active window, plus an O(1) counter of whether any repetition has occurred in the
/// active window (used for GHI-safe Transposition Table cutoffs).
#[derive(Clone, Debug)]
pub struct ClassicHistory {
    keys: Vec<u128>,
    bases: Vec<usize>,
    /// Number of positions in the current active window that were 2nd occurrences.
    rep_counts: Vec<u16>,
}

impl ClassicHistory {
    pub fn new(start_key: u128) -> Self {
        let mut keys = Vec::with_capacity(256);
        let mut bases = Vec::with_capacity(256);
        let mut rep_counts = Vec::with_capacity(256);
        keys.push(start_key);
        bases.push(0);
        rep_counts.push(0);
        Self {
            keys,
            bases,
            rep_counts,
        }
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.keys.len()
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }

    /// True if any repeated `(board, side)` exists in the active capture-free window.
    #[inline]
    pub fn has_active_repetitions(&self) -> bool {
        let len = self.rep_counts.len();
        unsafe { *self.rep_counts.get_unchecked(len - 1) > 0 }
    }

    /// Counts how many times `key` appears in the active capture-free window (capped at 2).
    #[inline]
    pub fn count_in_window(&self, key: u128) -> u8 {
        let len = self.keys.len();
        let base = unsafe { *self.bases.get_unchecked(len - 1) };
        let slice = &self.keys[base..len];
        let mut count = 0u8;
        let mut i = slice.len();
        while i > 0 {
            i -= 1;
            if slice[i] == key {
                count += 1;
                if count >= 2 {
                    return 2;
                }
            }
        }
        count
    }

    /// Fast check for whether creating `next_key` would be its 3rd occurrence (illegal!).
    /// Because `next_key` has opposite side-to-move from `keys.last()`, at least 4 entries
    /// must exist in the active window for 2 prior matching-side entries to exist.
    #[inline]
    pub fn is_third_occurrence(&self, next_key: u128) -> bool {
        let len = self.keys.len();
        let base = unsafe { *self.bases.get_unchecked(len - 1) };
        if len < base + 4 {
            return false;
        }
        let slice = &self.keys[base..(len - 1)];
        let mut seen = 0u8;
        let mut i = slice.len();
        while i > 0 {
            i -= 1;
            if slice[i] == next_key {
                seen += 1;
                if seen >= 2 {
                    return true;
                }
            }
        }
        false
    }

    #[inline]
    pub fn push(&mut self, key: u128, is_capture: bool) {
        let len = self.keys.len();
        if is_capture {
            self.keys.push(key);
            self.bases.push(len);
            self.rep_counts.push(0);
        } else {
            let base = unsafe { *self.bases.get_unchecked(len - 1) };
            let prev_reps = unsafe { *self.rep_counts.get_unchecked(len - 1) };
            // Check whether `key` already occurred once in the active window
            let mut repeated = false;
            if len >= base + 2 {
                let slice = &self.keys[base..(len - 1)];
                let mut i = slice.len();
                while i > 0 {
                    i -= 1;
                    if slice[i] == key {
                        repeated = true;
                        break;
                    }
                }
            }
            self.keys.push(key);
            self.bases.push(base);
            self.rep_counts.push(prev_reps + repeated as u16);
        }
    }

    #[inline]
    pub fn pop(&mut self) {
        debug_assert!(self.keys.len() > 1, "Cannot pop initial position");
        self.keys.pop();
        self.bases.pop();
        self.rep_counts.pop();
    }
}

#[inline]
pub const fn encode_state_key(mut piece_sq: [u8; 16], side: Color) -> u128 {
    if matches!(side, Color::P2) {
        piece_sq[0] |= 0x80;
    }
    u128::from_ne_bytes(piece_sq)
}

#[derive(Clone, Copy, Debug)]
pub struct ClassicPos {
    pub occ_side: [u64; 2],
    /// Indexed by `piece_id = color.idx() * 8 + kind.idx()`. Value `0..63` or `CAPTURED (63)`.
    pub piece_sq: [u8; 16],
    /// Mailbox: `piece_id (0..16)` or `EMPTY_SQ (255)` for each square `0..63`.
    pub board_piece: [u8; 64],
    /// Incremental Zobrist hash of board piece layout ONLY.
    pub pos_hash: u64,
    pub side_to_move: Color,
    pub winner: Option<Color>,
}

impl ClassicPos {
    pub fn new_start() -> (Self, ClassicHistory) {
        Self::from_custom(&INITIAL_PIECES, Color::P1)
    }

    pub fn from_custom(
        pieces: &[(Color, PieceKind, Square)],
        side_to_move: Color,
    ) -> (Self, ClassicHistory) {
        let mut pos = ClassicPos {
            occ_side: [0; 2],
            piece_sq: [CAPTURED; 16],
            board_piece: [EMPTY_SQ; 64],
            pos_hash: 0,
            side_to_move,
            winner: None,
        };

        for &(color, kind, sq) in pieces {
            let pid = color.idx() * 8 + kind.idx();
            assert_eq!(pos.piece_sq[pid], CAPTURED, "Duplicate piece kind");
            assert_eq!(pos.board_piece[sq.idx()], EMPTY_SQ, "Duplicate square");

            pos.piece_sq[pid] = sq.0;
            pos.board_piece[sq.idx()] = pid as u8;
            pos.occ_side[color.idx()] |= sq.bit();
            pos.pos_hash ^= ZOBRIST.piece[pid][sq.idx()];
        }

        pos.assert_valid();
        let hist = ClassicHistory::new(pos.state_key());
        (pos, hist)
    }

    /// Exact 128-bit canonical signature of `(board layout, side_to_move)`.
    #[inline]
    pub const fn state_key(&self) -> u128 {
        encode_state_key(self.piece_sq, self.side_to_move)
    }

    /// Transposition Table hash (board layout + side to move; no EP).
    #[inline]
    pub const fn tt_hash(&self) -> u64 {
        if matches!(self.side_to_move, Color::P2) {
            self.pos_hash ^ ZOBRIST.side
        } else {
            self.pos_hash
        }
    }

    pub fn assert_valid(&self) {
        assert_eq!(self.occ_side[0] & self.occ_side[1], 0, "Side overlap");
        assert_eq!(
            (self.occ_side[0] | self.occ_side[1]) & !ALL_SQUARES_MASK,
            0,
            "Bit 63 set"
        );
        assert_eq!(self.occ_side[0] & OWN_DEN_MASK[0], 0, "P1 in own den");
        assert_eq!(self.occ_side[1] & OWN_DEN_MASK[1], 0, "P2 in own den");

        let mut recomputed_occ = [0u64; 2];
        let mut recomputed_hash = 0u64;
        let mut seen_sq = 0u64;

        for pid in 0..16 {
            let sq = self.piece_sq[pid];
            if sq == CAPTURED {
                continue;
            }
            assert!((sq as usize) < NUM_SQUARES, "Invalid sq {}", sq);
            let bit = 1u64 << sq;
            assert_eq!(seen_sq & bit, 0, "Two pieces on sq {}", sq);
            seen_sq |= bit;

            let side = pid / 8;
            let kind = PieceKind::from_idx(pid % 8);
            if !kind.can_enter_water() {
                assert_eq!(bit & WATER_MASK, 0, "Non-rat in water");
            }
            assert_eq!(
                self.board_piece[sq as usize], pid as u8,
                "Mailbox mismatch at sq {}",
                sq
            );
            recomputed_occ[side] |= bit;
            recomputed_hash ^= ZOBRIST.piece[pid][sq as usize];
        }

        assert_eq!(self.occ_side, recomputed_occ, "occ_side mismatch");
        assert_eq!(self.pos_hash, recomputed_hash, "pos_hash mismatch");

        for sq in 0..NUM_SQUARES {
            let pid = self.board_piece[sq];
            if pid == EMPTY_SQ {
                assert_eq!(seen_sq & (1u64 << sq), 0, "Mailbox empty but piece present");
            } else {
                assert!((pid as usize) < 16);
                assert_eq!(self.piece_sq[pid as usize], sq as u8);
            }
        }
    }

    #[inline]
    fn all_rats_mask(&self) -> u64 {
        let mut m = 0u64;
        let r0 = self.piece_sq[0];
        if r0 != CAPTURED {
            m |= 1u64 << r0;
        }
        let r1 = self.piece_sq[8];
        if r1 != CAPTURED {
            m |= 1u64 << r1;
        }
        m
    }

    /// Returns how many times the resulting `(board, next_side)` has ALREADY appeared
    /// in the active window (0 = new, 1 = would be 2nd occurrence, 2 = would be 3rd = illegal).
    #[inline]
    pub fn prior_occurrences_after(&self, mv: Move, history: &ClassicHistory) -> u8 {
        let opp_den_sq = DEN_SQ[self.side_to_move.opp().idx()].0;
        if mv.to().0 == opp_den_sq || self.board_piece[mv.to().idx()] != EMPTY_SQ {
            return 0;
        }
        let pid = self.board_piece[mv.from().idx()] as usize;
        let mut next_sq = self.piece_sq;
        next_sq[pid] = mv.to().0;
        let next_key = encode_state_key(next_sq, self.side_to_move.opp());
        history.count_in_window(next_key)
    }

    #[inline]
    pub fn gen_legal_moves(&self, history: &ClassicHistory) -> ClassicMoveList {
        let mut list = ClassicMoveList::new();
        if self.winner.is_some() {
            return list;
        }

        let stm = self.side_to_move.idx();
        let opp_color = self.side_to_move.opp();
        let opp = opp_color.idx();
        let own_occ = self.occ_side[stm];
        let opp_occ = self.occ_side[opp];
        let own_den = OWN_DEN_MASK[stm];
        let own_traps = TRAPS_MASK[stm];
        let opp_traps = TRAPS_MASK[opp];
        let opp_den_sq = DEN_SQ[opp].0;
        let check_3fold = history.has_active_repetitions();
        let base_pid = stm * 8;
        let all_rats = self.all_rats_mask();

        for kind_idx in 0..8usize {
            let pid = base_pid + kind_idx;
            let from = self.piece_sq[pid];
            if from == CAPTURED {
                continue;
            }
            let from_bit = 1u64 << from;
            let from_in_water = (from_bit & WATER_MASK) != 0;
            let att_trapped = (from_bit & opp_traps) != 0;

            let mut targets = ORTHO_ADJ[from as usize] & !own_occ & !own_den;
            if kind_idx != PieceKind::Rat.idx() {
                targets &= !WATER_MASK;

                if kind_idx == PieceKind::Tiger.idx() || kind_idx == PieceKind::Lion.idx() {
                    let jc = JUMP_COUNT[from as usize] as usize;
                    for j in 0..jc {
                        let jump = JUMPS[from as usize][j];
                        if (all_rats & jump.water_mask) == 0 {
                            let to_bit = 1u64 << jump.to;
                            if (to_bit & own_occ) == 0 {
                                targets |= to_bit;
                            }
                        }
                    }
                }
            }

            while targets != 0 {
                let to = targets.trailing_zeros() as u8;
                targets &= targets - 1;
                let to_bit = 1u64 << to;

                if (to_bit & opp_occ) != 0 {
                    if att_trapped {
                        continue;
                    }
                    let to_in_water = (to_bit & WATER_MASK) != 0;
                    if from_in_water != to_in_water {
                        continue;
                    }
                    if (to_bit & own_traps) == 0 {
                        let def_pid = self.board_piece[to as usize] as usize;
                        let def_kind = def_pid & 7;
                        if !CAN_CAPTURE_NORMAL[kind_idx][def_kind] {
                            continue;
                        }
                    }
                    list.push(Move::new(Square(from), Square(to)));
                } else {
                    if check_3fold && to != opp_den_sq {
                        let mut next_sq = self.piece_sq;
                        next_sq[pid] = to;
                        if history.is_third_occurrence(encode_state_key(next_sq, opp_color)) {
                            continue;
                        }
                    }
                    list.push(Move::new(Square(from), Square(to)));
                }
            }
        }

        list
    }

    /// Generates ONLY legal captures and immediate opponent-den winning moves.
    #[inline]
    pub fn gen_tactical_moves(&self) -> ClassicMoveList {
        let mut list = ClassicMoveList::new();
        if self.winner.is_some() {
            return list;
        }

        let stm = self.side_to_move.idx();
        let opp = stm ^ 1;
        let opp_occ = self.occ_side[opp];
        let opp_den_bit = OWN_DEN_MASK[opp];
        let opp_den_sq = DEN_SQ[opp].0;
        let interesting = opp_occ | opp_den_bit;
        let own_traps = TRAPS_MASK[stm];
        let opp_traps = TRAPS_MASK[opp];
        let base_pid = stm * 8;
        let all_rats = self.all_rats_mask();

        for kind_idx in 0..8usize {
            let pid = base_pid + kind_idx;
            let from = self.piece_sq[pid];
            if from == CAPTURED {
                continue;
            }
            let from_bit = 1u64 << from;
            let mut targets = ORTHO_ADJ[from as usize] & interesting;
            if kind_idx != PieceKind::Rat.idx() {
                targets &= !WATER_MASK;

                if kind_idx == PieceKind::Tiger.idx() || kind_idx == PieceKind::Lion.idx() {
                    let jc = JUMP_COUNT[from as usize] as usize;
                    for j in 0..jc {
                        let jump = JUMPS[from as usize][j];
                        let to_bit = 1u64 << jump.to;
                        if (to_bit & opp_occ) != 0 && (all_rats & jump.water_mask) == 0 {
                            targets |= to_bit;
                        }
                    }
                }
            }

            if targets == 0 {
                continue;
            }

            let from_in_water = (from_bit & WATER_MASK) != 0;
            let att_trapped = (from_bit & opp_traps) != 0;

            while targets != 0 {
                let to = targets.trailing_zeros() as u8;
                targets &= targets - 1;

                if to == opp_den_sq {
                    list.push(Move::new(Square(from), Square(to)));
                    continue;
                }

                if att_trapped {
                    continue;
                }
                let to_bit = 1u64 << to;
                let to_in_water = (to_bit & WATER_MASK) != 0;
                if from_in_water != to_in_water {
                    continue;
                }
                if (to_bit & own_traps) == 0 {
                    let def_pid = self.board_piece[to as usize] as usize;
                    let def_kind = def_pid & 7;
                    if !CAN_CAPTURE_NORMAL[kind_idx][def_kind] {
                        continue;
                    }
                }
                list.push(Move::new(Square(from), Square(to)));
            }
        }

        list
    }

    #[inline]
    pub fn has_any_legal_move(&self, history: &ClassicHistory) -> bool {
        if self.winner.is_some() {
            return false;
        }

        let stm = self.side_to_move.idx();
        let opp_color = self.side_to_move.opp();
        let opp = opp_color.idx();
        let own_occ = self.occ_side[stm];
        let opp_occ = self.occ_side[opp];
        let all_occ = own_occ | opp_occ;
        let own_den = OWN_DEN_MASK[stm];
        let check_3fold = history.has_active_repetitions();
        let base_pid = stm * 8;

        // Fast path when no 2nd repetition exists yet: any empty legal adjacent tile suffices!
        if !check_3fold {
            let blocked_land = all_occ | own_den | WATER_MASK;
            let blocked_rat = all_occ | own_den;
            for kind_idx in 0..8usize {
                let from = self.piece_sq[base_pid + kind_idx];
                if from == CAPTURED {
                    continue;
                }
                let blocked = if kind_idx == PieceKind::Rat.idx() {
                    blocked_rat
                } else {
                    blocked_land
                };
                if (ORTHO_ADJ[from as usize] & !blocked) != 0 {
                    return true;
                }
            }
        }

        let own_traps = TRAPS_MASK[stm];
        let opp_traps = TRAPS_MASK[opp];
        let opp_den_sq = DEN_SQ[opp].0;
        let all_rats = self.all_rats_mask();

        for kind_idx in 0..8usize {
            let pid = base_pid + kind_idx;
            let from = self.piece_sq[pid];
            if from == CAPTURED {
                continue;
            }
            let from_bit = 1u64 << from;
            let from_in_water = (from_bit & WATER_MASK) != 0;
            let att_trapped = (from_bit & opp_traps) != 0;

            let mut targets = ORTHO_ADJ[from as usize] & !own_occ & !own_den;
            if kind_idx != PieceKind::Rat.idx() {
                targets &= !WATER_MASK;

                if kind_idx == PieceKind::Tiger.idx() || kind_idx == PieceKind::Lion.idx() {
                    let jc = JUMP_COUNT[from as usize] as usize;
                    for j in 0..jc {
                        let jump = JUMPS[from as usize][j];
                        if (all_rats & jump.water_mask) == 0 {
                            let to_bit = 1u64 << jump.to;
                            if (to_bit & own_occ) == 0 {
                                targets |= to_bit;
                            }
                        }
                    }
                }
            }

            while targets != 0 {
                let to = targets.trailing_zeros() as u8;
                targets &= targets - 1;
                let to_bit = 1u64 << to;

                if (to_bit & opp_occ) != 0 {
                    if att_trapped {
                        continue;
                    }
                    let to_in_water = (to_bit & WATER_MASK) != 0;
                    if from_in_water != to_in_water {
                        continue;
                    }
                    if (to_bit & own_traps) == 0 {
                        let def_pid = self.board_piece[to as usize] as usize;
                        let def_kind = def_pid & 7;
                        if !CAN_CAPTURE_NORMAL[kind_idx][def_kind] {
                            continue;
                        }
                    }
                    return true;
                } else {
                    if check_3fold && to != opp_den_sq {
                        let mut next_sq = self.piece_sq;
                        next_sq[pid] = to;
                        if history.is_third_occurrence(encode_state_key(next_sq, opp_color)) {
                            continue;
                        }
                    }
                    return true;
                }
            }
        }

        false
    }

    #[inline]
    pub fn make_move(&self, mv: Move, history: &mut ClassicHistory) -> ClassicPos {
        debug_assert!(self.winner.is_none());

        let stm = self.side_to_move.idx();
        let opp_color = self.side_to_move.opp();
        let opp = opp_color.idx();
        let from = mv.from().0;
        let to = mv.to().0;
        let pid = self.board_piece[from as usize] as usize;
        debug_assert!(pid < 16 && pid / 8 == stm);

        let cap_pid = self.board_piece[to as usize];
        let is_capture = cap_pid != EMPTY_SQ;

        let mut next = *self;

        next.piece_sq[pid] = to;
        next.board_piece[from as usize] = EMPTY_SQ;
        next.board_piece[to as usize] = pid as u8;
        next.occ_side[stm] ^= (1u64 << from) | (1u64 << to);
        next.pos_hash ^= ZOBRIST.piece[pid][from as usize] ^ ZOBRIST.piece[pid][to as usize];

        if is_capture {
            let cpid = cap_pid as usize;
            debug_assert_eq!(cpid / 8, opp);
            next.piece_sq[cpid] = CAPTURED;
            next.occ_side[opp] ^= 1u64 << to;
            next.pos_hash ^= ZOBRIST.piece[cpid][to as usize];
        }

        next.side_to_move = opp_color;
        let next_key = next.state_key();

        if to == DEN_SQ[opp].0 || next.occ_side[opp] == 0 {
            next.winner = Some(self.side_to_move);
            history.push(next_key, is_capture);
            #[cfg(debug_assertions)]
            next.assert_valid();
            return next;
        }

        debug_assert!(
            is_capture || !history.is_third_occurrence(next_key),
            "Classic engine executed illegal 3rd-occurrence repetition!"
        );

        history.push(next_key, is_capture);

        #[cfg(debug_assertions)]
        next.assert_valid();

        next
    }

    pub fn game_result(&self, history: &ClassicHistory) -> GameResult {
        if let Some(w) = self.winner {
            return GameResult::Win(w);
        }
        if !self.has_any_legal_move(history) {
            return GameResult::Win(self.side_to_move.opp());
        }
        GameResult::Ongoing
    }

    pub fn perft(&self, history: &mut ClassicHistory, depth: u32) -> u64 {
        if depth == 0 {
            return 1;
        }
        let moves = self.gen_legal_moves(history);
        if depth == 1 {
            return moves.len() as u64;
        }
        let mut nodes = 0u64;
        for &mv in moves.as_slice() {
            let child = self.make_move(mv, history);
            nodes += child.perft(history, depth - 1);
            history.pop();
        }
        nodes
    }
}

// ============================================================================
// Independent Reference Oracle & Exhaustive Verification Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::board_ref::{RefGame, RefGrid, RefPiece};
    use crate::core::{Rng, COLS, ROWS};

    #[derive(Clone)]
    struct ClassicRefGame {
        grid: RefGrid,
        side_to_move: Color,
        winner: Option<Color>,
        /// Full unpruned history of `(grid, side_to_move)` since ply 0.
        history: Vec<(RefGrid, Color)>,
    }

    impl ClassicRefGame {
        fn new_start() -> Self {
            Self::from_custom(&INITIAL_PIECES, Color::P1)
        }

        fn from_custom(pieces: &[(Color, PieceKind, Square)], side_to_move: Color) -> Self {
            let mut grid: RefGrid = [[None; COLS]; ROWS];
            for &(color, kind, sq) in pieces {
                grid[sq.row()][sq.col()] = Some(RefPiece { color, kind });
            }
            Self {
                grid,
                side_to_move,
                winner: None,
                history: vec![(grid, side_to_move)],
            }
        }

        fn count_occurrences(&self, grid: &RefGrid, side: Color) -> usize {
            self.history
                .iter()
                .filter(|(g, s)| *s == side && g == grid)
                .count()
        }

        fn can_capture(
            att: RefPiece,
            fr: usize,
            fc: usize,
            def: RefPiece,
            tr: usize,
            tc: usize,
        ) -> bool {
            if RefGame::is_water(fr, fc) != RefGame::is_water(tr, tc) {
                return false;
            }
            if RefGame::is_trap(att.color.opp(), fr, fc) {
                return false;
            }
            if RefGame::is_trap(def.color.opp(), tr, tc) {
                return true;
            }
            match (att.kind, def.kind) {
                (PieceKind::Rat, PieceKind::Elephant) => true,
                (PieceKind::Elephant, PieceKind::Rat) => false,
                (a, d) => a.rank() >= d.rank(),
            }
        }

        fn legal_moves(&self) -> Vec<Move> {
            if self.winner.is_some() {
                return Vec::new();
            }
            let stm = self.side_to_move;
            let opp = stm.opp();
            let mut moves = Vec::with_capacity(32);
            let dirs: [(isize, isize); 4] = [(-1, 0), (1, 0), (0, -1), (0, 1)];

            for r in 0..ROWS {
                for c in 0..COLS {
                    let Some(piece) = self.grid[r][c] else {
                        continue;
                    };
                    if piece.color != stm {
                        continue;
                    }
                    for &(dr, dc) in &dirs {
                        let nr = r as isize + dr;
                        let nc = c as isize + dc;
                        if nr < 0 || nr >= ROWS as isize || nc < 0 || nc >= COLS as isize {
                            continue;
                        }
                        let mut tr = nr as usize;
                        let mut tc = nc as usize;

                        if RefGame::is_water(tr, tc) {
                            if piece.kind.can_enter_water() {
                            } else if piece.kind.can_jump() {
                                let mut blocked = false;
                                while RefGame::is_water(tr, tc) {
                                    if self.grid[tr][tc].is_some() {
                                        blocked = true;
                                        break;
                                    }
                                    tr = (tr as isize + dr) as usize;
                                    tc = (tc as isize + dc) as usize;
                                }
                                if blocked {
                                    continue;
                                }
                            } else {
                                continue;
                            }
                        }

                        if RefGame::is_den(stm, tr, tc) {
                            continue;
                        }

                        if let Some(target) = self.grid[tr][tc] {
                            if target.color == stm {
                                continue;
                            }
                            if !Self::can_capture(piece, r, c, target, tr, tc) {
                                continue;
                            }
                        }

                        let mut next_grid = self.grid;
                        next_grid[r][c] = None;
                        next_grid[tr][tc] = Some(piece);
                        if !RefGame::is_den(opp, tr, tc)
                            && self.grid[tr][tc].is_none()
                            && self.count_occurrences(&next_grid, opp) >= 2
                        {
                            continue;
                        }

                        moves.push(Move::new(Square::from_rc(r, c), Square::from_rc(tr, tc)));
                    }
                }
            }
            moves
        }

        fn make_move(&self, mv: Move) -> Self {
            let stm = self.side_to_move;
            let opp = stm.opp();
            let from = mv.from();
            let to = mv.to();
            let piece = self.grid[from.row()][from.col()].unwrap();

            let mut next = self.clone();
            next.grid[from.row()][from.col()] = None;
            next.grid[to.row()][to.col()] = Some(piece);
            next.side_to_move = opp;

            let opp_alive = next
                .grid
                .iter()
                .flatten()
                .any(|p| p.map(|x| x.color == opp).unwrap_or(false));
            if RefGame::is_den(opp, to.row(), to.col()) || !opp_alive {
                next.winner = Some(stm);
            }
            next.history.push((next.grid, opp));
            next
        }

        fn perft(&self, depth: u32) -> u64 {
            if depth == 0 {
                return 1;
            }
            let moves = self.legal_moves();
            if depth == 1 {
                return moves.len() as u64;
            }
            let mut n = 0;
            for mv in moves {
                n += self.make_move(mv).perft(depth - 1);
            }
            n
        }
    }

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    fn mv(a: &str, b: &str) -> Move {
        Move::new(sq(a), sq(b))
    }

    fn assert_agree(ref_g: &ClassicRefGame, bb: &ClassicPos, hist: &ClassicHistory) {
        bb.assert_valid();
        assert_eq!(ref_g.side_to_move, bb.side_to_move);
        assert_eq!(ref_g.winner, bb.winner);
        assert_eq!(ref_g.history.len(), hist.len());

        let mut rm = ref_g.legal_moves();
        let mut bm = bb.gen_legal_moves(hist).as_slice().to_vec();
        rm.sort();
        bm.sort();
        assert_eq!(rm, bm, "Classic legal moves mismatch!");
        assert_eq!(bb.has_any_legal_move(hist), !bm.is_empty());

        let opp_den = DEN_SQ[bb.side_to_move.opp().idx()];
        let mut expected_tac: Vec<Move> = bm
            .iter()
            .copied()
            .filter(|m| m.to() == opp_den || bb.board_piece[m.to().idx()] != EMPTY_SQ)
            .collect();
        let mut actual_tac = bb.gen_tactical_moves().as_slice().to_vec();
        expected_tac.sort();
        actual_tac.sort();
        assert_eq!(expected_tac, actual_tac, "Classic tactical moves mismatch!");
    }

    #[test]
    fn test_arimaa_3fold_repetition_ban_exact() {
        let pieces = [
            (Color::P1, PieceKind::Cat, sq("a1")),
            (Color::P2, PieceKind::Cat, sq("g9")),
        ];
        let mut ref_g = ClassicRefGame::from_custom(&pieces, Color::P1);
        let (mut bb, mut hist) = ClassicPos::from_custom(&pieces, Color::P1);

        // Cycle 1 -> creates 2nd occurrence of (a1, g9, P1) — ALLOWED!
        for m in [mv("a1", "a2"), mv("g9", "g8"), mv("a2", "a1"), mv("g8", "g9")] {
            ref_g = ref_g.make_move(m);
            bb = bb.make_move(m, &mut hist);
            assert_agree(&ref_g, &bb, &hist);
        }
        assert!(hist.has_active_repetitions());

        // Cycle 2 up to ply 7 -> next move g8->g9 would create (a1, g9, P1) for the 3RD time!
        for m in [mv("a1", "a2"), mv("g9", "g8"), mv("a2", "a1")] {
            ref_g = ref_g.make_move(m);
            bb = bb.make_move(m, &mut hist);
            assert_agree(&ref_g, &bb, &hist);
        }

        // Now P2 is on g8: g8->g9 MUST BE ILLEGAL (3rd occurrence), while g8->f8 is LEGAL!
        let p2_moves = bb.gen_legal_moves(&hist);
        assert!(
            !p2_moves.as_slice().contains(&mv("g8", "g9")),
            "3rd repetition with same side-to-move MUST be illegal!"
        );
        assert!(p2_moves.as_slice().contains(&mv("g8", "f8")));
    }

    #[test]
    fn test_same_board_opposite_side_does_not_count_toward_3fold() {
        // Using Lion's vertical jump (b3->b7, parity shift) to revisit the same board
        // with OPPOSITE side to move — must NOT count as a same-side repetition!
        let pieces = [
            (Color::P1, PieceKind::Lion, sq("b3")),
            (Color::P2, PieceKind::Cat, sq("g9")),
        ];
        let mut ref_g = ClassicRefGame::from_custom(&pieces, Color::P1);
        let (mut bb, mut hist) = ClassicPos::from_custom(&pieces, Color::P1);

        // First, revisit (b3, g9, P1) once normally (now count for P1 = 2)
        for m in [mv("b3", "a3"), mv("g9", "f9"), mv("a3", "b3"), mv("f9", "g9")] {
            ref_g = ref_g.make_move(m);
            bb = bb.make_move(m, &mut hist);
            assert_agree(&ref_g, &bb, &hist);
        }

        // Now do the odd-length Lion jump loop so P1 returns to b3 on ply 17 with P2 to move!
        let loop_moves = [
            mv("b3", "b7"),
            mv("g9", "f9"),
            mv("b7", "a7"),
            mv("f9", "g9"),
            mv("a7", "a6"),
            mv("g9", "f9"),
            mv("a6", "a5"),
            mv("f9", "g9"),
            mv("a5", "a4"),
            mv("g9", "f9"),
            mv("a4", "a3"),
            mv("f9", "g9"),
        ];
        for m in loop_moves {
            ref_g = ref_g.make_move(m);
            bb = bb.make_move(m, &mut hist);
            assert_agree(&ref_g, &bb, &hist);
        }

        // a3->b3 creates board (b3, g9) with P2 to move (0 prior times with P2 to move!) => MUST BE LEGAL!
        let legal = bb.gen_legal_moves(&hist);
        assert!(
            legal.as_slice().contains(&mv("a3", "b3")),
            "Same board with DIFFERENT side-to-move must NOT be blocked by Arimaa 3-fold rule!"
        );
    }

    #[test]
    fn test_classic_perft_agrees_with_reference() {
        let ref_g = ClassicRefGame::new_start();
        let (bb, mut hist) = ClassicPos::new_start();
        for d in 1..=4 {
            assert_eq!(ref_g.perft(d), bb.perft(&mut hist, d));
            assert_eq!(hist.len(), 1);
        }
    }

    #[test]
    fn test_classic_differential_fuzz_full_and_endgame_stress() {
        let mut rng = Rng::new(0xC1A5_51C0_3F01_D123);

        // 50 full random games
        for _ in 0..50 {
            let mut ref_g = ClassicRefGame::new_start();
            let (mut bb, mut hist) = ClassicPos::new_start();
            for _ in 0..200 {
                assert_agree(&ref_g, &bb, &hist);
                let moves = bb.gen_legal_moves(&hist);
                if moves.is_empty() {
                    break;
                }
                let m = moves.as_slice()[rng.gen_range(moves.len())];
                ref_g = ref_g.make_move(m);
                bb = bb.make_move(m, &mut hist);
            }
        }

        // 200 sparse endgame stress tests (heavily triggers 2nd & 3rd repetitions!)
        for _ in 0..200 {
            let mut used = [false; 63];
            let mut pieces = Vec::new();
            let n1 = 1 + rng.gen_range(2);
            let n2 = 1 + rng.gen_range(2);
            for (color, cnt) in [(Color::P1, n1), (Color::P2, n2)] {
                let mut used_k = [false; 8];
                let mut placed = 0;
                while placed < cnt {
                    let k = rng.gen_range(8);
                    if used_k[k] {
                        continue;
                    }
                    let kind = PieceKind::from_idx(k);
                    let s_idx = rng.gen_range(63);
                    let s = Square(s_idx as u8);
                    if used[s_idx] {
                        continue;
                    }
                    if !kind.can_enter_water() && RefGame::is_water(s.row(), s.col()) {
                        continue;
                    }
                    if RefGame::is_den(Color::P1, s.row(), s.col())
                        || RefGame::is_den(Color::P2, s.row(), s.col())
                    {
                        continue;
                    }
                    used[s_idx] = true;
                    used_k[k] = true;
                    pieces.push((color, kind, s));
                    placed += 1;
                }
            }
            let stm = if rng.gen_range(2) == 0 {
                Color::P1
            } else {
                Color::P2
            };
            let mut ref_g = ClassicRefGame::from_custom(&pieces, stm);
            let (mut bb, mut hist) = ClassicPos::from_custom(&pieces, stm);

            for _ in 0..180 {
                assert_agree(&ref_g, &bb, &hist);
                let moves = bb.gen_legal_moves(&hist);
                if moves.is_empty() {
                    break;
                }
                let m = moves.as_slice()[rng.gen_range(moves.len())];
                ref_g = ref_g.make_move(m);
                bb = bb.make_move(m, &mut hist);
            }
        }
    }
}

