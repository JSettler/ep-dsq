//! High-speed Principal Variation Search (PVS) engine for Dou Shou Qi (EP + SuperKo).
//!
//! Single-threaded speed & tactical-strength features:
//! - 2-slot cache-line Transposition Table cluster (depth-preferred + always-replace)
//! - Exact 1-instruction Den-Win & Den-Check ("in check") detection:
//!   * Never prunes/reduces when defending a 1-ply den threat
//!   * 1-ply Den-Check extension for deep trap/den tactics
//!   * Exact `in_den_check` handling in Quiescence Search (disables stand-pat & delta pruning)
//! - Improving heuristic + Internal Iterative Reductions (IIR) + Razoring + Late Move Pruning (LMP)
//! - Zero heap allocations during search (stack-allocated triangular PV table)
//! - GHI-safe SuperKo TT tracking (clean beta cutoffs + move-only hints on tainted nodes)
//! - Zero-overhead cooperative Stop flag & per-depth live `SearchProgress` reporting

use crate::core::board_bb::{BitboardPos, History, EMPTY_SQ};
use crate::core::{Move, Square, DEN_SQ, ORTHO_ADJ, TRAPS_MASK};
use crate::eval::{evaluate, mvv_lva_value, SCORE_INF, SCORE_WIN, SCORE_WIN_THRESHOLD};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::Sender;
use std::sync::Arc;
use std::time::{Duration, Instant};

pub const MAX_PLY: usize = 96;
const DEFAULT_TT_MB: usize = 32;

/// Live progress snapshot emitted once per completed iterative-deepening depth.
#[derive(Clone, Copy, Debug)]
pub struct SearchProgress {
    pub best_move: Move,
    pub score: i32,
    pub depth: usize,
    pub nodes: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
enum Bound {
    Empty = 0,
    Exact = 1,
    Lower = 2,
    Upper = 3,
}

/// Compact 16-byte Transposition Table entry.
#[derive(Clone, Copy, Debug)]
#[repr(C)]
struct TTEntry {
    key: u64,
    best_move: Move,
    score: i16,
    depth: i8,
    /// Low 2 bits = Bound, High 6 bits = generation age.
    bound_age: u8,
    _pad: u16,
}

impl TTEntry {
    const EMPTY: TTEntry = TTEntry {
        key: 0,
        best_move: Move::NULL,
        score: 0,
        depth: -1,
        bound_age: 0,
        _pad: 0,
    };

    #[inline]
    const fn bound(self) -> Bound {
        match self.bound_age & 0x03 {
            1 => Bound::Exact,
            2 => Bound::Lower,
            3 => Bound::Upper,
            _ => Bound::Empty,
        }
    }

    #[inline]
    const fn age(self) -> u8 {
        self.bound_age >> 2
    }

    #[inline]
    const fn pack_bound_age(bound: Bound, age: u8) -> u8 {
        (bound as u8) | ((age & 0x3F) << 2)
    }
}

/// 2-slot cache-friendly TT bucket (32 bytes = 2 buckets per 64B CPU cache line).
/// Slot 0: depth-preferred. Slot 1: always-replace.
#[derive(Clone, Copy, Debug)]
#[repr(C)]
struct TTBucket {
    slots: [TTEntry; 2],
}

impl TTBucket {
    const EMPTY: TTBucket = TTBucket {
        slots: [TTEntry::EMPTY; 2],
    };
}

pub struct TranspositionTable {
    buckets: Vec<TTBucket>,
    mask: usize,
    age: u8,
}

impl TranspositionTable {
    pub fn new_mb(mb: usize) -> Self {
        let bytes = mb.max(1) * 1024 * 1024;
        let bucket_size = std::mem::size_of::<TTBucket>();
        let raw_count = (bytes / bucket_size).max(1024);
        let count = (raw_count.next_power_of_two() >> 1).max(1024);
        Self {
            buckets: vec![TTBucket::EMPTY; count],
            mask: count - 1,
            age: 0,
        }
    }

    pub fn clear(&mut self) {
        self.buckets.fill(TTBucket::EMPTY);
        self.age = 0;
    }

    pub fn next_age(&mut self) {
        self.age = (self.age + 1) & 0x3F;
    }

    #[inline]
    fn probe(&self, key: u64) -> Option<TTEntry> {
        let bucket = unsafe { self.buckets.get_unchecked((key as usize) & self.mask) };
        let s0 = bucket.slots[0];
        if s0.bound() != Bound::Empty && s0.key == key {
            return Some(s0);
        }
        let s1 = bucket.slots[1];
        if s1.bound() != Bound::Empty && s1.key == key {
            return Some(s1);
        }
        None
    }

    #[inline]
    fn store(&mut self, key: u64, best_move: Move, score: i32, depth: i32, bound: Bound) {
        let idx = (key as usize) & self.mask;
        let bucket = unsafe { self.buckets.get_unchecked_mut(idx) };
        let d8 = depth.clamp(-1, 120) as i8;
        let s16 = score.clamp(-SCORE_INF, SCORE_INF) as i16;
        let ba = TTEntry::pack_bound_age(bound, self.age);

        if bucket.slots[0].key == key && bucket.slots[0].bound() != Bound::Empty {
            if best_move != Move::NULL {
                bucket.slots[0].best_move = best_move;
            }
            if d8 >= bucket.slots[0].depth
                || bound == Bound::Exact
                || bucket.slots[0].age() != self.age
            {
                bucket.slots[0].score = s16;
                bucket.slots[0].depth = d8;
                bucket.slots[0].bound_age = ba;
            }
            return;
        }

        let s0 = bucket.slots[0];
        let replace_s0 = s0.bound() == Bound::Empty
            || s0.age() != self.age
            || d8 >= s0.depth
            || (bound == Bound::Exact && depth >= 2);

        if replace_s0 {
            if s0.bound() != Bound::Empty && s0.key != key {
                bucket.slots[1] = s0;
            }
            bucket.slots[0] = TTEntry {
                key,
                best_move,
                score: s16,
                depth: d8,
                bound_age: ba,
                _pad: 0,
            };
        } else {
            let mv = if best_move != Move::NULL {
                best_move
            } else if bucket.slots[1].key == key {
                bucket.slots[1].best_move
            } else {
                Move::NULL
            };
            bucket.slots[1] = TTEntry {
                key,
                best_move: mv,
                score: s16,
                depth: d8,
                bound_age: ba,
                _pad: 0,
            };
        }
    }

    #[inline]
    fn store_move_hint(&mut self, key: u64, best_move: Move) {
        if best_move == Move::NULL {
            return;
        }
        let idx = (key as usize) & self.mask;
        let bucket = unsafe { self.buckets.get_unchecked_mut(idx) };
        if bucket.slots[0].key == key && bucket.slots[0].bound() != Bound::Empty {
            bucket.slots[0].best_move = best_move;
            return;
        }
        if bucket.slots[1].key == key && bucket.slots[1].bound() != Bound::Empty {
            bucket.slots[1].best_move = best_move;
            return;
        }
        if bucket.slots[1].bound() == Bound::Empty || bucket.slots[1].age() != self.age {
            bucket.slots[1] = TTEntry {
                key,
                best_move,
                score: 0,
                depth: -1,
                bound_age: TTEntry::pack_bound_age(Bound::Upper, self.age),
                _pad: 0,
            };
        }
    }
}

fn build_lmr_table() -> [[i32; 40]; 64] {
    let mut tbl = [[0i32; 40]; 64];
    for d in 1..64 {
        for m in 1..40 {
            let r = 0.65 + (d as f64).ln() * (m as f64).ln() / 2.20;
            tbl[d][m] = (r as i32).max(1);
        }
    }
    tbl
}

#[derive(Clone, Copy, Debug)]
pub struct SearchLimits {
    pub max_depth: usize,
    pub max_time: Option<Duration>,
    pub max_nodes: Option<u64>,
}

impl SearchLimits {
    pub fn depth(d: usize) -> Self {
        Self {
            max_depth: d.min(MAX_PLY - 1),
            max_time: None,
            max_nodes: None,
        }
    }

    pub fn time_ms(ms: u64) -> Self {
        Self {
            max_depth: MAX_PLY - 1,
            max_time: Some(Duration::from_millis(ms)),
            max_nodes: None,
        }
    }

    pub fn nodes(n: u64) -> Self {
        Self {
            max_depth: MAX_PLY - 1,
            max_time: None,
            max_nodes: Some(n),
        }
    }
}

#[derive(Clone, Debug)]
pub struct SearchResult {
    pub best_move: Move,
    pub score: i32,
    pub depth: usize,
    pub nodes: u64,
    pub elapsed: Duration,
    pub pv: Vec<Move>,
}

pub struct Searcher {
    tt: TranspositionTable,
    killers: [[Move; 2]; MAX_PLY],
    countermoves: [[Move; 64]; 64],
    history_heur: [[[i32; 64]; 64]; 2],
    eval_stack: [i32; MAX_PLY],
    pv_table: [[Move; MAX_PLY]; MAX_PLY],
    pv_len: [usize; MAX_PLY],
    lmr: [[i32; 40]; 64],
    nodes: u64,
    start_time: Instant,
    limits: SearchLimits,
    stop_flag: Option<Arc<AtomicBool>>,
    aborted: bool,
    pub verbose: bool,
}

impl Searcher {
    pub fn new() -> Self {
        Self::with_tt_mb(DEFAULT_TT_MB)
    }

    pub fn with_tt_mb(mb: usize) -> Self {
        Self {
            tt: TranspositionTable::new_mb(mb),
            killers: [[Move::NULL; 2]; MAX_PLY],
            countermoves: [[Move::NULL; 64]; 64],
            history_heur: [[[0; 64]; 64]; 2],
            eval_stack: [SCORE_INF; MAX_PLY],
            pv_table: [[Move::NULL; MAX_PLY]; MAX_PLY],
            pv_len: [0; MAX_PLY],
            lmr: build_lmr_table(),
            nodes: 0,
            start_time: Instant::now(),
            limits: SearchLimits::depth(1),
            stop_flag: None,
            aborted: false,
            verbose: false,
        }
    }

    pub fn clear_tables(&mut self) {
        self.tt.clear();
        self.killers = [[Move::NULL; 2]; MAX_PLY];
        self.countermoves = [[Move::NULL; 64]; 64];
        self.history_heur = [[[0; 64]; 64]; 2];
        self.eval_stack = [SCORE_INF; MAX_PLY];
    }

    #[inline]
    fn score_to_tt(score: i32, ply: usize) -> i32 {
        if score >= SCORE_WIN_THRESHOLD {
            score + ply as i32
        } else if score <= -SCORE_WIN_THRESHOLD {
            score - ply as i32
        } else {
            score
        }
    }

    #[inline]
    fn score_from_tt(score: i32, ply: usize) -> i32 {
        if score >= SCORE_WIN_THRESHOLD {
            score - ply as i32
        } else if score <= -SCORE_WIN_THRESHOLD {
            score + ply as i32
        } else {
            score
        }
    }

    #[inline]
    fn check_limits(&mut self) -> bool {
        if self.aborted {
            return true;
        }
        if (self.nodes & 4095) == 0 {
            if let Some(flag) = &self.stop_flag {
                if flag.load(Ordering::Relaxed) {
                    self.aborted = true;
                    return true;
                }
            }
            if let Some(max_nodes) = self.limits.max_nodes {
                if self.nodes >= max_nodes {
                    self.aborted = true;
                    return true;
                }
            }
            if let Some(max_time) = self.limits.max_time {
                if self.start_time.elapsed() >= max_time {
                    self.aborted = true;
                    return true;
                }
            }
        }
        false
    }

    fn decay_history(&mut self) {
        for side in 0..2 {
            for f in 0..64 {
                for t in 0..64 {
                    self.history_heur[side][f][t] /= 2;
                }
            }
        }
    }

    #[inline]
    fn update_history(&mut self, side: usize, mv: Move, bonus: i32) {
        let entry = &mut self.history_heur[side][mv.from().idx()][mv.to().idx()];
        let clamped = bonus.clamp(-16_384, 16_384);
        *entry += clamped - (*entry * clamped.abs()) / 32_768;
    }

    #[inline]
    fn update_pv(&mut self, ply: usize, mv: Move) {
        self.pv_table[ply][0] = mv;
        let child_len = if ply + 1 < MAX_PLY {
            self.pv_len[ply + 1].min(MAX_PLY - 1 - ply)
        } else {
            0
        };
        for k in 0..child_len {
            self.pv_table[ply][k + 1] = self.pv_table[ply + 1][k];
        }
        self.pv_len[ply] = child_len + 1;
    }

    pub fn search(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        limits: SearchLimits,
    ) -> SearchResult {
        self.search_with_hooks(pos, history, limits, None, None)
    }

    /// Runs iterative deepening search with optional cooperative `stop_flag` and
    /// per-depth `progress_tx` reporting (zero overhead inside the search tree).
    pub fn search_with_hooks(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        limits: SearchLimits,
        stop_flag: Option<Arc<AtomicBool>>,
        progress_tx: Option<Sender<SearchProgress>>,
    ) -> SearchResult {
        let initial_hist_len = history.len();
        self.nodes = 0;
        self.start_time = Instant::now();
        self.limits = limits;
        self.stop_flag = stop_flag;
        self.aborted = false;
        self.tt.next_age();
        self.killers = [[Move::NULL; 2]; MAX_PLY];
        self.eval_stack = [SCORE_INF; MAX_PLY];
        self.decay_history();

        let root_moves = pos.gen_legal_moves(history);
        if root_moves.is_empty() {
            self.stop_flag = None;
            return SearchResult {
                best_move: Move::NULL,
                score: -SCORE_WIN,
                depth: 0,
                nodes: 0,
                elapsed: self.start_time.elapsed(),
                pv: Vec::new(),
            };
        }

        let mut best_move = root_moves.as_slice()[0];
        let mut best_score = 0i32;
        let mut completed_depth = 0usize;
        let mut best_pv: Vec<Move> = vec![best_move];

        let max_depth = limits.max_depth.clamp(1, MAX_PLY - 1);

        for depth in 1..=max_depth {
            // Check cooperative stop before starting a deeper iteration (always finish depth 1!)
            if depth > 1 {
                if let Some(flag) = &self.stop_flag {
                    if flag.load(Ordering::Relaxed) {
                        break;
                    }
                }
            }

            let mut alpha = -SCORE_INF;
            let mut beta = SCORE_INF;
            let mut delta = 40i32;

            if depth >= 5 && best_score.abs() < SCORE_WIN_THRESHOLD {
                alpha = (best_score - delta).max(-SCORE_INF);
                beta = (best_score + delta).min(SCORE_INF);
            }

            let score = loop {
                self.pv_len[0] = 0;
                let (s, _tainted) =
                    self.negamax(pos, history, depth as i32, 0, alpha, beta, true, Move::NULL);

                if self.aborted && depth > 1 {
                    break s;
                }

                if s <= alpha {
                    alpha = (alpha - delta).max(-SCORE_INF);
                    delta *= 2;
                } else if s >= beta {
                    beta = (beta + delta).min(SCORE_INF);
                    delta *= 2;
                } else {
                    break s;
                }

                if delta > 800 {
                    alpha = -SCORE_INF;
                    beta = SCORE_INF;
                }
            };

            if self.aborted && depth > 1 {
                break;
            }

            if self.pv_len[0] > 0 {
                best_move = self.pv_table[0][0];
                best_score = score;
                completed_depth = depth;
                best_pv.clear();
                best_pv.extend_from_slice(&self.pv_table[0][..self.pv_len[0]]);

                if let Some(tx) = &progress_tx {
                    let _ = tx.send(SearchProgress {
                        best_move,
                        score: best_score,
                        depth: completed_depth,
                        nodes: self.nodes,
                    });
                }
            }

            if self.verbose {
                let dt = self.start_time.elapsed().as_secs_f64();
                let nps = if dt > 0.0 {
                    (self.nodes as f64 / dt) as u64
                } else {
                    0
                };
                let pv_str: String = best_pv
                    .iter()
                    .map(|m| m.to_string())
                    .collect::<Vec<_>>()
                    .join(" ");
                println!(
                    "info depth {:>2} score {:>6} nodes {:>9} nps {:>9} time {:>5}ms pv {}",
                    completed_depth,
                    best_score,
                    self.nodes,
                    nps,
                    self.start_time.elapsed().as_millis(),
                    pv_str
                );
            }

            if best_score.abs() >= SCORE_WIN_THRESHOLD {
                let plies_to_win = (SCORE_WIN - best_score.abs()) as usize;
                if plies_to_win <= depth {
                    break;
                }
            }

            if let Some(max_time) = limits.max_time {
                if self.start_time.elapsed() * 100 >= max_time * 55 {
                    break;
                }
            }
        }

        self.stop_flag = None;
        debug_assert_eq!(
            history.len(),
            initial_hist_len,
            "History stack leaked during search!"
        );

        SearchResult {
            best_move,
            score: best_score,
            depth: completed_depth,
            nodes: self.nodes,
            elapsed: self.start_time.elapsed(),
            pv: best_pv,
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn negamax(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        mut depth: i32,
        ply: usize,
        mut alpha: i32,
        beta: i32,
        is_pv: bool,
        prev_move: Move,
    ) -> (i32, bool) {
        if is_pv {
            self.pv_len[ply] = 0;
        }

        if let Some(w) = pos.winner {
            let s = if w == pos.side_to_move {
                SCORE_WIN - ply as i32
            } else {
                -SCORE_WIN + ply as i32
            };
            return (s, false);
        }

        if ply >= MAX_PLY - 1 {
            return (evaluate(pos), false);
        }

        let stm = pos.side_to_move.idx();
        let opp = stm ^ 1;
        let opp_den_sq = DEN_SQ[opp].0;

        // 1. Exact 1-CPU-instruction immediate Den-Win detector
        let den_attackers = pos.occ_side[stm] & ORTHO_ADJ[opp_den_sq as usize];
        if den_attackers != 0 {
            if is_pv {
                let from = den_attackers.trailing_zeros() as u8;
                self.pv_table[ply][0] = Move::new(Square(from), Square(opp_den_sq));
                self.pv_len[ply] = 1;
            }
            return (SCORE_WIN - (ply as i32 + 1), false);
        }

        // 2. Exact 1-CPU-instruction Den-Check detector
        let in_den_check = (pos.occ_side[opp] & ORTHO_ADJ[DEN_SQ[stm].0 as usize]) != 0;
        if in_den_check && ply < MAX_PLY - 4 {
            depth += 1;
        }

        if depth <= 0 {
            return (self.qsearch(pos, history, ply, alpha, beta), false);
        }

        self.nodes += 1;
        if ply > 0 && self.check_limits() {
            return (0, true);
        }

        let low_ep_risk = pos.ep[0] == 0 || pos.ep[1] == 0;
        let tt_key = pos.tt_hash();
        let mut tt_move = Move::NULL;

        if let Some(entry) = self.tt.probe(tt_key) {
            tt_move = entry.best_move;
            if !is_pv && !low_ep_risk && entry.depth >= 1 && entry.depth as i32 >= depth {
                let tt_score = Self::score_from_tt(entry.score as i32, ply);
                match entry.bound() {
                    Bound::Exact => return (tt_score, false),
                    Bound::Lower if tt_score >= beta => return (tt_score, false),
                    Bound::Upper if tt_score <= alpha => return (tt_score, false),
                    _ => {}
                }
            }
        }

        let static_eval = if in_den_check {
            self.eval_stack[ply] = SCORE_INF;
            SCORE_INF
        } else {
            let ev = evaluate(pos);
            self.eval_stack[ply] = ev;
            ev
        };

        let improving = !in_den_check
            && ply >= 2
            && self.eval_stack[ply - 2] != SCORE_INF
            && static_eval > self.eval_stack[ply - 2];

        if !is_pv && !in_den_check && !low_ep_risk && beta.abs() < SCORE_WIN_THRESHOLD {
            if depth <= 4 {
                let margin = 95 * depth - if improving { 20 } else { 0 };
                if static_eval - margin >= beta {
                    return (static_eval, false);
                }
            }

            if depth <= 2 && alpha.abs() < SCORE_WIN_THRESHOLD {
                let razor_margin = 230 * depth + if improving { 45 } else { 0 };
                if static_eval + razor_margin <= alpha {
                    let q = self.qsearch(pos, history, ply, alpha, alpha + 1);
                    if self.aborted && ply > 0 {
                        return (0, true);
                    }
                    if q <= alpha {
                        return (q, false);
                    }
                }
            }
        }

        if depth >= 4 && tt_move == Move::NULL && !in_den_check {
            depth -= 1;
        }

        let legal = pos.gen_legal_moves(history);
        let move_count = legal.len();
        if move_count == 0 {
            return (-SCORE_WIN + ply as i32, low_ep_risk);
        }

        let orig_alpha = alpha;
        let mut best_score = -SCORE_INF;
        let mut best_move = Move::NULL;
        let mut any_tainted = low_ep_risk;
        let mut cutoff_tainted = low_ep_risk;
        let mut did_cutoff = false;

        let mut moves: [Move; 40] = [Move::NULL; 40];
        let mut scores: [i32; 40] = [0; 40];
        moves[..move_count].copy_from_slice(legal.as_slice());

        let opp_traps = TRAPS_MASK[opp];

        let mut start_idx = 0usize;
        if tt_move != Move::NULL {
            if let Some(pos_idx) = moves[..move_count].iter().position(|&m| m == tt_move) {
                moves.swap(0, pos_idx);
                let mv = moves[0];
                let is_capture = pos.board_piece[mv.to().idx()] != EMPTY_SQ;
                let child = pos.make_move(mv, history);
                let repeated_here = child.ep[stm] < pos.ep[stm];

                let (s, ct) = self.negamax(
                    &child,
                    history,
                    depth - 1,
                    ply + 1,
                    -beta,
                    -alpha,
                    is_pv,
                    mv,
                );
                history.pop();

                if self.aborted && ply > 0 {
                    return (0, true);
                }

                let score = -s;
                let move_tainted = repeated_here || ct;
                if move_tainted {
                    any_tainted = true;
                }

                best_score = score;
                best_move = mv;

                if score > alpha {
                    alpha = score;
                    if is_pv {
                        self.update_pv(ply, mv);
                    }
                    if alpha >= beta {
                        did_cutoff = true;
                        cutoff_tainted = low_ep_risk || move_tainted;
                        if !is_capture {
                            if self.killers[ply][0] != mv {
                                self.killers[ply][1] = self.killers[ply][0];
                                self.killers[ply][0] = mv;
                            }
                            if prev_move != Move::NULL {
                                self.countermoves[prev_move.from().idx()][prev_move.to().idx()] =
                                    mv;
                            }
                            self.update_history(stm, mv, depth * depth * 16);
                        }
                    }
                }
                start_idx = 1;
            }
        }

        if !did_cutoff && start_idx < move_count {
            let k1 = self.killers[ply][0];
            let k2 = self.killers[ply][1];
            let cm = if prev_move != Move::NULL {
                self.countermoves[prev_move.from().idx()][prev_move.to().idx()]
            } else {
                Move::NULL
            };

            for i in start_idx..move_count {
                let mv = moves[i];
                let victim = pos.board_piece[mv.to().idx()];
                scores[i] = if victim != EMPTY_SQ {
                    let att = pos.board_piece[mv.from().idx()] as usize & 7;
                    let vic = victim as usize & 7;
                    500_000 + mvv_lva_value(vic) * 16 - mvv_lva_value(att)
                } else if (mv.to().bit() & opp_traps) != 0 {
                    450_000
                } else if mv == k1 {
                    400_000
                } else if mv == k2 {
                    390_000
                } else if mv == cm {
                    380_000
                } else {
                    self.history_heur[stm][mv.from().idx()][mv.to().idx()]
                };
            }

            let can_futility = !is_pv
                && !in_den_check
                && !low_ep_risk
                && depth <= 2
                && static_eval != SCORE_INF
                && alpha.abs() < SCORE_WIN_THRESHOLD
                && static_eval + 135 * depth <= alpha;

            let lmp_limit: usize = if !is_pv && !in_den_check && !low_ep_risk && depth <= 3 {
                let base_lim = match depth {
                    1 => 6,
                    2 => 10,
                    _ => 15,
                };
                if improving {
                    base_lim + 3
                } else {
                    base_lim
                }
            } else {
                usize::MAX
            };

            let mut quiet_tried: [Move; 40] = [Move::NULL; 40];
            let mut quiet_count = 0usize;

            for i in start_idx..move_count {
                let mut best_idx = i;
                let mut best_order = scores[i];
                for j in (i + 1)..move_count {
                    if scores[j] > best_order {
                        best_order = scores[j];
                        best_idx = j;
                    }
                }
                if best_idx != i {
                    moves.swap(i, best_idx);
                    scores.swap(i, best_idx);
                }
                let mv = moves[i];
                let is_capture = pos.board_piece[mv.to().idx()] != EMPTY_SQ;
                let gives_den_check = (mv.to().bit() & opp_traps) != 0;

                if !is_capture && !gives_den_check && mv != k1 && mv != k2 {
                    if can_futility && i >= 2 {
                        continue;
                    }
                    if quiet_count >= lmp_limit && best_score > -SCORE_WIN_THRESHOLD {
                        continue;
                    }
                }

                let child = pos.make_move(mv, history);
                let repeated_here = child.ep[stm] < pos.ep[stm];

                let (score, child_tainted) = if i == 0 {
                    let (s, ct) = self.negamax(
                        &child,
                        history,
                        depth - 1,
                        ply + 1,
                        -beta,
                        -alpha,
                        is_pv,
                        mv,
                    );
                    (-s, ct)
                } else {
                    let mut reduction = 0;
                    if depth >= 3
                        && i >= 3
                        && !in_den_check
                        && !is_capture
                        && !gives_den_check
                        && mv != k1
                        && mv != k2
                    {
                        let d_idx = (depth as usize).min(63);
                        let m_idx = i.min(39);
                        reduction = self.lmr[d_idx][m_idx];
                        if is_pv {
                            reduction -= 1;
                        }
                        if !improving {
                            reduction += 1;
                        }
                        let hist_val = self.history_heur[stm][mv.from().idx()][mv.to().idx()];
                        if hist_val > 4_000 {
                            reduction -= 1;
                        } else if hist_val < -4_000 {
                            reduction += 1;
                        }
                        reduction = reduction.clamp(0, depth - 2);
                    }

                    let (mut s, mut ct) = self.negamax(
                        &child,
                        history,
                        depth - 1 - reduction,
                        ply + 1,
                        -alpha - 1,
                        -alpha,
                        false,
                        mv,
                    );
                    s = -s;

                    if reduction > 0 && s > alpha && !(self.aborted && ply > 0) {
                        let (s2, ct2) = self.negamax(
                            &child,
                            history,
                            depth - 1,
                            ply + 1,
                            -alpha - 1,
                            -alpha,
                            false,
                            mv,
                        );
                        s = -s2;
                        ct |= ct2;
                    }

                    if s > alpha && s < beta && !(self.aborted && ply > 0) {
                        let (s3, ct3) = self.negamax(
                            &child,
                            history,
                            depth - 1,
                            ply + 1,
                            -beta,
                            -alpha,
                            is_pv,
                            mv,
                        );
                        s = -s3;
                        ct |= ct3;
                    }
                    (s, ct)
                };

                history.pop();

                if self.aborted && ply > 0 {
                    return (0, true);
                }

                let move_tainted = repeated_here || child_tainted;
                if move_tainted {
                    any_tainted = true;
                }

                if score > best_score {
                    best_score = score;
                    best_move = mv;

                    if score > alpha {
                        alpha = score;
                        if is_pv {
                            self.update_pv(ply, mv);
                        }

                        if alpha >= beta {
                            did_cutoff = true;
                            cutoff_tainted = low_ep_risk || move_tainted;
                            if !is_capture {
                                if self.killers[ply][0] != mv {
                                    self.killers[ply][1] = self.killers[ply][0];
                                    self.killers[ply][0] = mv;
                                }
                                if prev_move != Move::NULL {
                                    self.countermoves[prev_move.from().idx()]
                                        [prev_move.to().idx()] = mv;
                                }
                                let bonus = depth * depth * 16;
                                self.update_history(stm, mv, bonus);
                                for &qmv in &quiet_tried[..quiet_count] {
                                    self.update_history(stm, qmv, -bonus);
                                }
                            }
                            break;
                        }
                    }
                }

                if !is_capture {
                    quiet_tried[quiet_count] = mv;
                    quiet_count += 1;
                }
            }
        }

        let final_tainted = if did_cutoff {
            cutoff_tainted
        } else {
            any_tainted
        };

        if !self.aborted && best_move != Move::NULL {
            if !final_tainted {
                let bound = if best_score <= orig_alpha {
                    Bound::Upper
                } else if best_score >= beta {
                    Bound::Lower
                } else {
                    Bound::Exact
                };
                self.tt.store(
                    tt_key,
                    best_move,
                    Self::score_to_tt(best_score, ply),
                    depth,
                    bound,
                );
            } else {
                self.tt.store_move_hint(tt_key, best_move);
            }
        }

        (best_score, final_tainted)
    }

    fn qsearch(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        ply: usize,
        mut alpha: i32,
        beta: i32,
    ) -> i32 {
        if let Some(w) = pos.winner {
            return if w == pos.side_to_move {
                SCORE_WIN - ply as i32
            } else {
                -SCORE_WIN + ply as i32
            };
        }

        let stm = pos.side_to_move.idx();
        let opp = stm ^ 1;
        let opp_den_sq = DEN_SQ[opp].0;

        if (pos.occ_side[stm] & ORTHO_ADJ[opp_den_sq as usize]) != 0 {
            return SCORE_WIN - (ply as i32 + 1);
        }

        if ply >= MAX_PLY - 1 {
            return evaluate(pos);
        }

        self.nodes += 1;
        if self.check_limits() {
            return 0;
        }

        let in_den_check = (pos.occ_side[opp] & ORTHO_ADJ[DEN_SQ[stm].0 as usize]) != 0;

        let stand_pat = if !in_den_check {
            let sp = evaluate(pos);
            if sp >= beta {
                if !pos.has_any_legal_move(history) {
                    return -SCORE_WIN + ply as i32;
                }
                return beta;
            }
            if sp > alpha {
                alpha = sp;
            }
            sp
        } else {
            -SCORE_INF
        };

        let tactical = pos.gen_tactical_moves();
        let cap_len = tactical.len();
        if cap_len == 0 {
            if !pos.has_any_legal_move(history) {
                return -SCORE_WIN + ply as i32;
            }
            if in_den_check {
                return -SCORE_WIN + (ply as i32 + 2);
            }
            return alpha;
        }

        let mut captures: [Move; 32] = [Move::NULL; 32];
        let mut cap_scores: [i32; 32] = [0; 32];
        let mut kept = 0usize;
        let own_traps = TRAPS_MASK[stm];

        for &mv in tactical.as_slice() {
            let vic = pos.board_piece[mv.to().idx()] as usize & 7;
            if !in_den_check && stand_pat + mvv_lva_value(vic) + 250 < alpha {
                continue;
            }
            let att = pos.board_piece[mv.from().idx()] as usize & 7;
            let trap_save_bonus = if (mv.to().bit() & own_traps) != 0 {
                500_000
            } else {
                0
            };
            captures[kept] = mv;
            cap_scores[kept] = trap_save_bonus + mvv_lva_value(vic) * 16 - mvv_lva_value(att);
            kept += 1;
        }

        let mut best_score = if in_den_check { -SCORE_INF } else { alpha };

        for i in 0..kept {
            let mut best_idx = i;
            let mut best_order = cap_scores[i];
            for j in (i + 1)..kept {
                if cap_scores[j] > best_order {
                    best_order = cap_scores[j];
                    best_idx = j;
                }
            }
            if best_idx != i {
                captures.swap(i, best_idx);
                cap_scores.swap(i, best_idx);
            }
            let mv = captures[i];

            let child = pos.make_move(mv, history);
            let score = -self.qsearch(&child, history, ply + 1, -beta, -alpha);
            history.pop();

            if self.aborted {
                return 0;
            }

            if score > best_score {
                best_score = score;
                if score >= beta {
                    return beta;
                }
                if score > alpha {
                    alpha = score;
                }
            }
        }

        if in_den_check && best_score == -SCORE_INF {
            if !pos.has_any_legal_move(history) {
                return -SCORE_WIN + ply as i32;
            }
            return -SCORE_WIN + (ply as i32 + 2);
        }

        alpha
    }
}

impl Default for Searcher {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{Color, PieceKind, Square};
    use std::sync::mpsc;

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    fn mv(a: &str, b: &str) -> Move {
        Move::new(sq(a), sq(b))
    }

    #[test]
    fn test_find_immediate_den_win() {
        let pieces = [
            (Color::P1, PieceKind::Cat, sq("d8")),
            (Color::P2, PieceKind::Elephant, sq("a7")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(3));
        assert_eq!(res.best_move, mv("d8", "d9"));
        assert_eq!(res.score, SCORE_WIN - 1);
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_find_forced_3ply_den_win() {
        let pieces = [
            (Color::P1, PieceKind::Cat, sq("d7")),
            (Color::P2, PieceKind::Elephant, sq("a1")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(4));
        assert_eq!(res.best_move, mv("d7", "d8"));
        assert_eq!(res.score, SCORE_WIN - 3);
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_defend_against_den_threat_at_depth_1() {
        let pieces = [
            (Color::P1, PieceKind::Elephant, sq("d3")),
            (Color::P1, PieceKind::Lion, sq("g7")),
            (Color::P2, PieceKind::Rat, sq("d2")),
            (Color::P2, PieceKind::Tiger, sq("g8")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(1));
        assert_eq!(res.best_move, mv("d3", "d2"));
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_find_river_jump_capture() {
        let pieces = [
            (Color::P1, PieceKind::Lion, sq("d4")),
            (Color::P2, PieceKind::Tiger, sq("a4")),
            (Color::P2, PieceKind::Cat, sq("g9")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(4));
        assert_eq!(res.best_move, mv("d4", "a4"));
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_avoid_illegal_zero_ep_superko_trap() {
        let pieces = [
            (Color::P2, PieceKind::Rat, sq("g9")),
            (Color::P1, PieceKind::Dog, sq("f9")),
            (Color::P1, PieceKind::Cat, sq("f8")),
            (Color::P1, PieceKind::Elephant, sq("g7")),
            (Color::P1, PieceKind::Tiger, sq("a1")),
        ];
        let (mut pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 0]);
        pos = pos.make_move(mv("a1", "a2"), &mut hist);
        assert_eq!(pos.ep[1], 0);
        pos = pos.make_move(mv("g9", "g8"), &mut hist);

        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(4));
        assert!(pos.gen_legal_moves(&hist).as_slice().contains(&res.best_move));
        assert_eq!(hist.len(), 3);
    }

    #[test]
    fn test_stop_flag_and_progress_hooks() {
        let (pos, mut hist) = BitboardPos::new_start();
        let mut searcher = Searcher::with_tt_mb(4);
        let stop = Arc::new(AtomicBool::new(true));
        let (tx, rx) = mpsc::channel();

        // Even with stop_flag pre-set, depth 1 MUST complete cleanly and return a legal move!
        let res = searcher.search_with_hooks(
            &pos,
            &mut hist,
            SearchLimits::depth(20),
            Some(stop),
            Some(tx),
        );
        assert_eq!(res.depth, 1);
        assert!(pos.gen_legal_moves(&hist).as_slice().contains(&res.best_move));
        let prog = rx.try_recv().expect("Progress must be emitted for depth 1");
        assert_eq!(prog.best_move, res.best_move);
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_search_respects_node_limit_and_history_integrity() {
        let (pos, mut hist) = BitboardPos::new_start();
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::nodes(5_000));
        assert!(pos.gen_legal_moves(&hist).as_slice().contains(&res.best_move));
        assert_eq!(hist.len(), 1);
    }
}

