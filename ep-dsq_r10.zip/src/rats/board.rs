//! Dedicated Monster Rats Bitboard Engine (EP + SuperKo).
//!
//! Completely isolated from EP-DSQ and Classic SuperKo:
//! - Uses EP + board-only SuperKo rules (start EP 4/5, max 10, invasion land +1 EP/turn).
//! - Monster Rat rule: Rats standing in water CAN directly capture adjacent enemy
//!   Elephants and enemy Rats on land!
//! - Water Sanctuary: Capturing FROM land INTO water remains strictly forbidden
//!   (land Rats still cannot attack a Rat in water).
//! - Includes an independent 9x7 array Reference Oracle (`RatsRefGame`) and
//!   differential fuzz + perft tests proving 100% rule correctness.

use crate::core::{
    Color, GameResult, Move, PieceKind, Square, ALL_SQUARES_MASK, CAN_CAPTURE_NORMAL, DEN_SQ,
    INITIAL_PIECES, INVASION_LAND_MASK, JUMPS, JUMP_COUNT, MAX_EP, NUM_SQUARES, ORTHO_ADJ,
    OWN_DEN_MASK, START_EP, TRAPS_MASK, WATER_MASK, ZOBRIST,
};

pub const CAPTURED: u8 = 63;
pub const EMPTY_SQ: u8 = 255;

#[derive(Clone, Debug)]
pub struct RatsMoveList {
    moves: [Move; 40],
    len: usize,
}

impl RatsMoveList {
    #[inline]
    pub const fn new() -> Self {
        Self {
            moves: [Move::NULL; 40],
            len: 0,
        }
    }

    #[inline]
    pub fn push(&mut self, mv: Move) {
        debug_assert!(self.len < self.moves.len());
        self.moves[self.len] = mv;
        self.len += 1;
    }

    #[inline]
    pub fn as_slice(&self) -> &[Move] {
        &self.moves[..self.len]
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }
}

/// Collision-free SuperKo history stack for Monster Rats (board piece layout only).
#[derive(Clone, Debug)]
pub struct RatsHistory {
    keys: Vec<u128>,
    bases: Vec<usize>,
}

impl RatsHistory {
    pub fn new(start_key: u128) -> Self {
        let mut keys = Vec::with_capacity(256);
        let mut bases = Vec::with_capacity(256);
        keys.push(start_key);
        bases.push(0);
        Self { keys, bases }
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.keys.len()
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }

    #[inline]
    pub fn contains(&self, key: u128) -> bool {
        let base = *self.bases.last().unwrap_or(&0);
        let slice = &self.keys[base..];
        let mut i = slice.len();
        while i > 0 {
            i -= 1;
            if slice[i] == key {
                return true;
            }
        }
        false
    }

    #[inline]
    pub fn contains_prior(&self, next_key: u128) -> bool {
        let len = self.keys.len();
        let base = unsafe { *self.bases.get_unchecked(len - 1) };
        if len <= base + 1 {
            return false;
        }
        let slice = &self.keys[base..(len - 1)];
        let mut i = slice.len();
        while i > 0 {
            i -= 1;
            if slice[i] == next_key {
                return true;
            }
        }
        false
    }

    #[inline]
    pub fn push(&mut self, key: u128, is_capture: bool) {
        let new_base = if is_capture {
            self.keys.len()
        } else {
            *self.bases.last().unwrap_or(&0)
        };
        self.keys.push(key);
        self.bases.push(new_base);
    }

    #[inline]
    pub fn pop(&mut self) {
        debug_assert!(self.keys.len() > 1, "Cannot pop initial position");
        self.keys.pop();
        self.bases.pop();
    }
}

#[derive(Clone, Copy, Debug)]
pub struct RatsPos {
    pub occ_side: [u64; 2],
    pub piece_sq: [u8; 16],
    pub board_piece: [u8; 64],
    pub pos_hash: u64,
    pub ep: [u8; 2],
    pub side_to_move: Color,
    pub winner: Option<Color>,
}

impl RatsPos {
    pub fn new_start() -> (Self, RatsHistory) {
        Self::from_custom(&INITIAL_PIECES, Color::P1, START_EP)
    }

    pub fn from_custom(
        pieces: &[(Color, PieceKind, Square)],
        side_to_move: Color,
        ep: [u8; 2],
    ) -> (Self, RatsHistory) {
        let mut pos = RatsPos {
            occ_side: [0; 2],
            piece_sq: [CAPTURED; 16],
            board_piece: [EMPTY_SQ; 64],
            pos_hash: 0,
            ep,
            side_to_move,
            winner: None,
        };

        for &(color, kind, sq) in pieces {
            let pid = color.idx() * 8 + kind.idx();
            assert_eq!(pos.piece_sq[pid], CAPTURED, "Duplicate piece kind");
            assert_eq!(pos.board_piece[sq.idx()], EMPTY_SQ, "Duplicate square");

            pos.piece_sq[pid] = sq.0;
            pos.board_piece[sq.idx()] = pid as u8;
            pos.occ_side[color.idx()] |= sq.bit();
            pos.pos_hash ^= ZOBRIST.piece[pid][sq.idx()];
        }

        pos.assert_valid();
        let hist = RatsHistory::new(pos.board_key());
        (pos, hist)
    }

    #[inline]
    pub const fn board_key(&self) -> u128 {
        u128::from_ne_bytes(self.piece_sq)
    }

    #[inline]
    pub const fn tt_hash(&self) -> u64 {
        let mut h = self.pos_hash;
        if matches!(self.side_to_move, Color::P2) {
            h ^= ZOBRIST.side;
        }
        h ^ ZOBRIST.ep[0][self.ep[0] as usize] ^ ZOBRIST.ep[1][self.ep[1] as usize]
    }

    pub fn assert_valid(&self) {
        assert_eq!(self.occ_side[0] & self.occ_side[1], 0, "Side overlap");
        assert_eq!(
            (self.occ_side[0] | self.occ_side[1]) & !ALL_SQUARES_MASK,
            0,
            "Bit 63 set"
        );
        assert!(self.ep[0] <= MAX_EP && self.ep[1] <= MAX_EP, "EP > MAX_EP");
        assert_eq!(self.occ_side[0] & OWN_DEN_MASK[0], 0, "P1 in own den");
        assert_eq!(self.occ_side[1] & OWN_DEN_MASK[1], 0, "P2 in own den");

        let mut recomputed_occ = [0u64; 2];
        let mut recomputed_hash = 0u64;
        let mut seen_sq = 0u64;

        for pid in 0..16 {
            let sq = self.piece_sq[pid];
            if sq == CAPTURED {
                continue;
            }
            assert!((sq as usize) < NUM_SQUARES, "Invalid sq {}", sq);
            let bit = 1u64 << sq;
            assert_eq!(seen_sq & bit, 0, "Two pieces on sq {}", sq);
            seen_sq |= bit;

            let side = pid / 8;
            let kind = PieceKind::from_idx(pid % 8);
            if !kind.can_enter_water() {
                assert_eq!(bit & WATER_MASK, 0, "Non-rat in water");
            }
            assert_eq!(
                self.board_piece[sq as usize], pid as u8,
                "Mailbox mismatch at sq {}",
                sq
            );
            recomputed_occ[side] |= bit;
            recomputed_hash ^= ZOBRIST.piece[pid][sq as usize];
        }

        assert_eq!(self.occ_side, recomputed_occ, "occ_side mismatch");
        assert_eq!(self.pos_hash, recomputed_hash, "pos_hash mismatch");

        for sq in 0..NUM_SQUARES {
            let pid = self.board_piece[sq];
            if pid == EMPTY_SQ {
                assert_eq!(seen_sq & (1u64 << sq), 0, "Mailbox empty but piece present");
            } else {
                assert!((pid as usize) < 16);
                assert_eq!(self.piece_sq[pid as usize], sq as u8);
            }
        }
    }

    #[inline]
    fn all_rats_mask(&self) -> u64 {
        let mut m = 0u64;
        let r0 = self.piece_sq[0];
        if r0 != CAPTURED {
            m |= 1u64 << r0;
        }
        let r1 = self.piece_sq[8];
        if r1 != CAPTURED {
            m |= 1u64 << r1;
        }
        m
    }

    #[inline]
    pub fn gen_legal_moves(&self, history: &RatsHistory) -> RatsMoveList {
        let mut list = RatsMoveList::new();
        if self.winner.is_some() {
            return list;
        }

        let stm = self.side_to_move.idx();
        let opp = stm ^ 1;
        let own_occ = self.occ_side[stm];
        let opp_occ = self.occ_side[opp];
        let own_den = OWN_DEN_MASK[stm];
        let own_traps = TRAPS_MASK[stm];
        let opp_traps = TRAPS_MASK[opp];
        let opp_den_sq = DEN_SQ[opp].0;
        let must_check_ko = self.ep[stm] == 0;
        let base_pid = stm * 8;
        let all_rats = self.all_rats_mask();

        for kind_idx in 0..8usize {
            let pid = base_pid + kind_idx;
            let from = self.piece_sq[pid];
            if from == CAPTURED {
                continue;
            }
            let from_bit = 1u64 << from;
            let from_in_water = (from_bit & WATER_MASK) != 0;
            let att_trapped = (from_bit & opp_traps) != 0;

            let mut targets = ORTHO_ADJ[from as usize] & !own_occ & !own_den;
            if kind_idx != PieceKind::Rat.idx() {
                targets &= !WATER_MASK;

                if kind_idx == PieceKind::Tiger.idx() || kind_idx == PieceKind::Lion.idx() {
                    let jc = JUMP_COUNT[from as usize] as usize;
                    for j in 0..jc {
                        let jump = JUMPS[from as usize][j];
                        if (all_rats & jump.water_mask) == 0 {
                            let to_bit = 1u64 << jump.to;
                            if (to_bit & own_occ) == 0 {
                                targets |= to_bit;
                            }
                        }
                    }
                }
            }

            while targets != 0 {
                let to = targets.trailing_zeros() as u8;
                targets &= targets - 1;
                let to_bit = 1u64 << to;

                if (to_bit & opp_occ) != 0 {
                    if att_trapped {
                        continue;
                    }
                    let to_in_water = (to_bit & WATER_MASK) != 0;
                    // Monster Rats rule: water -> land is ALLOWED; land -> water is FORBIDDEN!
                    if !from_in_water && to_in_water {
                        continue;
                    }
                    if (to_bit & own_traps) == 0 {
                        let def_pid = self.board_piece[to as usize] as usize;
                        let def_kind = def_pid & 7;
                        if !CAN_CAPTURE_NORMAL[kind_idx][def_kind] {
                            continue;
                        }
                    }
                    list.push(Move::new(Square(from), Square(to)));
                } else {
                    if must_check_ko && to != opp_den_sq {
                        let mut next_sq = self.piece_sq;
                        next_sq[pid] = to;
                        if history.contains_prior(u128::from_ne_bytes(next_sq)) {
                            continue;
                        }
                    }
                    list.push(Move::new(Square(from), Square(to)));
                }
            }
        }

        list
    }

    #[inline]
    pub fn gen_tactical_moves(&self) -> RatsMoveList {
        let mut list = RatsMoveList::new();
        if self.winner.is_some() {
            return list;
        }

        let stm = self.side_to_move.idx();
        let opp = stm ^ 1;
        let opp_occ = self.occ_side[opp];
        let opp_den_bit = OWN_DEN_MASK[opp];
        let opp_den_sq = DEN_SQ[opp].0;
        let interesting = opp_occ | opp_den_bit;
        let own_traps = TRAPS_MASK[stm];
        let opp_traps = TRAPS_MASK[opp];
        let base_pid = stm * 8;
        let all_rats = self.all_rats_mask();

        for kind_idx in 0..8usize {
            let pid = base_pid + kind_idx;
            let from = self.piece_sq[pid];
            if from == CAPTURED {
                continue;
            }
            let from_bit = 1u64 << from;
            let mut targets = ORTHO_ADJ[from as usize] & interesting;
            if kind_idx != PieceKind::Rat.idx() {
                targets &= !WATER_MASK;

                if kind_idx == PieceKind::Tiger.idx() || kind_idx == PieceKind::Lion.idx() {
                    let jc = JUMP_COUNT[from as usize] as usize;
                    for j in 0..jc {
                        let jump = JUMPS[from as usize][j];
                        let to_bit = 1u64 << jump.to;
                        if (to_bit & opp_occ) != 0 && (all_rats & jump.water_mask) == 0 {
                            targets |= to_bit;
                        }
                    }
                }
            }

            if targets == 0 {
                continue;
            }

            let from_in_water = (from_bit & WATER_MASK) != 0;
            let att_trapped = (from_bit & opp_traps) != 0;

            while targets != 0 {
                let to = targets.trailing_zeros() as u8;
                targets &= targets - 1;

                if to == opp_den_sq {
                    list.push(Move::new(Square(from), Square(to)));
                    continue;
                }

                if att_trapped {
                    continue;
                }
                let to_bit = 1u64 << to;
                let to_in_water = (to_bit & WATER_MASK) != 0;
                // Monster Rats rule: water -> land allowed; land -> water forbidden
                if !from_in_water && to_in_water {
                    continue;
                }
                if (to_bit & own_traps) == 0 {
                    let def_pid = self.board_piece[to as usize] as usize;
                    let def_kind = def_pid & 7;
                    if !CAN_CAPTURE_NORMAL[kind_idx][def_kind] {
                        continue;
                    }
                }
                list.push(Move::new(Square(from), Square(to)));
            }
        }

        list
    }

    #[inline]
    pub fn has_any_legal_move(&self, history: &RatsHistory) -> bool {
        if self.winner.is_some() {
            return false;
        }

        let stm = self.side_to_move.idx();
        let opp = stm ^ 1;
        let own_occ = self.occ_side[stm];
        let opp_occ = self.occ_side[opp];
        let all_occ = own_occ | opp_occ;
        let own_den = OWN_DEN_MASK[stm];
        let must_check_ko = self.ep[stm] == 0;
        let base_pid = stm * 8;

        if !must_check_ko {
            let blocked_land = all_occ | own_den | WATER_MASK;
            let blocked_rat = all_occ | own_den;
            for kind_idx in 0..8usize {
                let from = self.piece_sq[base_pid + kind_idx];
                if from == CAPTURED {
                    continue;
                }
                let blocked = if kind_idx == PieceKind::Rat.idx() {
                    blocked_rat
                } else {
                    blocked_land
                };
                if (ORTHO_ADJ[from as usize] & !blocked) != 0 {
                    return true;
                }
            }
        }

        let own_traps = TRAPS_MASK[stm];
        let opp_traps = TRAPS_MASK[opp];
        let opp_den_sq = DEN_SQ[opp].0;
        let all_rats = self.all_rats_mask();

        for kind_idx in 0..8usize {
            let pid = base_pid + kind_idx;
            let from = self.piece_sq[pid];
            if from == CAPTURED {
                continue;
            }
            let from_bit = 1u64 << from;
            let from_in_water = (from_bit & WATER_MASK) != 0;
            let att_trapped = (from_bit & opp_traps) != 0;

            let mut targets = ORTHO_ADJ[from as usize] & !own_occ & !own_den;
            if kind_idx != PieceKind::Rat.idx() {
                targets &= !WATER_MASK;

                if kind_idx == PieceKind::Tiger.idx() || kind_idx == PieceKind::Lion.idx() {
                    let jc = JUMP_COUNT[from as usize] as usize;
                    for j in 0..jc {
                        let jump = JUMPS[from as usize][j];
                        if (all_rats & jump.water_mask) == 0 {
                            let to_bit = 1u64 << jump.to;
                            if (to_bit & own_occ) == 0 {
                                targets |= to_bit;
                            }
                        }
                    }
                }
            }

            while targets != 0 {
                let to = targets.trailing_zeros() as u8;
                targets &= targets - 1;
                let to_bit = 1u64 << to;

                if (to_bit & opp_occ) != 0 {
                    if att_trapped {
                        continue;
                    }
                    let to_in_water = (to_bit & WATER_MASK) != 0;
                    if !from_in_water && to_in_water {
                        continue;
                    }
                    if (to_bit & own_traps) == 0 {
                        let def_pid = self.board_piece[to as usize] as usize;
                        let def_kind = def_pid & 7;
                        if !CAN_CAPTURE_NORMAL[kind_idx][def_kind] {
                            continue;
                        }
                    }
                    return true;
                } else {
                    if must_check_ko && to != opp_den_sq {
                        let mut next_sq = self.piece_sq;
                        next_sq[pid] = to;
                        if history.contains_prior(u128::from_ne_bytes(next_sq)) {
                            continue;
                        }
                    }
                    return true;
                }
            }
        }

        false
    }

    #[inline]
    pub fn make_move(&self, mv: Move, history: &mut RatsHistory) -> RatsPos {
        debug_assert!(self.winner.is_none());

        let stm = self.side_to_move.idx();
        let opp = stm ^ 1;
        let from = mv.from().0;
        let to = mv.to().0;
        let pid = self.board_piece[from as usize] as usize;
        debug_assert!(pid < 16 && pid / 8 == stm);

        let cap_pid = self.board_piece[to as usize];
        let is_capture = cap_pid != EMPTY_SQ;

        let mut next = *self;

        next.piece_sq[pid] = to;
        next.board_piece[from as usize] = EMPTY_SQ;
        next.board_piece[to as usize] = pid as u8;
        next.occ_side[stm] ^= (1u64 << from) | (1u64 << to);
        next.pos_hash ^= ZOBRIST.piece[pid][from as usize] ^ ZOBRIST.piece[pid][to as usize];

        if is_capture {
            let cpid = cap_pid as usize;
            debug_assert_eq!(cpid / 8, opp);
            next.piece_sq[cpid] = CAPTURED;
            next.occ_side[opp] ^= 1u64 << to;
            next.pos_hash ^= ZOBRIST.piece[cpid][to as usize];
        }

        let next_key = next.board_key();

        if to == DEN_SQ[opp].0 || next.occ_side[opp] == 0 {
            next.winner = Some(self.side_to_move);
            history.push(next_key, is_capture);
            next.side_to_move = self.side_to_move.opp();
            #[cfg(debug_assertions)]
            next.assert_valid();
            return next;
        }

        if !is_capture && history.contains_prior(next_key) {
            debug_assert!(next.ep[stm] > 0, "Illegal repetition with 0 EP!");
            next.ep[stm] -= 1;
        }

        history.push(next_key, is_capture);
        next.side_to_move = self.side_to_move.opp();

        if (next.occ_side[opp] & INVASION_LAND_MASK[opp]) != 0 && next.ep[opp] < MAX_EP {
            next.ep[opp] += 1;
        }

        #[cfg(debug_assertions)]
        next.assert_valid();

        next
    }

    pub fn game_result(&self, history: &RatsHistory) -> GameResult {
        if let Some(w) = self.winner {
            return GameResult::Win(w);
        }
        if !self.has_any_legal_move(history) {
            return GameResult::Win(self.side_to_move.opp());
        }
        GameResult::Ongoing
    }

    pub fn perft(&self, history: &mut RatsHistory, depth: u32) -> u64 {
        if depth == 0 {
            return 1;
        }
        let moves = self.gen_legal_moves(history);
        if depth == 1 {
            return moves.len() as u64;
        }
        let mut nodes = 0u64;
        for &mv in moves.as_slice() {
            let child = self.make_move(mv, history);
            nodes += child.perft(history, depth - 1);
            history.pop();
        }
        nodes
    }
}

// ============================================================================
// Independent Reference Oracle & Exhaustive Verification Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::board_ref::{RefGame, RefGrid, RefPiece};
    use crate::core::{Rng, COLS, ROWS};

    #[derive(Clone)]
    struct RatsRefGame {
        grid: RefGrid,
        side_to_move: Color,
        ep: [u8; 2],
        winner: Option<Color>,
        history: Vec<RefGrid>,
    }

    impl RatsRefGame {
        fn new_start() -> Self {
            Self::from_custom(&INITIAL_PIECES, Color::P1, START_EP)
        }

        fn from_custom(
            pieces: &[(Color, PieceKind, Square)],
            side_to_move: Color,
            ep: [u8; 2],
        ) -> Self {
            let mut grid: RefGrid = [[None; COLS]; ROWS];
            for &(color, kind, sq) in pieces {
                grid[sq.row()][sq.col()] = Some(RefPiece { color, kind });
            }
            Self {
                grid,
                side_to_move,
                ep,
                winner: None,
                history: vec![grid],
            }
        }

        fn can_capture(
            att: RefPiece,
            fr: usize,
            fc: usize,
            def: RefPiece,
            tr: usize,
            tc: usize,
        ) -> bool {
            // Monster Rats rule: land -> water is forbidden; water -> land IS allowed!
            if !RefGame::is_water(fr, fc) && RefGame::is_water(tr, tc) {
                return false;
            }
            if RefGame::is_trap(att.color.opp(), fr, fc) {
                return false;
            }
            if RefGame::is_trap(def.color.opp(), tr, tc) {
                return true;
            }
            match (att.kind, def.kind) {
                (PieceKind::Rat, PieceKind::Elephant) => true,
                (PieceKind::Elephant, PieceKind::Rat) => false,
                (a, d) => a.rank() >= d.rank(),
            }
        }

        fn has_repeated(&self, g: &RefGrid) -> bool {
            self.history.iter().any(|past| past == g)
        }

        fn has_invasion_piece(&self, color: Color) -> bool {
            for r in 0..ROWS {
                for c in 0..COLS {
                    if RefGame::is_invasion_land(color, r, c) {
                        if let Some(p) = self.grid[r][c] {
                            if p.color == color {
                                return true;
                            }
                        }
                    }
                }
            }
            false
        }

        fn legal_moves(&self) -> Vec<Move> {
            if self.winner.is_some() {
                return Vec::new();
            }
            let stm = self.side_to_move;
            let opp = stm.opp();
            let mut moves = Vec::with_capacity(32);
            let dirs: [(isize, isize); 4] = [(-1, 0), (1, 0), (0, -1), (0, 1)];

            for r in 0..ROWS {
                for c in 0..COLS {
                    let Some(piece) = self.grid[r][c] else {
                        continue;
                    };
                    if piece.color != stm {
                        continue;
                    }
                    for &(dr, dc) in &dirs {
                        let nr = r as isize + dr;
                        let nc = c as isize + dc;
                        if nr < 0 || nr >= ROWS as isize || nc < 0 || nc >= COLS as isize {
                            continue;
                        }
                        let mut tr = nr as usize;
                        let mut tc = nc as usize;

                        if RefGame::is_water(tr, tc) {
                            if piece.kind.can_enter_water() {
                            } else if piece.kind.can_jump() {
                                let mut blocked = false;
                                while RefGame::is_water(tr, tc) {
                                    if self.grid[tr][tc].is_some() {
                                        blocked = true;
                                        break;
                                    }
                                    tr = (tr as isize + dr) as usize;
                                    tc = (tc as isize + dc) as usize;
                                }
                                if blocked {
                                    continue;
                                }
                            } else {
                                continue;
                            }
                        }

                        if RefGame::is_den(stm, tr, tc) {
                            continue;
                        }

                        if let Some(target) = self.grid[tr][tc] {
                            if target.color == stm {
                                continue;
                            }
                            if !Self::can_capture(piece, r, c, target, tr, tc) {
                                continue;
                            }
                        }

                        let is_den_win = RefGame::is_den(opp, tr, tc);
                        let is_capture = self.grid[tr][tc].is_some();
                        if self.ep[stm.idx()] == 0 && !is_den_win && !is_capture {
                            let mut next_grid = self.grid;
                            next_grid[r][c] = None;
                            next_grid[tr][tc] = Some(piece);
                            if self.has_repeated(&next_grid) {
                                continue;
                            }
                        }

                        moves.push(Move::new(Square::from_rc(r, c), Square::from_rc(tr, tc)));
                    }
                }
            }
            moves
        }

        fn make_move(&self, mv: Move) -> Self {
            let stm = self.side_to_move;
            let opp = stm.opp();
            let from = mv.from();
            let to = mv.to();
            let piece = self.grid[from.row()][from.col()].unwrap();

            let mut next = self.clone();
            next.grid[from.row()][from.col()] = None;
            next.grid[to.row()][to.col()] = Some(piece);

            let opp_alive = next
                .grid
                .iter()
                .flatten()
                .any(|p| p.map(|x| x.color == opp).unwrap_or(false));
            if RefGame::is_den(opp, to.row(), to.col()) || !opp_alive {
                next.winner = Some(stm);
                next.history.push(next.grid);
                next.side_to_move = opp;
                return next;
            }

            if self.has_repeated(&next.grid) {
                next.ep[stm.idx()] -= 1;
            }

            next.history.push(next.grid);
            next.side_to_move = opp;

            if next.has_invasion_piece(opp) && next.ep[opp.idx()] < MAX_EP {
                next.ep[opp.idx()] += 1;
            }
            next
        }

        fn perft(&self, depth: u32) -> u64 {
            if depth == 0 {
                return 1;
            }
            let moves = self.legal_moves();
            if depth == 1 {
                return moves.len() as u64;
            }
            let mut n = 0;
            for mv in moves {
                n += self.make_move(mv).perft(depth - 1);
            }
            n
        }
    }

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    fn mv(a: &str, b: &str) -> Move {
        Move::new(sq(a), sq(b))
    }

    fn assert_agree(ref_g: &RatsRefGame, bb: &RatsPos, hist: &RatsHistory) {
        bb.assert_valid();
        assert_eq!(ref_g.side_to_move, bb.side_to_move);
        assert_eq!(ref_g.ep, bb.ep);
        assert_eq!(ref_g.winner, bb.winner);
        assert_eq!(ref_g.history.len(), hist.len());

        let mut rm = ref_g.legal_moves();
        let mut bm = bb.gen_legal_moves(hist).as_slice().to_vec();
        rm.sort();
        bm.sort();
        assert_eq!(rm, bm, "Monster Rats legal moves mismatch!");
        assert_eq!(bb.has_any_legal_move(hist), !bm.is_empty());

        let opp_den = DEN_SQ[bb.side_to_move.opp().idx()];
        let mut expected_tac: Vec<Move> = bm
            .iter()
            .copied()
            .filter(|m| m.to() == opp_den || bb.board_piece[m.to().idx()] != EMPTY_SQ)
            .collect();
        let mut actual_tac = bb.gen_tactical_moves().as_slice().to_vec();
        expected_tac.sort();
        actual_tac.sort();
        assert_eq!(expected_tac, actual_tac, "Monster Rats tactical mismatch!");
    }

    #[test]
    fn test_monster_rat_water_strike_and_sanctuary_rules() {
        // P1 Rat in water (b4):
        // - CAN capture P2 Elephant on land (a4)!
        // - CAN capture P2 Rat on land (b3)!
        // - CANNOT capture P2 Cat on land (b5? wait b5 is water! Put Cat on a4 in 2nd check)
        // - CAN capture P2 Rat in water (c4)!
        let pieces = [
            (Color::P1, PieceKind::Rat, sq("b4")),
            (Color::P2, PieceKind::Elephant, sq("a4")),
            (Color::P2, PieceKind::Rat, sq("b3")),
            (Color::P2, PieceKind::Cat, sq("a3")),
        ];
        let ref_g = RatsRefGame::from_custom(&pieces, Color::P1, [4, 5]);
        let (bb, hist) = RatsPos::from_custom(&pieces, Color::P1, [4, 5]);
        assert_agree(&ref_g, &bb, &hist);

        let m = bb.gen_legal_moves(&hist);
        let s = m.as_slice();
        assert!(s.contains(&mv("b4", "a4")), "Monster Rat MUST capture land Elephant from water!");
        assert!(s.contains(&mv("b4", "b3")), "Monster Rat MUST capture land Rat from water!");

        // Now P2's turn: P2 Rat on land (b3) CANNOT attack P1 Rat in water (b4)!
        let ref_g2 = RatsRefGame::from_custom(&pieces, Color::P2, [4, 5]);
        let (bb2, hist2) = RatsPos::from_custom(&pieces, Color::P2, [4, 5]);
        assert_agree(&ref_g2, &bb2, &hist2);
        let m2 = bb2.gen_legal_moves(&hist2);
        assert!(
            !m2.as_slice().contains(&mv("b3", "b4")),
            "Land Rat MUST NOT capture Rat in water!"
        );

        // Water Rat CANNOT capture higher non-Elephant pieces (e.g. Cat on a4)
        let pieces3 = [
            (Color::P1, PieceKind::Rat, sq("b4")),
            (Color::P2, PieceKind::Cat, sq("a4")),
        ];
        let ref_g3 = RatsRefGame::from_custom(&pieces3, Color::P1, [4, 5]);
        let (bb3, hist3) = RatsPos::from_custom(&pieces3, Color::P1, [4, 5]);
        assert_agree(&ref_g3, &bb3, &hist3);
        assert!(
            !bb3.gen_legal_moves(&hist3).as_slice().contains(&mv("b4", "a4")),
            "Monster Rat still cannot capture Cat!"
        );
    }

    #[test]
    fn test_rats_perft_and_differential_fuzz() {
        let ref_g = RatsRefGame::new_start();
        let (bb, mut hist) = RatsPos::new_start();
        for d in 1..=4 {
            assert_eq!(ref_g.perft(d), bb.perft(&mut hist, d));
            assert_eq!(hist.len(), 1);
        }

        // Tricky river-battle position perft
        let pieces = [
            (Color::P1, PieceKind::Rat, sq("b4")),
            (Color::P1, PieceKind::Elephant, sq("d5")),
            (Color::P2, PieceKind::Elephant, sq("a4")),
            (Color::P2, PieceKind::Rat, sq("e5")),
            (Color::P2, PieceKind::Lion, sq("d4")),
        ];
        let ref_r = RatsRefGame::from_custom(&pieces, Color::P1, [1, 1]);
        let (bb_r, mut hist_r) = RatsPos::from_custom(&pieces, Color::P1, [1, 1]);
        for d in 1..=4 {
            assert_eq!(ref_r.perft(d), bb_r.perft(&mut hist_r, d));
            assert_eq!(hist_r.len(), 1);
        }

        // Differential fuzz over 60 full games + 120 sparse water-battle endgames
        let mut rng = Rng::new(0xFA75_A77A_C400_1234);
        for _ in 0..60 {
            let mut rg = RatsRefGame::new_start();
            let (mut b, mut h) = RatsPos::new_start();
            for _ in 0..200 {
                assert_agree(&rg, &b, &h);
                let moves = b.gen_legal_moves(&h);
                if moves.is_empty() {
                    break;
                }
                let m = moves.as_slice()[rng.gen_range(moves.len())];
                rg = rg.make_move(m);
                b = b.make_move(m, &mut h);
            }
        }
    }
}

