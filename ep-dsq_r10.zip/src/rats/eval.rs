//! Dedicated handcrafted evaluation for Monster Rats Dou Shou Qi (EP + SuperKo).
//!
//! Strategic adaptations for Monster Rats (where Rats in water can strike directly onto
//! land Elephants & land Rats while remaining untouchable from land):
//! - Higher Rat material value & strong water-sanctuary bonus
//! - Elephant cage & threat detection treats BOTH water and land enemy Rats as live predators
//! - River-bank ambush awareness (rewards water Rats pressuring enemy Elephants/land Rats)
//! - Full EP + SuperKo reserve, invasion dominance, and opponent EP-starvation scoring
//! - Exact compile-time BFS shortest-path distances & Heavy-Piece Corner-Cage detector

use crate::core::{
    Color, PieceKind, Square, COLS, DEN_SQ, INVASION_LAND_MASK, JUMPS, JUMP_COUNT, MAX_EP,
    NUM_SQUARES, ORTHO_ADJ, OWN_DEN_MASK, ROWS, TRAPS_MASK, WATER_MASK,
};
use crate::rats::board::{RatsPos, CAPTURED};

pub const SCORE_INF: i32 = 30_000;
pub const SCORE_WIN: i32 = 29_000;
pub const SCORE_WIN_THRESHOLD: i32 = 28_000;
pub const EVAL_CLAMP: i32 = 20_000;

/// Base material values indexed by `PieceKind::idx()` (Rat=0 .. Elephant=7).
/// Monster Rat is significantly more valuable because water is now an invulnerable ambush zone.
pub const PIECE_VALUE: [i32; 8] = [
    340, // Monster Rat: invulnerable in water & strikes land Elephants/Rats directly!
    145, // Cat
    215, // Dog
    300, // Wolf
    420, // Leopard
    680, // Tiger: river jumper
    910, // Lion: dominant jumper
    955, // Elephant: slightly more vulnerable near rivers due to Monster Rats
];

const PIECE_PHASE: [i32; 8] = [3, 1, 1, 2, 3, 4, 5, 6];
const MAX_PHASE: i32 = 50;

const EP_VALUE: [i32; (MAX_EP as usize) + 1] = [
    -95, // 0 EP
    -15, // 1 EP
    18,  // 2 EP
    36,  // 3 EP
    50,  // 4 EP
    60,  // 5 EP
    68,  // 6 EP
    74,  // 7 EP
    79,  // 8 EP
    83,  // 9 EP
    86,  // 10 EP
];

const TEMPO_BONUS: i32 = 18;

const fn sq_bit(r: usize, c: usize) -> u64 {
    1u64 << (r * COLS + c)
}

const OPP_CORNER_POCKET_MASK: [u64; 2] = [
    sq_bit(8, 0) | sq_bit(8, 1) | sq_bit(7, 0) | sq_bit(8, 6) | sq_bit(8, 5) | sq_bit(7, 6),
    sq_bit(0, 6) | sq_bit(0, 5) | sq_bit(1, 6) | sq_bit(0, 0) | sq_bit(0, 1) | sq_bit(1, 0),
];

const RIVER_BANK_MASK: u64 = {
    let mut m = 0u64;
    let v_cols = [1usize, 2, 4, 5];
    let mut i = 0;
    while i < 4 {
        let c = v_cols[i];
        m |= sq_bit(2, c) | sq_bit(6, c);
        i += 1;
    }
    let mut r = 3;
    while r <= 5 {
        m |= sq_bit(r, 0) | sq_bit(r, 3) | sq_bit(r, 6);
        r += 1;
    }
    m
};

const CENTER_CORRIDOR_MASK: u64 = sq_bit(3, 3) | sq_bit(4, 3) | sq_bit(5, 3);

const OWN_DEN_ZONE: [u64; 2] = {
    let mut zones = [0u64; 2];
    let mut side = 0;
    while side < 2 {
        let dr = DEN_SQ[side].row();
        let dc = DEN_SQ[side].col();
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let dist = r.abs_diff(dr) + c.abs_diff(dc);
                if dist >= 1 && dist <= 2 {
                    zones[side] |= sq_bit(r, c);
                }
                c += 1;
            }
            r += 1;
        }
        side += 1;
    }
    zones
};

const fn build_bfs_den_dist(mode: u8) -> [[i32; NUM_SQUARES]; 2] {
    let mut tbl = [[20i32; NUM_SQUARES]; 2];
    let mut side = 0;
    while side < 2 {
        let opp = side ^ 1;
        let opp_den = DEN_SQ[opp].idx();
        let own_den_mask = OWN_DEN_MASK[side];
        tbl[side][opp_den] = 0;

        let mut pass = 0;
        while pass < 20 {
            let mut sq = 0;
            while sq < NUM_SQUARES {
                let bit = 1u64 << sq;
                let invalid = (bit & own_den_mask) != 0 || (mode != 0 && (bit & WATER_MASK) != 0);
                if !invalid {
                    let mut best = tbl[side][sq];
                    let mut adj = ORTHO_ADJ[sq] & !own_den_mask;
                    if mode != 0 {
                        adj &= !WATER_MASK;
                    }
                    while adj != 0 {
                        let to = adj.trailing_zeros() as usize;
                        adj &= adj - 1;
                        let cand = tbl[side][to] + 1;
                        if cand < best {
                            best = cand;
                        }
                    }
                    if mode == 2 {
                        let jc = JUMP_COUNT[sq] as usize;
                        let mut j = 0;
                        while j < jc {
                            let to = JUMPS[sq][j].to as usize;
                            let cand = tbl[side][to] + 1;
                            if cand < best {
                                best = cand;
                            }
                            j += 1;
                        }
                    }
                    tbl[side][sq] = best;
                }
                sq += 1;
            }
            pass += 1;
        }
        side += 1;
    }
    tbl
}

const DIST_RAT: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(0);
const DIST_LAND: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(1);
const DIST_JUMPER: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(2);

const PST_MG: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let center_file = 3 - c.abs_diff(3) as i32;
                let advance = r as i32;
                let dist = if k == 0 {
                    DIST_RAT[0][sq]
                } else if k == 5 || k == 6 {
                    DIST_JUMPER[0][sq]
                } else {
                    DIST_LAND[0][sq]
                };

                let mut val = match k {
                    0 => {
                        // Monster Rat: HUGE bonus in water (invulnerable ambush fortress!)
                        let mut v = advance * 5 + center_file * 5;
                        if (sq_bit & WATER_MASK) != 0 {
                            v += 68;
                        }
                        v
                    }
                    1 => advance * 6 + center_file * 3,
                    2 => advance * 7 + center_file * 4,
                    3 => advance * 8 + center_file * 5,
                    4 => advance * 9 + center_file * 5,
                    5 => {
                        let mut v = advance * 10 + center_file * 6;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 26;
                        }
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 22;
                        }
                        v
                    }
                    6 => {
                        let mut v = advance * 11 + center_file * 7;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 32;
                        }
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 26;
                        }
                        v
                    }
                    7 => {
                        let mut v = advance * 10 + center_file * 8;
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 12;
                        }
                        v
                    }
                    _ => 0,
                };

                if k >= 4 {
                    if r == 8 && (c == 0 || c == 6) {
                        val -= 58;
                    } else if (r == 8 && (c == 1 || c == 5)) || (r == 7 && (c == 0 || c == 6)) {
                        val -= 26;
                    } else if r >= 6 && (c == 0 || c == 6) {
                        val -= 10;
                    }
                }

                if dist <= 4 {
                    val += (5 - dist) * 20;
                }
                if dist == 1 {
                    val += 30;
                }
                if k <= 4 && (sq_bit & TRAPS_MASK[0]) != 0 {
                    val += 10;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

const PST_EG: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let dist = if k == 0 {
                    DIST_RAT[0][sq]
                } else if k == 5 || k == 6 {
                    DIST_JUMPER[0][sq]
                } else {
                    DIST_LAND[0][sq]
                };

                let progress = if 12 > dist { 12 - dist } else { 0 };
                let weight = match k {
                    0 => 15,
                    1 => 13,
                    2 => 14,
                    3 => 15,
                    4 => 16,
                    5 => 20,
                    6 => 22,
                    7 => 19,
                    _ => 14,
                };
                let mut val = progress * weight;

                if k >= 4 {
                    if r == 8 && (c == 0 || c == 6) {
                        val -= 45;
                    } else if (r == 8 && (c == 1 || c == 5)) || (r == 7 && (c == 0 || c == 6)) {
                        val -= 20;
                    }
                }

                if dist <= 3 {
                    val += (4 - dist) * 35;
                }
                if (k == 5 || k == 6) && (sq_bit & RIVER_BANK_MASK) != 0 {
                    val += 18;
                }
                if k == 0 && (sq_bit & WATER_MASK) != 0 {
                    val += 36;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

const HEAVY_CAGE_ZERO_SAFE: [i32; 4] = [95, 130, 165, 180];
const HEAVY_CAGE_ONE_SAFE_POCKET: [i32; 4] = [38, 52, 68, 76];
const HEAVY_CAGE_ONE_SAFE_OPEN: [i32; 4] = [14, 18, 22, 26];

#[inline]
const fn manhattan(sq_a: u8, sq_b: u8) -> i32 {
    let ra = (sq_a as usize) / COLS;
    let ca = (sq_a as usize) % COLS;
    let rb = (sq_b as usize) / COLS;
    let cb = (sq_b as usize) % COLS;
    (ra.abs_diff(rb) + ca.abs_diff(cb)) as i32
}

/// Evaluates `pos` from the perspective of `pos.side_to_move`.
#[inline]
pub fn evaluate(pos: &RatsPos) -> i32 {
    if let Some(w) = pos.winner {
        return if w == pos.side_to_move {
            SCORE_WIN
        } else {
            -SCORE_WIN
        };
    }

    let mut phase = 0i32;
    for k in 0..8usize {
        if pos.piece_sq[k] != CAPTURED {
            phase += PIECE_PHASE[k];
        }
        if pos.piece_sq[8 + k] != CAPTURED {
            phase += PIECE_PHASE[k];
        }
    }
    let mg_w = phase.min(MAX_PHASE);
    let eg_w = MAX_PHASE - mg_w;

    let (p1_mg, p1_eg) = eval_side(pos, 0);
    let (p2_mg, p2_eg) = eval_side(pos, 1);

    let mg_diff = p1_mg - p2_mg;
    let eg_diff = p1_eg - p2_eg;
    let blended = (mg_diff * mg_w + eg_diff * eg_w) / MAX_PHASE;

    let stm_score = match pos.side_to_move {
        Color::P1 => blended + TEMPO_BONUS,
        Color::P2 => -blended + TEMPO_BONUS,
    };

    stm_score.clamp(-EVAL_CLAMP, EVAL_CLAMP)
}

#[inline]
fn eval_side(pos: &RatsPos, side: usize) -> (i32, i32) {
    let opp = side ^ 1;
    let base = side * 8;
    let opp_base = opp * 8;

    let mut mg = 0i32;
    let mut eg = 0i32;
    let mut min_den_dist = 20i32;
    let mut second_den_dist = 20i32;
    let mut highest_alive = -1i32;
    let mut opp_highest_alive = -1i32;

    for k in 0..8usize {
        if pos.piece_sq[opp_base + k] != CAPTURED {
            opp_highest_alive = k as i32;
        }
        let sq = pos.piece_sq[base + k];
        if sq == CAPTURED {
            continue;
        }
        highest_alive = k as i32;
        let sq_idx = sq as usize;
        let pst_sq = if side == 0 { sq_idx } else { 62 - sq_idx };

        let mat = PIECE_VALUE[k];
        mg += mat + PST_MG[k][pst_sq];
        eg += mat + PST_EG[k][pst_sq];

        let d = if k == 0 {
            DIST_RAT[side][sq_idx]
        } else if k == 5 || k == 6 {
            DIST_JUMPER[side][sq_idx]
        } else {
            DIST_LAND[side][sq_idx]
        };

        if d < min_den_dist {
            second_den_dist = min_den_dist;
            min_den_dist = d;
        } else if d < second_den_dist {
            second_den_dist = d;
        }
    }

    let own_rat = pos.piece_sq[base + PieceKind::Rat.idx()];
    let own_leo = pos.piece_sq[base + PieceKind::Leopard.idx()];
    let own_tiger = pos.piece_sq[base + PieceKind::Tiger.idx()];
    let own_lion = pos.piece_sq[base + PieceKind::Lion.idx()];
    let own_ele = pos.piece_sq[base + PieceKind::Elephant.idx()];

    let opp_rat = pos.piece_sq[opp_base + PieceKind::Rat.idx()];
    let opp_leo = pos.piece_sq[opp_base + PieceKind::Leopard.idx()];
    let opp_tiger = pos.piece_sq[opp_base + PieceKind::Tiger.idx()];
    let opp_lion = pos.piece_sq[opp_base + PieceKind::Lion.idx()];
    let opp_ele = pos.piece_sq[opp_base + PieceKind::Elephant.idx()];

    // Monster Rat predator-prey hierarchy
    if own_ele != CAPTURED && opp_rat == CAPTURED {
        mg += 240;
        eg += 300;
    }
    if own_rat != CAPTURED && opp_ele != CAPTURED {
        let rat_in_water = ((1u64 << own_rat) & WATER_MASK) != 0;
        mg += if rat_in_water { 165 } else { 125 };
        eg += if rat_in_water { 175 } else { 135 };
        let d_re = manhattan(own_rat, opp_ele);
        let hunt = (10 - d_re).max(0) * if rat_in_water { 10 } else { 7 };
        mg += hunt;
        eg += hunt + 4;
    }
    // Bonus when our water Monster Rat dominates an enemy land Rat (safe from counterattack!)
    if own_rat != CAPTURED && opp_rat != CAPTURED {
        let own_in_w = ((1u64 << own_rat) & WATER_MASK) != 0;
        let opp_in_w = ((1u64 << opp_rat) & WATER_MASK) != 0;
        if own_in_w && !opp_in_w {
            let d_rr = manhattan(own_rat, opp_rat);
            mg += 28 + (6 - d_rr).max(0) * 6;
            eg += 22 + (6 - d_rr).max(0) * 5;
        }
    }
    // Extra caution when our Elephant stands on a river bank while enemy Monster Rat is in water
    if own_ele != CAPTURED && opp_rat != CAPTURED {
        let ele_bit = 1u64 << own_ele;
        let opp_r_bit = 1u64 << opp_rat;
        if (opp_r_bit & WATER_MASK) != 0 && (ele_bit & RIVER_BANK_MASK) != 0 {
            let d = manhattan(own_ele, opp_rat);
            if d <= 2 {
                mg -= 42;
                eg -= 36;
            }
        }
    }

    if own_lion != CAPTURED && opp_ele == CAPTURED {
        mg += 170;
        eg += 220;
    }
    if own_tiger != CAPTURED && opp_ele == CAPTURED && opp_lion == CAPTURED {
        mg += 160;
        eg += 210;
    }
    if highest_alive > opp_highest_alive && highest_alive >= 2 {
        eg += 95;
    }

    // O(1) Bitboard Heavy-Piece Safe-Mobility & Corner-Cage Detector
    let own_occ = pos.occ_side[side];
    let opp_occ = pos.occ_side[opp];
    let own_den = OWN_DEN_MASK[side];
    let opp_traps = TRAPS_MASK[opp];
    let opp_pocket = OPP_CORNER_POCKET_MASK[side];

    let mut all_rats = 0u64;
    if own_rat != CAPTURED {
        all_rats |= 1u64 << own_rat;
    }
    if opp_rat != CAPTURED {
        all_rats |= 1u64 << opp_rat;
    }

    let mut hi_occ = 0u64;
    let mut hi_atk = 0u64;
    if opp_ele != CAPTURED {
        hi_occ |= 1u64 << opp_ele;
        hi_atk |= ORTHO_ADJ[opp_ele as usize];
    }

    // Elephant (k=7): in Monster Rats, enemy Rat threatens Elephant from BOTH water AND land!
    if own_ele != CAPTURED {
        let mut ele_pred_occ = hi_occ;
        let mut ele_pred_atk = hi_atk;
        if opp_rat != CAPTURED {
            let r_bit = 1u64 << opp_rat;
            ele_pred_occ |= r_bit;
            ele_pred_atk |= ORTHO_ADJ[opp_rat as usize];
        }
        let pen = heavy_cage_penalty(
            own_ele,
            3,
            false,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            ele_pred_occ,
            ele_pred_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Lion (k=6)
    if opp_lion != CAPTURED {
        hi_occ |= 1u64 << opp_lion;
        hi_atk |= ORTHO_ADJ[opp_lion as usize];
    }
    if own_lion != CAPTURED {
        let pen = heavy_cage_penalty(
            own_lion,
            2,
            true,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            hi_occ,
            hi_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Tiger (k=5)
    if opp_tiger != CAPTURED {
        hi_occ |= 1u64 << opp_tiger;
        hi_atk |= ORTHO_ADJ[opp_tiger as usize];
    }
    if own_tiger != CAPTURED {
        let pen = heavy_cage_penalty(
            own_tiger,
            1,
            true,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            hi_occ,
            hi_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Leopard (k=4)
    if opp_leo != CAPTURED {
        hi_occ |= 1u64 << opp_leo;
        hi_atk |= ORTHO_ADJ[opp_leo as usize];
    }
    if own_leo != CAPTURED {
        let pen = heavy_cage_penalty(
            own_leo,
            0,
            false,
            own_occ,
            own_den,
            opp_traps,
            opp_pocket,
            hi_occ,
            hi_atk,
            all_rats,
        );
        mg -= pen;
        eg -= pen;
    }

    // Live River-Jump Blocking
    if own_rat != CAPTURED {
        let rat_bit = 1u64 << own_rat;
        if (rat_bit & WATER_MASK) != 0 {
            for &jumper_sq in &[opp_lion, opp_tiger] {
                if jumper_sq != CAPTURED {
                    let jc = JUMP_COUNT[jumper_sq as usize] as usize;
                    for j in 0..jc {
                        if (rat_bit & JUMPS[jumper_sq as usize][j].water_mask) != 0 {
                            mg += 32;
                            eg += 24;
                        }
                    }
                }
            }
        }
    }

    // Closest-Piece & Dual-Threat Den-Race Evaluation
    if min_den_dist <= 5 {
        let bonus = (6 - min_den_dist) * 20;
        mg += bonus;
        eg += bonus * 2;
    }
    if second_den_dist <= 4 {
        let duo = (5 - second_den_dist) * 16;
        mg += duo;
        eg += duo + 20;
    }

    // Den Defense & Trap Control
    let opp_invading = (opp_occ & INVASION_LAND_MASK[opp]) != 0;
    let own_defenders = (own_occ & OWN_DEN_ZONE[side]).count_ones() as i32;
    let opp_defenders = (opp_occ & OWN_DEN_ZONE[opp]).count_ones() as i32;

    if opp_invading {
        if own_defenders == 0 {
            mg -= 65;
            eg -= 95;
        } else {
            mg += own_defenders.min(2) * 20;
            eg += own_defenders.min(2) * 16;
        }
    }

    if min_den_dist <= 3 && opp_defenders == 0 {
        mg += 70;
        eg += 130;
    }

    let trapped_own = own_occ & opp_traps;
    if trapped_own != 0 {
        let sq = trapped_own.trailing_zeros() as usize;
        if (ORTHO_ADJ[sq] & opp_occ) != 0 {
            mg -= 110;
            eg -= 120;
        } else if opp_defenders > 0 {
            mg -= 25;
            eg -= 25;
        }
    }

    // Energy Points (EP), Invasion Dominance & Opponent EP Starvation
    let own_ep = pos.ep[side] as usize;
    let opp_ep = pos.ep[opp] as usize;
    mg += EP_VALUE[own_ep];
    eg += EP_VALUE[own_ep] + (EP_VALUE[own_ep] / 3);

    let own_invaders = (own_occ & INVASION_LAND_MASK[side]).count_ones() as i32;
    if own_invaders > 0 {
        let base_inv = if own_ep <= 2 { 55 } else { 26 };
        let extra_inv = (own_invaders - 1).min(2) * 14;
        mg += base_inv + extra_inv;
        eg += base_inv + extra_inv + 12;

        if !opp_invading {
            let squeeze = if opp_ep <= 1 {
                75
            } else if opp_ep <= 3 {
                45
            } else {
                22
            };
            mg += squeeze;
            eg += squeeze + 20;
        }
    }

    let piece_count = own_occ.count_ones() as i32;
    mg += piece_count * 12;
    eg += piece_count * 18;

    (mg, eg)
}

#[allow(clippy::too_many_arguments)]
#[inline]
fn heavy_cage_penalty(
    sq: u8,
    tier: usize,
    can_jump: bool,
    own_occ: u64,
    own_den: u64,
    opp_traps: u64,
    opp_pocket: u64,
    pred_occ: u64,
    pred_atk: u64,
    all_rats: u64,
) -> i32 {
    let sq_bit = 1u64 << sq;
    if (sq_bit & opp_traps) != 0 {
        return 0;
    }

    let mut exits = ORTHO_ADJ[sq as usize] & !WATER_MASK & !own_den;
    if can_jump {
        let jc = JUMP_COUNT[sq as usize] as usize;
        for j in 0..jc {
            let jump = JUMPS[sq as usize][j];
            if (all_rats & jump.water_mask) == 0 {
                exits |= 1u64 << jump.to;
            }
        }
    }

    let unblocked = exits & !own_occ & !pred_occ;
    let safe = unblocked & !pred_atk;
    let n_safe = safe.count_ones();
    if n_safe >= 2 {
        return 0;
    }

    let in_opp_pocket = (sq_bit & opp_pocket) != 0;
    if n_safe == 0 {
        let mut pen = HEAVY_CAGE_ZERO_SAFE[tier];
        if unblocked == 0 {
            pen += 75;
        }
        if in_opp_pocket {
            pen += 60;
        }
        pen
    } else if in_opp_pocket {
        HEAVY_CAGE_ONE_SAFE_POCKET[tier]
    } else {
        HEAVY_CAGE_ONE_SAFE_OPEN[tier]
    }
}

#[inline]
pub const fn mvv_lva_value(kind_idx: usize) -> i32 {
    PIECE_VALUE[kind_idx]
}

#[inline]
pub const fn is_trapped_at(side: Color, sq: Square) -> bool {
    (sq.bit() & TRAPS_MASK[side.opp().idx()]) != 0
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::Square;

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    #[test]
    fn test_rats_eval_rotational_symmetry() {
        let p1_pieces = [
            (Color::P1, PieceKind::Rat, sq("b5")),
            (Color::P1, PieceKind::Lion, sq("g9")),
            (Color::P1, PieceKind::Elephant, sq("d4")),
            (Color::P2, PieceKind::Elephant, sq("a5")),
            (Color::P2, PieceKind::Rat, sq("e6")),
            (Color::P2, PieceKind::Cat, sq("d2")),
        ];
        let p2_pieces: Vec<(Color, PieceKind, Square)> = p1_pieces
            .iter()
            .map(|&(c, k, s)| (c.opp(), k, Square(62 - s.0)))
            .collect();

        let (pos1, _) = RatsPos::from_custom(&p1_pieces, Color::P1, [3, 6]);
        let (pos2, _) = RatsPos::from_custom(&p2_pieces, Color::P2, [6, 3]);
        assert_eq!(evaluate(&pos1), evaluate(&pos2));
    }

    #[test]
    fn test_water_monster_rat_strongly_valued_against_elephant() {
        let in_water = [
            (Color::P1, PieceKind::Rat, sq("b5")),
            (Color::P2, PieceKind::Elephant, sq("a5")),
        ];
        let on_land = [
            (Color::P1, PieceKind::Rat, sq("a4")),
            (Color::P2, PieceKind::Elephant, sq("a5")),
        ];
        let (pos_w, _) = RatsPos::from_custom(&in_water, Color::P1, [4, 5]);
        let (pos_l, _) = RatsPos::from_custom(&on_land, Color::P1, [4, 5]);
        assert!(
            evaluate(&pos_w) > evaluate(&pos_l) + 80,
            "Water Monster Rat should score much higher than land Rat vs Elephant!"
        );
    }
}

