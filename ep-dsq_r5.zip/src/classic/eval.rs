//! Dedicated handcrafted evaluation for Classic SuperKo Dou Shou Qi (no EP rules).
//!
//! Pure Dou Shou Qi strategy — zero EP reserve or invasion-farming bias:
//! - Exact compile-time BFS shortest-path distances to enemy Den for all 3 movement
//!   classes: Rat (swims), Land (walks around rivers), and Jumper (Lion/Tiger river jumps)
//! - Tapered Midgame / Endgame evaluation
//! - Dynamic predator-prey hierarchy (invincible Elephant, Rat-hunts-Elephant geometry,
//!   uncontested Lion/Tiger top predators)
//! - Live River-Jump blocking detection
//! - Dual-threat den-race & trap defense/vulnerability awareness

use crate::classic::board::{ClassicPos, CAPTURED};
use crate::core::{
    Color, PieceKind, COLS, DEN_SQ, INVASION_LAND_MASK, JUMPS, JUMP_COUNT, NUM_SQUARES, ORTHO_ADJ,
    OWN_DEN_MASK, ROWS, TRAPS_MASK, WATER_MASK,
};

pub const SCORE_INF: i32 = 30_000;
pub const SCORE_WIN: i32 = 29_000;
pub const SCORE_WIN_THRESHOLD: i32 = 28_000;
pub const EVAL_CLAMP: i32 = 20_000;

/// Base material values indexed by `PieceKind::idx()` (Rat=0 .. Elephant=7).
pub const PIECE_VALUE: [i32; 8] = [
    245, // Rat: sole water piece & Elephant killer
    145, // Cat
    215, // Dog
    300, // Wolf
    420, // Leopard
    680, // Tiger: river jumper
    910, // Lion: dominant jumper
    975, // Elephant: dominates Lion & Tiger
];

const PIECE_PHASE: [i32; 8] = [2, 1, 1, 2, 3, 4, 5, 6];
const MAX_PHASE: i32 = 48;
const TEMPO_BONUS: i32 = 18;

const RIVER_BANK_MASK: u64 = {
    let mut m = 0u64;
    let v_cols = [1usize, 2, 4, 5];
    let mut i = 0;
    while i < 4 {
        let c = v_cols[i];
        m |= (1u64 << (2 * COLS + c)) | (1u64 << (6 * COLS + c));
        i += 1;
    }
    let mut r = 3;
    while r <= 5 {
        m |= (1u64 << (r * COLS)) | (1u64 << (r * COLS + 3)) | (1u64 << (r * COLS + 6));
        r += 1;
    }
    m
};

const CENTER_CORRIDOR_MASK: u64 =
    (1u64 << (3 * COLS + 3)) | (1u64 << (4 * COLS + 3)) | (1u64 << (5 * COLS + 3));

const OWN_DEN_ZONE: [u64; 2] = {
    let mut zones = [0u64; 2];
    let mut side = 0;
    while side < 2 {
        let dr = DEN_SQ[side].row();
        let dc = DEN_SQ[side].col();
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let dist = r.abs_diff(dr) + c.abs_diff(dc);
                if dist >= 1 && dist <= 2 {
                    zones[side] |= 1u64 << (r * COLS + c);
                }
                c += 1;
            }
            r += 1;
        }
        side += 1;
    }
    zones
};

const fn build_bfs_den_dist(mode: u8) -> [[i32; NUM_SQUARES]; 2] {
    let mut tbl = [[20i32; NUM_SQUARES]; 2];
    let mut side = 0;
    while side < 2 {
        let opp = side ^ 1;
        let opp_den = DEN_SQ[opp].idx();
        let own_den_mask = OWN_DEN_MASK[side];
        tbl[side][opp_den] = 0;

        let mut pass = 0;
        while pass < 20 {
            let mut sq = 0;
            while sq < NUM_SQUARES {
                let bit = 1u64 << sq;
                let invalid = (bit & own_den_mask) != 0 || (mode != 0 && (bit & WATER_MASK) != 0);
                if !invalid {
                    let mut best = tbl[side][sq];
                    let mut adj = ORTHO_ADJ[sq] & !own_den_mask;
                    if mode != 0 {
                        adj &= !WATER_MASK;
                    }
                    while adj != 0 {
                        let to = adj.trailing_zeros() as usize;
                        adj &= adj - 1;
                        let cand = tbl[side][to] + 1;
                        if cand < best {
                            best = cand;
                        }
                    }
                    if mode == 2 {
                        let jc = JUMP_COUNT[sq] as usize;
                        let mut j = 0;
                        while j < jc {
                            let to = JUMPS[sq][j].to as usize;
                            let cand = tbl[side][to] + 1;
                            if cand < best {
                                best = cand;
                            }
                            j += 1;
                        }
                    }
                    tbl[side][sq] = best;
                }
                sq += 1;
            }
            pass += 1;
        }
        side += 1;
    }
    tbl
}

const DIST_RAT: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(0);
const DIST_LAND: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(1);
const DIST_JUMPER: [[i32; NUM_SQUARES]; 2] = build_bfs_den_dist(2);

const PST_MG: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let center_file = 3 - c.abs_diff(3) as i32;
                let advance = r as i32;
                let dist = if k == 0 {
                    DIST_RAT[0][sq]
                } else if k == 5 || k == 6 {
                    DIST_JUMPER[0][sq]
                } else {
                    DIST_LAND[0][sq]
                };

                let mut val = match k {
                    0 => {
                        let mut v = advance * 5 + center_file * 4;
                        if (sq_bit & WATER_MASK) != 0 {
                            v += 34;
                        }
                        v
                    }
                    1 => advance * 6 + center_file * 3,
                    2 => advance * 7 + center_file * 4,
                    3 => advance * 8 + center_file * 5,
                    4 => advance * 9 + center_file * 5,
                    5 => {
                        let mut v = advance * 10 + center_file * 6;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 26;
                        }
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 22;
                        }
                        v
                    }
                    6 => {
                        let mut v = advance * 11 + center_file * 7;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 32;
                        }
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 26;
                        }
                        v
                    }
                    7 => {
                        let mut v = advance * 10 + center_file * 8;
                        if (sq_bit & CENTER_CORRIDOR_MASK) != 0 {
                            v += 16;
                        }
                        v
                    }
                    _ => 0,
                };

                if dist <= 4 {
                    val += (5 - dist) * 20;
                }
                if dist == 1 {
                    val += 30;
                }
                if k <= 4 && (sq_bit & TRAPS_MASK[0]) != 0 {
                    val += 10;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

const PST_EG: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let dist = if k == 0 {
                    DIST_RAT[0][sq]
                } else if k == 5 || k == 6 {
                    DIST_JUMPER[0][sq]
                } else {
                    DIST_LAND[0][sq]
                };

                let progress = if 12 > dist { 12 - dist } else { 0 };
                let weight = match k {
                    0 => 14,
                    1 => 13,
                    2 => 14,
                    3 => 15,
                    4 => 16,
                    5 => 20,
                    6 => 22,
                    7 => 19,
                    _ => 14,
                };
                let mut val = progress * weight;

                if dist <= 3 {
                    val += (4 - dist) * 35;
                }
                if (k == 5 || k == 6) && (sq_bit & RIVER_BANK_MASK) != 0 {
                    val += 18;
                }
                if k == 0 && (sq_bit & WATER_MASK) != 0 {
                    val += 16;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

#[inline]
const fn manhattan(sq_a: u8, sq_b: u8) -> i32 {
    let ra = (sq_a as usize) / COLS;
    let ca = (sq_a as usize) % COLS;
    let rb = (sq_b as usize) / COLS;
    let cb = (sq_b as usize) % COLS;
    (ra.abs_diff(rb) + ca.abs_diff(cb)) as i32
}

/// Evaluates `pos` from the perspective of `pos.side_to_move`.
#[inline]
pub fn evaluate(pos: &ClassicPos) -> i32 {
    if let Some(w) = pos.winner {
        return if w == pos.side_to_move {
            SCORE_WIN
        } else {
            -SCORE_WIN
        };
    }

    let mut phase = 0i32;
    for k in 0..8usize {
        if pos.piece_sq[k] != CAPTURED {
            phase += PIECE_PHASE[k];
        }
        if pos.piece_sq[8 + k] != CAPTURED {
            phase += PIECE_PHASE[k];
        }
    }
    let mg_w = phase.min(MAX_PHASE);
    let eg_w = MAX_PHASE - mg_w;

    let (p1_mg, p1_eg) = eval_side(pos, 0);
    let (p2_mg, p2_eg) = eval_side(pos, 1);

    let mg_diff = p1_mg - p2_mg;
    let eg_diff = p1_eg - p2_eg;
    let blended = (mg_diff * mg_w + eg_diff * eg_w) / MAX_PHASE;

    let stm_score = match pos.side_to_move {
        Color::P1 => blended + TEMPO_BONUS,
        Color::P2 => -blended + TEMPO_BONUS,
    };

    stm_score.clamp(-EVAL_CLAMP, EVAL_CLAMP)
}

#[inline]
fn eval_side(pos: &ClassicPos, side: usize) -> (i32, i32) {
    let opp = side ^ 1;
    let base = side * 8;
    let opp_base = opp * 8;

    let mut mg = 0i32;
    let mut eg = 0i32;
    let mut min_den_dist = 20i32;
    let mut second_den_dist = 20i32;
    let mut highest_alive = -1i32;
    let mut opp_highest_alive = -1i32;

    for k in 0..8usize {
        if pos.piece_sq[opp_base + k] != CAPTURED {
            opp_highest_alive = k as i32;
        }
        let sq = pos.piece_sq[base + k];
        if sq == CAPTURED {
            continue;
        }
        highest_alive = k as i32;
        let sq_idx = sq as usize;
        let pst_sq = if side == 0 { sq_idx } else { 62 - sq_idx };

        let mat = PIECE_VALUE[k];
        mg += mat + PST_MG[k][pst_sq];
        eg += mat + PST_EG[k][pst_sq];

        let d = if k == 0 {
            DIST_RAT[side][sq_idx]
        } else if k == 5 || k == 6 {
            DIST_JUMPER[side][sq_idx]
        } else {
            DIST_LAND[side][sq_idx]
        };

        if d < min_den_dist {
            second_den_dist = min_den_dist;
            min_den_dist = d;
        } else if d < second_den_dist {
            second_den_dist = d;
        }
    }

    let own_rat = pos.piece_sq[base + PieceKind::Rat.idx()];
    let own_tiger = pos.piece_sq[base + PieceKind::Tiger.idx()];
    let own_lion = pos.piece_sq[base + PieceKind::Lion.idx()];
    let own_ele = pos.piece_sq[base + PieceKind::Elephant.idx()];

    let opp_rat = pos.piece_sq[opp_base + PieceKind::Rat.idx()];
    let opp_tiger = pos.piece_sq[opp_base + PieceKind::Tiger.idx()];
    let opp_lion = pos.piece_sq[opp_base + PieceKind::Lion.idx()];
    let opp_ele = pos.piece_sq[opp_base + PieceKind::Elephant.idx()];

    if own_ele != CAPTURED && opp_rat == CAPTURED {
        mg += 225;
        eg += 285;
    }
    if own_rat != CAPTURED && opp_ele != CAPTURED {
        mg += 115;
        eg += 130;
        let d_re = manhattan(own_rat, opp_ele);
        let hunt = (10 - d_re).max(0) * 7;
        mg += hunt;
        eg += hunt + 4;
    }
    if own_lion != CAPTURED && opp_ele == CAPTURED {
        mg += 175;
        eg += 225;
    }
    if own_tiger != CAPTURED && opp_ele == CAPTURED && opp_lion == CAPTURED {
        mg += 165;
        eg += 215;
    }
    if highest_alive > opp_highest_alive && highest_alive >= 2 {
        eg += 100;
    }

    // Live River-Jump Blocking
    if own_rat != CAPTURED {
        let rat_bit = 1u64 << own_rat;
        if (rat_bit & WATER_MASK) != 0 {
            for &jumper_sq in &[opp_lion, opp_tiger] {
                if jumper_sq != CAPTURED {
                    let jc = JUMP_COUNT[jumper_sq as usize] as usize;
                    for j in 0..jc {
                        if (rat_bit & JUMPS[jumper_sq as usize][j].water_mask) != 0 {
                            mg += 30;
                            eg += 24;
                        }
                    }
                }
            }
        }
    }

    // Den-race pressure & dual threats
    if min_den_dist <= 5 {
        let bonus = (6 - min_den_dist) * 20;
        mg += bonus;
        eg += bonus * 2;
    }
    if second_den_dist <= 4 {
        let duo = (5 - second_den_dist) * 16;
        mg += duo;
        eg += duo + 20;
    }

    // Den defense & undefended den bonus
    let own_occ = pos.occ_side[side];
    let opp_occ = pos.occ_side[opp];
    let opp_invading = (opp_occ & INVASION_LAND_MASK[opp]) != 0;
    let own_defenders = (own_occ & OWN_DEN_ZONE[side]).count_ones() as i32;
    let opp_defenders = (opp_occ & OWN_DEN_ZONE[opp]).count_ones() as i32;

    if opp_invading {
        if own_defenders == 0 {
            mg -= 65;
            eg -= 95;
        } else {
            mg += own_defenders.min(2) * 20;
            eg += own_defenders.min(2) * 16;
        }
    }

    if min_den_dist <= 3 && opp_defenders == 0 {
        mg += 70;
        eg += 130;
    }

    // Vulnerable piece standing on an enemy trap
    let trapped_own = own_occ & TRAPS_MASK[opp];
    if trapped_own != 0 {
        let sq = trapped_own.trailing_zeros() as usize;
        if (ORTHO_ADJ[sq] & opp_occ) != 0 {
            mg -= 110;
            eg -= 120;
        } else if opp_defenders > 0 {
            mg -= 25;
            eg -= 25;
        }
    }

    // Piece count bonus
    let piece_count = own_occ.count_ones() as i32;
    mg += piece_count * 12;
    eg += piece_count * 18;

    (mg, eg)
}

#[inline]
pub const fn mvv_lva_value(kind_idx: usize) -> i32 {
    PIECE_VALUE[kind_idx]
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::Square;

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    #[test]
    fn test_classic_start_eval_exact_tempo() {
        let (pos, _) = ClassicPos::new_start();
        // Classic starting board is 100% symmetric (no EP offset!), so eval == +TEMPO_BONUS!
        assert_eq!(evaluate(&pos), TEMPO_BONUS);
    }

    #[test]
    fn test_classic_eval_rotational_symmetry() {
        let p1_pieces = [
            (Color::P1, PieceKind::Lion, sq("d4")),
            (Color::P1, PieceKind::Rat, sq("b5")),
            (Color::P2, PieceKind::Wolf, sq("f7")),
            (Color::P2, PieceKind::Cat, sq("d2")),
        ];
        let p2_pieces: Vec<(Color, PieceKind, Square)> = p1_pieces
            .iter()
            .map(|&(c, k, s)| (c.opp(), k, Square(62 - s.0)))
            .collect();

        let (pos1, _) = ClassicPos::from_custom(&p1_pieces, Color::P1);
        let (pos2, _) = ClassicPos::from_custom(&p2_pieces, Color::P2);
        assert_eq!(evaluate(&pos1), evaluate(&pos2));
    }
}

