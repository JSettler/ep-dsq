//! Fast handcrafted evaluation for Dou Shou Qi with EP rules.
//!
//! Returns centipawn scores from the perspective of `pos.side_to_move`.
//! Static scores are strictly clamped within `[-EVAL_CLAMP, +EVAL_CLAMP]`
//! so they never collide with forced-win mate scores (`±SCORE_WIN`).

use crate::core::board_bb::{BitboardPos, CAPTURED};
use crate::core::{
    Color, PieceKind, Square, COLS, DEN_SQ, INVASION_LAND_MASK, MAX_EP, NUM_SQUARES, ROWS,
    TRAPS_MASK, WATER_MASK,
};

pub const SCORE_INF: i32 = 30_000;
pub const SCORE_WIN: i32 = 29_000;
pub const SCORE_WIN_THRESHOLD: i32 = 28_000;
pub const EVAL_CLAMP: i32 = 20_000;

/// Base material values indexed by `PieceKind::idx()` (Rat=0 .. Elephant=7).
pub const PIECE_VALUE: [i32; 8] = [
    220, // Rat: only water piece & Elephant killer
    140, // Cat
    210, // Dog
    290, // Wolf
    400, // Leopard
    650, // Tiger: jumps rivers
    880, // Lion: dominant jumper
    950, // Elephant: dominates Lion/Tiger
];

/// Non-linear value of current EP reserve `0..=10`.
/// Having 0 EP carries a real tactical risk (SuperKo lockout / zugzwang),
/// while high EP has diminishing marginal utility.
const EP_VALUE: [i32; (MAX_EP as usize) + 1] = [
    -75, // 0 EP: danger of repetition lockout
    0,   // 1 EP
    22,  // 2 EP
    38,  // 3 EP
    50,  // 4 EP
    59,  // 5 EP
    66,  // 6 EP
    71,  // 7 EP
    75,  // 8 EP
    78,  // 9 EP
    80,  // 10 EP
];

const TEMPO_BONUS: i32 = 16;

/// River bank squares from which Lion & Tiger can jump across water.
const RIVER_BANK_MASK: u64 = {
    let mut m = 0u64;
    // Vertical jump banks: rows 2 & 6, cols 1, 2, 4, 5
    let v_cols = [1usize, 2, 4, 5];
    let mut i = 0;
    while i < 4 {
        let c = v_cols[i];
        m |= (1u64 << (2 * COLS + c)) | (1u64 << (6 * COLS + c));
        i += 1;
    }
    // Horizontal jump banks: rows 3, 4, 5, cols 0, 3, 6
    let mut r = 3;
    while r <= 5 {
        m |= (1u64 << (r * COLS)) | (1u64 << (r * COLS + 3)) | (1u64 << (r * COLS + 6));
        r += 1;
    }
    m
};

/// Squares within Manhattan distance 2 of each player's own den (defensive zone).
const OWN_DEN_ZONE: [u64; 2] = {
    let mut zones = [0u64; 2];
    let mut side = 0;
    while side < 2 {
        let dr = DEN_SQ[side].row();
        let dc = DEN_SQ[side].col();
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let dist = r.abs_diff(dr) + c.abs_diff(dc);
                if dist >= 1 && dist <= 2 {
                    zones[side] |= 1u64 << (r * COLS + c);
                }
                c += 1;
            }
            r += 1;
        }
        side += 1;
    }
    zones
};

/// Precomputed Manhattan distance to the opponent's den: `DIST_TO_OPP_DEN[side][sq]`.
const DIST_TO_OPP_DEN: [[i32; NUM_SQUARES]; 2] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 2];
    let mut side = 0;
    while side < 2 {
        let opp = side ^ 1;
        let dr = DEN_SQ[opp].row();
        let dc = DEN_SQ[opp].col();
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let dist = r.abs_diff(dr) + c.abs_diff(dc);
                tbl[side][r * COLS + c] = dist as i32;
                c += 1;
            }
            r += 1;
        }
        side += 1;
    }
    tbl
};

/// Piece-square tables indexed by `[kind 0..8][p1_perspective_sq 0..63]`.
/// For P2, square `sq` is rotated 180 degrees to `62 - sq`.
const PST: [[i32; NUM_SQUARES]; 8] = {
    let mut tbl = [[0i32; NUM_SQUARES]; 8];
    let mut k = 0;
    while k < 8 {
        let mut r = 0;
        while r < ROWS {
            let mut c = 0;
            while c < COLS {
                let sq = r * COLS + c;
                let sq_bit = 1u64 << sq;
                let dist_to_den = (8 - r) + c.abs_diff(3); // 0..=11
                let center_file = 3 - c.abs_diff(3) as i32; // 0 on a/g, 3 on d
                let advance = r as i32; // 0..=8

                // Advancement + central control + den-race urgency
                let mut val = match k {
                    0 => {
                        // Rat: loves water & central river control, advances toward enemy Elephant/den
                        let mut v = advance * 6 + center_file * 4;
                        if (sq_bit & WATER_MASK) != 0 {
                            v += 28;
                        }
                        v
                    }
                    1 => {
                        // Cat: cheap utility/invader/defender
                        advance * 7 + center_file * 3
                    }
                    2 => {
                        // Dog: solid mid-tier advancing piece
                        advance * 8 + center_file * 4
                    }
                    3 => {
                        // Wolf: mid-tier attacker
                        advance * 9 + center_file * 5
                    }
                    4 => {
                        // Leopard: strong flank & invasion piece
                        advance * 10 + center_file * 5
                    }
                    5 => {
                        // Tiger: loves river banks (especially center column d4..d6)
                        let mut v = advance * 11 + center_file * 6;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 24;
                        }
                        if c == 3 && r >= 3 && r <= 5 {
                            v += 18; // Controls BOTH rivers from center strip
                        }
                        v
                    }
                    6 => {
                        // Lion: dominates river banks and center corridor
                        let mut v = advance * 12 + center_file * 7;
                        if (sq_bit & RIVER_BANK_MASK) != 0 {
                            v += 28;
                        }
                        if c == 3 && r >= 3 && r <= 5 {
                            v += 22;
                        }
                        v
                    }
                    7 => {
                        // Elephant: slow tank, very valuable near center and invading
                        advance * 11 + center_file * 8
                    }
                    _ => 0,
                };

                // Extra proximity bonus when closing in on the opponent's den
                if dist_to_den <= 4 {
                    val += (5 - dist_to_den as i32) * 18;
                }
                if dist_to_den == 1 {
                    // On an enemy trap: dangerous if enemy can capture, but threatens immediate win.
                    // Keep bonus moderate so search resolves tactics cleanly.
                    val += 25;
                }

                tbl[k][sq] = val;
                c += 1;
            }
            r += 1;
        }
        k += 1;
    }
    tbl
};

/// Evaluates `pos` from the perspective of `pos.side_to_move`.
#[inline]
pub fn evaluate(pos: &BitboardPos) -> i32 {
    if let Some(w) = pos.winner {
        return if w == pos.side_to_move {
            SCORE_WIN
        } else {
            -SCORE_WIN
        };
    }

    let p1_score = eval_side(pos, 0);
    let p2_score = eval_side(pos, 1);

    let diff = p1_score - p2_score;
    let stm_score = match pos.side_to_move {
        Color::P1 => diff + TEMPO_BONUS,
        Color::P2 => -diff + TEMPO_BONUS,
    };

    stm_score.clamp(-EVAL_CLAMP, EVAL_CLAMP)
}

#[inline]
fn eval_side(pos: &BitboardPos, side: usize) -> i32 {
    let opp = side ^ 1;
    let base = side * 8;
    let opp_base = opp * 8;

    let mut score = 0i32;
    let mut min_den_dist = 12i32;

    // 1. Material + Piece-Square Tables + Den Race
    for k in 0..8usize {
        let sq = pos.piece_sq[base + k];
        if sq == CAPTURED {
            continue;
        }
        let sq_idx = sq as usize;
        let pst_sq = if side == 0 { sq_idx } else { 62 - sq_idx };
        score += PIECE_VALUE[k] + PST[k][pst_sq];

        let d = DIST_TO_OPP_DEN[side][sq_idx];
        if d < min_den_dist {
            min_den_dist = d;
        }
    }

    // 2. Dynamic Dou Shou Qi piece-hierarchy interactions
    let opp_rat_alive = pos.piece_sq[opp_base + PieceKind::Rat.idx()] != CAPTURED;
    let opp_lion_alive = pos.piece_sq[opp_base + PieceKind::Lion.idx()] != CAPTURED;
    let opp_ele_alive = pos.piece_sq[opp_base + PieceKind::Elephant.idx()] != CAPTURED;

    // Own Elephant is nearly invincible once enemy Rat is eliminated
    if pos.piece_sq[base + PieceKind::Elephant.idx()] != CAPTURED && !opp_rat_alive {
        score += 210;
    }
    // Own Rat has extra value while enemy Elephant is still on the board
    if pos.piece_sq[base + PieceKind::Rat.idx()] != CAPTURED && opp_ele_alive {
        score += 110;
    }
    // Own Lion becomes top predator if enemy Elephant is gone
    if pos.piece_sq[base + PieceKind::Lion.idx()] != CAPTURED && !opp_ele_alive {
        score += 160;
    }
    // Own Tiger becomes top predator if both enemy Elephant & Lion are gone
    if pos.piece_sq[base + PieceKind::Tiger.idx()] != CAPTURED && !opp_ele_alive && !opp_lion_alive
    {
        score += 150;
    }

    // 3. Closest-piece den-race bonus
    if min_den_dist <= 5 {
        score += (6 - min_den_dist) * 14;
    }

    // 4. Defensive presence near own den when opponent has pieces in our half
    let opp_invading = (pos.occ_side[opp] & INVASION_LAND_MASK[opp]) != 0;
    if opp_invading {
        let defenders = (pos.occ_side[side] & OWN_DEN_ZONE[side]).count_ones() as i32;
        if defenders == 0 {
            score -= 55;
        } else {
            score += defenders.min(2) * 18;
        }
    }

    // 5. Trap occupation penalty if enemy has adjacent pieces (vulnerable to rank-0 capture)
    let trapped_own = pos.occ_side[side] & TRAPS_MASK[opp];
    if trapped_own != 0 && (pos.occ_side[opp] & OWN_DEN_ZONE[opp]) != 0 {
        // Still allow search to find den-win, just discourage passive self-trapping in leaf nodes
        score -= 35;
    }

    // 6. EP reserve and sustainable EP generation (land presence in opponent's last 4 rows)
    let ep = pos.ep[side] as usize;
    score += EP_VALUE[ep];

    let has_invasion_land = (pos.occ_side[side] & INVASION_LAND_MASK[side]) != 0;
    if has_invasion_land {
        score += if ep <= 2 { 45 } else { 22 };
    }

    // 7. Mobility / piece count endgame bonus (more pieces = easier to force traps & blocks)
    let piece_count = pos.occ_side[side].count_ones() as i32;
    score += piece_count * 12;

    score
}

/// Fast MVV-LVA victim/attacker value for move ordering in search.
#[inline]
pub const fn mvv_lva_value(kind_idx: usize) -> i32 {
    PIECE_VALUE[kind_idx]
}

/// Helper to check if a square is inside a given side's traps (useful in eval/search).
#[inline]
pub const fn is_trapped_at(side: Color, sq: Square) -> bool {
    (sq.bit() & TRAPS_MASK[side.opp().idx()]) != 0
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::Square;

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    #[test]
    fn test_start_position_eval_is_sane() {
        let (pos, _hist) = BitboardPos::new_start();
        // Start position is symmetric except P2 has +1 EP (5 vs 4 -> +9 cp) and P1 has tempo (+16 cp)
        let s = evaluate(&pos);
        assert!(
            s > -50 && s < 50,
            "Start position eval should be near 0, got {}",
            s
        );
    }

    #[test]
    fn test_eval_rotational_symmetry() {
        let p1_pieces = [
            (Color::P1, PieceKind::Lion, sq("d4")),
            (Color::P1, PieceKind::Rat, sq("b5")),
            (Color::P2, PieceKind::Wolf, sq("f7")),
        ];
        // Rotate 180 degrees: sq -> 62 - sq, swap colors & EP
        let p2_pieces: Vec<(Color, PieceKind, Square)> = p1_pieces
            .iter()
            .map(|&(c, k, s)| (c.opp(), k, Square(62 - s.0)))
            .collect();

        let (pos1, _) = BitboardPos::from_custom(&p1_pieces, Color::P1, [3, 5]);
        let (pos2, _) = BitboardPos::from_custom(&p2_pieces, Color::P2, [5, 3]);

        assert_eq!(
            evaluate(&pos1),
            evaluate(&pos2),
            "Evaluation must be perfectly rotationally symmetric!"
        );
    }

    #[test]
    fn test_material_and_ep_advantage() {
        let pieces_a = [
            (Color::P1, PieceKind::Lion, sq("d4")),
            (Color::P2, PieceKind::Cat, sq("d6")),
        ];
        let (pos_a, _) = BitboardPos::from_custom(&pieces_a, Color::P1, [4, 4]);
        assert!(evaluate(&pos_a) > 500);

        // Same board, P1 has 4 EP vs 0 EP
        let pieces_b = [
            (Color::P1, PieceKind::Cat, sq("a2")),
            (Color::P2, PieceKind::Cat, sq("g8")),
        ];
        let (pos_hi, _) = BitboardPos::from_custom(&pieces_b, Color::P1, [4, 4]);
        let (pos_lo, _) = BitboardPos::from_custom(&pieces_b, Color::P1, [0, 4]);
        assert!(evaluate(&pos_hi) > evaluate(&pos_lo) + 100);
    }
}

