//! Principal Variation Search (PVS) engine for Dou Shou Qi with EP + SuperKo rules.
//!
//! Features:
//! - Iterative Deepening with Aspiration Windows
//! - Principal Variation Search (PVS) + Quiescence Search (captures + den wins)
//! - GHI-safe Transposition Table (respects EP reserves & SuperKo path dependence)
//! - Move Ordering: TT move -> Den win -> MVV-LVA captures -> Killers -> History heuristic
//! - Late Move Reductions (LMR) & Reverse Futility Pruning (RFP)
//! - Exact mate-distance scoring and strict `History` stack invariants

use crate::core::board_bb::{BitboardPos, History, EMPTY_SQ};
use crate::core::{Move, DEN_SQ};
use crate::eval::{evaluate, mvv_lva_value, SCORE_INF, SCORE_WIN, SCORE_WIN_THRESHOLD};
use std::time::{Duration, Instant};

pub const MAX_PLY: usize = 96;
const DEFAULT_TT_MB: usize = 32;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
enum Bound {
    Empty = 0,
    Exact = 1,
    Lower = 2,
    Upper = 3,
}

#[derive(Clone, Copy, Debug)]
struct TTEntry {
    key: u64,
    best_move: Move,
    score: i16,
    depth: i8,
    bound: Bound,
    age: u8,
}

impl TTEntry {
    const EMPTY: TTEntry = TTEntry {
        key: 0,
        best_move: Move::NULL,
        score: 0,
        depth: -1,
        bound: Bound::Empty,
        age: 0,
    };
}

pub struct TranspositionTable {
    entries: Vec<TTEntry>,
    mask: usize,
    age: u8,
}

impl TranspositionTable {
    pub fn new_mb(mb: usize) -> Self {
        let bytes = mb.max(1) * 1024 * 1024;
        let entry_size = std::mem::size_of::<TTEntry>();
        let raw_count = (bytes / entry_size).max(1024);
        let count = raw_count.next_power_of_two() >> 1;
        let count = count.max(1024);
        Self {
            entries: vec![TTEntry::EMPTY; count],
            mask: count - 1,
            age: 0,
        }
    }

    pub fn clear(&mut self) {
        self.entries.fill(TTEntry::EMPTY);
        self.age = 0;
    }

    pub fn next_age(&mut self) {
        self.age = self.age.wrapping_add(1);
    }

    #[inline]
    fn probe(&self, key: u64) -> Option<TTEntry> {
        let e = self.entries[(key as usize) & self.mask];
        if e.bound != Bound::Empty && e.key == key {
            Some(e)
        } else {
            None
        }
    }

    #[inline]
    fn store(&mut self, key: u64, best_move: Move, score: i32, depth: i32, bound: Bound) {
        let idx = (key as usize) & self.mask;
        let cur = self.entries[idx];

        // Replace if empty, older search generation, deeper/equal depth, or exact bound
        let replace = cur.bound == Bound::Empty
            || cur.age != self.age
            || depth as i8 >= cur.depth
            || bound == Bound::Exact;

        if replace {
            // Preserve existing move if new entry has no move for the same key
            let mv = if best_move != Move::NULL {
                best_move
            } else if cur.key == key {
                cur.best_move
            } else {
                Move::NULL
            };
            self.entries[idx] = TTEntry {
                key,
                best_move: mv,
                score: score.clamp(-SCORE_INF, SCORE_INF) as i16,
                depth: depth.clamp(-1, 120) as i8,
                bound,
                age: self.age,
            };
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct SearchLimits {
    pub max_depth: usize,
    pub max_time: Option<Duration>,
    pub max_nodes: Option<u64>,
}

impl SearchLimits {
    pub fn depth(d: usize) -> Self {
        Self {
            max_depth: d.min(MAX_PLY - 1),
            max_time: None,
            max_nodes: None,
        }
    }

    pub fn time_ms(ms: u64) -> Self {
        Self {
            max_depth: MAX_PLY - 1,
            max_time: Some(Duration::from_millis(ms)),
            max_nodes: None,
        }
    }

    pub fn nodes(n: u64) -> Self {
        Self {
            max_depth: MAX_PLY - 1,
            max_time: None,
            max_nodes: Some(n),
        }
    }
}

#[derive(Clone, Debug)]
pub struct SearchResult {
    pub best_move: Move,
    pub score: i32,
    pub depth: usize,
    pub nodes: u64,
    pub elapsed: Duration,
    pub pv: Vec<Move>,
}

pub struct Searcher {
    tt: TranspositionTable,
    killers: [[Move; 2]; MAX_PLY],
    history_heur: [[[i32; 64]; 64]; 2],
    nodes: u64,
    start_time: Instant,
    limits: SearchLimits,
    aborted: bool,
    pub verbose: bool,
}

impl Searcher {
    pub fn new() -> Self {
        Self::with_tt_mb(DEFAULT_TT_MB)
    }

    pub fn with_tt_mb(mb: usize) -> Self {
        Self {
            tt: TranspositionTable::new_mb(mb),
            killers: [[Move::NULL; 2]; MAX_PLY],
            history_heur: [[[0; 64]; 64]; 2],
            nodes: 0,
            start_time: Instant::now(),
            limits: SearchLimits::depth(1),
            aborted: false,
            verbose: false,
        }
    }

    pub fn clear_tables(&mut self) {
        self.tt.clear();
        self.killers = [[Move::NULL; 2]; MAX_PLY];
        self.history_heur = [[[0; 64]; 64]; 2];
    }

    #[inline]
    fn score_to_tt(score: i32, ply: usize) -> i32 {
        if score >= SCORE_WIN_THRESHOLD {
            score + ply as i32
        } else if score <= -SCORE_WIN_THRESHOLD {
            score - ply as i32
        } else {
            score
        }
    }

    #[inline]
    fn score_from_tt(score: i32, ply: usize) -> i32 {
        if score >= SCORE_WIN_THRESHOLD {
            score - ply as i32
        } else if score <= -SCORE_WIN_THRESHOLD {
            score + ply as i32
        } else {
            score
        }
    }

    #[inline]
    fn check_limits(&mut self) -> bool {
        if self.aborted {
            return true;
        }
        if (self.nodes & 2047) == 0 {
            if let Some(max_nodes) = self.limits.max_nodes {
                if self.nodes >= max_nodes {
                    self.aborted = true;
                    return true;
                }
            }
            if let Some(max_time) = self.limits.max_time {
                if self.start_time.elapsed() >= max_time {
                    self.aborted = true;
                    return true;
                }
            }
        }
        false
    }

    fn decay_history(&mut self) {
        for side in 0..2 {
            for f in 0..64 {
                for t in 0..64 {
                    self.history_heur[side][f][t] /= 2;
                }
            }
        }
    }

    pub fn search(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        limits: SearchLimits,
    ) -> SearchResult {
        let initial_hist_len = history.len();
        self.nodes = 0;
        self.start_time = Instant::now();
        self.limits = limits;
        self.aborted = false;
        self.tt.next_age();
        self.killers = [[Move::NULL; 2]; MAX_PLY];
        self.decay_history();

        let root_moves = pos.gen_legal_moves(history);
        if root_moves.is_empty() {
            return SearchResult {
                best_move: Move::NULL,
                score: -SCORE_WIN,
                depth: 0,
                nodes: 0,
                elapsed: self.start_time.elapsed(),
                pv: Vec::new(),
            };
        }

        // Fast path: if only 1 legal move exists (and we aren't running a fixed-depth analysis),
        // we still evaluate depth 1 to provide a sensible score.
        let mut best_move = root_moves.as_slice()[0];
        let mut best_score = 0i32;
        let mut completed_depth = 0usize;
        let mut best_pv: Vec<Move> = vec![best_move];

        let max_depth = limits.max_depth.clamp(1, MAX_PLY - 1);

        for depth in 1..=max_depth {
            let mut pv_line = Vec::with_capacity(depth + 8);

            // Aspiration windows from depth 4 onward
            let mut alpha = -SCORE_INF;
            let mut beta = SCORE_INF;
            let mut delta = 40i32;

            if depth >= 4 && best_score.abs() < SCORE_WIN_THRESHOLD {
                alpha = (best_score - delta).max(-SCORE_INF);
                beta = (best_score + delta).min(SCORE_INF);
            }

            let score = loop {
                pv_line.clear();
                let (s, _tainted) = self.negamax(
                    pos,
                    history,
                    depth as i32,
                    0,
                    alpha,
                    beta,
                    true,
                    &mut pv_line,
                );

                // Always complete depth 1 regardless of time/node abort
                if self.aborted && depth > 1 {
                    break s;
                }

                if s <= alpha {
                    alpha = (alpha - delta).max(-SCORE_INF);
                    delta *= 2;
                } else if s >= beta {
                    beta = (beta + delta).min(SCORE_INF);
                    delta *= 2;
                } else {
                    break s;
                }

                if delta > 1000 {
                    alpha = -SCORE_INF;
                    beta = SCORE_INF;
                }
            };

            if self.aborted && depth > 1 {
                break;
            }

            if let Some(&mv) = pv_line.first() {
                best_move = mv;
                best_score = score;
                completed_depth = depth;
                best_pv = pv_line;
            }

            if self.verbose {
                let dt = self.start_time.elapsed().as_secs_f64();
                let nps = if dt > 0.0 {
                    (self.nodes as f64 / dt) as u64
                } else {
                    0
                };
                let pv_str: String = best_pv
                    .iter()
                    .map(|m| m.to_string())
                    .collect::<Vec<_>>()
                    .join(" ");
                println!(
                    "info depth {:>2} score {:>6} nodes {:>9} nps {:>9} time {:>5}ms pv {}",
                    completed_depth,
                    best_score,
                    self.nodes,
                    nps,
                    self.start_time.elapsed().as_millis(),
                    pv_str
                );
            }

            // Stop early if a forced win is found within this depth
            if best_score.abs() >= SCORE_WIN_THRESHOLD {
                let plies_to_win = (SCORE_WIN - best_score.abs()) as usize;
                if plies_to_win <= depth {
                    break;
                }
            }

            // Soft time check: don't start a brand-new iteration if >55% of time is spent
            if let Some(max_time) = limits.max_time {
                if self.start_time.elapsed() * 100 >= max_time * 55 {
                    break;
                }
            }
        }

        debug_assert_eq!(
            history.len(),
            initial_hist_len,
            "History stack leaked during search!"
        );

        SearchResult {
            best_move,
            score: best_score,
            depth: completed_depth,
            nodes: self.nodes,
            elapsed: self.start_time.elapsed(),
            pv: best_pv,
        }
    }

    /// Core PVS search.
    /// Returns `(score, history_tainted)` where `history_tainted == true` means the
    /// subtree encountered a SuperKo EP deduction or 0-EP move restriction, so we
    /// avoid storing a path-dependent score in the Transposition Table.
    #[allow(clippy::too_many_arguments)]
    fn negamax(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        depth: i32,
        ply: usize,
        mut alpha: i32,
        beta: i32,
        is_pv: bool,
        pv: &mut Vec<Move>,
    ) -> (i32, bool) {
        pv.clear();

        if let Some(w) = pos.winner {
            let s = if w == pos.side_to_move {
                SCORE_WIN - ply as i32
            } else {
                -SCORE_WIN + ply as i32
            };
            return (s, false);
        }

        if ply >= MAX_PLY - 1 {
            return (evaluate(pos), false);
        }

        if depth <= 0 {
            return (self.qsearch(pos, history, ply, alpha, beta), false);
        }

        self.nodes += 1;
        if ply > 0 && self.check_limits() {
            return (0, true);
        }

        let stm = pos.side_to_move.idx();
        let opp = stm ^ 1;
        let opp_den_sq = DEN_SQ[opp].0;

        // GHI safety: when either side has 0 EP, SuperKo can forbid moves depending on path.
        let low_ep_risk = pos.ep[0] == 0 || pos.ep[1] == 0;
        let mut tainted = low_ep_risk;

        let tt_key = pos.tt_hash();
        let mut tt_move = Move::NULL;

        if let Some(entry) = self.tt.probe(tt_key) {
            tt_move = entry.best_move;
            if !is_pv && !low_ep_risk && entry.depth as i32 >= depth {
                let tt_score = Self::score_from_tt(entry.score as i32, ply);
                match entry.bound {
                    Bound::Exact => return (tt_score, false),
                    Bound::Lower if tt_score >= beta => return (tt_score, false),
                    Bound::Upper if tt_score <= alpha => return (tt_score, false),
                    _ => {}
                }
            }
        }

        let legal = pos.gen_legal_moves(history);
        let move_count = legal.len();
        if move_count == 0 {
            return (-SCORE_WIN + ply as i32, tainted);
        }

        // Immediate 1-ply win detection (entering opponent's den)
        for &mv in legal.as_slice() {
            if mv.to().0 == opp_den_sq {
                pv.push(mv);
                return (SCORE_WIN - (ply as i32 + 1), false);
            }
        }

        // Reverse Futility Pruning (static null move pruning) on quiet non-PV nodes
        let static_eval = if !is_pv && depth <= 3 && !low_ep_risk {
            let ev = evaluate(pos);
            let margin = 120 * depth;
            if ev - margin >= beta && beta.abs() < SCORE_WIN_THRESHOLD {
                return (ev, false);
            }
            Some(ev)
        } else {
            None
        };
        let _ = static_eval;

        // Score & sort moves for strong alpha-beta cutoffs
        let mut scored_moves: [(Move, i32); 40] = [(Move::NULL, 0); 40];
        let k1 = self.killers[ply][0];
        let k2 = self.killers[ply][1];

        for (i, &mv) in legal.as_slice().iter().enumerate() {
            let s = if mv == tt_move {
                1_000_000
            } else if mv.to().0 == opp_den_sq {
                900_000
            } else {
                let victim = pos.board_piece[mv.to().idx()];
                if victim != EMPTY_SQ {
                    let att = pos.board_piece[mv.from().idx()] as usize & 7;
                    let vic = victim as usize & 7;
                    500_000 + mvv_lva_value(vic) * 16 - mvv_lva_value(att)
                } else if mv == k1 {
                    400_000
                } else if mv == k2 {
                    390_000
                } else {
                    self.history_heur[stm][mv.from().idx()][mv.to().idx()]
                }
            };
            scored_moves[i] = (mv, s);
        }

        let orig_alpha = alpha;
        let mut best_score = -SCORE_INF;
        let mut best_move = Move::NULL;
        let mut child_pv = Vec::with_capacity(depth as usize + 4);

        for i in 0..move_count {
            // Incremental selection sort (only sorts as many moves as needed before cutoff)
            let mut best_idx = i;
            let mut best_order = scored_moves[i].1;
            for j in (i + 1)..move_count {
                if scored_moves[j].1 > best_order {
                    best_order = scored_moves[j].1;
                    best_idx = j;
                }
            }
            scored_moves.swap(i, best_idx);
            let mv = scored_moves[i].0;

            let is_capture = pos.board_piece[mv.to().idx()] != EMPTY_SQ;
            let child = pos.make_move(mv, history);
            let repeated_here = child.ep[stm] < pos.ep[stm];
            if repeated_here {
                tainted = true;
            }

            let (score, child_tainted) = if i == 0 {
                let (s, ct) = self.negamax(
                    &child,
                    history,
                    depth - 1,
                    ply + 1,
                    -beta,
                    -alpha,
                    is_pv,
                    &mut child_pv,
                );
                (-s, ct)
            } else {
                // Late Move Reductions (LMR) for quiet, non-killer late moves
                let mut reduction = 0;
                if depth >= 3 && i >= 4 && !is_capture && mv != k1 && mv != k2 {
                    reduction = 1;
                    if i >= 10 && depth >= 5 {
                        reduction = 2;
                    }
                }

                // Zero-window scout search
                let (mut s, mut ct) = self.negamax(
                    &child,
                    history,
                    depth - 1 - reduction,
                    ply + 1,
                    -alpha - 1,
                    -alpha,
                    false,
                    &mut child_pv,
                );
                s = -s;

                // Re-search at full depth if reduced search beat alpha
                if reduction > 0 && s > alpha && !(self.aborted && ply > 0) {
                    let (s2, ct2) = self.negamax(
                        &child,
                        history,
                        depth - 1,
                        ply + 1,
                        -alpha - 1,
                        -alpha,
                        false,
                        &mut child_pv,
                    );
                    s = -s2;
                    ct |= ct2;
                }

                // Full-window PV re-search if scout search fell inside (alpha, beta)
                if s > alpha && s < beta && !(self.aborted && ply > 0) {
                    let (s3, ct3) = self.negamax(
                        &child,
                        history,
                        depth - 1,
                        ply + 1,
                        -beta,
                        -alpha,
                        is_pv,
                        &mut child_pv,
                    );
                    s = -s3;
                    ct |= ct3;
                }
                (s, ct)
            };

            // CRITICAL: Always restore history immediately after recursion
            history.pop();

            if child_tainted {
                tainted = true;
            }

            if self.aborted && ply > 0 {
                return (0, true);
            }

            if score > best_score {
                best_score = score;
                best_move = mv;

                if score > alpha {
                    alpha = score;

                    if is_pv {
                        pv.clear();
                        pv.push(mv);
                        pv.extend_from_slice(&child_pv);
                    }

                    if alpha >= beta {
                        if !is_capture {
                            if self.killers[ply][0] != mv {
                                self.killers[ply][1] = self.killers[ply][0];
                                self.killers[ply][0] = mv;
                            }
                            let bonus = depth * depth;
                            let h = &mut self.history_heur[stm][mv.from().idx()][mv.to().idx()];
                            *h = (*h + bonus).min(200_000);
                        }
                        break;
                    }
                }
            }
        }

        if !self.aborted && !tainted && best_move != Move::NULL {
            let bound = if best_score <= orig_alpha {
                Bound::Upper
            } else if best_score >= beta {
                Bound::Lower
            } else {
                Bound::Exact
            };
            self.tt.store(
                tt_key,
                best_move,
                Self::score_to_tt(best_score, ply),
                depth,
                bound,
            );
        }

        (best_score, tainted)
    }

    /// Quiescence search: resolves captures and immediate den-entry wins at leaf nodes
    /// while accurately detecting 0-EP / zugzwang no-legal-move losses.
    fn qsearch(
        &mut self,
        pos: &BitboardPos,
        history: &mut History,
        ply: usize,
        mut alpha: i32,
        beta: i32,
    ) -> i32 {
        if let Some(w) = pos.winner {
            return if w == pos.side_to_move {
                SCORE_WIN - ply as i32
            } else {
                -SCORE_WIN + ply as i32
            };
        }

        if ply >= MAX_PLY - 1 {
            return evaluate(pos);
        }

        self.nodes += 1;
        if self.check_limits() {
            return 0;
        }

        let legal = pos.gen_legal_moves(history);
        if legal.is_empty() {
            return -SCORE_WIN + ply as i32;
        }

        let opp_den_sq = DEN_SQ[pos.side_to_move.opp().idx()].0;

        // Collect captures & check immediate den wins
        let mut captures: [(Move, i32); 32] = [(Move::NULL, 0); 32];
        let mut cap_len = 0usize;

        for &mv in legal.as_slice() {
            if mv.to().0 == opp_den_sq {
                return SCORE_WIN - (ply as i32 + 1);
            }
            let victim = pos.board_piece[mv.to().idx()];
            if victim != EMPTY_SQ {
                let att = pos.board_piece[mv.from().idx()] as usize & 7;
                let vic = victim as usize & 7;
                let order = mvv_lva_value(vic) * 16 - mvv_lva_value(att);
                captures[cap_len] = (mv, order);
                cap_len += 1;
            }
        }

        let stand_pat = evaluate(pos);
        if stand_pat >= beta {
            return beta;
        }
        if stand_pat > alpha {
            alpha = stand_pat;
        }

        for i in 0..cap_len {
            let mut best_idx = i;
            let mut best_order = captures[i].1;
            for j in (i + 1)..cap_len {
                if captures[j].1 > best_order {
                    best_order = captures[j].1;
                    best_idx = j;
                }
            }
            captures.swap(i, best_idx);
            let mv = captures[i].0;

            let child = pos.make_move(mv, history);
            let score = -self.qsearch(&child, history, ply + 1, -beta, -alpha);
            history.pop();

            if self.aborted {
                return 0;
            }

            if score >= beta {
                return beta;
            }
            if score > alpha {
                alpha = score;
            }
        }

        alpha
    }
}

impl Default for Searcher {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{Color, PieceKind, Square};

    fn sq(s: &str) -> Square {
        Square::from_alg(s).unwrap()
    }

    fn mv(a: &str, b: &str) -> Move {
        Move::new(sq(a), sq(b))
    }

    #[test]
    fn test_find_immediate_den_win() {
        let pieces = [
            (Color::P1, PieceKind::Cat, sq("d8")), // Next to P2 den d9!
            (Color::P2, PieceKind::Elephant, sq("a7")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(3));
        assert_eq!(res.best_move, mv("d8", "d9"));
        assert_eq!(res.score, SCORE_WIN - 1);
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_find_forced_3ply_den_win() {
        // P1 Lion on c8 can step to c9? No, d8 is closer; wait:
        // P1 Cat on d7, P2 Elephant far away on a1 -> P1 plays d7->d8, P2 anything, P1 d8->d9!
        let pieces = [
            (Color::P1, PieceKind::Cat, sq("d7")),
            (Color::P2, PieceKind::Elephant, sq("a1")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(4));
        assert_eq!(res.best_move, mv("d7", "d8"));
        assert_eq!(res.score, SCORE_WIN - 3);
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_find_river_jump_capture() {
        // P1 Lion on d4 can jump left to a4 to capture P2 Tiger on a4 (worth 650)!
        let pieces = [
            (Color::P1, PieceKind::Lion, sq("d4")),
            (Color::P2, PieceKind::Tiger, sq("a4")),
            (Color::P2, PieceKind::Cat, sq("g9")),
        ];
        let (pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 5]);
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(4));
        assert_eq!(res.best_move, mv("d4", "a4"));
        assert_eq!(hist.len(), 1);
    }

    #[test]
    fn test_avoid_illegal_zero_ep_superko_trap() {
        // P1 Rat trapped near corner a1 with P2 Cat on b1 and P2 Dog on a3, P2 Wolf on b2:
        // Setup where P1 has 0 EP and repeating is illegal.
        // P1 Rat on a1 (can only move to a2), P2 Cat on b1, P2 Dog on b2, P2 Wolf on a3.
        // Ply 0: P1 plays a1->a2. Now P2 plays something that preserves the cage?
        // Simpler: P1 Cat on a1, P2 Wolf on b1, P2 Dog on b2, P2 Elephant on a3.
        // From a1, P1 Cat can ONLY move to a2!
        // Make that move once so a1 is in history, then put P2 Elephant on a3:
        // Wait: if P2 plays a3->a2, P2 captures Cat directly!
        // Instead, P2 has 0 EP and is in a1:
        // P2 Cat on a1 (cannot capture P1 Wolf on b1), P1 Dog on b2, P1 Lion on a3 (too far to capture a1? No, a3->a2 captures a2).
        // Make P2 piece a Rat on a1, P1 pieces: Dog on b1, Cat on b2, Elephant on a3 (Elephant CANNOT capture Rat!).
        // Ply 0 (P2): Rat a1 -> a2 (only legal move!).
        // Ply 1 (P1): P1 has 4 EP, plays any waiting move that leaves a1/b1/b2/a3 cage intact, e.g. P1 Tiger g1->g2.
        // Now P2 Rat is on a2 with 0 EP! Can P2 Rat go a2->a1? NO, that repeats a position if P1 returned,
        // wait: if P1 returned Tiger g2->g1? Let's just start with Tiger on g2, P1 moves g2->g1 after Rat moves a1->a2,
        // wait: at ply 0 Tiger is g1, Rat is a1.
        // Ply 0 (P1): g1->g2
        // Ply 1 (P2): a1->a2 (Rat's ONLY move, since b1 is Dog!)
        // Ply 2 (P1): g2->g1 -> board is (Rat a2, Tiger g1)
        // Wait: if P2 goes a2->a1, board becomes (Rat a1, Tiger g1) == Ply 0!
        // With P2 EP = 0, a2->a1 is ILLEGAL, so P2 has ZERO legal moves and LOSES IMMEDIATELY!
        // Note: P2 Rat is in P1's invasion rows (0..=3), so P2 gets +1 EP at start of P2's turn!
        // So put the cage in P2's OWN corner (g9) so P2 does NOT gain invasion EP!
        // P2 Rat on g9, P1 Dog on f9, P1 Cat on f8, P1 Elephant on g7 (cannot capture Rat!), P1 Tiger on a1.
        let pieces = [
            (Color::P2, PieceKind::Rat, sq("g9")),
            (Color::P1, PieceKind::Dog, sq("f9")),
            (Color::P1, PieceKind::Cat, sq("f8")),
            (Color::P1, PieceKind::Elephant, sq("g7")),
            (Color::P1, PieceKind::Tiger, sq("a1")),
        ];
        let (mut pos, mut hist) = BitboardPos::from_custom(&pieces, Color::P1, [4, 0]);
        // Ply 1: P1 plays a1->a2 (keeps P2 EP at 0 because P2 Rat is on row 8, not invasion rows 0..=3)
        pos = pos.make_move(mv("a1", "a2"), &mut hist);
        assert_eq!(pos.ep[1], 0);
        // Ply 2: P2 Rat's ONLY legal move is g9->g8 (f9 is Dog, g9 is corner)
        pos = pos.make_move(mv("g9", "g8"), &mut hist);

        // Now P1 to move! If P1 plays a2->a1, then P2 Rat at g8:
        // - f8 is P1 Cat (Rat can't capture Cat)
        // - g7 is P1 Elephant (Wait: Rat CAN capture Elephant!! Good thing we checked!)
        // Replace Elephant with Wolf on g7 (Rat can't capture Wolf, Wolf CAN capture Rat on g8!).
        // Better yet: P1 searches from here and should find a forced win!
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::depth(4));
        assert!(pos.gen_legal_moves(&hist).as_slice().contains(&res.best_move));
        assert_eq!(hist.len(), 3);
    }

    #[test]
    fn test_search_respects_node_limit_and_history_integrity() {
        let (pos, mut hist) = BitboardPos::new_start();
        let mut searcher = Searcher::with_tt_mb(4);
        let res = searcher.search(&pos, &mut hist, SearchLimits::nodes(5_000));
        assert!(pos.gen_legal_moves(&hist).as_slice().contains(&res.best_move));
        assert_eq!(hist.len(), 1);
    }
}

